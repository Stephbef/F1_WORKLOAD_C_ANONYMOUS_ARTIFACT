# F1 Workload C — server deployment and one-shot run

## Hardware (authoritative target server)
- x86_64, ≥ 8 dedicated CPUs for OTP (frozen envelope: cpuset of 8 CPUs, CPUQuota 800 %, MemoryMax 32G,
  -Xms24g -Xmx24g, -XX:ActiveProcessorCount=8, G1) plus CPUs for validator (2c/4g) and control plane; the frozen target
  fingerprint is the Xeon Silver 4314 class host; physical L28 must report EXECUTED_ON_TARGET / PASS.
- RAM ≥ 64 GiB recommended (OTP 32G scope + validator + control plane).
- Disk: ≥ 2 TiB free on the work-root filesystem (`conservative_disk_required_bytes`, checked before any execution).
- Root (or equivalent capability) is REQUIRED for the frozen cold-state secondary (`/proc/sys/vm/drop_caches`) and for
  systemd/cgroup scopes used by L28; without it the campaign SAFE-STOPs (never approximated).

## OS / runtime
Linux with cgroup v2 + systemd (cgroup v1 supported by the frozen resource manager), Python 3.12, NumPy 2.4.4,
PyYAML 6.0.3, OpenJDK 25.0.4.1, osmium-tool 1.16.0, faketime 0.9.10; pinned jars OTP 2.10.0 and gtfs-validator 8.0.1
(SHA-256 in configs/workload_c/pinned_dependencies.json). Egress to https://api.mobilitydatabase.org and
https://download.geofabrik.de (the frozen OSM rule, docs/oneshot/provenance/V3_05_OSM_OSMIUM_PIN_MANIFEST.md).

## Steps
1. Copy `F1_WORKLOAD_C_ONE_SHOT_SERVER_CAMPAIGN_FINAL.zip` to the server; `unzip` it; `cd F1_WORKLOAD_C_ONE_SHOT_SERVER_CAMPAIGN_FINAL`;
   `sha256sum -c SHA256SUMS.txt`.
2. `./install_server_dependencies.sh` (detects, installs only exact pins, verifies; prints what needs root).
3. Token: `install -m 600 /dev/stdin /secure/path/mobility_token` and paste the Mobility Database refresh token
   (never on the command line, never in the repository).
4. Optional: `./run_f1_workload_c_campaign.sh --dry-run --work-root /data/f1_workload_c` and
   `./run_f1_workload_c_campaign.sh --preflight-only --mobility-token-file /secure/path/mobility_token --work-root /data/f1_workload_c`
   (L28, dependencies, network, secret presence, disk; no study data).
5. ONE command:
   `./run_f1_workload_c_campaign.sh --mobility-token-file /secure/path/mobility_token --work-root /data/f1_workload_c`
   Run it inside `tmux`/`screen`. Progress lines `[01/18] … [18/18]`; no scientific interpretation is printed.
6. Status (read-only, any time): `./campaign_status.sh /data/f1_workload_c`.
7. After an SSH drop / reboot / interruption:
   `./run_f1_workload_c_campaign.sh --resume --mobility-token-file /secure/path/mobility_token --work-root /data/f1_workload_c`
   (re-verifies every sealed digest and the source identity; refuses if anything changed).

## Outcomes
- SUCCESS: `/data/f1_workload_c/output/F1_WORKLOAD_C_REAL_CAMPAIGN_RESULTS_FINAL.zip` (+ `.sha256`).
- SAFE STOP: `/data/f1_workload_c/output/F1_WORKLOAD_C_CAMPAIGN_SAFE_STOP_<STAGE>.zip` — return it for independent
  review. Never patch and continue: a corrected campaign restarts with `--new-campaign` on a NEW work-root.

## Frozen decisions embedded (no runtime choice)
AMENDMENT-ONESHOT-ROUTER-SEMCONFIG-01 (fixed service bounds 2024-04-01..2029-06-30 for every OTP build); V3 OSM rule;
physical cache-state protocol (complete common input corpus pre-read per request, counterbalanced arm order; cold
secondary with page-cache drop); N4 τ* = lexicographic argmin (U_τ, C_τ, τ) over {1,6,24,72,168} h on VALIDATION only;
automatic TEST authorization only when audit conditions A–S hold (integrity only, never performance).
Expected compute: the frozen design (daily consumer ticks over 2025-04-01..2026-06-30, N0 full cold rebuild at every
tick, five N4 arms in VALIDATION) can take days to weeks; nothing is reduced for runtime.
