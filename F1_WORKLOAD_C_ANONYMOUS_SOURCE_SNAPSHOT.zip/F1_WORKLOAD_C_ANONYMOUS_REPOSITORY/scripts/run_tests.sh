#!/usr/bin/env bash
# Session-2 complete test run (every step actually executes; nothing is reused from earlier runs):
#   1. Session-1 regression (S1-01..S1-30)                      -> reports/s1/S1_GATE_LEDGER.{csv,md}
#   2. frozen conformance through the S2 producer path (REAL)   -> reports/conformance/   (oracle 35, D1-D10+DF, C1-C8)
#   3. L28 runner: authoritative attempt + sandbox rehearsal    -> reports/l28/
#   4. Session-2 suite (S2-01..S2-50)                            -> reports/S2_GATE_LEDGER.{csv,md}
#   5. core reference regression (reused f1 modules), if its deps are installed
set -uo pipefail
cd "$(dirname "$0")/.." || exit 2
PY="${PYTHON:-python3}"
OUT="${F1_WC_REPORT_DIR:-$PWD/reports}"
mkdir -p "$OUT"
export PYTHONPATH="$PWD/src" F1_WC_REPORT_DIR="$OUT" F1_WC_CONFORMANCE_DIR="$OUT/conformance" F1_WC_L28_DIR="$OUT/l28"
rc=0
step(){ echo "== $(date -u +%FT%TZ) $*"; }
step "1/5 Session-1 regression";      bash scripts/run_s1_regression.sh || rc=1
step "2/5 frozen conformance (REAL)"; bash scripts/run_oracle_conformance.sh all > "$OUT/conformance.log" 2>&1 || rc=1; tail -20 "$OUT/conformance.log"
step "3/5 L28 runner";                bash scripts/run_l28_fixture.sh > "$OUT/l28.log" 2>&1 || rc=1; cat "$OUT/l28.log"
step "4/5 Session-2 suite"
F1_WC_GATE_REPORT="$OUT/s2_gate_report.json" "$PY" -m pytest tests/workload_c/test_s2_*.py tests/workload_c/test_s1_corrections.py \
  tests/workload_c/test_s1_01_imports.py --confcutdir=tests/workload_c -o addopts="" -q -rA \
  --junitxml="$OUT/s2_junit.xml" > "$OUT/s2_pytest.log" 2>&1 || rc=1
tail -3 "$OUT/s2_pytest.log"
"$PY" scripts/gate_ledger.py "$OUT/s2_gate_report.json" "$OUT" --gates S2 || rc=1
step "4b PRE-S3 closure suite"
F1_WC_GATE_REPORT="$OUT/p3_gate_report.json" "$PY" -m pytest tests/workload_c/test_pre_s3_closure.py tests/workload_c/test_pre_s3_v11_interfaces.py tests/workload_c/test_pre_s3_v12_freeze.py --confcutdir=tests/workload_c \
  -o addopts="" -q -rA --junitxml="$OUT/p3_junit.xml" > "$OUT/p3_pytest.log" 2>&1 || rc=1
tail -3 "$OUT/p3_pytest.log"
"$PY" scripts/gate_ledger.py "$OUT/p3_gate_report.json" "$OUT" --gates P3 || rc=1
step "4c Session-3/3.1 suite (S3-01..S3-66; S3-50 is the package-verification command at packaging time)"
F1_WC_GATE_REPORT="$OUT/s3_gate_report.json" "$PY" -m pytest tests/workload_c/test_s3_engines.py tests/workload_c/test_s3_campaign.py \
  tests/workload_c/test_s3_1_corrections.py \
  --confcutdir=tests/workload_c -o addopts="" -q -rA --junitxml="$OUT/s3_junit.xml" > "$OUT/s3_pytest.log" 2>&1 || rc=1
tail -3 "$OUT/s3_pytest.log"
"$PY" scripts/gate_ledger.py "$OUT/s3_gate_report.json" "$OUT" --gates S3 --pending S3-50 || rc=1
step "4d Session-4A.1 baseline suite (S4A1-01..S4A1-25)"
F1_WC_GATE_REPORT="$OUT/s4a1_gate_report.json" "$PY" -m pytest tests/workload_c/test_s4a1_baselines.py \
  --confcutdir=tests/workload_c -o addopts="" -q -rA --junitxml="$OUT/s4a1_junit.xml" > "$OUT/s4a1_pytest.log" 2>&1 || rc=1
tail -3 "$OUT/s4a1_pytest.log"
"$PY" scripts/gate_ledger.py "$OUT/s4a1_gate_report.json" "$OUT" --gates S4A1 || rc=1
step "4e One-shot server campaign suite (OSC-01..OSC-55; fixture backend, no real execution)"
F1_WC_REPORT_DIR="$OUT" F1_WC_GATE_REPORT="$OUT/osc_gate_report.json" "$PY" -m pytest tests/workload_c/test_oneshot_campaign.py \
  --confcutdir=tests/workload_c -o addopts="" -p no:cacheprovider -q -rA --junitxml="$OUT/osc_junit.xml" > "$OUT/osc_pytest.log" 2>&1 || rc=1
tail -3 "$OUT/osc_pytest.log"
"$PY" scripts/gate_ledger_osc.py "$OUT/osc_gate_report.json" "$OUT" || rc=1
find /tmp -maxdepth 1 -name 'osc-*' -exec rm -rf {} +
step "5/5 core reference regression"
if "$PY" -c "import numpy, pyarrow, matplotlib" 2>/dev/null; then
  "$PY" -m pytest tests/unit tests/property tests/regression -o addopts="" -q > "$OUT/core_regression.log" 2>&1 || rc=1
  tail -1 "$OUT/core_regression.log"
else
  echo "core regression: NOT RUN (numpy/pyarrow/matplotlib absent; optional, not a gate)" | tee "$OUT/core_regression.log"
fi
echo "RUN_TESTS_RC=$rc"
exit "$rc"
