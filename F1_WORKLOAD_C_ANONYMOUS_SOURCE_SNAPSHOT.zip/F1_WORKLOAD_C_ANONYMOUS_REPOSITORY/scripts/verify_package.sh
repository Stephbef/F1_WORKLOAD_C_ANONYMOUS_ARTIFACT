#!/usr/bin/env bash
# Verify a Session-1 package directory: SHA256SUMS.txt, source manifest, frozen specs, and a secret scan.
set -euo pipefail
cd "$(dirname "$0")/.."
PY="${PYTHON:-python3}"
fail=0
check() {  # check <manifest> <dir>
  if (cd "$2" && sha256sum -c --quiet "$(basename "$1")"); then
    echo "$1: $(wc -l < "$1") entries OK"
  else
    echo "$1: MISMATCH"; fail=1
  fi
}
[ -f SHA256SUMS.txt ] && check SHA256SUMS.txt .
[ -f SOURCE_MANIFEST_SHA256.txt ] && check SOURCE_MANIFEST_SHA256.txt .
check frozen_specs/FROZEN_SPECS_SHA256.txt frozen_specs
if ! PYTHONPATH="$PWD/src" "$PY" -m f1.workload_c.campaign.cli verify-frozen >/dev/null; then
  echo "frozen spec loader: FAIL"; fail=1
fi
if PYTHONPATH="$PWD/src" "$PY" -m f1.workload_c.campaign.cli secret-scan src scripts fixtures tests configs frozen_specs docs >/dev/null; then
  echo "secret scan: clean"
else
  echo "secret scan: FINDINGS"; fail=1
fi
exit "$fail"
