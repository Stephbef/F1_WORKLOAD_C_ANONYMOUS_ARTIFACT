#!/usr/bin/env bash
# Session-2 deterministic fixture E2E (history -> schedule -> producers -> Canon -> K0..K3 -> catalog -> ledger),
# run twice and checked for identical semantic digests; then secret-scanned. ENGINEERING FIXTURE ONLY.
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD/src"
PY="${PYTHON:-python3}"
OUT="$(realpath -m "${1:-outputs/workload_c_fixture_s2}")"   # producers run in per-job cwd: paths must be absolute
MODE="${F1_WC_E2E_MODE:-auto}"
echo "*** ENGINEERING FIXTURE ONLY — NOT SCIENTIFIC RESULTS ***"
"$PY" -m f1.workload_c.campaign.cli fixture-s2 --out "$OUT/run1" --mode "$MODE" > "$OUT.run1.json"
"$PY" -m f1.workload_c.campaign.cli fixture-s2 --out "$OUT/run2" --mode "$MODE" > "$OUT.run2.json"
"$PY" - "$OUT" <<'PY'
# Determinism check across the two runs. OTP's graph.obj serialization is not byte-reproducible across rebuilds
# (Canon_D is the semantic identity; graph_sha256 identifies one build instance only), so graph-instance digests are
# excluded; schedule, Canon digests, contract footprints (minus graph_sha256), evaluations and outcomes must be equal.
import json, sys
o = sys.argv[1]
def load(r):
    s = json.load(open(f"{o}/{r}/E2E_SUMMARY.json"))
    cs = []
    for ln in open(f"{o}/{r}/contracts.jsonl"):
        c = json.loads(ln); c["footprint"].pop("graph_sha256", None); cs.append(c)
    return {"schedule": open(f"{o}/{r}/schedule.json").read(), "evals": open(f"{o}/{r}/evaluations.jsonl").read(),
            "contracts": cs, "outcomes": s["outcomes"], "k3": s["k3"], "invariants_ok": s["invariants_ok"],
            "mode": s["binary_mode"], "counts": [s["n_artifacts"], s["n_contracts"], s["n_evaluations"]]}
a, b = load("run1"), load("run2")
det = {k: a[k] == b[k] for k in ("schedule", "evals", "contracts", "outcomes", "k3", "counts")}
ok = a["invariants_ok"] and b["invariants_ok"] and all(det.values())
print(json.dumps({"binary_mode": a["mode"], "invariants_ok": a["invariants_ok"] and b["invariants_ok"],
                  "deterministic_components": det, "k3": a["k3"], "counts": a["counts"]}))
sys.exit(0 if ok else 1)
PY
"$PY" -m f1.workload_c.campaign.cli secret-scan "$OUT"
