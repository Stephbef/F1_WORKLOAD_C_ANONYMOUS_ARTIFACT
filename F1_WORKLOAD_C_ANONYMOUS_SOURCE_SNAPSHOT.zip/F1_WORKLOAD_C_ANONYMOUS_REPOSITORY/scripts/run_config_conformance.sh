#!/usr/bin/env bash
# Frozen semantic-config C1-C8 suite through the integrated semantic-config digest (no binaries needed).
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${F1_WC_CONFORMANCE_DIR:-$PWD/reports/conformance}"
PYTHONPATH="$PWD/src" exec "${PYTHON:-python3}" -m f1.workload_c.campaign.cli conformance --suite config --mode stub --out "$OUT"
