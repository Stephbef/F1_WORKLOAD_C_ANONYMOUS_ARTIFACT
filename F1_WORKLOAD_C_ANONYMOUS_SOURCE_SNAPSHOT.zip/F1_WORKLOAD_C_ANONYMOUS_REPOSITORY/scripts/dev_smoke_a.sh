#!/usr/bin/env bash
# Engineering smoke of workload A on development repositories (never part of the scientific set).
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD/src"
PY=${PYTHON:-python3}
[ -x tools/cargo-audit ] || bash scripts/fetch_tools.sh
[ -f work/dev_a/repos_manifest_dev.json ] || $PY scripts/make_dev_manifest.py --config configs/dev_workload_a.yaml sharkdp/hexyl sharkdp/pastel
rm -rf work/dev_a/outputs
$PY -m f1 freeze --config configs/dev_workload_a.yaml --force
$PY -m f1 full --config configs/dev_workload_a.yaml
