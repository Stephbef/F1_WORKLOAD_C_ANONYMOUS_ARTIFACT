#!/usr/bin/env python3
# ruff: noqa: E501
"""Build the S1-01…S1-30 gate ledger from the pytest gate report. A gate PASSES iff >= 1 mapped test executed
and every mapped test PASSED (no SKIP counts as PASS). Usage: gate_ledger.py REPORT.json OUT_DIR"""
import csv
import json
import sys
from pathlib import Path

GATES = [ln.split(",", 1) for ln in """S1-01,source package imports/builds
S1-02,frozen config validation
S1-03,content-addressed storage
S1-04,corruption/partial-write detection
S1-05,Mobility mock pagination
S1-06,Mobility 401/403 classification
S1-07,Mobility 429 bounded retry
S1-08,secret/token redaction
S1-09,GTFS canonical content hash
S1-10,"logical A,A collapse"
S1-11,"logical A,B"
S1-12,"logical A,B,A recurrence"
S1-13,license engine all classes
S1-14,dedup/mirror/bundle rules
S1-15,spatial/connectivity primitives
S1-16,region construction
S1-17,eligibility engine
S1-18,deterministic first-24 selection
S1-19,deterministic 8/16 split
S1-20,input-permutation invariance
S1-21,FIXTURE/VALIDATION/TEST isolation
S1-22,unauthorized TEST execution guard
S1-23,append-only structured log
S1-24,run-state transition rules
S1-25,checkpoint/restart
S1-26,incompatible-resume refusal
S1-27,hard-gate stop semantics
S1-28,phase failure injection
S1-29,fixture population >24 eligible with controlled exclusions
S1-30,complete Phase00→Phase18 fixture orchestration""".splitlines()]


GATES_S2 = [ln.split(",", 1) for ln in """S2-01,Session-1 integrity verified
S2-02,S1 correction gate
S2-03,S1-01..S1-30 rerun
S2-04,INT-01..INT-10 audited
S2-05,INT-06 agency_id correction
S2-06,INT-04 stop/platform correction
S2-07,pinned dependency schema
S2-08,dependency hash mismatch refusal
S2-09,validator command construction
S2-10,validator provenance
S2-11,validator semantic fixture
S2-12,validator infra/error classification
S2-13,OTP command construction
S2-14,OTP historical-date resolution
S2-15,OTP wall-clock independence
S2-16,OTP provenance
S2-17,resource manager capability detection
S2-18,cgroup-v2 fixture/backend tests
S2-19,cgroup-v1 fixture/backend tests
S2-20,systemd capability handling
S2-21,taskset-only rejection
S2-22,in-scope resource proof
S2-23,L28 orchestration test
S2-24,Canon integration
S2-25,full frozen oracle suite
S2-26,semantic-config digest suite
S2-27,K0 generation
S2-28,K1 generation
S2-29,K2 generation
S2-30,K3/reference path
S2-31,deterministic contract bytes
S2-32,contract error fail-closed
S2-33,K2<->Canon alignment
S2-34,history partial-order model
S2-35,cut consistency
S2-36,artifact catalog immutability
S2-37,request-slot vs derivation-instance
S2-38,rederive identity semantics
S2-39,validator scheduler
S2-40,OTP scheduler
S2-41,consumer scheduler
S2-42,DST tests
S2-43,overlapping producer tests
S2-44,deterministic event-ledger replay
S2-45,failure classification
S2-46,producer provenance
S2-47,Session-1 orchestrator integration
S2-48,fixture producer->Canon->contracts E2E
S2-49,REAL mode remains scientifically disabled
S2-50,no real study data accessed""".splitlines()]


GATES_P3 = [ln.split(",", 1) for ln in """P3-01,PRE-S3 input identity recorded and consistent
P3-02,interpretation register frozen and internally consistent
P3-03,licence identifier table audited and frozen
P3-04,SCH-01 frozen in register and scheduler
P3-05,INT-02 boundary gaps frozen behaviour
P3-06,INT-06 equal-cardinality keeps both
P3-07,no stale unresolved claims in current documentation
P3-08,validation/TEST firewall machine checks
P3-09,Session-3 gate ledger frozen and well-formed
P3-10,Session-3 V1.1 interfaces frozen (no Session-3 algorithm implemented)
P3-11,no study data or scientific result in the repository
P3-12,frozen digests recorded and matching
P3-13,joint ConsumerRequest and slot-set OPT
P3-14,joint witness and negative cases
P3-15,AdmissionDecision action/mode and typed repair plan
P3-16,sanitized N5 view
P3-17,N1 non-interference
P3-18,CostModel explicit t and no future-cost leakage
P3-19,firewall completion (restart / semantic-preservation evidence)
P3-20,replay/export representability
P3-21,est(s t) ordinary arithmetic median convention
P3-22,serial canonical fail-fast repair execution
P3-23,request parity vs method-specific overlay binding
P3-24,N1 own native costs and one-time preprocessing
P3-25,inference determinism (region clusters B seeds RNG sign test)
P3-26,V1.2 gates prompt and interface version frozen""".splitlines()]


GATES_S3 = [ln.split(",", 1) for ln in """S3-01,PRE-S3 input package integrity verified (SHA256SUMS; source manifest; bundle HEAD = recorded PRE-S3 commit)
S3-02,PRE-S3 decision register unchanged (spec_interpretations.json SHA-256 = PRE-S3 record; PI_CONFIRMED)
S3-03,licence identifier table unchanged (SHA-256 = PRE-S3 record; PI_CONFIRMED)
S3-04,SCH-01 frozen policy last_successful_build used on every scientific path
S3-05,S1-01..S1-30 rerun PASS
S3-06,S2-01..S2-50 rerun PASS
S3-07,all PRE-S3 closure gates rerun PASS: P3-01..P3-26 (includes every V1.1 gate P3-01..P3-20 and the V1.2 gates P3-21..P3-26)
S3-08,Gamma admissible cuts per spec17 §5 (available <= t; service on every date of [t;t+6]; <= 2 superseding versions) incl. sensitivities
S3-09,WitnessSearch deterministic and input-permutation invariant
S3-10,no future-cut witness: every witness version available <= tick and every artifact completed <= tick (negative tests)
S3-11,fixed-R enforced: cross-slot substitution rejected; only designated-slot instances considered
S3-12,JointWitness provenance complete: one WitnessBinding per slot (artifact; contracts; all EvaluationResults at the witness cut; catalog-entry digest; birth context; provenance digest; TemporalEvidence) + GammaEvidence
S3-13,K3 never usable as an ordinary admission contract (rejected)
S3-14,admission decision order exactly as frozen (current -> historical witness -> repair -> no-artifact); action/mode representation per V1.1
S3-15,historical repair deterministic; OPT_hist vs OPT_current with frozen decision-time cost estimates; tie -> current
S3-16,rederive(r;c) creates a new instance of the same slot; no synthetic historical state; no future information
S3-17,A->B->A remain distinct state events in witness/repair; recurrence valid only through realized states
S3-18,CostModel deterministic given the frozen ledger
S3-19,cost-accounting symmetry and measurement parity: F1/N5 share the est(s;t) ledger; measurement rules and envelopes and are charged their own executions; N1 uses identical measurement methodology and the authoritative OTP envelope but is charged its OWN measured native executions
S3-20,control-plane costs (evaluation; witness search; solver; catalog lookup) charged to the method that incurs them
S3-21,failed producer attempts accounted; no work disappears
S3-22,offline analysis/replay cost excluded from online cost
S3-23,N5 history non-interference: N5 receives only CurrentCutView (= RequestBinding of sanitized BoundArtifacts); sentinel history/catalog/witness-index objects raise if touched
S3-24,N5 current-cut parity: identical contracts; evaluator and verdicts as F1 at the current cut
S3-25,N5 receives no F1 witnesses; historical summaries or cache hints (construction + runtime spies)
S3-26,N1 native --loadStreet + cache.enabled active; cache persisted across eligible builds; instrumentation recorded
S3-27,N1 resource envelope identical to F1 router production (same envelope digest)
S3-28,N1 has no historical witness mechanism
S3-29,N1 executed with the real pinned OTP on non-study fixtures (or BLOCKED with exact reason)
S3-30,replay deterministic; reproduces every decision from the sealed ledger
S3-31,replay never consults future events and never mutates the source ledger
S3-32,mutation sample deterministic: ids sorted; ranked with the mutation seed; top ceil(5%·n)
S3-33,mutation families exactly as frozen; invalid mutations fail closed
S3-34,mutation detection semantics on fixtures (mutant contract admits where Canon differs -> missing dependence detected)
S3-35,raw export complete (all frozen fields)
S3-36,raw export append-only and provenance-linked
S3-37,every aggregate recomputed from the raw export alone
S3-38,frozen analysis: unit; influence period; denominators; missing/failure/inconclusive rules exactly as frozen
S3-39,frozen analysis deterministic (seeded exact sign test; BCa B=9;999; wild-cluster Rademacher)
S3-40,Holm family exactly {H_witness(K0); H_repair(K0); H_hist(K2); H_native(K2)}
S3-41,namespace firewall: FIXTURE free; VALIDATION only under gate; TEST inaccessible
S3-42,change-class firewall (E1/E2/S1/R1) enforced
S3-43,no scientific result emitted (fixture marker on every output; no TEST data)
S3-44,no secret emitted (secret scan of all outputs)
S3-45,no live campaign: --real still refuses; no study API contacted
S3-46,orchestrator Phases 11-16 use real Session-3 engines in FIXTURE mode; Phase 00->18 COMPLETE
S3-47,fixture E2E with F1/N5/N1 reproduces identifiability traces T1-T4 (non-study)
S3-48,mandatory negative-test battery (08/10/11/13 specs) all PASS
S3-49,static analysis clean (ruff; mypy; shellcheck)
S3-50,Session-3 package integrity and Session-4 handoff verified
S3-51,V1.2 interface file src/f1/workload_c/interfaces/session3.py (F1-WC-S3-INTERFACES-V1.2) SHA-256 unchanged through Session 3 (equals PRE_S3_FROZEN_DIGESTS.json) unless a formal pre-implementation amendment exists
S3-52,exact est(s;t) median convention incl. even-n arithmetic median; reproduces V1_2_REFERENCE_VECTORS.json est cases
S3-53,multi-slot repair: canonical serial order; exact target cut; t information boundary; fail-fast; attempted-work charging; reproduces repair_execution vectors
S3-54,method-specific overlay isolation and binding-rule parity (identical ConsumerRequest; each method binds shared + own overlay; N5 invariant to F1 overlay); reproduces binding vector
S3-55,N1 native cost observations are N1's own measured executions; distinct from the F1/N5 est ledger; with identical measurement/envelope rules; one-time preprocessing charged once per region
S3-56,BCa and wild bootstrap use region as cluster with B = 9;999; frozen seeds; PCG64/numpy 2.4.4 and the frozen formulas; exact sign test; reproduces inference vectors
S3-57,paired OPERATIONAL_CAP exclusion applies to HSR / repair / DeltaCost / H_hist / H_native
S3-58,regions with zero eligible paired cells give an undefined contrast; a measured zero stays a defined zero
S3-59,one-time N1 preprocessing survives per-tick exclusions and is charged exactly once per participating region
S3-60,catalog_lookup and online journal/fsync B costs measured and emitted without nested double counting
S3-61,real producer CPU seconds survive producer -> cost record -> raw export -> replay
S3-62,mutation subjects use Canon_D reference verdicts and input mutations measure Canon_D
S3-63,validator_date and validator_file mutation subjects are distinct and valid
S3-64,actual RealizedHistory journal populated / sealed / used for consistency checks
S3-65,ReplayItem source_event_ids are sealed history event ids; every SealedLedger digest verified
S3-66,DeltaCost per-unit mean and exact-binomial prevalence produced deterministically""".splitlines()]


GATES_S4A1 = [ln.split(",", 1) for ln in """S4A1-01,input S3.1 identity verified
S4A1-02,blocked-report identity verified
S4A1-03,amendment created before validation
S4A1-04,router conflict resolved exactly as directive
S4A1-05,N0 semantics frozen
S4A1-06,N2 semantics frozen
S4A1-07,N3 semantics frozen
S4A1-08,N4 semantics frozen
S4A1-09,N4 selection rule frozen before outputs
S4A1-10,N6 semantics frozen
S4A1-11,capability matrix complete
S4A1-12,N0 implementation conforms
S4A1-13,N2 implementation conforms
S4A1-14,N3 implementation conforms
S4A1-15,N4 implementation conforms
S4A1-16,N6 implementation conforms
S4A1-17,A->B->A N3 behavior correct
S4A1-18,TTL boundary exact
S4A1-19,N6 date omission deliberate and tested
S4A1-20,no baseline history leakage
S4A1-21,N4 selection oracle tests PASS
S4A1-22,no VALIDATION accessed before refreeze
S4A1-23,no TEST outcome accessed
S4A1-24,complete baseline regression PASS
S4A1-25,amended semantic freeze complete
S4A1-26,VAL N3 pin uses actual producer validation date (not ARTIFACT_BORN date)
S4A1-27,cross-local-midnight validator completion preserves the original validation date in the N3 pin
S4A1-28,n3_pin_index control-plane timing non-overlapping and charged exactly once
S4A1-29,N3 pin/index creation-update and lookup costs represented without double counting
S4A1-30,baseline view construction charges only metadata actually required by the method
S4A1-31,N6 cache access exact-key restricted and invariant to unrelated historical artifacts
S4A1-32,A->B->A fixture gate proves event-identity non-resurrection with no vacuous assertion
S4A1-33,the three PI-confirmed baseline applications frozen (no longer awaiting confirmation)""".splitlines()]


def main(report: str, out_dir: str, which: str = "S1", pending: tuple = ()) -> int:
    gates = {"S1": GATES, "S2": GATES_S2, "P3": GATES_P3, "S3": GATES_S3, "S4A1": GATES_S4A1}[which]
    rep = json.loads(Path(report).read_text())
    by = {g: [] for g, _ in gates}
    for r in rep["results"]:
        for g in r["gates"]:
            by.setdefault(g, []).append(r)
    rows = []
    for g, desc in gates:
        desc = desc.strip('"')
        rs = by[g]
        n_pass = sum(r["status"] == "PASSED" for r in rs)
        status = "PASS" if rs and n_pass == len(rs) else ("NOT_EXECUTED" if not rs else "FAIL")
        if status == "NOT_EXECUTED" and g in pending:
            status = "PENDING"                      # preregistered lifecycle-stage gate (e.g. S3-50 at packaging)
        rows.append({"gate": g, "requirement": desc, "status": status, "tests_executed": len(rs),
                     "tests_passed": n_pass, "tests_failed": sum(r["status"] == "FAILED" for r in rs),
                     "tests_skipped": sum(r["status"] == "SKIPPED" for r in rs),
                     "evidence": " | ".join(sorted({r["nodeid"].split("::")[0].split("/")[-1] for r in rs}))})
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    with open(out / f"{which}_GATE_LEDGER.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator="\n")
        w.writeheader()
        w.writerows(rows)
    md = ["| Gate | Requirement | Status | Tests (pass/run) | Evidence |", "|---|---|---|---|---|"]
    md += [f"| {r['gate']} | {r['requirement']} | **{r['status']}** | {r['tests_passed']}/{r['tests_executed']} | "
           f"{r['evidence']} |" for r in rows]
    (out / f"{which}_GATE_LEDGER.md").write_text("\n".join(md) + "\n")
    n_ok = sum(r["status"] == "PASS" for r in rows)
    print(f"{which} gates PASS: {n_ok}/{len(rows)}")
    n_pending = sum(r["status"] == "PENDING" for r in rows)
    return 0 if n_ok + n_pending == len(rows) else 1


if __name__ == "__main__":
    which = sys.argv[sys.argv.index("--gates") + 1] if "--gates" in sys.argv else "S1"
    pend = tuple(sys.argv[sys.argv.index("--pending") + 1].split(",")) if "--pending" in sys.argv else ()
    sys.exit(main(sys.argv[1], sys.argv[2], which, pend))
