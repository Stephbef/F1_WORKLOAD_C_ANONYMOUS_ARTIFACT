#!/usr/bin/env bash
# Fetch pinned jar artifacts into $F1_WC_DEPS_DIR (default <repo>/.deps): download -> verify exact SHA-256 ->
# atomic rename. A digest mismatch deletes the download and exits 1 (no fallback, no 'latest').
# F1_WC_DEPS_MIRROR=<dir>: use a local directory instead of the network (still digest-verified).
# Tools (JDK 25.0.4.1, osmium 1.16.0, faketime 0.9.10) are host-provisioned; their exact versions are printed and
# checked by scripts/verify_pinned_dependencies.sh.
set -euo pipefail
cd "$(dirname "$0")/.."
DEST="${F1_WC_DEPS_DIR:-$PWD/.deps}"
mkdir -p "$DEST"
PY="${PYTHON:-python3}"
rc=0
while IFS=$'\t' read -r name file url sha; do
  if [ -f "$DEST/$file" ] && [ "$(sha256sum "$DEST/$file" | cut -c1-64)" = "$sha" ]; then
    echo "OK (cached)  $name $file"; continue
  fi
  tmp="$DEST/.tmp-$file.$$"
  if [ -n "${F1_WC_DEPS_MIRROR:-}" ] && [ -f "$F1_WC_DEPS_MIRROR/$file" ]; then
    cp "$F1_WC_DEPS_MIRROR/$file" "$tmp"
  else
    curl -fsSL --retry 3 --max-time 1800 -o "$tmp" "$url"
  fi
  got="$(sha256sum "$tmp" | cut -c1-64)"
  if [ "$got" != "$sha" ]; then
    rm -f "$tmp"; echo "DIGEST_MISMATCH $name: expected $sha got $got" >&2; rc=1; continue
  fi
  sync "$tmp" 2>/dev/null || true
  mv -f "$tmp" "$DEST/$file"; chmod 0444 "$DEST/$file"
  echo "FETCHED      $name $file $sha"
done < <("$PY" -c "
import json,sys
m=json.load(open('configs/workload_c/pinned_dependencies.json'))
for a in m['artifacts']: print('\t'.join([a['name'],a['file'],a['source'],a['sha256']]))")
"$PY" -c "
import json
m=json.load(open('configs/workload_c/pinned_dependencies.json'))
for t in m['tools']: print('HOST TOOL REQUIRED:', t['name'], t['version'], '--', t['provision'])"
exit "$rc"
