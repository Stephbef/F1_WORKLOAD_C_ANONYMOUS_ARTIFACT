#!/usr/bin/env bash
# Authoritative one-shot entry point. Session 1: --fixture-mode runs Phase 00 -> 18 (real S1 engines + deterministic
# mocks); --real refuses with REAL_MODE_NOT_YET_IMPLEMENTATION_COMPLETE.
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD/src"
exec "${PYTHON:-python3}" -m f1.workload_c.campaign.cli run "$@"
