#!/usr/bin/env bash
# Fetch the pinned, statically linked (musl) cargo-audit and verify its sha256.
set -euo pipefail
cd "$(dirname "$0")/.."
VER=0.22.2
SHA=66f9c8f530950d106c1869ce27ef5a4008bcea53c7716c3ed8117586337ee7d8
URL="https://github.com/rustsec/rustsec/releases/download/cargo-audit%2Fv${VER}/cargo-audit-x86_64-unknown-linux-musl-v${VER}.tgz"
mkdir -p tools
if [ -x tools/cargo-audit ] && echo "${SHA}  tools/cargo-audit" | sha256sum -c --status; then
  echo "cargo-audit ${VER} already present and verified"; exit 0
fi
tmp=$(mktemp -d)
curl -fsSL -o "$tmp/ca.tgz" "$URL"
tar -xzf "$tmp/ca.tgz" -C "$tmp"
install -m 0755 "$(find "$tmp" -name cargo-audit -type f | head -1)" tools/cargo-audit
rm -rf "$tmp"
echo "${SHA}  tools/cargo-audit" | sha256sum -c
tools/cargo-audit --version
