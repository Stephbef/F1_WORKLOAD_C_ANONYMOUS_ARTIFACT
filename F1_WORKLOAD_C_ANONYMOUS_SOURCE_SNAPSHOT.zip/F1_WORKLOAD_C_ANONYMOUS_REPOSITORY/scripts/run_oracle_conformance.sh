#!/usr/bin/env bash
# Frozen oracle (35) + determinism (D1-D10, DF) + config (C1-C8) suites through the Session-2 producer code path
# with REAL_PINNED_BINARY (OTP 2.10.0 / JDK 25.0.4.1). Exit 0 only if every suite passes (BLOCKED allowed only for
# determinism variants the host cannot provide). Output: ${F1_WC_CONFORMANCE_DIR:-reports/conformance}.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${F1_WC_CONFORMANCE_DIR:-$PWD/reports/conformance}"
WORK="${F1_WC_CONFORMANCE_WORK:-$(mktemp -d -t f1wc-conf-XXXXXX)}"
SUITE="${1:-all}"
PYTHONPATH="$PWD/src" exec "${PYTHON:-python3}" -m f1.workload_c.campaign.cli conformance --suite "$SUITE" --mode real \
  --out "$OUT" --work "$WORK"
