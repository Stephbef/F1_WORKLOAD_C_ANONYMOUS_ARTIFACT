#!/usr/bin/env python3
"""Read-only re-run of the automatic pre-TEST audit for a campaign: python3 scripts/automatic_pretest_audit.py WORK_ROOT
(the launcher itself runs the audit at stage S14; this tool only re-computes and prints it)."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from f1.workload_c.oneshot.audit import automatic_pretest_audit  # noqa: E402
from f1.workload_c.oneshot.core import Campaign, Journal  # noqa: E402


def main(argv):
    wr = Path(argv[0]).resolve()
    ident = json.loads((wr / "CAMPAIGN_ID.json").read_text())
    if ident["mode"] == "FIXTURE":
        from f1.workload_c.oneshot.fixture_backend import FixtureBackend as B
        be = B()
    else:
        from f1.workload_c.oneshot.real_backend import RealBackend
        be = RealBackend(None)
    c = Campaign(wr, ident, Journal(wr / "journal" / "campaign.jsonl"), be)
    print(json.dumps(automatic_pretest_audit(c), indent=1, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
