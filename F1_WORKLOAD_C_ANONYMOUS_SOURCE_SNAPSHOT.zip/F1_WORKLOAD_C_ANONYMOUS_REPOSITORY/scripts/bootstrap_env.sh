#!/usr/bin/env bash
# Build an ISOLATED research environment without modifying the host system, in order of preference:
#   1. Docker/Podman image (environment/Dockerfile)   2. Apptainer image (environment/f1.def)
#   3. micromamba env (Python 3.12, conda-forge)       4. venv (Python >= 3.11) with locked top-level versions
# If already running inside the container (F1_CONTAINER_IMAGE set) only the venv/packages check is done.
set -uo pipefail
cd "$(dirname "$0")/.."
log(){ echo "[bootstrap] $*"; }
if [ -n "${F1_CONTAINER_IMAGE:-}" ]; then log "inside container ${F1_CONTAINER_IMAGE}: nothing to build"; exit 0; fi
for C in docker podman; do
  if command -v $C >/dev/null 2>&1 && $C info >/dev/null 2>&1; then
    log "building image f1-system with $C"
    if $C build -t f1-system -f environment/Dockerfile .; then
      log "OK. Run every subsequent target inside it, e.g.:"
      log "  $C run --rm -it --security-opt seccomp=unconfined -v \$PWD:/work/f1-system f1-system make env-check"
      log "  (seccomp=unconfined lets 'unshare -rn' and strace work inside the container; otherwise isolation is downgraded and recorded)"
      exit 0
    fi
  fi
done
if command -v apptainer >/dev/null 2>&1 || command -v singularity >/dev/null 2>&1; then
  A=$(command -v apptainer || command -v singularity)
  if $A build --fakeroot f1.sif environment/f1.def; then
    log "OK. Run: $A exec --bind \$PWD f1.sif make <target>"; exit 0
  fi
  log "Apptainer build failed; trying micromamba"
fi
if ! command -v micromamba >/dev/null 2>&1 && [ ! -x bin/micromamba ]; then
  mkdir -p bin && curl -fsSL https://micro.mamba.pm/api/micromamba/linux-64/latest | tar -xj -C . bin/micromamba || true
fi
MM=$(command -v micromamba || echo bin/micromamba)
if [ -x "$MM" ]; then
  export MAMBA_ROOT_PREFIX="$PWD/.mamba"
  if "$MM" create -y -p "$PWD/.env-f1" -f environment/environment.yml; then
    ln -sfn "$PWD/.env-f1" .venv
    log "OK: micromamba env at .env-f1 (linked as .venv; the Makefile uses .venv/bin/python automatically)"; exit 0
  fi
fi
PY=$(command -v python3.12 || command -v python3.11 || command -v python3)
log "creating venv with $PY"
$PY -m venv .venv && .venv/bin/pip install -U pip && .venv/bin/pip install -r environment/requirements.lock.txt \
  && { log "OK: .venv (the Makefile uses .venv/bin/python automatically)"; exit 0; }
log "FAILED to create an isolated environment"; exit 1
