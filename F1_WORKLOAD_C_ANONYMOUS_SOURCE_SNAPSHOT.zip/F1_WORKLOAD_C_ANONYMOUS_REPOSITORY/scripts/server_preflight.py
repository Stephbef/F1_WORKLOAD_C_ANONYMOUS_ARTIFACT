#!/usr/bin/env python3
"""Server preflight (no study data): python3 scripts/server_preflight.py --work-root DIR [--mobility-token-file F]"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from f1.workload_c.oneshot.cli import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main(["--preflight-only", *sys.argv[1:]]))
