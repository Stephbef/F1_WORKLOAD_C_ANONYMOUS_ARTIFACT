#!/usr/bin/env python3
"""OSC-01…OSC-55 gate ledger. Kept OUT of scripts/gate_ledger.py, which is part of the frozen S4A.1.1 semantic freeze
(docs/s4a1/S4A1_1_SEMANTIC_FREEZE.json); this wrapper reuses its main() unchanged."""
import importlib.util
import sys
from pathlib import Path

_spec = importlib.util.spec_from_file_location("gate_ledger", Path(__file__).with_name("gate_ledger.py"))
GL = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(GL)  # type: ignore[union-attr]

GATES_OSC = [ln.split(",", 1) for ln in """OSC-01,authoritative input identity
OSC-02,complete scientific regression
OSC-03,launcher executable
OSC-04,one-command path
OSC-05,secret redaction
OSC-06,target identity capture
OSC-07,L28 hard-stop
OSC-08,dependency verification
OSC-09,network hard-stop
OSC-10,disk-space hard-stop
OSC-11,cache protocol pre-timing freeze
OSC-12,real population state
OSC-13,24-region deterministic selection
OSC-14,8/16 deterministic split
OSC-15,test sealing
OSC-16,OSM pinning (V3 rule; verified provenance)
OSC-17,real producer path
OSC-18,fixture forbidden in REAL
OSC-19,validation readiness
OSC-20,exactly 8 validation regions
OSC-21,no test before authorization
OSC-22,N4 exact candidate set
OSC-23,N4 exact selection function
OSC-24,N4 no F1 dependency
OSC-25,validation incident classification
OSC-26,source modification after validation forces stop
OSC-27,unresolved E1 forces stop
OSC-28,unresolved E2 forces stop
OSC-29,S1 forces restart
OSC-30,R1 forbidden
OSC-31,validation closure
OSC-32,campaign freeze
OSC-33,automatic pretest audit
OSC-34,authorization bound to freeze hash
OSC-35,exactly 16 test regions
OSC-36,no scientific retuning during test
OSC-37,replay
OSC-38,mutations
OSC-39,analysis immutable
OSC-40,safe-stop package
OSC-41,resume identity
OSC-42,concurrent-run lock
OSC-43,idempotency
OSC-44,dry run
OSC-45,preflight-only
OSC-46,status command read-only
OSC-47,no secrets in package
OSC-48,final results package
OSC-49,no fabricated real evidence
OSC-50,end-to-end fixture state machine (cases A-H)
OSC-51,router semantic-config digest identical for consecutive build days
OSC-52,changing a semantic config field changes the digest
OSC-53,K2 still rejects a router whose service coverage does not contain D
OSC-54,every router producer path uses the frozen absolute service bounds
OSC-55,no real producer can fall back to relative OTP service defaults""".splitlines()]

def main(report: str, out_dir: str) -> int:
    """Run the frozen ledger builder on the OSC list in a private directory, then publish OSC_GATE_LEDGER.*"""
    import contextlib
    import io
    import shutil
    import tempfile
    GL.GATES_S4A1 = GATES_OSC          # main() selects lists by name; the OSC list rides the S4A1 slot privately
    with tempfile.TemporaryDirectory() as tmp:
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = GL.main(report, tmp, "S4A1", ())
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        for ext in ("csv", "md"):
            shutil.copy(Path(tmp) / f"S4A1_GATE_LEDGER.{ext}", out / f"OSC_GATE_LEDGER.{ext}")
    print(buf.getvalue().replace("S4A1 gates PASS", "OSC gates PASS"), end="")
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
