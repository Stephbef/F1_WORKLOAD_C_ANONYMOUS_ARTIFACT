#!/usr/bin/env bash
# Fresh Session-1 fixture run (Phase 00 -> 18) followed by an automated secret scan of every produced artifact.
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD/src"
PY="${PYTHON:-python3}"
ROOT_OUT="${1:-outputs/workload_c_fixture}"
rm -rf "$ROOT_OUT"
echo "*** ENGINEERING FIXTURE ONLY — NOT SCIENTIFIC RESULTS ***"
"$PY" -m f1.workload_c.campaign.cli run --fixture-mode --run-root "$ROOT_OUT" --run-id wc-s1-fixture
"$PY" -m f1.workload_c.campaign.cli secret-scan "$ROOT_OUT"
