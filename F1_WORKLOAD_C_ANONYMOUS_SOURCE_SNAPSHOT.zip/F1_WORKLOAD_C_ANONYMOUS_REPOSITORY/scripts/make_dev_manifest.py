"""Build a DEVELOPMENT manifest for workload A from explicitly named repositories (engineering smoke only).
The scientific manifest is produced exclusively by `python -m f1 select` (algorithmic selection)."""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from f1.common.util import atomic_write_json, sha256_obj  # noqa: E402
from f1.datasets.workload_a import clone_blobless, evaluate_candidate  # noqa: E402
from f1.runner.context import load_config  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--config", required=True)
ap.add_argument("repos", nargs="+", help="owner/name")
a = ap.parse_args()
cfg = load_config(a.config)
cache = Path(cfg["paths"]["data"]) / "cache" / "git"
sel = []
for i, full in enumerate(a.repos):
    slug = full.replace("/", "__")
    d = clone_blobless(f"https://github.com/{full}.git", cache / f"{slug}.git")
    ok, info = evaluate_candidate(d, cfg["workload_a"])
    print(full, ok, info.get("reason"))
    sel.append({"repo": full, "url": f"https://github.com/{full}.git", "slug": slug, "split": "test" if i % 2 == 0 else "validation",
                "dev_only": True, **info})
body = {"workload": "A", "DEVELOPMENT_ONLY": True, "selected": sel, "window": cfg["workload_a"]["window"]}
body["manifest_sha256"] = sha256_obj(body)
atomic_write_json(cfg["paths"]["manifest_a"], body)
print("wrote", cfg["paths"]["manifest_a"])
