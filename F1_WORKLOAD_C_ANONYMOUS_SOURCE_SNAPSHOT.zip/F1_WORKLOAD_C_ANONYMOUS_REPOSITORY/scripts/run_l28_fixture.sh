#!/usr/bin/env bash
# L28 runner: authoritative-envelope attempt on THIS host (BLOCKED / NOT_EXECUTED_ON_TARGET unless on the attested
# target) + sandbox rehearsal (scaled, NON-authoritative envelope in a real cgroup scope + real determinism suite).
# A sandbox result is never physical L28 PASS. Output: ${F1_WC_L28_DIR:-reports/l28}.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${F1_WC_L28_DIR:-$PWD/reports/l28}"
PYTHONPATH="$PWD/src" exec "${PYTHON:-python3}" -m f1.workload_c.campaign.cli l28 --out "$OUT" --sandbox \
  --work "$(mktemp -d -t f1wc-l28-XXXXXX)"
