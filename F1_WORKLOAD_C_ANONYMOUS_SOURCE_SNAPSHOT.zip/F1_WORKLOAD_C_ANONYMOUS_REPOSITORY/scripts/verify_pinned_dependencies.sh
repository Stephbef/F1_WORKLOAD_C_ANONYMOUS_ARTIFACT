#!/usr/bin/env bash
# Verify every pin (jar digests + exact tool versions). Writes a JSON report; exit 0 only if all REAL pins verify.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${1:-reports/pinned_dependencies_status.json}"
mkdir -p "$(dirname "$OUT")"
PYTHONPATH="$PWD/src" "${PYTHON:-python3}" - "$OUT" <<'PY'
import json, sys
from f1.workload_c.deps.pins import verify_all
st = [s.to_dict() for s in verify_all()]
json.dump(st, open(sys.argv[1], "w"), indent=1)
for s in st:
    print(f"{s['status']:<20} {s['name']:<15} {s['version']:<10} {(s['actual_sha256'] or '-')[:16]}  {s['detail'][:50]}")
sys.exit(0 if all(s["status"] in ("VERIFIED", "VERIFIED_BY_VERSION") for s in st) else 1)
PY
