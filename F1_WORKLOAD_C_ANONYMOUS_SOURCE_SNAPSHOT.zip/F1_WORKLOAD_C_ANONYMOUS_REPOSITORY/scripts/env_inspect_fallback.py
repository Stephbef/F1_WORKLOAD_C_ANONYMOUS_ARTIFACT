"""Dependency-free environment inspection used by `make env` before any Python package is installed."""
import json, os, platform, shutil, subprocess, sys, time
def run(c):
    try:
        p = subprocess.run(c, capture_output=True, text=True, timeout=20); return p.stdout.strip() or p.stderr.strip()
    except Exception as e:
        return f"unavailable: {e}"
rep = {"generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "python": sys.version, "platform": platform.platform(),
       "os_release": open("/etc/os-release").read() if os.path.exists("/etc/os-release") else None,
       "cpus": os.cpu_count(), "lscpu": run(["lscpu"]), "mem": run(["free", "-g"]), "disk": run(["df", "-hT", "."]),
       "nvidia_smi": run(["nvidia-smi"]), "nvcc": run(["nvcc", "--version"]),
       "tools": {t: run([t, "--version"]) for t in ("git", "gcc", "rustc", "cargo", "docker", "podman", "apptainer", "singularity", "micromamba")}}
os.makedirs("environment", exist_ok=True)
json.dump(rep, open("environment/environment_before.json", "w"), indent=2)
open("environment/environment_before.md", "w").write("# Environment (before)\n\n```\n" + json.dumps(rep, indent=2) + "\n```\n")
print("wrote environment/environment_before.{json,md} (fallback inspector)")
