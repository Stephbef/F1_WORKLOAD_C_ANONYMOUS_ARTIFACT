#!/usr/bin/env bash
# Re-run the Session-1 gate suite (S1-01..S1-30) and write its ledger to ${F1_WC_REPORT_DIR:-reports}/s1.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${F1_WC_REPORT_DIR:-$PWD/reports}/s1"
mkdir -p "$OUT"
export PYTHONPATH="$PWD/src"
set +e
F1_WC_GATE_REPORT="$OUT/gate_report.json" "${PYTHON:-python3}" -m pytest tests/workload_c --confcutdir=tests/workload_c \
  -o addopts="" -q -rA -m "not s2only" --ignore-glob='tests/workload_c/test_s2_*' --ignore-glob='tests/workload_c/test_s3_*' --ignore-glob='tests/workload_c/test_s4a1_*' --ignore-glob='tests/workload_c/test_oneshot_*' --junitxml="$OUT/junit.xml" > "$OUT/pytest.log" 2>&1
rc=$?
set -e
tail -3 "$OUT/pytest.log"
"${PYTHON:-python3}" scripts/gate_ledger.py "$OUT/gate_report.json" "$OUT" --gates S1 || rc=1
exit "$rc"
