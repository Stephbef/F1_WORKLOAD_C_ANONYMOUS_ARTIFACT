# F1 Workload C — Anonymous Research Artifact

This repository contains the implementation, frozen specifications, test fixtures, and reproducibility infrastructure for an anonymous research submission.

**No author-identifying information, real campaign credentials, real study outputs, or authoritative TEST results are included.**

## Scope

The artifact implements the F1 Workload C experiment, including:

- GTFS history ingestion and logical-version construction;
- deterministic region formation and split logic;
- F1 realized-history witness search and selective repair;
- baselines N0–N6;
- native OpenTripPlanner execution paths;
- replay/provenance checks;
- mutation/reference checks;
- warm-primary and cold-secondary execution support;
- the one-shot validation → freeze → TEST state machine.

The scientific rules used by the implementation are preserved under `configs/workload_c/`, `docs/`, and `frozen_specs/`.

## Important review note

This is an **anonymized review snapshot with a fresh Git history**. Historical Git-ancestry assertions used only during internal development packaging are disabled when the file `ANONYMIZED_REVIEW_ARTIFACT` is present. No scientific implementation rule, baseline behavior, statistical rule, workload rule, or frozen semantic configuration is changed by that packaging adaptation.

## Requirements

The exact pinned dependencies are described in:

- `configs/workload_c/pinned_dependencies.json`
- `docs/PINNED_DEPENDENCIES.md`

The full real campaign additionally requires a Mobility Database token supplied at runtime. **No token is included in this repository.**

## Install / verify dependencies

```bash
./install_server_dependencies.sh
bash scripts/verify_pinned_dependencies.sh
```

## Run the fixture / engineering test suite

```bash
python -m pytest -q tests/workload_c
```

For the complete frozen gate regression:

```bash
F1_WC_REPORT_DIR=reports bash scripts/run_tests.sh
```

Some host-conformance checks require the exact pinned runtime and system capabilities documented in the artifact.

## Dry run / preflight

```bash
./run_f1_workload_c_campaign.sh \
  --preflight-only \
  --mobility-token-file /secure/path/token \
  --work-root /data/f1_workload_c
```

## Real campaign

```bash
./run_f1_workload_c_campaign.sh \
  --mobility-token-file /secure/path/token \
  --work-root /data/f1_workload_c
```

Resume after interruption:

```bash
./run_f1_workload_c_campaign.sh \
  --resume \
  --mobility-token-file /secure/path/token \
  --work-root /data/f1_workload_c
```

## Repository layout

- `src/` — implementation
- `tests/` — unit, integration, conformance, and Workload C tests
- `configs/workload_c/` — frozen Workload C configuration
- `frozen_specs/` — authoritative semantic/conformance specifications and fixtures
- `docs/` — design and reproducibility documentation
- `scripts/` — dependency, test, and conformance tooling
- `fixtures/` — non-study fixtures
- `reports/` — engineering gate evidence only; **not study results**

## Data and results

The repository intentionally does **not** contain the authoritative real campaign dataset or final scientific results. The real campaign downloads/constructs its study inputs according to the frozen protocol at execution time.

## Anonymity

Do not add author names, institution names, personal email addresses, ORCID identifiers, personal repository URLs, or real campaign credentials while the submission is under anonymous review.
