# Runbook

1. **Environment.** `make env` then `make env-check`. CentOS 7 (glibc 2.17, GCC 4.8.5): prefer Apptainer or
   Docker; conda-forge/pip binaries built for newer glibc fail with `GLIBC_2.xx` errors (the check reports it).
   cargo-audit is a static musl binary and does not depend on the host glibc.
2. **Network.** Acquisition needs github.com (git), crates.io (license API), d37ci6vzurychx.cloudfront.net (NYC TLC).
   A missing workload-B source is recorded as failed in `data/workload_b/acquisition_summary.json`; the run
   continues with the remaining sources only if at least one remains (otherwise histories fail loudly).
3. **Pre-registration.** `make select` (set GITHUB_TOKEN to avoid search rate limits; selection itself uses
   blobless git clones, not the API), inspect `datasets/workload_a/repos_manifest.json`, then `make freeze`.
   Commit `manifests/FREEZE_MANIFEST.json` with a timestamp before starting the run.
4. **Run.** `make full-experiment`. Concurrency starts at `server.initial_workers` and adapts to measured peak RSS
   within `server.mem_budget_gb` (never above `server.max_workers`).
5. **Failures.** Producer failures are results (recorded in `raw/birth_failures.jsonl`, oracle runs with
   non-ok status are excluded and counted). Harness exceptions are retried on resume.

Known engineering constraints (measured, not assumptions):
- cargo-audit 0.22.2 cannot parse RustSec snapshots before 2023-01-01; the window starts in 2024.
- License gate = deterministic SPDX wrapper (cargo-deny cannot be replayed hermetically offline);
  divergences: "A/B" = OR, "X WITH Y" = X, "X+" = X, missing expression = violation.
