# Failure classification (`producers/failure.py`)

SUCCESS, SEMANTIC_FAIL, INVALID_INPUT, INFRA_ERROR, TIMEOUT, RESOURCE_FAILURE, DEPENDENCY_MISSING, DIGEST_MISMATCH.
Frozen rules (spec17 §4): no scientific timeouts; operational 24 h cap (TIMEOUT → affected instants excluded from
primary metrics, `EXCLUDED_FROM_PRIMARY`); build failure = "no artifact", never cost ∞. Only SUCCESS and SEMANTIC_FAIL
yield an artifact; every infrastructure class yields none and is never converted into semantic invalidity.
Process mapping: timeout → TIMEOUT; SIGKILL without timeout (OOM / envelope overflow) → RESOURCE_FAILURE; rc ≠ 0 →
INFRA_ERROR; corrupt/missing report or graph → INFRA_ERROR; unreadable input container → INVALID_INPUT; unverifiable
pins → DEPENDENCY_MISSING / DIGEST_MISMATCH (raised by the pin layer). Verified with stubs and with a real cgroup-v1
memory kill.
