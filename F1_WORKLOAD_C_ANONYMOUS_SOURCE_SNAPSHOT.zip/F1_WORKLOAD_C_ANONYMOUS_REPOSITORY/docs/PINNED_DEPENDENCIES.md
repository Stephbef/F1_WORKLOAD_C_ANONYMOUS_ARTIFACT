# Pinned dependencies

Manifest `configs/workload_c/pinned_dependencies.json`; code `src/f1/workload_c/deps/pins.py`;
`scripts/fetch_pinned_dependencies.sh` (download/mirror → exact SHA-256 → atomic rename; mismatch deletes and exits 1),
`scripts/verify_pinned_dependencies.sh` (JSON report; exit 0 only if every pin verifies).

| Name | Version | Source | Expected SHA-256 | Verification |
|---|---|---|---|---|
| OTP | 2.10.0 (`otp-shaded-2.10.0.jar`) | GitHub release v2.10.0 | `8acd28081f859cfbb4a18a7979789fc02d472f229ce656167f3da5971eea7990` (spec17 §1) | digest |
| gtfs-validator | 8.0.1 (`gtfs-validator-8.0.1-cli.jar`) | GitHub release v8.0.1 | `19293ddd9b6f954f216d4f12054bd8a3232921751c4484339e339764a91000e2` (spec17 §1) | digest |
| JDK / javac | OpenJDK 25.0.4.1 | Ubuntu 24.04 `openjdk-25-jdk-headless=25.0.4.1+1-1~24.04.4`; other hosts: an OpenJDK 25.0.4.1 build | version-pinned (frozen pins the version) | exact version + identity digest (java binary + `lib/modules`) recorded |
| osmium-tool | 1.16.0 (1.16.0-1build1) | Ubuntu package | version-pinned | exact version |
| faketime/libfaketime | 0.9.10 | Ubuntu package | version-pinned | exact version (D2 determinism test) |
| Python | ≥ 3.11 (tested 3.12.3), PyYAML 6.0.3, pytest 9.1.1 | pip | — | recorded |

Modes: `REAL_PINNED_BINARY` (all required pins verify; required for any scientific execution) and
`FIXTURE_STUB_BINARY` (deterministic stubs in `fixtures/stub_binaries/`, stamped in every output; never satisfy REAL).
The jars are not redistributed in the package (191 MB / 40 MB); the fetch script reproduces them by digest.
