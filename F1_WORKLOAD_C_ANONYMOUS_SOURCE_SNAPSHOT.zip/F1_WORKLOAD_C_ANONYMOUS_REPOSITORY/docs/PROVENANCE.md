# Provenance (`producers/provenance.py`)

`ProducerProvenance` (frozen) bound into every artifact: producer identity, binary mode, binary SHA-256, runtime
identity (JDK version + identity digest, or stub interpreter), configuration digest (validator flags / semantic config),
input digests, resource envelope, start/end (clock), wall and CPU seconds (wait4 rusage), host identity (hostname
digest, platform, CPU count, memory), stdout/stderr digests, result digest, argv digest, failure class, extras
(rc, signal, timeout, wrappers, network isolation, graph digest). Fixture producers carry `FIXTURE-STUB:` identities and
`FIXTURE_STUB_BINARY` mode. Producer environments are allow-listed (no credentials can be passed; MOBILITY_DB_TOKEN and
any *TOKEN*/*SECRET* variable are refused).
