# Workload C — Session-1 architecture (navigation)

Package `src/f1/workload_c/` lives inside the reference F1 system (commit 20271cf) and reuses `f1.common.util`
(canonical JSON, SHA-256 helpers, atomic writes, F1Error). It does not import numpy/pyarrow and does not fork any F1
core module. Workload A/B modules are untouched; their regression suite still passes.

```
config/      spec.py (frozen protocol spec loader, cross-checked against frozen text/tools), runtime.py (runtime
             config, interpretation register, licence table, effective-config digest)
storage/     BlobStore / ManifestStore / SnapshotStore (immutable, content-addressed, link-no-overwrite)
security/    secrets.py (SecretProvider, Redactor, secret scan), namespaces.py (FIXTURE/VALIDATION/TEST, TEST guard)
state/       journal.py (hash-chained append-only JSONL, StructuredLog), run_state.py (5-state machine + ledger)
checkpoint/  store.py (identity-bound checkpoints, resume verification)
api/         transport.py, mobility.py (real client), mock.py (deterministic server), caching.py (resumable snapshot)
ingestion/   gtfs.py (frozen canonical content hash, GTFS parsing, ArchiveRecord)
versioning/  logical.py (logical-version engine)
licensing/   engine.py (classes A–E -> PASS/RESTRICTED_BUT_USABLE/UNCLEAR/INCOMPATIBLE)
regions/     spatial.py, eligibility.py, dedup.py, connectivity.py, construct.py, model.py
selection/   hashrank.py (first-24 selection, 8/16 split, proofs)
interfaces/  protocols.py (14 stable interfaces), mocks.py (deterministic MOCK adapters)
fixturegen/  gtfs_gen.py, population.py (deterministic engineering fixture population)
campaign/    phases.py (19 phases), orchestrator.py, dataplane.py (phases 02–07), later_phases.py, fixture.py, cli.py
```

Data flow (FIXTURE): mock API → real `MobilityClient` (through `CachingTransport`) → Phase 02 snapshot (raw ZIPs
in BlobStore) → Phase 03 canonical hashes + logical versions (checked against the frozen tool) → Phase 04 licences
→ Phase 05 facts / eligibility / dedup / connectivity / regions → Phase 06 selection (checked against the frozen
tool) → Phase 07 split → Phases 08–18 via interfaces (mocks) → FINAL_VERDICT.json with the fixture marker.
