# Artifact catalog and fixed-R (`catalog/artifacts.py`)

`RequestSlot` = designated request identity (`VAL:feed=<id>`, `ROUTER:region=<id>`); `designated_slots(region, feeds)` =
fixed R (one validation slot per feed + one router slot). `ArtifactEntry` (frozen) = one derivation instance: artifact
id (slot + instance + birth cut + inputs + outputs + status; never timestamps), instance number, producer type, class,
birth cut + frontier, logical input vector, contract ids, status (FailureClass), provenance digest, output digests,
cost placeholder (wall/cpu; Session-3 cost model), namespace, binary mode, `rederived_from`. The catalog is
append-only (journal), refuses changed content for an existing id and out-of-order instances, and offers no
cross-slot content lookup (no free historical substitution). `rederive(r, c)` = new instance of the same slot born at
c, linked to the previous instance.
