# AMENDMENT-ONESHOT-ROUTER-SEMCONFIG-01 — router semantic-config policy (pre-data PI decision)

**Policy:** `FIXED_CAMPAIGN_ABSOLUTE_SERVICE_BOUNDS` (PI choice B). Decided before any real campaign execution; no
VALIDATION or TEST outcome exists or motivated the decision.

**Why.** ROUTER K0 binds "feed hashes + OSM + semantic config + OTP". The frozen projection (cfgproj.py) includes
`transitServiceStart/End` resolved against BUILD_DATE, and the frozen OTP producer leaves those bounds at OTP's relative
defaults (−P1Y / +P3Y). Resolved independently at every build, the semantic-config digest would change every calendar
day although nothing semantic changed, making every router contract INVALID on any later day. Discovered while wiring
the real-server backend (the fixture campaign uses a constant placeholder digest), before any real execution.

**Rule (resolved ONCE, frozen).** Study window = calendar dates 2025-04-01 .. 2026-06-30 (T_start = 2025-04-01,
T_end = 2026-07-01 exclusive). With the frozen cfgproj period convention:
- transitServiceStart = 2025-04-01 − P1Y = **2024-04-01**
- transitServiceEnd = (2026-07-01 − 1 day = 2026-06-30) + P3Y = **2029-06-30**
Timezone convention: the window is defined in local calendar dates, identical for every agency timezone, so one pair
serves all regions. These explicit absolute dates are written into EVERY OTP ROUTER build configuration of the campaign:
shared scheduled production, F1, N0, N1, N2, N3, N4, N5, N6, K3/reference rebuilds, mutation/reference rebuilds, warm
and cold passes (oneshot/semconfig_policy.py: FixedBoundsOtp wraps the single OTP producer; the N1-native builder
receives the same pair). The same values enter cfgproj.py and the semantic-config digest; they are never recomputed
from a build date; a request carrying any other explicit bound is refused.

**Not changed.** Reuse validity is still decided by the frozen contracts, including K2's condition D ⊆ router service
coverage; GTFS / version / OSM / config / OTP changes still invalidate as frozen.

**Tests:** tests/workload_c/test_oneshot_campaign.py — OSC-51…OSC-55 (consecutive-day digest equality; semantic field
change changes the digest; K2 rejects a router whose coverage excludes D; every producer path uses the same bounds;
no fallback to relative defaults).
