# 05 — OSM / osmium pin manifest (B5): tool PINNED, snapshot BLOCKED

| Item | Value |
|---|---|
| osmium-tool | **1.16.0** (Ubuntu 24.04 package `1.16.0-1build1`, package SHA256 `724c103ee5312b1b80e6a37b21efb17e489fa110ef3bf74717932c62bbc037da`) |
| OSM source | Geofabrik regional extract covering the region's connected-feed hull (country/sub-region file chosen by smallest Geofabrik polygon containing the hull) |
| Snapshot date | **2025-04-01** (window start), via Geofabrik's dated `-250401.osm.pbf` file if available. Otherwise the earliest dated extract ≥ 2025-04-01, recorded |
| Clip | `osmium extract --strategy complete_ways --bbox <hull bbox + 5 km> in.osm.pbf -o region.osm.pbf` |
| Digest | SHA-256 of `in.osm.pbf` and `region.osm.pbf` recorded |
| Rule | **OSM fixed** for the whole experiment |

**Blocked:**
- `download.geofabrik.de` returns 403 from this environment.
- Region hulls depend on B1.
