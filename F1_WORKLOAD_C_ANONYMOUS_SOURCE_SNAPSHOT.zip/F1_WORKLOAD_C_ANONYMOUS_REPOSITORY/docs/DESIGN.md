# Design notes

**Separation of semantics.** The admission side receives `r, beta, RS, kappa, cost, H, Gamma` only. Producers are
imported by the production and oracle stages, never by `admission/` or `repair/`.

**Contracts.** JSON ASTs over registered features (pure functions of item contents). The evaluator only loads
items in the declared footprint and memoises on footprint contents (footprint transfer). K1 is structurally
restricted to equalities between disclosed features and recorded birth values (no order comparison, no
disjunction/negation, no set algebra); K2 adds decision regions; K3 is the full executable logic and is a
reference that violates opacity. `kappa_eff = K OR K0`. Every emitted contract must accept its own birth cut,
otherwise it is rejected and recorded.

**Producers.** Hermetic: fresh sandbox, HOME inside, LC_ALL=C, TZ=UTC, SOURCE_DATE_EPOCH, private network
namespace (`unshare -rn`) when available, strace tracing of open/openat/connect (plus an audit hook for Python
jobs). Reads outside the sandbox and outside library-init system paths are A3 violations, reported per artifact.

**Workload A.** S = Cargo.lock, V = RustSec DB (daily snapshots, deduplicated by content), P = policy file
(deny.toml/.cargo/audit.toml/audit.toml at file granularity, or default), L = license table (immutable per crate
version). Producers: cargo-audit (vulnerability report and gate), SPDX license gate/issues.
**Workload B.** D = table version (parquet), R = reference table (TLC zones). Producer: full-data quality
certification over a frozen, documentation-derived check suite.

**Statistics.** Primary aggregation macro over units (artifacts or events); two-stage cluster bootstrap
(clusters = repositories/datasets). TTL tau* is selected on the validation split only.

**Open design question (to settle before freezing).** In workload B, K1 compares exact floating-point statistics;
on tables that grow, it may be indistinguishable from K0. This is reported, not patched after the fact.

## Final pre-execution decisions (v2)

**Primary joint schedule (identifiability).** Vulnerability scanning is a periodic security service: nightly at
02:00 UTC and whenever the advisory-database content changes; it is NOT triggered by Cargo.lock changes.
License evaluation is dependency/policy-triggered: on every Cargo.lock change and every policy-file change. The
dashboard consumes the latest artifact of each. Asynchrony therefore arises only from differing triggers (no delays,
skips or failures are injected). With the former synchronised schedule (both producers re-run on every lockfile change)
stale-S divergence was structurally impossible; that configuration is kept only as the negative control J1
(`vuln_on_lock_change: true`). Hostile-reviewer answers: nightly scans and DB-change-triggered rescans are the
standard operating mode of scanning services; license checks are dependency-change gates in CI; the two are owned by
different teams/services; the schedule is fixed independently of M4; a coordinator could force both to re-run on every
change (eliminating stale composition) at the price of coordination and recomputation — exactly the
recompute/synchronise baseline that witnessed admission and selective repair aim to avoid (B4).

**Workload B, K1 = K0 (negative result kept).** P_DQ decides d(T) = AND_i [s_i(T) op_i theta_i]. A K1 contract may
disclose the statistics s_i and their birth values but never (op_i, theta_i). K1 is sound iff K1(c) implies
d(c) = d(beta); without thresholds this requires pinning every s_i whose value can cross theta_i. On growing tables the
continuous statistics (null fractions, quantiles, out-of-range fractions, row counts) change at every version, so K1
rejects every later version: K1 = K0. Pinning only invariant discrete features (schema identity, column presence,
logical types, reference-table version, categorical vocabularies) omits decision dependencies and would be unsound
(U2) — forbidden by A6. Rounded/quantised statistics would leak threshold proximity (K2 semantics) or be unsound near
thresholds — forbidden by G3. Hence workload B tests whether feature disclosure suffices; the expected answer is no,
and decision-region disclosure (K2) is required. Test: `test_K1_workload_B_is_complete_feature_disclosure_without_thresholds`.

**RustSec semantics (U1).** A differential test against the pinned cargo-audit binary found two genuine mismatches in
the former Cargo-semver matcher (RustSec zero-fills partial versions for =,>,>=,<,<= and compares by plain version
order). The matcher now implements RustSec semantics: U1 = 0 on 34 adversarial cases accepted by cargo-audit; the two
cases cargo-audit rejects at database load (wildcards, overlapping ranges) are excluded upstream by `validate_db`.

**Costs.** Contract cost = evaluation with a fresh evaluator per pair over a content-addressed parse cache of immutable
snapshots (advisory DB, license table, policy, lockfile, table schema); parse-miss CPU is amortised evenly across the
class's evaluations (order-independent). A seeded 2% sample of fully uncached evaluations is reported as sensitivity.
Repair: fast path when a witness exists (no solver); shared decision cost (contracts at the current cut, required by F1
and by current-cut repair) cancels symmetrically in M5_net_fair (gate G6); end-to-end totals and the asymmetric M5_net
are always reported.

**Execution.** Resource-aware scheduler: per class, workers = min(floor(CPU_budget/cpu), floor(RAM_budget/ram),
floor(IO_budget/io), cap); reservations never exceed the budget (60 cores, 290 GB, 1200 MB/s); heavy-first dispatch;
RAM estimates adapt upward to measured RSS. Telemetry (2 s, observational only) writes raw/server_telemetry.parquet and
statistics/server_resource_summary.{json,csv}. Canonical ledger (statistics/LEDGER.json) asserts every global identity
exactly.
