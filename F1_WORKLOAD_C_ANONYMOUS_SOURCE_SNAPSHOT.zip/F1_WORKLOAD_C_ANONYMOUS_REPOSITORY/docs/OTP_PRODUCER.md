# OTP producer (`producers/otp.py`)

`OtpRouterProducer.produce(OtpRequest)`: copies hashed local inputs (GTFS logical-version files, OSM extract) into a
per-job directory, writes `build-config.json` with ABSOLUTE `transitServiceStart/End` resolved before invocation from
the explicit build date (OTP defaults `-P1Y`/`P3Y` relative to BUILD_DAY, via the frozen `cfgproj.period`), canonical
feed order (sorted feed ids), `transitModelTimeZone`; computes the semantic-config digest with the frozen `cfgproj`;
runs `java <envelope JVM flags> -Djava.io.tmpdir=<job>/tmp -jar otp-shaded-2.10.0.jar --buildStreet <job>/graph` then
`--loadStreet --save <job>/graph` (identical to the frozen harness) under `unshare -rn`, TZ=UTC, LC_ALL=C.UTF-8,
optional resource scope; then Canon_D. ROUTER artifact metadata: artifact id, request slot, region, birth cut, GTFS
logical-version vector, OSM digest, OTP digest, JDK identity, semantic config digest, resolved service window,
horizon D, graph digest, Canon digest + schema, binary mode, producer start/end, status.
Wall-clock independence: config generation takes no clock input (tested under TZ changes and under `faketime`
2031/1999); a REAL OTP build under `faketime 2031-03-15` yields the identical Canon digest
(`37a5b102…497c`, equal to the frozen record). `build_dir()` is shared with the conformance harness so the frozen
oracle/determinism suites exercise the same code path.
