# Resource manager (`resources/`)

`detect_capabilities()` inspects the host (cgroup fs type, writable v2 controllers, writable v1 cpu/memory/cpuset,
systemd-run with each required property probed, taskset) — no distribution assumptions. `ResourceManager.select()`:
systemd-run > cgroup v2 > cgroup v1; `NoopFixtureBackend` only when explicitly allowed (FIXTURE); taskset-only →
`ResourceEnforcementUnavailable`. Backends write exactly the frozen controls:
v2 `cpu.max`, `memory.max`, `cpuset.cpus`, `cpuset.mems` + `cgroup.procs`; v1 `cpu.cfs_period_us`, `cpu.cfs_quota_us`,
`memory.limit_in_bytes`, `cpuset.cpus`, `cpuset.mems` + `tasks`; systemd `--scope -p MemoryMax -p CPUQuota -p AllowedCPUs`.
Processes are attached by `attach.py` (writes its own pid, then `execvp`; no shell). Scope names are unique per job.
Authoritative OTP envelope (`otp_authoritative_envelope`, from the frozen spec and checked against file 14 text):
8 CPUs (cpuset 0-7), quota 800000/100000, MemoryMax 32 GiB, `-XX:ActiveProcessorCount=8 -Xms24g -Xmx24g -XX:+UseG1GC
-Duser.timezone=UTC`; any cpuset not providing exactly 8 CPUs is refused (no selective resizing).
`sandbox_envelope()` is NON-AUTHORITATIVE (engineering only) and can never yield L28 PASS.
In-scope proof (`resources/proof.py`) runs inside the scope and records /proc/self/status Cpus_allowed_list,
/proc/self/cgroup, effective cgroup paths, cpu quota, memory limit, cpuset, JVM final flags (ActiveProcessorCount,
InitialHeapSize, MaxHeapSize, UseG1GC), Java version, locale, timezone → `TARGET_RESOURCE_RUNTIME_PROOF.json`.
This session's host: cgroup v1 writable (real kernel enforcement exercised: memory kill → RESOURCE_FAILURE; in-scope
proof verified for a sandbox envelope), no systemd PID 1, 1 CPU / 3 GiB.
