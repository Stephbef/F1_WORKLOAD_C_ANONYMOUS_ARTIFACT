# Realized history and cuts (`history/realized.py`, `scheduler/ledger.py`)

Events: LOGICAL_VERSION_AVAILABLE, PRODUCER_QUEUED/STARTED/COMPLETED, ARTIFACT_BORN, DERIVATION_EDGE, OTP_TRIGGER(_SKIPPED),
CONSUMER_TICK, INFRA_ERROR. Event id = SHA-256 of content incl. sorted causal predecessors. The history is a DAG
(append-only journal, hash-chained); per-feed versions form a chain (index n requires predecessor n-1 as cause); causes
must exist and not be later in time; re-adding an identical event is idempotent; `happens_before` / `concurrent` are
DAG reachability — no total order is imposed. Cut = frontier vector {feed: logical index} (0 = none), canonical
serialization `F1-WC-CUT-1`, id `CUT:` + SHA-256. `cut_at(H, t)`; `is_consistent`; `enumerate_cuts` = finite product of
per-feed prefixes (optionally depth-bounded from the frontier) as the representation of Cuts(H_t); `leq` partial order.
