# Adding a producer family (e.g. a Distributed Intelligence case study)

The admission engine, repair solvers, oracle, statistics and reports are workload-agnostic. To add autonomous
AI services that emit durable artifacts with contracts:

1. Subclass `f1.producers.base.PythonJobProducer` (or `Producer` for external binaries): declare `read_items`,
   `artifact_types`, implement `run_job` (hermetic), `project`, and `contracts` (the producer-side emitter of
   K1/K2/K3 JSON ASTs). Register any new features with `@feature(name)`.
2. Subclass `f1.workloads.base.Workload`: clusters, history construction (model/data/policy versions as items),
   birth schedule, unary ticks, consumer events (joint reuse by a coordinator).
3. Add the workload name to `RunContext.workload` and a config section.

Non-deterministic producers (e.g. LLMs) are detected by the determinism protocol and excluded from the primary
analysis; their acceptance relation must be defined explicitly (e.g. support semantics) before any claim.
`f1.producers.synthetic` / `f1.workloads.synthetic` are a complete minimal example.
