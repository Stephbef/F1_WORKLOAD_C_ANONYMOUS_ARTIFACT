# Baseline semantics — FINAL (AMENDMENT-S4A-BASELINES-01)

| Method | Decision at request t | VAL slot | ROUTER slot | State visible | Failure | Cost |
|---|---|---|---|---|---|---|
| F1 | unchanged (S3.1) | contracts K, witness, repair | frozen producer | shared + own overlay + history (Γ) | frozen | frozen |
| N0 | full rebuild of EVERY slot at EVERY request | validator, current date | FULL COLD street+transit (frozen two-step producer) | nothing reusable | slot no artifact; joint NO_ARTIFACT; no fallback | full, A+B |
| N1 | unchanged (S3.1 + AMENDMENT-S3-N1-01) | N5(K0) path | native (loadStreet + cache) | own native state | frozen | own native measured |
| N2 | per slot: current-cut K0 rerun (reuse iff K0 VALID at current cut, else re-derive) | validator | N1-native | latest admissible artifact per slot (shared + own) | no stale fallback | A+B |
| N3 | per slot: exact version-EVENT pin + half-open interval join, born ≤ t | validator | N1-native | same + current version events | no stale fallback | A+B incl. n3_pin_index |
| N4(τ) | per slot: age = t − ARTIFACT_BORN < τ → reuse (no check), else re-derive; τ ∈ {1,6,24,72,168} h | validator | N1-native | same + born times | no fallback to expired | A+B |
| N5 | unchanged (S3.1) | contracts, current cut | frozen producer | CurrentCutView | frozen | frozen |
| N6 | VAL: key (feed, LV event, canonical, country, validator) — no date; ROUTER: N2 policy | cache hit else validator (artifact results cached) | N2 policy, N1-native | admissible VAL artifacts by key + latest router | infra not cached; no fallback | A+B |

Execution: per-slot independent decisions in canonical slot order; every needed re-derivation is attempted (the frozen
fail-fast rule is defined for F1/N5 RepairPlans, not for these per-slot baselines); artifacts are born at t + cumulative
executed serial durations; inputs are the snapshot at t. Reference truth for N4 safety: frozen K3 (offline only).
N4 τ selection: docs/s4a1/N4_SELECTION_RULE_FINAL.md.
