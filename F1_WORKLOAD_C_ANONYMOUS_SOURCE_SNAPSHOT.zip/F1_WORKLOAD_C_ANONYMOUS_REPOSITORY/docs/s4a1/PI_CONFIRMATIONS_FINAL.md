# PI confirmations — FINAL (Session 4A.1.1 directive §2; pre-VALIDATION)

The three items recorded as applications in AMENDMENT-S4A-BASELINES-01 §6 are now AUTHORITATIVELY CONFIRMED:

- **§2.1 Shared scheduled-production visibility — CONFIRMED.** N2, N3, N4 and N6 bind artifacts from the SHARED
  scheduled-production catalog plus their OWN method overlay with the frozen binding rule. This is exogenous common
  system state, NOT F1 historical-witness access. N0 remains the explicit no-reuse exception.
- **§2.2 K0 identity of N1-native router artifacts — CONFIRMED.** Routers re-derived by N2/N3/N4/N6 with
  `--loadStreet --save cache.enabled=true` receive the normal frozen ROUTER K0 identity (per-feed canonical hashes, OSM
  digest, semantic-config digest, OTP digest). The production mechanism is provenance only (output digest
  "mechanism"), never a K0 field.
- **§2.3 Independent per-slot execution — CONFIRMED.** N0/N2/N3/N4/N6 execute every re-derivation their per-slot policy
  requires in canonical slot order, without F1/N5 fail-fast; a failed slot is charged and yields no artifact; later
  required slots are still attempted; their successful outputs become baseline state; the joint request is NO_ARTIFACT
  when any required slot lacks an artifact.
