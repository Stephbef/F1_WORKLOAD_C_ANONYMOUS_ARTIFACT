# AMENDMENT-S4A-BASELINES-01 — pre-VALIDATION closure of baselines N0, N2, N3, N4, N6

**Class:** S1 scientific clarification at stage IMPLEMENTATION (pre-VALIDATION). **Authority:** Session 4A.1 directive
(PI), closing exactly the gaps reported by F1_WORKLOAD_C_S4A_BLOCKED_REPORT.zip (SHA-256 9b617213…1877).
**Timing facts:** created before any VALIDATION execution; no N4 TTL outcome has ever been produced; no TEST outcome
exists; no real population has been retrieved. A clean preregistered restart from the amended freeze is required
before VALIDATION (expected and authorized).

**Independence from F1 performance:** every rule below was specified by the PI directive before any data; none uses an
F1 field, an F1-vs-baseline comparison, or any observed outcome. The N4 selection function takes only (U_τ, C_τ, τ).

## 1. Global rules (directive §3, §12, §13, §14)
Same frozen consumer stream, current cut, ConsumerRequest and designated fixed-R slots for every method; no method uses
information born after t; a producer launched at t uses the snapshot at t even if it completes later; completion controls
future visibility; failures keep their frozen classes (SUCCESS / SEMANTIC_FAIL artifact; infra/resource/timeout no
artifact; INFEASIBLE when inputs do not exist); failed work is charged; no stale fallback; OPERATIONAL_CAP keeps the paired
exclusion of primary metrics. Resources: VAL = frozen validator envelope; N0 router = frozen OTP envelope (cold full
build); N1/N2/N3/N4/N6 router = identical N1 OTP envelope; F1/N5 unchanged; no extra resources for slower methods.

## 2. Router-configuration conflict (directive §4) — resolution
A. N0 is the explicit exception: TRUE full cold street + transit rebuild (frozen producer two-step build), no persisted
street, no history. B. N1 unchanged. C. N2, N3, N4, N6: every ROUTER re-derivation uses the N1 native configuration
(persisted street graph, `--loadStreet --save`, `cache.enabled=true`, same OTP envelope); their decision policies remain
their own. D. F1 and N5 remain EXACTLY as frozen in S3.1; the V3 phrase "all ROUTER rebuilds in every method use the N1
configuration" is NOT applied retroactively to F1/N5.

## 3. Method semantics
- **N0 (full rebuild):** at EVERY consumer request re-execute EVERY designated slot from the current-cut snapshot (VAL:
  pinned validator, current consumer date, frozen country/validator; ROUTER: full cold build); full cost charged; any
  failed slot → no artifact for that slot, joint request NO_ARTIFACT; next request rebuilds again; no historical catalog,
  no reuse cache.
- **N2 (current-cut K0 selective rerun):** per slot independently: bound N2 artifact satisfies K0 at the current cut →
  REUSE CURRENT; otherwise (or unbound) → REDERIVE CURRENT (VAL: validator; ROUTER: N1 native). No history, no Γ, no
  witness search, no repair optimisation; algorithmically distinct from N5 even where observationally equal.
- **N3 (version pinning + exact interval join):** every artifact is pinned to the exact logical-version EVENT identities of
  its inputs (VAL: feed, LV event id, canonical hash, validation date, country, validator digest; ROUTER: region, LV event
  id + canonical hash of every feed, OSM, semantic config, OTP). Version interval I(v) = [available(v), available(next(v)))
  (final version: [available(v), +∞)), half-open; study-window boundary applied separately. Reuse at t only if every
  pinned event id equals the current realized version event, t ∈ the exact pin interval, all non-version pin fields match,
  and the artifact was born ≤ t. No catalog-wide search; no recurring-hash resurrection (A1→B→A2: an A1 pin never joins A2);
  otherwise REDERIVE CURRENT (ROUTER: N1 native). Pin/index creation, update and interval lookup: measured B_CONTROL_PLANE.
- **N4 (TTL):** τ ∈ {1, 6, 24, 72, 168} h exactly; per slot; age(t) = t − ARTIFACT_BORN; age < τ → reuse WITHOUT any
  contract/history check (may be stale — measured); age ≥ τ (incl. age == τ) or no artifact → REDERIVE CURRENT (VAL:
  validator; ROUTER: N1 native); an input change inside τ does NOT invalidate; failed re-derivation → no artifact, no
  fallback to the expired artifact (which stays only as historical N4 state); retry at the next request.
- **N6 (per-dataset validation cache):** VAL key = (feed_id, logical_version_event_id, canonical_content_sha256, country,
  validator_digest) — the consumer date is DELIBERATELY absent (cross-date reuse may be stale vs. the date-binding VAL
  contracts; measured, never corrected). Miss → run the validator at the current date; artifact-producing result (incl.
  SEMANTIC_FAIL) cached; infra failure / no artifact not cached. Hit → reuse; no history search, no contract evaluation
  before the decision. ROUTER in the N6 arm follows the N2 policy (current-cut K0 reuse else N1-native re-derivation).

## 4. N4 reference truth (directive §9)
UNSAFE_ADMISSION iff N4 reuses a cached artifact and the frozen K3 reference (VAL: validator re-run at the exact current
request context; ROUTER: rebuild + Canon_D under the exact current D) determines it invalid for that request. Reference
evaluation is offline / separate; N4 never sees it before deciding.

## 5. N4 τ-selection rule (directive §10) — frozen before any N4 output
For each τ ∈ {1, 6, 24, 72, 168}: run N4 on exactly the same 8 VALIDATION regions; U_τ = number of UNSAFE_ADMISSION
events over all eligible N4 reuse decisions; C_τ = total measured N4 online wall-clock cost (frozen accounting).
τ* = argmin over τ of the tuple (U_τ, C_τ, τ) lexicographically (fewest unsafe, then least cost, then smaller τ).
Producer failures are not unsafe admissions (their attempted work stays in C_τ; no-artifact requests reported
separately). OPERATIONAL_CAP: actual work up to the cap stays in C_τ; no unsafe admission unless an artifact was reused;
reported separately. A reuse whose K3 reference cannot produce a valid verdict is UNCLASSIFIABLE; if any τ has
unclassifiable reuse decisions affecting selection → N4 TAU SELECTION BLOCKED (unless the same cells are excluded for
every τ by an already-frozen rule). No F1 field enters the function. TEST never selects τ. The function is frozen from
this commit (implementation: engines/baselines_s4.py::select_tau; oracle tests S4A1-21).

## 6. Applications of already-frozen rules (stated for transparency; not new choices by this session)
- Shared scheduled production (PRE-S3 06 §5: executed once, shared by every method) is visible to N2/N3/N4/N6 exactly as
  to F1/N5/N1: each method binds the latest artifact-bearing instance from the SHARED catalog plus ITS OWN overlay with
  the frozen V1.2 binding rule; N0 by definition never reuses anything. For N6 the cache lookup ranges over the same
  admissible artifacts (shared + own) keyed as in §3.
- ROUTER artifacts produced by N1-native re-derivations in N2/N3/N4/N6 receive the frozen K0 identity (per-feed
  canonical hashes, OSM, semantic config, OTP) so that the N2/N6 K0 checks and the N3 pins apply uniformly.
If the PI disagrees with either application it must be amended before VALIDATION.

## 7. Files and tests
docs/s4a1/* (this amendment, final semantics, capability matrix, N4 rule), src/f1/workload_c/engines/baselines_s4.py,
tests/workload_c/test_s4a1_baselines.py (S4A1 gates). Amendment commit: recorded in SOURCE_IDENTITY.json /
docs/s4a1/AMENDMENT_COMMIT.txt.
