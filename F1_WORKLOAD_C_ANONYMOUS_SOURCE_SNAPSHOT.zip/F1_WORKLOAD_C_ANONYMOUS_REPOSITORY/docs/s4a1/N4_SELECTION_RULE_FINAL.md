# N4 τ-selection rule (FINAL, frozen pre-VALIDATION)

Candidates: τ ∈ {1, 6, 24, 72, 168} hours — no other value.
Inputs (VALIDATION only, same 8 regions for every τ): U_τ = count of UNSAFE_ADMISSION events (frozen K3 reference) over
eligible N4 reuse decisions; C_τ = total measured N4 online wall-clock seconds (frozen cost accounting, attempted failed
work included, work up to OPERATIONAL_CAP included).
Selection: τ* = lexicographic argmin of (U_τ, C_τ, τ).
Failures: not unsafe; cost kept; no-artifact requests reported separately. Cap: cost kept; not unsafe unless an artifact
was reused; reported separately. UNCLASSIFIABLE reuse affecting selection → selection BLOCKED.
No F1 field, no TEST data, no comparative gap. Frozen from the amendment commit; VALIDATION supplies only (U_τ, C_τ).
