# AMENDMENT-S4A-BASELINES-01A — implementation-integrity correction (pre-VALIDATION)

Scope: ONLY (a) PI confirmations of the three §6 applications (docs/s4a1/PI_CONFIRMATIONS_FINAL.md), (b) N3 pin
implementation correction, (c) N3 cost-accounting correction, (d) baseline-view accounting isolation, (e) N6 structural
cache hardening, (f) gate hardening. The baseline science of AMENDMENT-S4A-BASELINES-01 (preserved unchanged as
historical evidence; its hash is still gate-checked) is retained: no meaning of N0/N2/N3/N4/N6, no N4 candidate or
objective changes.

Timing: created before VALIDATION, before real population retrieval, before any N4 TTL outcome, and before TEST.
Motivation: an independent code audit reproduced two N3 implementation defects and one baseline-view accounting
contamination; no comparative result exists or was consulted.

| # | Defect | Correction |
|---|---|---|
| 1 | N3 VAL pin date taken from local_date(ARTIFACT_BORN) (wrong after local midnight) | pin built from the artifact's ACTUAL birth-time K0 contract footprint (date, country, validator / feeds, OSM, semantic config, OTP) + exact LV event ids; missing provenance → N3PinError → never pinnable (fail closed) |
| 2 | N3 pin/index work inside `admission` AND as `n3_pin_index` (double counted) | disjoint ControlTimer intervals: `n3_pin_index_lookup` (join) then `admission` |
| 3 | index work only at lookup | `n3_pin_index_update` (first-sight creation for bound/new artifacts, from N3's explicit pin index) vs `n3_pin_index_lookup` (index fetch + current pin + join) |
| 4 | view construction computed K0/pins/keys for every method inside `catalog_lookup` | method-specific projections; K0 only for N2/N6, pins only N3, N6 keys only N6; BaselineView refuses foreign metadata |
| 5 | N6 candidates from an unrestricted per-request catalog scan | explicit N6 exact-key cache index in method state (incremental `n6_cache_index_update`, `n6_cache_index_lookup`); the view admits exact-key candidates only |
| 6 | S4A1-17 contained a vacuous `or True` | removed; the A→B→A gate inspects the exact pin event ids of every N3 reuse |
Files: src/f1/workload_c/engines/baselines_s4.py, tests/workload_c/test_s4a1_baselines.py (S4A1-26…33), docs/s4a1/*.
