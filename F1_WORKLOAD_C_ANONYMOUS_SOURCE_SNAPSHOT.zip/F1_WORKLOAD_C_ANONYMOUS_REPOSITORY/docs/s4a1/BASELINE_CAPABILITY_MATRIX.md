# Baseline capability matrix (frozen pre-VALIDATION)

Columns: current-cut access | RealizedHistory access | historical artifact enumeration | own persistent artifacts | own cache |
shared scheduled catalog | method overlay | Γ access | K evaluator | producer access | K3 during decision | K3 offline
(evaluation only) | future information | router rebuild | VAL policy

| Method | current-cut | RealizedHistory | historical artifact enumeration | own persistent | own cache | shared scheduled | overlay | Γ | K evaluator | producer | K3 during decision | K3 offline | future information | router rebuild | VAL policy |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | yes | yes (validation of cuts) | no (fixed-R bindings only) | overlay | no | yes | own | yes | K0–K2 at Γ cuts | yes | no | yes (K3 reference path) | no | frozen producer | contracts |
| N0 | yes | no | no | no | no | no (never reused) | no | no | none | yes | no | no | no | full cold street+transit | always rerun |
| N1 | yes | no | no | native street/cache state | native OTP cache | VAL via N5(K0) | own | no | K0 (VAL) at current cut | yes | no | no | no | N1 native | N5(K0) |
| N2 | yes | no | no | overlay | no | yes | own | no | K0 at current cut | yes | no | no | no | N1 native | K0 rerun |
| N3 | yes | no (only CURRENT version events in its view) | no | overlay | pin index | yes | own | no | none (pins) | yes | no | no | no | N1 native | exact pin |
| N4 | yes | no | no | overlay | TTL (born times) | yes | own | no | none | yes | no | yes (offline U_τ) | no | N1 native | TTL |
| N5 | yes | no | no | overlay | no | yes | own | no | K at current cut | yes | no | no | no | frozen producer | contracts |
| N6 | yes | no | no | overlay | dataset key cache | yes | own | no | K0 (ROUTER only) | yes | no | no | no | N1 native | dataset cache (no date) |

Structural enforcement: BaselineView (engines/baselines_s4.py) reaches no RealizedHistory / ArtifactCatalog / ArtifactEntry /
witness type; S4Baseline.decide(view, evaluator, producers) only; evaluator is current-cut bound; producers are
current-cut bound (tests S4A1-20; N5/N1: S3-23…S3-28).
