# Contracts K0–K3 (`contracts/`)

`Contract` (immutable): schema F1-WC-CONTRACT-1, level, artifact class, artifact id, request slot, birth cut,
footprint (immutable references only), generator digest, evaluator digest (source digests), canonical bytes
(canonical JSON), SHA-256 digest, metadata size. Generated at artifact birth only; same artifact/spec → same bytes.

| Class | K0 | K1 | K2 | K3 |
|---|---|---|---|---|
| VAL | canonical hash + date + country + validator digest | per-file normalised hashes (all GTFS files) | = K1 | re-run validator (reference) |
| ROUTER | per-feed canonical hashes + OSM + semantic config + OTP | per-file hashes of the routing files | K2_D: per-feed projection over ActiveClosure_D + OSM + config + OTP; valid while D ⊆ service window | rebuild + Canon_D 1.3 (reference) |

K0 binds exactly the frozen identities (the horizon is not part of router K0 in the frozen definition; it enters K2/K3).
Routing files (K1) = the GTFS files from which Canon/K2 fields derive per matrices 03/09.
K2_D (`contracts/k2.py`) mirrors Canon_D's active closure at input level (services/trips/stop_times/frequencies/routes/
agencies/stops+stations+entrances+boarding areas/levels/transfers/pathways touching active elements); display-only
fields excluded per the matrices. Evaluation (`ContractSystem.evaluate`) recomputes the footprint from the candidate
cut's immutable blobs (and, for K2, the birth inputs over the consumer's D) → VALID / INVALID / ERROR; any exception,
tampered bytes, foreign evaluator digest or missing data → ERROR (never VALID); K3 via ordinary evaluation → ERROR.
K3 runs only through `ReferencePath` (explicit producer re-execution).
