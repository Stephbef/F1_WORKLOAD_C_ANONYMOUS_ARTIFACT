# Time and DST (`scheduler/timeutil_local.py`)

All schedule logic uses IANA agency time zones (`zoneinfo`) and UTC instants in canonical form; local trigger times are
resolved per local date: a non-existent local time moves to the next valid minute; an ambiguous local time takes its
first occurrence (frozen spec17 §4). Every trigger/tick records the rule applied. Tested: ordinary day, DST forward
(Europe/Paris 2025-03-30 02:00 → 03:00 CEST; America/New_York 2025-03-09 02:30 → 03:00 EDT), DST backward
(Europe/Paris 2025-10-26 02:00 → first, 00:00Z; New York 2025-11-02 01:30 → first, 05:30Z), southern hemisphere,
simultaneous feed updates, update exactly at trigger, completion exactly at consumer tick, queue overlap.
Note: the frozen spec names "Java 25 tzdata"; Python uses the host tzdata — the tzdata version is a host fact to be
recorded on the server (Session 4 seal).
