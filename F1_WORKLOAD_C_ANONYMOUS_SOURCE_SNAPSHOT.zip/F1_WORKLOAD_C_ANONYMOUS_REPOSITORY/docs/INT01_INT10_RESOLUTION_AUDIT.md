# INT-01 … INT-10 (+ SCH-01) — final register (PRE-S3 freeze)

All items are **FROZEN_PRE_S3**: frozen by the PRE-S3 scientific closure directive (§5) before any study outcome existed.
Canonical machine record: `configs/workload_c/spec_interpretations.json` (status PI_CONFIRMED). The Session-2 version of this
audit (with alternatives and UNRESOLVED statuses) is preserved in Git history (commit f1e9368). Changing any item is a
CLASS S1 scientific change (13_VALIDATION_TEST_FIREWALL.md).

## INT-01

- **ID:** INT-01
- **Issue:** spec17 §3 'using the version in force at 2025-04-01'
- **Current implementation:** in_force_instant_utc = 2025-04-01T00:00:00Z; latest logical version with first_observed_utc <= that instant
- **Authoritative frozen evidence:** spec17 §3; V3 10 'at window start'
- **Resolution:** frozen by PRE-S3 directive §5 (Session-2 state: in_force_instant_utc parameter (UNRESOLVED in S2))
- **Code affected:** regions/eligibility.py, campaign/dataplane.py
- **Tests affected:** test_s1_15_17_spatial_regions.py, test_pre_s3_closure.py
- **Status:** FROZEN_PRE_S3

## INT-02

- **ID:** INT-02
- **Issue:** spec17 §3 'logical history covering 2025-04-01..2026-06-30 with no gap > 30 days'
- **Current implementation:** history_gap_basis = archive_observations; an OK archive observation at or before 2025-04-01T00:00:00Z is required; gaps between consecutive OK observations clipped to [2025-04-01T00:00:00Z, 2026-07-01T00:00:00Z) including start->first and last->end boundary gaps; fail iff gap > 30*86400 s (exactly 30 days allowed)
- **Authoritative frozen evidence:** spec17 §3; V1/V2 provenance speak of archive gaps
- **Resolution:** frozen by PRE-S3 directive §5 (Session-2 state: archive-observation basis behind a parameter with a logical-version alternative (UNRESOLVED in S2))
- **Code affected:** regions/eligibility.py::history_check
- **Tests affected:** test_s1_15_17_spatial_regions.py::test_history_rule_boundaries, test_pre_s3_closure.py
- **Status:** FROZEN_PRE_S3

## INT-03

- **ID:** INT-03
- **Issue:** spec17 §3 'Total zip size <= 500 MB'
- **Current implementation:** MB = 1,000,000 bytes; sum of raw byte sizes of the latest archive of each region feed
- **Authoritative frozen evidence:** spec17 §3; V5 'latest-zip size'
- **Resolution:** frozen by PRE-S3 directive §5 (Session-2 state: 10^6 bytes behind a parameter accepting 2^20 (UNRESOLVED in S2))
- **Code affected:** regions/construct.py
- **Tests affected:** test_s1_15_17_spatial_regions.py::test_region_construction_bounds_and_ids
- **Status:** FROZEN_PRE_S3

## INT-04

- **ID:** INT-04
- **Issue:** spec17 §3 stop pairs within 400 m / hulls within 2 km
- **Current implementation:** boarding points only (location_type blank/missing/0, valid coordinates) for stop pairs and hulls; haversine, R = 6,371,008.8 m; inclusive thresholds (resolved in Session 2, unchanged)
- **Authoritative frozen evidence:** V3 10 / V5 18 great-circle; Session-2 directive §3.5
- **Resolution:** frozen by PRE-S3 directive §5 (Session-2 state: boarding points (RESOLVED_ENGINEERING in S2))
- **Code affected:** ingestion/gtfs.py, regions/connectivity.py
- **Tests affected:** test_s1_corrections.py
- **Status:** FROZEN_PRE_S3

## INT-05

- **ID:** INT-05
- **Issue:** spec17 §3 'bounding-box diagonal <= 500 km'
- **Current implementation:** great-circle distance between (min_lat,min_lon) and (max_lat,max_lon) of the latest logical version's GTFS stop coordinates; catalog bbox metadata is not used
- **Authoritative frozen evidence:** spec17 §3
- **Resolution:** frozen by PRE-S3 directive §5 (Session-2 state: latest-version stop bbox (UNRESOLVED in S2))
- **Code affected:** campaign/dataplane.py::compute_feed_facts
- **Tests affected:** test_s1_15_17_spatial_regions.py
- **Status:** FROZEN_PRE_S3

## INT-06

- **ID:** INT-06
- **Issue:** spec17 §3 / V5 'merged bundles ... agency_id overlap >= 50 %'
- **Current implementation:** identity = exact agency_id (blank ids carry no identity; agency_name never used); overlap = |A∩B|/min(|A|,|B|) >= 0.5; drop the feed with the strictly larger agency_id set; equal cardinality -> keep both (no tie-breaker)
- **Authoritative frozen evidence:** V5 18 'agency_id overlap ≥ 50 %'
- **Resolution:** frozen by PRE-S3 directive §5 (Session-2 state: agency_id identity; overlap coefficient denominator UNRESOLVED in S2)
- **Code affected:** regions/dedup.py
- **Tests affected:** test_s1_corrections.py, test_pre_s3_closure.py::test_int06_equal_cardinality_keeps_both
- **Status:** FROZEN_PRE_S3

## INT-07

- **ID:** INT-07
- **Issue:** spec17 §3 'redirects; identical URL or canonical hash; aliases'
- **Current implementation:** transitive collapse; survivor = smallest canonical feed id (implementation string order); URL: lowercase scheme/host, default port removed, trailing slash removed; alias key = normalised (provider, feed_name); rule order redirect, URL, canonical hash, alias, merged bundle
- **Authoritative frozen evidence:** spec17 §3; V5 18
- **Resolution:** frozen by PRE-S3 directive §5 (Session-2 state: smallest-id survivor etc. (UNRESOLVED in S2))
- **Code affected:** regions/dedup.py
- **Tests affected:** test_s1_13_14_license_dedup.py
- **Status:** FROZEN_PRE_S3

## INT-08

- **ID:** INT-08
- **Issue:** spec17 §3 'same agency_timezone'
- **Current implementation:** unique agency_timezone of the in-force version; several distinct values -> undefined -> no edge (resolved in Session 2, unchanged)
- **Authoritative frozen evidence:** spec17 §3; GTFS reference (single agency timezone)
- **Resolution:** frozen by PRE-S3 directive §5 (Session-2 state: unique agency timezone (RESOLVED_ENGINEERING in S2))
- **Code affected:** ingestion/gtfs.py, regions/connectivity.py
- **Tests affected:** test_s1_15_17_spatial_regions.py
- **Status:** FROZEN_PRE_S3

## INT-09

- **ID:** INT-09
- **Issue:** (unspecified) unretrievable / malformed archives
- **Current implementation:** feed excluded with ARCHIVE_UNRETRIEVABLE / MALFORMED_GTFS; failed archives never become logical-version events; the population run is not hard-failed by one unusable candidate
- **Authoritative frozen evidence:** not addressed by frozen text
- **Resolution:** frozen by PRE-S3 directive §5 (Session-2 state: feed exclusion (UNRESOLVED in S2))
- **Code affected:** campaign/dataplane.py, regions/eligibility.py
- **Tests affected:** test_s1_29_fixture_population.py
- **Status:** FROZEN_PRE_S3

## INT-10

- **ID:** INT-10
- **Issue:** spec17 'licence class A/B/C' identifier mapping
- **Current implementation:** configs/workload_c/license_identifier_table.json (audited, PI_CONFIRMED); unknown identifiers / URLs, missing or conflicting evidence -> D (UNCLEAR)
- **Authoritative frozen evidence:** V4 03 classes; V3 02 examples
- **Resolution:** frozen by PRE-S3 directive §5 (Session-2 state: identifier table UNCONFIRMED in S2)
- **Code affected:** licensing/engine.py, configs/workload_c/license_identifier_table.json
- **Tests affected:** test_s1_13_14_license_dedup.py, test_pre_s3_closure.py
- **Status:** FROZEN_PRE_S3

## SCH-01

- **ID:** SCH-01
- **Issue:** spec17 §4 'OTP: 02:00 local if newer inputs exist'
- **Current implementation:** otp_newer_than = last_successful_build: inputs are compared with those of the last SUCCESSFUL build; with no successful build the current input state requires an attempt; a failed attempt never becomes the reference; one build per region; trigger skipped while a build runs
- **Authoritative frozen evidence:** spec17 §4
- **Resolution:** frozen by PRE-S3 directive §5 (Session-2 state: parameter defaulting to last_completed_build (UNRESOLVED in S2))
- **Code affected:** scheduler/workload_c.py (FROZEN_OTP_NEWER_THAN, scientific_policy)
- **Tests affected:** test_s2_contracts_history.py::test_otp_sch01_frozen_last_successful_build
- **Status:** FROZEN_PRE_S3
