# Canon integration (`producers/canon.py`, `conformance/harness.py`)

The frozen `06_CANON_EXTRACT_FINAL.java` (F1-OTP-CANON-1.3) is used byte-for-byte: SHA-256 checked against the frozen
spec, copied as `CanonExtractFinal.java`, compiled with the pinned javac 25.0.4.1 against the pinned OTP jar into a
content-addressed classes directory, executed as `java -Xmx2G -Duser.timezone=UTC -cp otp.jar:classes
CanonExtractFinal graph.obj D out configSha osmSha otpSha`. `CanonRunner.run` returns `CanonResult` (status, `CanonDigest`
{schema, sha256, records}, canonical bytes digest — verified equal to the printed digest —, path, horizon, config/OSM/OTP
bindings, router artifact id, binary mode, source digest, wall time). No redesign, no added reflection.
All 146 frozen conformance fixture files and expectations are imported under `frozen_specs/authoritative/conformance/`
(verified against the baseline SHA256SUMS). Results with the real binaries in this session: frozen harness unmodified
35/35 + D1–D10/DF PASS + C1–C8 PASS; integrated harness (Session-2 code path) — see `reports/conformance/` — with every
Canon digest compared to the frozen recorded results (`11_ORACLE_TEST_RESULTS_FINAL.csv`).
