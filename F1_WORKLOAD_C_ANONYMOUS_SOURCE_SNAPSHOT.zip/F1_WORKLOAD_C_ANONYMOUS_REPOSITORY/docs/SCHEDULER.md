# Scheduler (`scheduler/workload_c.py`)

Deterministic discrete-event simulation of spec17 §4 with values from the frozen spec `schedule` section (checked
against spec17 text at load): validator jobs queued at availability, region FIFO by (availability, feed, index), one
worker; OTP trigger 02:00 local, build only if newer inputs, inputs = latest available (availability ≤ trigger
included), one build per region, trigger skipped while a build runs; consumer tick 06:00 local, artifacts completed
≤ tick visible. Tie order at equal instants: availability < completion < OTP trigger < validator start < consumer tick.
SCH-01 is FROZEN (PRE-S3): `otp_newer_than = last_successful_build` (default and only scientific policy;
`last_completed_build` survives for provenance/unit tests and is refused by `scientific_policy()`). Durations/outcomes from an explicit backend:
`FIXTURE_DURATION_BACKEND` or `REAL_MEASURED_BACKEND` (recorded in every completion event; a ledger never mixes them).
Output event ledger + digest; `scheduler/ledger.py` writes it into the realized-history DAG with causal predecessors.
Determinism: identical ledgers under input permutation (tested over 10 permutations).
