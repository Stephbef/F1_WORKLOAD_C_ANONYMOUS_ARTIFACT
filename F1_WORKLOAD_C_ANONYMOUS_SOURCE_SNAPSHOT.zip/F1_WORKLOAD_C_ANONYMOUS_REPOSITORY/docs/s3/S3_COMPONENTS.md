# Session-3 components (behind F1-WC-S3-INTERFACES-V1.2; interface file unchanged)

| Interface | Implementation | Notes |
|---|---|---|
| WitnessSearch | engines/f1.py::WitnessSearchImpl | Γ_t candidates in frozen order; whole R_t at ONE cut; JointWitness with temporal + Γ evidence; no catalog access |
| AdmissionEngine | engines/f1.py::AdmissionEngineImpl | REUSE/CURRENT → REUSE/HISTORICAL → REDERIVE (RepairPlan) → NO_ARTIFACT; B costs recorded |
| RepairEngine | engines/f1.py::RepairEngineImpl | S(c) = unbound ∪ failing; OPT slot-set sums of est(s,t); historical only if strictly cheaper; execution via core.execute_plan (serial, canonical, fail-fast) |
| CostModel | engines/core.py::CostModelImpl | ordinary arithmetic median over PriorCostView (shared SUCCESS runs < t), priors 600/5400 s; online = A + B |
| N5Baseline | engines/baselines_n.py::N5BaselineImpl | CurrentCutView only + current-bound evaluator/rederiver |
| N1Baseline | engines/baselines_n.py::N1BaselineImpl | VAL via N5(K0) path; ROUTER via NativeOtpBuilder (Fixture / Real; AMENDMENT-S3-N1-01) |
| ReplayEngine | engines/replay.py::ReplayEngineImpl | verifies sealed digests; read-only reconstruction; recorded producer outcomes; logical-field comparison incl. binding digest |
| MutationEngine | engines/mutation.py::MutationEngineImpl | authoritative ranked 5 % sample; frozen families; INVALID_MUTATION fail-closed; oracle subjects from frozen corpus |
| StatisticsExporter | engines/stats.py::StatisticsExporterImpl + RawExportLog | one-shot registration bridge (binding digest), hash-chained append-only JSONL |
| FrozenAnalysis | engines/stats.py::FrozenAnalysisImpl | per-region HSR / ΔCost / ΔE2E / native contrast; sign test; BCa; wild; Holm(4); inconclusive rule |

Orchestration glue: engines/core.py (RegionState, binding rule MethodCatalog.bind, CutContextFactoryImpl,
GammaAdmissibilityImpl, InProcessFixtureProducer, ProducerRederiver, current-bound wrappers), engines/runner.py
(RegionCampaign: shared production, per-arm overlays, arm order N5, N1, F1; sealing), campaign/s3_phases.py
(Phases 11, 13–16), campaign/e2e_s3.py (traces T1–T4).

## Interpretations approved by the PI (Session-3 review)
- Root-change unit: newly available logical version whose canonical content differs from the immediately preceding
  realized version of the feed; the window-start in-force version is baseline (engines/runner.py::root_change_units).
- Contributing region: region-level statistic DEFINED after frozen denominator/exclusion rules, counted before the
  sign test drops zeros.
- Validator contracts bind the consumer validation date (a VAL artifact is valid only for its date).
- Repaired artifact born at t + cumulative executed serial durations; information boundary stays t.
- `INFEASIBLE` = non-artifact outcome when required inputs do not exist at t (distinct from failures/timeouts).
- Export registration hook: implementation-private, one-shot, digest-validated (S3-36).

## Fixture campaign note
The orchestrator fixture campaign uses the synthetic Session-1 population with consumer ticks on three fixture
dates; its validator artifacts are always from earlier consumer dates and Γ_t is empty, so every decision is a
current-cut re-derivation. This is NOT tuned; history behaviour is covered by the frozen T1–T4 traces.
