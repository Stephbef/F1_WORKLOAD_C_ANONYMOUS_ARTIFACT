# AMENDMENT-S3-N1-01 — N1 cache/persistence evidence rule (pre-VALIDATION)

**Authority:** PI decision (a) of the Session-3 review ("Choose (a)…", §1). **Class:** S1 at stage IMPLEMENTATION
(before any validation/TEST access; ChangeRecord S3-CR-05). **Trigger:** discovered semantics of the pinned OTP 2.10.0
binary — its graph-build cache (`org.opentripplanner.graph_builder.module.cache.CacheTask`) has exactly two tasks,
ELEVATION and VISIBILITY; under the frozen graph configuration (no elevation input; `areaVisibility` absent = OTP
default false; OTP logs "Skipping visibility graph construction for walkable areas") neither applies, so
`cache.enabled=true` writes no cache file.

**Previous rule (preserved in Git history: docs/pre_s3/09 + engines/baselines_n.py at c9d314a):** "If cache activity
cannot be evidenced, the N1 run is BLOCKED."

**Amended rule.** The N1 mechanism is UNCHANGED (pinned OTP 2.10.0, persisted street graph, `--loadStreet`,
`cache.enabled=true`, identical authoritative OTP envelope, N1's own measured costs). N1 cache/persistence
conformance is PASS iff ALL hold (implemented in `engines/baselines_n.py::RealNativeOtpBuilder.build`, evidence
recorded in `last_evidence`, tested by S3-26/S3-29):
1. exact pinned OTP binary (jar SHA-256 recorded = 8acd2808…);
2. exact frozen graph configuration (`build_config_for` of the F1 router producer; `frozen_config_identical`);
3. `cache.enabled=true` in the effective configuration;
4. persisted `streetGraph.obj` actually loaded (OTP log "Reading graph from …streetGraph.obj");
5. the set of cacheable tasks of THIS binary is read from the jar (`otp_cache_tasks`: enum constants of CacheTask)
   and every task is shown inapplicable under THIS configuration (`applicable_cache_tasks`);
6. ELEVATION: no elevation key in build-config and no DEM file in the base directory; VISIBILITY: `areaVisibility`
   not true AND the OTP street-build log shows visibility construction skipped;
7. no scientific configuration changed to create a cache hit (none: config compared to the frozen generator);
8. cache directory/state (manifest before/after) and OTP log paths retained as evidence;
9. status reported literally as `CACHE_ENABLED_NO_CACHEABLE_TASK_UNDER_FROZEN_CONFIG` (never as a cache hit);
10. N1's native rebuild cost = the measured wall time of the executed `--loadStreet --save` run.
Unknown task names are never assumed inapplicable (→ BLOCKED). An applicable task without cache activity → BLOCKED.
