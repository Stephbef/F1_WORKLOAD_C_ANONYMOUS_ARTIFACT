# Validator producer (`producers/validator.py`)

`GtfsValidatorProducer.produce(ValidatorRequest)` → `ValidatorOutcome(failure_class, val_report, val_gate, provenance)`.
Command (REAL): `java -Xmx4g -Duser.timezone=UTC -Djava.io.tmpdir=<job> -jar gtfs-validator-8.0.1-cli.jar -i <zip> -o <job>/out
-d <consumer date> -c <country> -svu -t 1` — exact frozen flags (spec17 §1, envelope 14). Executed as an argv array with a
minimal environment, `unshare -rn` network isolation, optional resource scope, bounded by the 24 h operational cap.
Input pre-check: unreadable ZIP → `INVALID_INPUT` (producer not invoked).
Artifacts: `VAL_REPORT` (raw report stored immutably + semantic projection {validatorVersion, dateForValidation,
countryCode, sorted notices}; volatile timing/paths excluded; its digest is the report identity) and `VAL_GATE`
(PASS iff zero ERROR notices). Both record request slot, region, feed, logical version, birth cut, date, country,
validator digest, binary mode. ERROR notices → `SEMANTIC_FAIL` (artifact exists); timeout/crash/corrupt report/OOM →
infrastructure classes (no artifact; never semantic FAIL). Session-1 protocol `ValidatorProducer` is kept by the mocks.
Verified with the real pinned jar on JDK 25.0.4.1 (frozen fixture with `invalid_row_length` ERRORs → FAIL; synthetic
WARNING-only feed → PASS; deterministic report digest).
