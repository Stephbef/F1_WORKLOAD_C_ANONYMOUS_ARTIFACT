# 04 — SCH-01 final policy

**Frozen:** `otp_newer_than = last_successful_build` (register parameter; `scheduler.workload_c.FROZEN_OTP_NEWER_THAN`;
`simulate()` default; `scientific_policy()` refuses any other value).
At each 02:00-local trigger: skip if a build is running; otherwise build iff every feed has a version and the latest
available input vector differs from the inputs of the last SUCCESSFUL build (or no successful build exists). A failed
attempt never becomes the reference, so the same inputs are retried at the next eligible trigger. All other schedule
rules and tie ordering are unchanged.
**Change from Session 2:** the Session-2 default was `last_completed_build` (a failed build suppressed retries of the
same inputs). The alternative is retained only for provenance/unit tests.
**Tests:** test_s2_contracts_history.py::test_otp_sch01_frozen_last_successful_build (cases A–E), P3-04.
