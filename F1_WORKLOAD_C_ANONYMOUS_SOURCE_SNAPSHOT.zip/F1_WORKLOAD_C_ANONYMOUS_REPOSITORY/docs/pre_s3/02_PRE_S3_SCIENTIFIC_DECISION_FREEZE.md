# 02 — PRE-S3 scientific decision freeze

Frozen by the PRE-S3 directive before any study outcome existed (no study population, split, TEST region or outcome
has ever been accessed). Changing any of these is a CLASS S1 change (13_VALIDATION_TEST_FIREWALL.md).

| Item | Frozen decision | Category |
|---|---|---|
| INT-01 | in-force instant 2025-04-01T00:00:00Z (latest version with first_observed ≤ it) | FROZEN SCIENTIFIC DECISION |
| INT-02 | archive-observation gap basis; observation ≤ start required; clipped gaps incl. both boundary gaps; fail iff > 30·86400 s | FROZEN SCIENTIFIC DECISION |
| INT-03 | MB = 10^6 bytes; latest archive of each region feed | FROZEN SCIENTIFIC DECISION |
| INT-04 | boarding points only; haversine R = 6,371,008.8 m; inclusive (Session 2, unchanged) | FROZEN (unchanged) |
| INT-05 | bbox diagonal from latest-version GTFS stops | FROZEN SCIENTIFIC DECISION |
| INT-06 | exact agency_id; overlap coefficient ≥ 0.5; drop strictly larger set; equal cardinality keeps both | FROZEN SCIENTIFIC DECISION |
| INT-07 | transitive collapse, smallest canonical feed id survivor, URL/alias normalisation as implemented | FROZEN SCIENTIFIC DECISION |
| INT-08 | unique agency timezone else undefined (Session 2, unchanged) | FROZEN (unchanged) |
| INT-09 | exclude feed with ARCHIVE_UNRETRIEVABLE / MALFORMED_GTFS; no population hard-fail | FROZEN SCIENTIFIC DECISION |
| INT-10 | audited licence table, PI_CONFIRMED; unknown → D | FROZEN SCIENTIFIC DECISION |
| SCH-01 | otp_newer_than = last_successful_build | FROZEN SCIENTIFIC DECISION (changed default) |
| Session-3 semantics | 06–12 specs: R_t, Γ_t, witness order, decision orders, cost accounting, N1/N5, replay, mutations, export, analysis | FROZEN SCIENTIFIC DECISION |
| N5 interface | `N5Baseline.decide(view: CurrentCutView)` (no catalog/history) | FROZEN INTERFACE |

Audit: none of these contradicts frozen_specs/authoritative (checked against spec17 §3–§10, 08, 14, 16 FIXED-R).
Physical L28 remains a FUTURE SERVER GATE (NOT_EXECUTED_ON_TARGET).
