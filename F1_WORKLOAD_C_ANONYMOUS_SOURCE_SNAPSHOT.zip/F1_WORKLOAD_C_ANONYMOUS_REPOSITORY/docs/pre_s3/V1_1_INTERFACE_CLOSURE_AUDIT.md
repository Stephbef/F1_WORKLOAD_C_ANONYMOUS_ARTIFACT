# V1.1 interface-closure audit (independent, type-level)

Scope: the ten Session-3 interfaces in `src/f1/workload_c/interfaces/session3.py` (F1-WC-S3-INTERFACES-V1.1). Only data
structures and security boundaries changed; no scientific rule changed (Γ, witness order, decision order, repair
objective, tie → current, fixed-R, K levels, Canon, N1 mechanism, N5 definition, cost formulas, tests, hypotheses,
mutations, population rules, schedules, resources, INT-01…10, SCH-01 are byte-identical in their frozen sources).

## Defects found in the PRE-S3 (V1.0) interface and their repair

| # | V1.0 defect | V1.1 repair | Gate |
|---|---|---|---|
| 1 | `ConsumerRequest.request_slot: str` (single slot) cannot represent the joint R_t | joint `ConsumerRequest.request_slots` (canonical order) + `request_id`; `RequestBinding` | P3-13 |
| 2 | `Witness.artifact_id: str` cannot carry the slot→artifact binding of R_t | `JointWitness` of `WitnessBinding`s at ONE cut + `TemporalEvidence` + `GammaEvidence` | P3-14 |
| 3 | spec said action refined by `mode`, datatype had no `mode`; repair info only in `cost: dict` | `Action` + `Mode` enums, invariants, typed `RepairPlan`/`RederivationStep`, typed `CostRecord` | P3-15 |
| 4 | `CurrentCutView` embedded `ArtifactEntry` (exposes `instance`, `rederived_from`) | sanitized `BoundArtifact`; `CurrentCutView = RequestBinding`; current-bound evaluator/rederiver | P3-16 |
| 5 | `N1Baseline.decide(req, catalog: ArtifactCatalog)` exposed the full F1 history | `N1CurrentView` + own `NativeOtpState` + `NativeOtpBuilder`; `N1Outcome` | P3-17 |
| 6 | `CostModel.rederive_cost(slot, cut)` had no t (hidden tick state needed) | `estimate_rederive(slot, producer_class, tick_utc, prior: PriorCostView)`; `PriorCostView.before` | P3-18 |
| 7 | firewall: S1 post-validation needed only an amendment; E2 only an issue id | restart flag + evidence id; semantic-preservation evidence | P3-19 |
| 8 | replay/export/analysis exchanged `list[dict]` / `dict` | `RawExportRecord`, `SealedLedger`, `ReplayReport`, `Mutation*`, `AnalysisReport`, `HypothesisResult` | P3-20 |

## Per-interface answers (1 represent inputs, 2 represent outputs, 3 over-exposure, 4 hidden state, 5 S3 change needed)

| Interface | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| WitnessSearch(binding, level, history, contexts, gamma, evaluator) → JointWitness/None | yes | yes | no (F1 may use history) | no | no |
| AdmissionEngine(binding, level, history, contexts, gamma, evaluator, witness_search, repair, rederiver) → AdmissionDecision | yes | yes | no | no | no |
| RepairEngine.plan(...) → RepairPlan/None; execute(plan, rederiver, tick) → RepairPlan | yes | yes | no | no | no |
| CostModel.estimate_rederive(slot, producer_class, tick, prior); online_cost(record) | yes | yes | no (prior strictly before t) | no | no |
| N5Baseline.decide(view, level, evaluator, rederiver) | yes | yes | no (type-reachability checked) | no | no |
| N1Baseline.decide(view, evaluator, rederiver, native) → N1Outcome | yes | yes | no | no (state passed in/out explicitly) | no |
| ReplayEngine.replay(ledger, records) → ReplayReport | yes | yes | n/a (offline) | no | no |
| MutationEngine.plan(population) → MutationPlan; apply(artifact_id, family) → MutationResult | yes | yes | n/a | no | no |
| StatisticsExporter.export(decision, run, root_changes, tick_local, gamma_size, scheduler_state_digest) → RawExportRecord | yes | yes | n/a | no | no |
| FrozenAnalysis.run(records, namespace) → AnalysisReport | yes | yes | n/a (raw export only) | no | no |

Residual notes (not interface defects): `Contract.footprint` and `EvaluationContext.feeds` are Session-2 dict-typed
records; they are hashed, immutable-by-convention inputs of the evaluator and carry only the visible artifact's own
birth/input provenance. `MutationEngine.apply` receives only an artifact id; the engine resolves it from its own sealed
inputs, injected at construction (no global state).
