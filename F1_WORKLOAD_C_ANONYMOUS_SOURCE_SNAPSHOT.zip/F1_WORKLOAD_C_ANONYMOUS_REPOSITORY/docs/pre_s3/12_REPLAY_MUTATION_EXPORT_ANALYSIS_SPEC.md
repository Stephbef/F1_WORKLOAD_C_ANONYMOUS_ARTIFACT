# 12 — Replay, mutations, raw export, frozen analysis

## 1. Replay
Input: sealed ledgers (history journal, catalog journals incl. overlays, contracts, raw decision export, measured cost
ledger). Replay recomputes every decision with the same engines and the recorded est() values, using only events ≤ t,
never re-running producers (recorded outcomes) and never mutating the inputs. Output: per decision REPRODUCED /
NOT_REPRODUCED with source-event provenance. Replay is never used to obtain a different decision rule.

## 2. Mutations (authoritative spec17 §10; operational definitions from provenance V4 18 / V5 22)
- **Sample**: per artifact class (template), TEST artifact ids sorted, ranked by SHA-256(seed_bytes("mutation") ||
  0x00 || UTF8(id)) ascending, top ceil(0.05·n) (authoritative "ranked with the mutation seed" supersedes V4's shuffle).
- **Contract-dependency drops** (mutant K2/K-contract omits one dependency; detection = Canon_D changes on an
  opportunity where the omitted dependency changed while the mutant admits): stop_times, frequencies, calendar_dates,
  transfers, block_id, coordinates, pathways (traversal time, slope, steps), wheelchair, route_type, timezones,
  namespace (drop feedId binding), horizon (shortened to 3 days), validator date (drop from VAL K0/K1), validator file
  (omit one file from VAL K1).
- **Negative control**: shapes (reverse): reversing shapes must leave Canon_D and K2 unchanged.
- **Input mutations** (expected outcomes frozen): M-FUTURE-1 future-only trip → Canon_D unchanged, K2 holds;
  M-FUTURE-2 same trip shifted into D → Canon_D changes, K2 rejects; M-CT constrained-transfer (transfers.txt) change
  between active stops → both change; M-FREQ frequency window moved into / out of D → both change / both unchanged;
  M-STOP-ACTIVE coordinates of a stop served by an active trip → both change; M-STOP-INACTIVE same for a stop served
  by no active trip → both unchanged; M-AGENCY-ACTIVE agency_timezone of an agency of an active route → both change;
  M-AGENCY-FUTURE same for an agency referenced only by routes without trips in D → both unchanged. (Operationalised
  by the pattern of the frozen descriptions and the 08 K2 alignment: active-closure members change both, non-members
  change neither.)
- Invalid mutations (target absent, not applicable to the artifact class) fail closed (recorded INVALID_MUTATION, never
  silently skipped). Mutations are evaluation of contracts, not scientific outcomes; no family may be added later.

## 3. Raw export (append-only, provenance-linked; one record per method × K × request)
namespace, run identity, code/config digests, region, root logical-content change ids (all whose influence period
contains t), consumer tick (UTC + local), request slots, method, K, current cut, Γ size, witness cut, action + mode,
bound artifact ids, contract ids, per-contract verdicts, re-derivation events (slot, cut, producer, outcome, provenance
digest), A and B costs, est() values, OPT_current, OPT_hist, failures (class), scheduler state digest, excluded flag
(+ reason). Aggregates are computed ONLY from this export.

## 4. Frozen analysis
- **Unit**: region × distinct root logical-content change (feed f, logical version v). Influence period =
  [available(v), available(v+1)) ∩ window. A tick is attributed to every root change whose influence period contains
  it. Γ variants, ticks, duplicate content and request cells are not units.
- **HSR_witness(K)** per region = #units with ≥ 1 attributed tick where c_cur ∉ W and ∃ c ≠ c_cur ∈ W, divided by
  #units with ≥ 1 attributed tick where c_cur ∉ W. **HSR_repair(K)** = #units with ≥ 1 attributed tick where W = ∅,
  OPT_current > 0 and OPT_hist < OPT_current, divided by #units with ≥ 1 tick where W = ∅ and OPT_current > 0.
  Primary estimate = mean of per-region proportions over regions with a non-zero denominator (zero-denominator regions
  excluded and counted); exact binomial for "≥ 1 event in a region".
- **ΔCost_history** = OPT_current − min(OPT_current, OPT_hist) per tick with W = ∅; reported per region (sum) and per
  unit (mean). **ΔE2E_history(K2)** per region = Cost_N5(K2) − Cost_F1(K2) (11 §2); **H_native** per region
  Cost_F1(K2) − Cost_N1.
- **Exclusions**: operational-cap instants (all methods); ticks with an evaluation ERROR (counted, excluded from HSR);
  ticks where R cannot be formed (no instance and re-derivation infeasible) are excluded from HSR denominators and
  counted; NO_ARTIFACT outcomes remain in cost totals.
- **Inference** (reporting order: raw per-region → #regions → #root changes → exact sign test → BCa bootstrap
  B = 9,999 (bootstrap seed) → wild-cluster bootstrap, Rademacher (wild-bootstrap seed)). Hypotheses (one-sided):
  H_witness HSR_witness(K0) > 0; H_repair HSR_repair(K0) > 0; H_hist ΔE2E_history(K2) > 0; H_native Cost_F1(K2) <
  Cost_N1. Exact one-sided sign tests over regions (zeros dropped); Holm over exactly these four at α = 0.05.
- **Inconclusive** (V2 provenance): fewer than 3 regions contributing events, or a CI including 0 ⇒ INCONCLUSIVE.
- VALIDATION regions: used only for N4's TTL τ selection and engineering defect detection; never in TEST statistics.

## 5. V1.1 typed records (normative; content unchanged)
Raw export = `RawExportRecord` (all §3 fields typed; no untyped scientific dictionaries; `record_digest`), replay =
`ReplayEngine.replay(SealedLedger, records) -> ReplayReport` (per record REPRODUCED / NOT_REPRODUCED + source event
ids), mutations = `MutationPopulation` / `MutationPlan` / `MutationResult` (APPLIED | INVALID_MUTATION), analysis =
`FrozenAnalysis.run(records, namespace) -> AnalysisReport` with one `HypothesisResult` per frozen hypothesis (P3-20).

## 6. V1.2 inference determinism (normative)
Region is the bootstrap/wild-bootstrap cluster; BCa (B = 9,999, bootstrap seed, leave-one-region-out jackknife
acceleration, two-sided 95 %), wild-cluster Rademacher (B = 9,999, wild-bootstrap seed), exact sign test — exact
formulas, RNG and order-statistic rule in V1_2_DETERMINISTIC_FREEZE.md §5; vectors in V1_2_REFERENCE_VECTORS.json.
