# 11 — Cost accounting (frozen before results)

## 1. Categories
- **A — producer cost (measured)**: wall-clock seconds (primary) and CPU seconds (secondary) of every producer
  process executed on demand by a method (validator, OTP, Canon when part of a producer step), under the frozen
  envelope of that producer, INCLUDING failed and timed-out attempts.
- **B — control-plane cost (measured)**: wall seconds of contract evaluation, witness search, Γ construction, catalog
  lookup/indexing, repair optimisation, journal/fsync, measured in the method's own process under the F1/N5 envelope
  (2 cores, 8 GB, single-threaded).
- **C — offline cost (excluded)**: replay, statistics, export, oracle (Canon/K3) checks done for evaluation only.
  Never charged as online cost.

## 2. Online cost of a method in a region
Cost_M = Σ over consumer ticks in the window of (A + B incurred by M for that tick) + M's amortised preprocessing
(N1: street graph build + cache creation; F1/N5: parse/feature caches and logical-version hashing are SHARED and
identical, hence charged equally to all methods). Shared scheduled production (validator at availability, OTP at
02:00) is identical for all methods: reported separately as "shared production cost", excluded from paired
differences, included in the secondary "total system cost".

## 3. Decision-time estimate est(s, t) (used by repair choice, HSR_repair and ΔCost_history)
Median wall seconds of SUCCESS runs of the slot's producer class in the region, completed strictly before t, from the
SHARED scheduled-production ledger; if none exists, the frozen prior {validator: 600 s, otp: 5400 s}. Identical for F1
and N5; deterministic given the ledger.

## 4. Rules
- Same envelope, same measurement code, same warm state for F1/N5/N1 (primary steady-state warm; secondary cold).
- Skipped scheduler triggers cost 0 for everyone. Duplicate work is charged each time it is executed.
- Failed/timeout attempts are charged to the method that launched them; their artifacts do not exist.
- Instants affected by the 24 h operational cap are excluded from primary metrics for ALL methods (paired exclusion).
- F1 search/repair overhead is never hidden: B is always added to F1's total.
- N5 is never charged for work it did not perform; F1 never receives free work.
- The CostModel is a pure function of the frozen ledger (deterministic; replayable).
Tests: S3-18..S3-22.

## 5. V1.1 interface (normative; formulas unchanged)
`CostModel.estimate_rederive(slot_id, producer_class, tick_utc, prior: PriorCostView) -> float` and
`CostModel.online_cost(record: CostRecord) -> float`. `PriorCostView.before(region, t, ledger)` keeps only SHARED
scheduled-production runs completed STRICTLY BEFORE t; a view containing any other observation cannot be constructed;
future ledger edits leave the view (and its digest) bitwise unchanged; the CostModel has no tick state. Costs are typed
`CostItem`s with `CostCategory` A_PRODUCER / B_CONTROL_PLANE / C_OFFLINE; `CostRecord.online_wall_s` = A + B.
est(s,t) values enter `RequestBinding.estimates`, so F1 and N5 receive the identical numbers (P3-18).

## 6. V1.2 (normative)
est(s,t) = ordinary arithmetic median (even n: mean of the two middle values) — V1_2_DETERMINISTIC_FREEZE.md §1.
N1 is charged its own measured native executions; one-time preprocessing charged once per region — §4 there.
