# 05 — Licence identifier table audit

Policy: V4 03 classes (A raw redistribution permitted; B research processing permitted, redistribution constrained;
C attribution modifier; D unclear → excluded; E incompatible → excluded), V3 02 examples for A.

| Identifier | Class | Justification |
|---|---|---|
| cc0-1.0, pddl-1.0 | A | public-domain dedication: redistribution permitted, no attribution |
| cc-by-3.0, cc-by-4.0, odbl-1.0, ogl-uk-3.0, etalab-2.0 | A+C | redistribution permitted with attribution (V3 02 names CC BY, ODbL, open government licences) |
| cc-by-sa-4.0 | A+C | redistribution permitted, attribution + share-alike |
| cc-by-nd-4.0 | B+C | verbatim redistribution allowed but no adaptations: the CONSERVATIVE publication treatment (IDs/hashes only) is used; eligibility unchanged (A and B both eligible) |
| research-use-only | B | internal label: research processing permitted, redistribution not granted |
| no-redistribution-research-permitted | B+C | internal label |
| login-only-terms, no-derivatives-no-research, proprietary-prohibits-research | E | V3 D/E definition: login-only terms or research/derivative use prohibited |
| any other identifier / URL, missing or conflicting evidence | D | fail closed (never upgraded to enlarge the population) |

Status: **PI_CONFIRMED**; SHA-256 recorded in PRE_S3_FROZEN_DIGESTS.json. No live licence values were fetched.
Tests: P3-03, test_s1_13_14_license_dedup.py.
