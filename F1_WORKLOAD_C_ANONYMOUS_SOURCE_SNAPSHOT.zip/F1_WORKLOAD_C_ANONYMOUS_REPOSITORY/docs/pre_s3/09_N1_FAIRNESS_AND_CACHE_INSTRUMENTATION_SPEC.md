# 09 — N1: strongest fair native OTP baseline

Frozen (spec17 §8 "N1 `--loadStreet` + cache.enabled, warm page cache"; 14 "N1 identical OTP envelope"; provenance
V4 16): same pinned OTP 2.10.0 jar (8acd2808…), JDK 25.0.4.1, identical authoritative OTP envelope (8 CPUs, quota
800000/100000, MemoryMax 32G, -XX:ActiveProcessorCount=8 -Xms24g -Xmx24g -XX:+UseG1GC -Duser.timezone=UTC), same
frozen OSM extract per region, warm page cache (primary), cold (secondary, page cache dropped).

**Mechanism.** Per region: `--buildStreet` once (amortized preprocessing, charged once to N1, reported separately) into a
persistent N1 street directory; each N1 router rebuild = `--loadStreet --save` with build-config `cache.enabled = true`
and a persistent per-region cache directory (semantically neutral: frozen D5 / O13 EQ). Builds are CLI processes
(OTP has no persistent build server); a warm JVM is not claimed.

**Policy.** ROUTER slot at tick t: if the last successful N1 graph's input vector (K0 identities) equals c_cur's →
reuse it; else native rebuild at c_cur; failure → NO_ARTIFACT (charged). VAL slots: identical to the N5(K0) current-cut
path (N1 applies only to the router-producing path; non-router work is accounted identically to N5(K0)).
N1 has no contracts beyond K0 identity and no historical witness mechanism.

**Instrumentation required (gates S3-26..S3-29):** record per build: street graph path + digest loaded, cache dir path,
size and file digests before/after, presence of the cache key in the effective build-config, OTP log lines evidencing
street-graph loading, wall/CPU under the identical envelope (envelope digest equal to F1 router production). If cache
activity cannot be evidenced, the N1 run is BLOCKED (never silently degraded to a cold rebuild).

**V1.1 interface (normative):** `N1Baseline.decide(view: N1CurrentView, evaluator: CurrentCutEvaluator, rederiver:
CurrentCutRederiver, native: NativeOtpBuilder) -> N1Outcome`. `N1CurrentView` = joint request, current VAL bindings
(sanitized) and their K0 contracts, current router input vector, N1's OWN `NativeOtpState` (persisted street graph +
digest, native cache dir + manifest digest, envelope digest, last successful N1 input vector and graph digest), est(s,t)
per slot. N1 receives no RealizedHistory, ArtifactCatalog, ArtifactEntry, F1 witness or historical cut enumeration
(P3-17). `N1Outcome` returns the decision, the updated native state and the cache instrumentation evidence.
