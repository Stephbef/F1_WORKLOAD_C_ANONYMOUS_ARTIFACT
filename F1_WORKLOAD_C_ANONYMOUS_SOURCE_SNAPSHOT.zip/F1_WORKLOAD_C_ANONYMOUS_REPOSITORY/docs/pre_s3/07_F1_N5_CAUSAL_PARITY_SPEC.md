# 07 — F1(K2) vs N5(K2) causal parity

Intended treatment difference: **F1 may use realized prior cuts in Γ_t; N5 may use only req.current_cut.** Nothing else.

| Shared item | How parity is enforced in Session 3 |
|---|---|
| request population, ConsumerRequest, designated slots, current cut, D_t | one request stream generated once per region; both methods receive the identical `ConsumerRequest` (same request_id) |
| R_t binding rule | identical rule (latest instance with ARTIFACT_BORN ≤ t; tie: overlay before shared, then higher instance) applied to the shared catalog + EACH METHOD'S OWN overlay; bound instances may differ because of earlier method-specific repairs (treatment consequence, not a parity violation) |
| contracts (K2), evaluator, Canon semantics | same `ContractSystem` instance digest; N5 evaluates exactly F1 step-1 evaluations (S3-24) |
| Γ, schedule, SCH-01, producer states, failures, timestamps, provenance | single shared scheduled-production ledger |
| resource envelope, producer cost observations | same envelope digests; same measured cost ledger; same decision-time estimator |
| re-derivation implementation | the same `rederive(r, c)` code path; N5 calls it only with c = c_cur |
| evaluation-cost / accounting rules, objective | same CostModel (11_…SPEC); same tie rule (tie → current) |
| caching | same warm state (steady-state warm primary; cold secondary for all methods) |

Forbidden: any F1-only cache, precomputation, prefetch, or producer privilege not derived from Γ_t; any N5 handicap
(extra work, slower path, different envelope, missing contracts). Session-3 tests: S3-19, S3-23, S3-24, S3-25.
