# 16 — Session-3 implementation roadmap (V1.2)

Implement behind the frozen V1.2 interfaces (interfaces/session3.py, unchanged: S3-51) and reproduce
V1_2_REFERENCE_VECTORS.json (S3-52..S3-56) before wiring engines into the orchestrator.

1. Verify the PRE-S3 package (S3-01..S3-07); read 02, 06–13 before any code.
2. Γ_t and R_t binding (S3-08) → WitnessSearch (S3-09..S3-12) → AdmissionEngine (S3-13, S3-14).
3. CostModel + measured cost ledger (S3-18..S3-22) → RepairEngine (S3-15..S3-17).
4. N5Baseline over CurrentCutView with sentinel/spy tests (S3-23..S3-25).
5. N1Baseline with native street/cache instrumentation; real-binary fixture runs (S3-26..S3-29).
6. ReplayEngine (S3-30, S3-31); MutationEngine (S3-32..S3-34).
7. StatisticsExporter raw export (S3-35..S3-37) → FrozenAnalysis (S3-38..S3-40).
8. Firewall (S3-41, S3-42); orchestrator Phases 11–16 on real engines in FIXTURE (S3-46); S3-51 interface hash; fixture E2E reproducing
   identifiability traces T1–T4 (S3-47); negative battery (S3-48); static analysis (S3-49); package (S3-50).
Engineering only; FIXTURE data only; VALIDATION only if explicitly allowed; TEST never.
