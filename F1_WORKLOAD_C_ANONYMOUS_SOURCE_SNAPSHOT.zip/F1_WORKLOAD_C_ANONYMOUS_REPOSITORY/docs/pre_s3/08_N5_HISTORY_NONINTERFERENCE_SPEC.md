# 08 — N5 history non-interference (architectural property, stronger than output equality)

Interface (frozen V1.1, `interfaces/session3.py`): `N5Baseline.decide(view: CurrentCutView, level, evaluator:
CurrentCutEvaluator, rederiver: CurrentCutRederiver) -> AdmissionDecision`. `CurrentCutView` IS `RequestBinding` — the same
type and identical binding rule as F1 (shared catalog + N5's OWN overlay; never F1's overlay): the joint request, one sanitized `BoundArtifact` per slot (NO instance number, NO
rederived_from, NO catalog handle; birth/input provenance of the visible artifact only), the contracts of exactly those
artifacts, and est(s,t) per slot. The evaluator and rederiver are bound to the current context/cut (their methods have
no cut parameter). Nothing reachable from N5's inputs contains a RealizedHistory, ArtifactCatalog, ArtifactEntry,
cut enumerator, witness index, historical summary or F1 result (checked by recursive type-reachability test P3-16).

Required Session-3 proofs (all mandatory, gates S3-23/24/25):
1. **Static**: the N5 module imports none of `history.realized`, `catalog.artifacts.ArtifactCatalog`, `enumerate_cuts`,
   the F1 witness/repair modules (AST import check).
2. **Construction**: the orchestration layer builds the view; a test asserts the view's fields are exactly the three
   above and that its instances all satisfy birth ≤ t and belong to designated slots.
3. **Sentinels**: run N5 with sentinel objects injected wherever a history/catalog/witness index could be reached
   (module globals, contract system attributes, request context); any attribute access raises → test fails.
4. **Spy on cut ids**: every EvaluationContext passed by N5 to the evaluator has cut_id == req.current_cut.cut_id.
5. **Catalog with historical entries**: give the orchestration layer a catalog containing older instances; prove the
   view excludes them and N5's decision is invariant to their presence/absence (bitwise-equal decision records).
6. **No F1 leakage**: N5 is run BEFORE F1 for each request in a fresh object graph; F1 outputs are never inputs to N5.
7. **Legal current-cut work**: N5 may evaluate the SAME contracts as F1 on the current cut and invoke the same
   `rederive(r, c_cur)`; tests prove identical verdicts to F1 step 1 for every request.

8. **Overlay isolation (V1.2)**: with the same shared catalog and distinct legal F1/N5 overlays, each method binds only
   its own overlay; N5's binding and decision are invariant to any modification of F1's overlay (S3-54).
