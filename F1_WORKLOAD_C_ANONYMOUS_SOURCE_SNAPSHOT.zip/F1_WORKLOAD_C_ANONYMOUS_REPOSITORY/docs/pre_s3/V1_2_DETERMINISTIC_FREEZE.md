# V1.2 — Final deterministic micro-freeze (before Session 3)

Classification: PRE-IMPLEMENTATION scientific-operational clarification, frozen BEFORE any validation or TEST access
(ChangeRecord class S1 at stage IMPLEMENTATION — permitted by the firewall; not R1; no outcome exists). No frozen
scientific input changed (frozen_specs/**, spec_interpretations.json, license_identifier_table.json byte-identical).
Executable restatements: tests/workload_c/reference_v12.py; frozen vectors: docs/pre_s3/V1_2_REFERENCE_VECTORS.json
(Session 3 must reproduce them exactly — S3-52..S3-56).

## 1. est(s, t) median convention (S3-52)
Qualifying runs: SUCCESS runs of the slot's producer class, same region, SHARED scheduled production, completed STRICTLY
BEFORE t (`PriorCostView.before`). Sort wall-clock seconds ascending; n odd → x[n//2]; n even → (x[n/2−1] + x[n/2]) / 2.0
(ordinary arithmetic median; e.g. [5000, 5200] → 5100.0). n = 0 → prior: validator 600.0 s, otp 5400.0 s. Never upper/lower
median, nearest observation, weighted median, mean, future observations or method-overlay observations. F1 and N5 receive
the identical value (same shared ledger, same function).

## 2. Multi-slot repair EXECUTION (S3-53) — the plan S(c), OPT(c) is unchanged
A serial, deterministic. B/C steps in canonical request-slot order (VAL by ascending feed id, then ROUTER) filtered to S(c).
D every on-demand producer operation uses exactly the plan's target cut. E t is the information boundary: a step that
starts later never observes a logical version that became available after t. F stop after the first required step that
is infeasible or returns a non-artifact outcome (INFRA_ERROR, TIMEOUT, RESOURCE_FAILURE, INVALID_INPUT,
DEPENDENCY_MISSING, DIGEST_MISMATCH); SUCCESS and SEMANTIC_FAIL produce artifacts and continue. G all attempted work is
charged. H successful earlier steps remain immutable overlay artifacts of that method and may be bound at later ticks
when ARTIFACT_BORN ≤ the later tick. I unattempted steps: outcome None, no artifact, zero producer cost. J a plan with a
failed step ends in action = NO_ARTIFACT, mode = None, retaining the attempted RepairPlan. Applies identically to F1 and N5;
N1 follows its native mechanism. Enforced structurally by `AdmissionDecision` invariants (V1.2).

## 3. ConsumerRequest parity vs method-specific binding (S3-54)
Identical across F1 and N5: request stream, current cut, D_t, designated slots, shared scheduled-production state, binding
RULE, contract semantics, current-cut evaluator, cost estimator, resource/accounting rules. R_t is bound per method from
the SHARED catalog plus THAT METHOD'S OWN overlay: latest instance of the slot with ARTIFACT_BORN ≤ t; tie on ARTIFACT_BORN:
overlay instance before shared instance, then the higher instance number. Bound instances may differ between methods
because of earlier method-specific repairs — a treatment consequence, not a parity violation. N5 never receives F1's
overlay (nor history, catalog handles, witnesses, summaries, repair decisions or cache hints); its own overlay contains
only artifacts of N5's previous current-cut re-derivations.

## 4. N1 costs and preprocessing (S3-55)
F1 vs N5: identical shared ledger for est(s,t), identical measurement rules and envelopes; each method is charged its own
on-demand executions. N1: identical measurement methodology and identical authoritative OTP envelope, but N1 router costs
are N1's OWN measured `--loadStreet` + `cache.enabled` executions — never a hypothetical full-build cost from the F1/N5
ledger; F1/N5 never receive N1's native-cache advantage. Preprocessing: A the one-time N1 street-graph build is measured
and charged ONCE per region to N1's regional total over the whole window; B reported separately; C not divided by
ticks/artifacts/root changes; D cache creation inside a measured rebuild is part of that rebuild (no double count); E a
genuinely separate cache-preparation process (if the pinned mechanism needs one) is measured and charged once; F cache
maintenance during builds stays in the measured build cost; G the same one-time principle applies to method-specific F1/N5
preprocessing; truly shared preprocessing is reported separately and charged symmetrically.

## 5. Inference determinism (S3-56)
Cluster/resampling unit = REGION (never root change, tick, artifact or request cell). Integer seeds = first 8 bytes
(big-endian) of seed_bytes(domain) (authoritative §11); RNG = numpy.random.Generator(numpy.random.PCG64(seed)) with numpy
2.4.4 pinned; regions sorted ascending by region id before any draw (permutation invariant).
- BCa (domain "bootstrap", B = 9,999): statistic = mean of region-level values (H_witness/H_repair: per-region proportions,
  zero-denominator regions excluded as frozen; H_hist: per-region ΔE2E_history(K2); H_native: per-region
  Cost_F1(K2) − Cost_N1, direction "less"). Indices = rng.integers(0, n, size=(B, n)); z0 = Φ⁻¹(p0),
  p0 = (#{θ* < θ̂} + 0.5·#{θ* = θ̂}) / B clamped to [1/(2B), 1 − 1/(2B)]; acceleration a = Σd³ / (6 (Σd²)^{3/2}),
  d = mean(jack) − jack over leave-one-region-out means (a = 0 if the denominator is 0); two-sided 95 %: α_j =
  Φ(z0 + (z0 + z_j)/(1 − a(z0 + z_j))), z_j = Φ⁻¹(0.025), Φ⁻¹(0.975); endpoints = order statistics θ*_(⌈α_j·B⌉) (1-based,
  clipped to [1, B]). Φ from Python statistics.NormalDist.
- Wild-cluster (domain "wild-bootstrap", B = 9,999, Rademacher): w = rng.integers(0, 2, size=(B, n))·2 − 1; replicate =
  mean + mean_i(w_bi (x_i − mean)); two-sided 95 % percentile interval by the same order-statistic rule.
- Exact sign test (unchanged): one-sided, region-level, zeros dropped, direction from the hypothesis, p = Σ_{j≥k} C(n,j)/2ⁿ,
  no normal approximation, no continuity correction. Holm over the four primary hypotheses (unchanged). Everything else
  descriptive.

## 6. Gates
S3-07 now requires P3-01…P3-26 (all PRE-S3 gates, including P3-01…P3-20). S3-19 reworded to cost-accounting symmetry and
measurement parity. New S3-52…S3-56. Interface version F1-WC-S3-INTERFACES-V1.2 (hash frozen; S3-51).
