# 15 — Session-3 acceptance gates (frozen before Session-3 code exists; V1.2)

A gate PASSES only if >= 1 mapped test/command executed and every mapped test passed; SKIP never counts as PASS; an
environmental impossibility is BLOCKED with the exact reason, never PASS. Session 3 may ADD gates but may not remove,
renumber or weaken these. V1.2: S3-07 → P3-01..P3-26, S3-19 reworded (measurement parity; N1 own native costs), S3-51 → V1.2
interface hash, new S3-52..S3-56.

| Gate | Requirement | Evidence |
|---|---|---|
| S3-01 | PRE-S3 input package integrity verified (SHA256SUMS, source manifest, bundle HEAD = recorded PRE-S3 commit) | command |
| S3-02 | PRE-S3 decision register unchanged (spec_interpretations.json SHA-256 = PRE-S3 record; PI_CONFIRMED) | test |
| S3-03 | licence identifier table unchanged (SHA-256 = PRE-S3 record; PI_CONFIRMED) | test |
| S3-04 | SCH-01 frozen policy last_successful_build used on every scientific path | test |
| S3-05 | S1-01..S1-30 rerun PASS | ledger |
| S3-06 | S2-01..S2-50 rerun PASS | ledger |
| S3-07 | all PRE-S3 closure gates rerun PASS: P3-01..P3-26 (includes every V1.1 gate P3-01..P3-20 and the V1.2 gates P3-21..P3-26) | ledger |
| S3-08 | Gamma admissible cuts per spec17 §5 (available <= t, service on every date of [t,t+6], <= 2 superseding versions) incl. sensitivities | test |
| S3-09 | WitnessSearch deterministic and input-permutation invariant | test |
| S3-10 | no future-cut witness: every witness version available <= tick and every artifact completed <= tick (negative tests) | test |
| S3-11 | fixed-R enforced: cross-slot substitution rejected; only designated-slot instances considered | test |
| S3-12 | JointWitness provenance complete: one WitnessBinding per slot (artifact, contracts, all EvaluationResults at the witness cut, catalog-entry digest, birth context, provenance digest, TemporalEvidence) + GammaEvidence | test |
| S3-13 | K3 never usable as an ordinary admission contract (rejected) | test |
| S3-14 | admission decision order exactly as frozen (current -> historical witness -> repair -> no-artifact); action/mode representation per V1.1 | test |
| S3-15 | historical repair deterministic; OPT_hist vs OPT_current with frozen decision-time cost estimates; tie -> current | test |
| S3-16 | rederive(r,c) creates a new instance of the same slot; no synthetic historical state; no future information | test |
| S3-17 | A->B->A remain distinct state events in witness/repair; recurrence valid only through realized states | test |
| S3-18 | CostModel deterministic given the frozen ledger | test |
| S3-19 | cost-accounting symmetry and measurement parity: F1/N5 share the est(s,t) ledger, measurement rules and envelopes and are charged their own executions; N1 uses identical measurement methodology and the authoritative OTP envelope but is charged its OWN measured native executions | test |
| S3-20 | control-plane costs (evaluation, witness search, solver, catalog lookup) charged to the method that incurs them | test |
| S3-21 | failed producer attempts accounted; no work disappears | test |
| S3-22 | offline analysis/replay cost excluded from online cost | test |
| S3-23 | N5 history non-interference: N5 receives only CurrentCutView (= RequestBinding of sanitized BoundArtifacts); sentinel history/catalog/witness-index objects raise if touched | test |
| S3-24 | N5 current-cut parity: identical contracts, evaluator and verdicts as F1 at the current cut | test |
| S3-25 | N5 receives no F1 witnesses, historical summaries or cache hints (construction + runtime spies) | test |
| S3-26 | N1 native --loadStreet + cache.enabled active, cache persisted across eligible builds, instrumentation recorded | test |
| S3-27 | N1 resource envelope identical to F1 router production (same envelope digest) | test |
| S3-28 | N1 has no historical witness mechanism | test |
| S3-29 | N1 executed with the real pinned OTP on non-study fixtures (or BLOCKED with exact reason) | test |
| S3-30 | replay deterministic; reproduces every decision from the sealed ledger | test |
| S3-31 | replay never consults future events and never mutates the source ledger | test |
| S3-32 | mutation sample deterministic: ids sorted, ranked with the mutation seed, top ceil(5%·n) | test |
| S3-33 | mutation families exactly as frozen; invalid mutations fail closed | test |
| S3-34 | mutation detection semantics on fixtures (mutant contract admits where Canon differs -> missing dependence detected) | test |
| S3-35 | raw export complete (all frozen fields) | test |
| S3-36 | raw export append-only and provenance-linked | test |
| S3-37 | every aggregate recomputed from the raw export alone | test |
| S3-38 | frozen analysis: unit, influence period, denominators, missing/failure/inconclusive rules exactly as frozen | test |
| S3-39 | frozen analysis deterministic (seeded exact sign test, BCa B=9,999, wild-cluster Rademacher) | test |
| S3-40 | Holm family exactly {H_witness(K0), H_repair(K0), H_hist(K2), H_native(K2)} | test |
| S3-41 | namespace firewall: FIXTURE free, VALIDATION only under gate, TEST inaccessible | test |
| S3-42 | change-class firewall (E1/E2/S1/R1) enforced | test |
| S3-43 | no scientific result emitted (fixture marker on every output; no TEST data) | test |
| S3-44 | no secret emitted (secret scan of all outputs) | test |
| S3-45 | no live campaign: --real still refuses; no study API contacted | test |
| S3-46 | orchestrator Phases 11-16 use real Session-3 engines in FIXTURE mode; Phase 00->18 COMPLETE | test |
| S3-47 | fixture E2E with F1/N5/N1 reproduces identifiability traces T1-T4 (non-study) | test |
| S3-48 | mandatory negative-test battery (08/10/11/13 specs) all PASS | test |
| S3-49 | static analysis clean (ruff, mypy, shellcheck) | command |
| S3-50 | Session-3 package integrity and Session-4 handoff verified | command |
| S3-51 | V1.2 interface file src/f1/workload_c/interfaces/session3.py (F1-WC-S3-INTERFACES-V1.2) SHA-256 unchanged through Session 3 (equals PRE_S3_FROZEN_DIGESTS.json) unless a formal pre-implementation amendment exists | test |
| S3-52 | exact est(s,t) median convention incl. even-n arithmetic median; reproduces V1_2_REFERENCE_VECTORS.json est cases | test |
| S3-53 | multi-slot repair: canonical serial order, exact target cut, t information boundary, fail-fast, attempted-work charging; reproduces repair_execution vectors | test |
| S3-54 | method-specific overlay isolation and binding-rule parity (identical ConsumerRequest; each method binds shared + own overlay; N5 invariant to F1 overlay); reproduces binding vector | test |
| S3-55 | N1 native cost observations are N1's own measured executions, distinct from the F1/N5 est ledger, with identical measurement/envelope rules; one-time preprocessing charged once per region | test |
| S3-56 | BCa and wild bootstrap use region as cluster with B = 9,999, frozen seeds, PCG64/numpy 2.4.4 and the frozen formulas; exact sign test; reproduces inference vectors | test |
