# 06 — Session-3 scientific specification (frozen PRE-S3)

Normative for Session 3. Every rule below was fixed before any study outcome existed. Sources: spec17 (authoritative),
16_FIXED_R_REDERIVE_CONFIRMATION (authoritative), provenance V4 13/16/17/18/20, V5 22, V2 18 (only where the
authoritative text is silent and nothing contradicts them; copies with SHA-256 under frozen_specs/provenance/).

## 1. Objects
- **Region request R_t** at consumer tick t (06:00 local): the designated slots of the region (one VAL slot per feed,
  one ROUTER slot) each bound to the **latest instance of that slot whose ARTIFACT_BORN ≤ t** (artifact exists at
  completion; completion == t counts). Instances come from the SHARED scheduled-production catalog plus the method's
  own on-demand overlay (§5). A slot without any instance is "unbound".
- **Current cut** c_cur(t) = `cut_at(H, t)` (latest logical version available ≤ t per feed).
- **Consumer horizon** D_t = the 7 local dates [t, t+6] (spec17 §5).
- **Γ_t (primary)** — per feed f, admissible versions v satisfy: (a) available ≤ t; (b) service on every date of D_t,
  where "service on date d" means ≥ 1 trip of version v whose service_id runs on d (calendar ∪ calendar_dates);
  (c) at most 2 newer superseding versions (cur_f − v ≤ 2). Γ_t = cuts whose every coordinate is admissible.
  Sensitivities (secondary, never primary): horizon 3 / 13 days; depth 1 / 4; current-only control (= N5).
- **Valid(R, c, K)** for K ∈ {K0, K1, K2}: every bound artifact of R has all its level-K contracts VALID in the
  evaluation context (c, D_t) (`ContractSystem.evaluate`). Any ERROR makes the cut not valid (fail closed) and is
  recorded. K3 is never an admission level (reference only).
- **W_t(R, Γ, K)** = { c ∈ Γ_t : Valid(R, c, K) } ∪ ({c_cur} if Valid(R, c_cur, K)).

## 2. Frozen deterministic witness order
Candidates Γ_t \ {c_cur} are ordered by (i) lag(c) = Σ_f (cur_f − c_f) ascending, then (ii) the frontier vector in
ascending feed-id order compared lexicographically with HIGHER indices first. The witness is the first candidate in
this order that is valid. The order is defined without reference to costs or outcomes.

## 3. F1(K) decision procedure (frozen order)
1. If Valid(R, c_cur, K) → **action=REUSE, mode=CURRENT**.
2. Else if a historical witness exists (§2) → **action=REUSE, mode=HISTORICAL** (witness recorded, 10_…SPEC).
3. Else **REPAIR**: failing set S(c) = unbound slots ∪ slots whose bound instance fails any level-K contract at c.
   OPT_current = Σ_{s∈S(c_cur)} est(s, t); OPT_hist = min over c ∈ Γ_t \ {c_cur} of Σ_{s∈S(c)} est(s, t) (ties in c
   broken by §2 order). If OPT_hist < OPT_current → rederive S(c*) at the historical cut c* (**action=REDERIVE, mode=HISTORICAL**);
   otherwise rederive S(c_cur) at c_cur (**action=REDERIVE, mode=CURRENT**) — tie → current.
4. If any required re-derivation is infeasible (input archive unavailable) or fails → **action=NO_ARTIFACT, mode=None** (the attempted RepairPlan and all
   attempted work are recorded and charged).
`est(s, t)` = decision-time cost estimate (11_COST_ACCOUNTING_SPEC §3), identical for F1 and N5.

## 4. N5(K) decision procedure
1. If Valid(R, c_cur, K) → **action=REUSE, mode=CURRENT** (identical evaluation to F1 step 1).
2. Else rederive S(c_cur) at c_cur → **action=REDERIVE, mode=CURRENT**; failure/infeasible → **action=NO_ARTIFACT, mode=None**.
N5 never forms Γ_t \ {c_cur}; it receives only a `CurrentCutView` (08_N5_…SPEC).

## 5. Shared production and method overlays
Scheduled production (validator at availability, OTP at 02:00 with SCH-01 = last_successful_build) is executed ONCE
and shared by F1, N5 and N1 (identical producer states, failures, timestamps, provenance). On-demand re-derivations are
method-specific instances appended to that method's own catalog overlay (`rederive(r, c)` = new instance of the same
slot r born at c); later ticks of the same method may bind them.

## 6. N1 (09_N1_…SPEC)
ROUTER slot: native OTP rebuild at c_cur with persisted street graph (`--loadStreet`) and `cache.enabled`, reusing the
last N1 graph only when its exact input vector equals c_cur's (K0 identity). VAL slots: the N5(K0) current-cut path.

## 7. Metrics (12_…SPEC §4)
HSR_witness(K), HSR_repair(K), ΔCost_history, ΔE2E_history(K2) = Cost_N5(K2) − Cost_F1(K2), H_native
Cost_F1(K2) < Cost_N1; unit = region × distinct root logical-content change; Holm over {H_witness(K0), H_repair(K0),
H_hist(K2), H_native(K2)}.

## 8. Correctness boundary
Admission evaluates machine-checkable contracts only; it does not know the opaque producer's hidden acceptance
relation. Contract soundness is an assumption checked empirically (Canon_D oracle, mutations); it is never claimed as
a proof of black-box semantic equivalence.

## 9. V1.1 interface mapping (normative; no rule above changed)
R_t is ONE `ConsumerRequest` (region_id, canonical `request_slots` = VAL slots by ascending feed id + ROUTER slot,
tick_utc, current_cut, context) bound as ONE `RequestBinding` (sanitized `BoundArtifact` per slot, their contracts,
est(s,t) per slot). One `AdmissionDecision` per (method, K, joint request) with `action` ∈ {REUSE, REDERIVE,
NO_ARTIFACT}, `mode` ∈ {CURRENT, HISTORICAL, None} (None iff NO_ARTIFACT), a `JointWitness` (one `WitnessBinding` per
slot, all at the same witness cut) for historical reuse, and a typed `RepairPlan` (failing slot set S(c), one
`RederivationStep` per slot, OPT_current/OPT_hist as slot-set sums) for REDERIVE (and for attempted repairs ending in
NO_ARTIFACT). Interface file: src/f1/workload_c/interfaces/session3.py (F1-WC-S3-INTERFACES-V1.1).
