# 10 — Witness search, admission and repair

**WitnessSearch** operates only over: the designated request slots; instances legally bound to those slots (R_t
rule); cuts in Γ_t (available ≤ t; never later events); the frozen contracts of those instances; consumer horizon D_t.
No catalog-wide substitution; no cut containing a version available after t; no artifact completed after t.

**Witness record** (all fields mandatory): artifact ids of R (per slot), witness cut (frontier + cut_id), request slot
ids, contract ids, every EvaluationResult (verdict, reason, evaluator digest), derivation provenance of each bound
instance (catalog entry digest, birth cut, provenance digest), temporal evidence (availability instants of every
witness-cut version ≤ t; ARTIFACT_BORN instants ≤ t), Γ evidence (service-on-D and depth checks), method, K.

**Ordering** — frozen in 06 §2. **Admission order** — 06 §3 (F1), §4 (N5). Representation (V1.1, single and
unambiguous): `AdmissionDecision.action` ∈ {REUSE, REDERIVE, NO_ARTIFACT} and `AdmissionDecision.mode` ∈ {CURRENT,
HISTORICAL, None}; NO_ARTIFACT ⇒ mode None; REUSE+HISTORICAL ⇒ `witness: JointWitness`; REDERIVE ⇒ `repair: RepairPlan`
with the same mode. Repair information is never stored in the cost record.

**Repair**: `rederive(r, c)` creates a NEW instance of the SAME slot r born at c using exactly the logical versions of
c (realized archives only; no synthetic state; no future information; no TEST outcomes in candidate choice). Separate
records for witness reuse, historical re-derivation, current re-derivation, failure/no-artifact.

**Mandatory negative tests**: future-cut witness rejected; witness using an artifact born after t rejected; cross-slot
substitution rejected; K3 as admission contract rejected; corrupted provenance (catalog digest mismatch) → fail
closed; A→B→A: a historical A-cut is a distinct realized state event and is valid only through realized versions;
identical input twice → identical decisions (logical fields).

**V1.1 joint witness (normative):** `JointWitness` = request_id, request_slots, method (F1 only), level (K0–K2),
witness_cut, one `WitnessBinding` for EVERY designated slot (slot_id, sanitized `BoundArtifact` with catalog-entry
digest, birth context and provenance digest, contract_ids, every `EvaluationResult` — all VALID and all at the witness
cut —, `TemporalEvidence` proving artifact completion ≤ tick and witness versions available ≤ tick) and
`GammaEvidence` for the witness cut. A per-slot mixture of different cuts is unrepresentable.

**V1.2 repair execution (normative):** serial, canonical slot order filtered to S(c), exact target cut, t as the
information boundary, fail-fast after the first infeasible/non-artifact step, attempted work charged, unattempted steps
zero-cost and artifact-free, NO_ARTIFACT (mode None) with the attempted plan retained (V1_2_DETERMINISTIC_FREEZE.md §2).
