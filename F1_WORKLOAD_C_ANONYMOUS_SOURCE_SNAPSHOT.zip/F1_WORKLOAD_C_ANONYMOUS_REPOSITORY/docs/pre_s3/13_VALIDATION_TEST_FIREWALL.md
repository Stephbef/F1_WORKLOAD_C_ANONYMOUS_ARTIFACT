# 13 — VALIDATION / TEST firewall

Namespaces: FIXTURE (free), VALIDATION (only after Session-3 implementation, under an open validation gate,
for defect detection and N4 TTL τ), TEST (sealed until the authorized final campaign; certificate verified by
`TestExecutionGuard`). Machine checks: `security/firewall.py::check_namespace_read`, `require_namespace`,
`TestExecutionGuard`, statistics namespace homogeneity.

| Class | Meaning | Allowed? | Requirements |
|---|---|---|---|
| E1 | pure implementation bug (wrong branch, parser defect, exception, serialization contrary to frozen spec) | yes, incl. during validation | issue record, failing test, fix, regression test, changelog |
| E2 | portability/runtime adaptation preserving frozen semantics | yes | documented issue + independent proof of semantic preservation |
| S1 | scientific semantic change (contract, Gamma, history visibility, baseline capability, cost definition, region rule, scheduler science, analysis denominator) | only before validation access; afterwards only via formal amendment + complete restart from a clean preregistered state; never during the campaign | formal amendment id |
| R1 | change motivated by an observed comparative result ("widen witness search", "disable N1 cache", "loosen K2", "alter eligibility", "change denominator") | **NEVER** | — |

`check_change(ChangeRecord)` enforces the table (gate P3-08 now; S3-42 in Session 3). Every change in Sessions 3/4
must carry a ChangeRecord in the changelog.

**V1.1 machine enforcement:** `ChangeRecord` carries `formal_amendment`, `restart_from_clean_freeze`,
`restart_evidence_id` and `semantic_preservation_evidence`. S1 at VALIDATION_OPEN / POST_VALIDATION requires the
amendment AND restart_from_clean_freeze AND restart_evidence_id; S1 during CAMPAIGN is always rejected; E2 requires an
issue id AND semantic-preservation evidence; R1 is always rejected (P3-19).
