| Gate | Requirement | Status | Tests (pass/run) | Evidence |
|---|---|---|---|---|
| P3-01 | PRE-S3 input identity recorded and consistent | **PASS** | 1/1 | test_pre_s3_closure.py |
| P3-02 | interpretation register frozen and internally consistent | **PASS** | 1/1 | test_pre_s3_closure.py |
| P3-03 | licence identifier table audited and frozen | **PASS** | 1/1 | test_pre_s3_closure.py |
| P3-04 | SCH-01 frozen in register and scheduler | **PASS** | 1/1 | test_pre_s3_closure.py |
| P3-05 | INT-02 boundary gaps frozen behaviour | **PASS** | 1/1 | test_pre_s3_closure.py |
| P3-06 | INT-06 equal-cardinality keeps both | **PASS** | 1/1 | test_pre_s3_closure.py |
| P3-07 | no stale unresolved claims in current documentation | **PASS** | 1/1 | test_pre_s3_closure.py |
| P3-08 | validation/TEST firewall machine checks | **PASS** | 1/1 | test_pre_s3_closure.py |
| P3-09 | Session-3 gate ledger frozen and well-formed | **PASS** | 1/1 | test_pre_s3_closure.py |
| P3-10 | Session-3 V1.1 interfaces frozen (no Session-3 algorithm implemented) | **PASS** | 1/1 | test_pre_s3_closure.py |
| P3-11 | no study data or scientific result in the repository | **PASS** | 1/1 | test_pre_s3_closure.py |
| P3-12 | frozen digests recorded and matching | **PASS** | 1/1 | test_pre_s3_closure.py |
| P3-13 | joint ConsumerRequest and slot-set OPT | **PASS** | 2/2 | test_pre_s3_v11_interfaces.py |
| P3-14 | joint witness and negative cases | **PASS** | 1/1 | test_pre_s3_v11_interfaces.py |
| P3-15 | AdmissionDecision action/mode and typed repair plan | **PASS** | 1/1 | test_pre_s3_v11_interfaces.py |
| P3-16 | sanitized N5 view | **PASS** | 1/1 | test_pre_s3_v11_interfaces.py |
| P3-17 | N1 non-interference | **PASS** | 1/1 | test_pre_s3_v11_interfaces.py |
| P3-18 | CostModel explicit t and no future-cost leakage | **PASS** | 1/1 | test_pre_s3_v11_interfaces.py |
| P3-19 | firewall completion (restart / semantic-preservation evidence) | **PASS** | 1/1 | test_pre_s3_v11_interfaces.py |
| P3-20 | replay/export representability | **PASS** | 1/1 | test_pre_s3_v11_interfaces.py |
| P3-21 | est(s t) ordinary arithmetic median convention | **PASS** | 1/1 | test_pre_s3_v12_freeze.py |
| P3-22 | serial canonical fail-fast repair execution | **PASS** | 1/1 | test_pre_s3_v12_freeze.py |
| P3-23 | request parity vs method-specific overlay binding | **PASS** | 1/1 | test_pre_s3_v12_freeze.py |
| P3-24 | N1 own native costs and one-time preprocessing | **PASS** | 1/1 | test_pre_s3_v12_freeze.py |
| P3-25 | inference determinism (region clusters B seeds RNG sign test) | **PASS** | 1/1 | test_pre_s3_v12_freeze.py |
| P3-26 | V1.2 gates prompt and interface version frozen | **PASS** | 1/1 | test_pre_s3_v12_freeze.py |
