| Gate | Requirement | Status | Tests (pass/run) | Evidence |
|---|---|---|---|---|
| S1-01 | source package imports/builds | **PASS** | 6/6 | test_s1_01_imports.py |
| S1-02 | frozen config validation | **PASS** | 23/23 | test_s1_02_config.py |
| S1-03 | content-addressed storage | **PASS** | 4/4 | test_s1_03_04_storage.py |
| S1-04 | corruption/partial-write detection | **PASS** | 5/5 | test_s1_03_04_storage.py |
| S1-05 | Mobility mock pagination | **PASS** | 5/5 | test_s1_05_07_mobility.py |
| S1-06 | Mobility 401/403 classification | **PASS** | 3/3 | test_s1_05_07_mobility.py |
| S1-07 | Mobility 429 bounded retry | **PASS** | 3/3 | test_s1_05_07_mobility.py |
| S1-08 | secret/token redaction | **PASS** | 6/6 | test_s1_08_secrets.py |
| S1-09 | GTFS canonical content hash | **PASS** | 16/16 | test_s1_09_12_gtfs_logical.py |
| S1-10 | logical A,A collapse | **PASS** | 1/1 | test_s1_09_12_gtfs_logical.py |
| S1-11 | logical A,B | **PASS** | 1/1 | test_s1_09_12_gtfs_logical.py |
| S1-12 | logical A,B,A recurrence | **PASS** | 4/4 | test_s1_09_12_gtfs_logical.py |
| S1-13 | license engine all classes | **PASS** | 12/12 | test_s1_13_14_license_dedup.py |
| S1-14 | dedup/mirror/bundle rules | **PASS** | 8/8 | test_s1_13_14_license_dedup.py | test_s1_corrections.py |
| S1-15 | spatial/connectivity primitives | **PASS** | 10/10 | test_s1_15_17_spatial_regions.py | test_s1_corrections.py |
| S1-16 | region construction | **PASS** | 3/3 | test_s1_15_17_spatial_regions.py |
| S1-17 | eligibility engine | **PASS** | 2/2 | test_s1_15_17_spatial_regions.py |
| S1-18 | deterministic first-24 selection | **PASS** | 4/4 | test_s1_18_20_selection.py |
| S1-19 | deterministic 8/16 split | **PASS** | 2/2 | test_s1_18_20_selection.py |
| S1-20 | input-permutation invariance | **PASS** | 2/2 | test_s1_18_20_selection.py |
| S1-21 | FIXTURE/VALIDATION/TEST isolation | **PASS** | 5/5 | test_s1_21_22_namespaces_guard.py |
| S1-22 | unauthorized TEST execution guard | **PASS** | 2/2 | test_s1_21_22_namespaces_guard.py |
| S1-23 | append-only structured log | **PASS** | 8/8 | test_s1_23_24_log_state.py |
| S1-24 | run-state transition rules | **PASS** | 27/27 | test_s1_23_24_log_state.py |
| S1-25 | checkpoint/restart | **PASS** | 4/4 | test_s1_25_28_orchestration.py |
| S1-26 | incompatible-resume refusal | **PASS** | 3/3 | test_s1_25_28_orchestration.py |
| S1-27 | hard-gate stop semantics | **PASS** | 5/5 | test_s1_25_28_orchestration.py |
| S1-28 | phase failure injection | **PASS** | 3/3 | test_s1_25_28_orchestration.py |
| S1-29 | fixture population >24 eligible with controlled exclusions | **PASS** | 5/5 | test_s1_29_fixture_population.py |
| S1-30 | complete Phase00→Phase18 fixture orchestration | **PASS** | 4/4 | test_s1_25_28_orchestration.py |
