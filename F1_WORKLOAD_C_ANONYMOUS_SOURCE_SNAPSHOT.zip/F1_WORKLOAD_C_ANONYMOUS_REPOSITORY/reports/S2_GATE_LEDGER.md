| Gate | Requirement | Status | Tests (pass/run) | Evidence |
|---|---|---|---|---|
| S2-01 | Session-1 integrity verified | **PASS** | 1/1 | test_s2_integration.py |
| S2-02 | S1 correction gate | **PASS** | 12/12 | test_s1_01_imports.py | test_s1_corrections.py |
| S2-03 | S1-01..S1-30 rerun | **PASS** | 1/1 | test_s2_integration.py |
| S2-04 | INT-01..INT-10 audited | **PASS** | 1/1 | test_s2_integration.py |
| S2-05 | INT-06 agency_id correction | **PASS** | 4/4 | test_s1_corrections.py |
| S2-06 | INT-04 stop/platform correction | **PASS** | 6/6 | test_s1_corrections.py |
| S2-07 | pinned dependency schema | **PASS** | 2/2 | test_s2_deps_producers.py |
| S2-08 | dependency hash mismatch refusal | **PASS** | 2/2 | test_s2_deps_producers.py |
| S2-09 | validator command construction | **PASS** | 1/1 | test_s2_deps_producers.py |
| S2-10 | validator provenance | **PASS** | 1/1 | test_s2_deps_producers.py |
| S2-11 | validator semantic fixture | **PASS** | 2/2 | test_s2_deps_producers.py |
| S2-12 | validator infra/error classification | **PASS** | 6/6 | test_s2_deps_producers.py |
| S2-13 | OTP command construction | **PASS** | 1/1 | test_s2_deps_producers.py |
| S2-14 | OTP historical-date resolution | **PASS** | 1/1 | test_s2_deps_producers.py |
| S2-15 | OTP wall-clock independence | **PASS** | 2/2 | test_s2_deps_producers.py |
| S2-16 | OTP provenance | **PASS** | 2/2 | test_s2_deps_producers.py |
| S2-17 | resource manager capability detection | **PASS** | 1/1 | test_s2_resources_l28.py |
| S2-18 | cgroup-v2 fixture/backend tests | **PASS** | 2/2 | test_s2_resources_l28.py |
| S2-19 | cgroup-v1 fixture/backend tests | **PASS** | 2/2 | test_s2_resources_l28.py |
| S2-20 | systemd capability handling | **PASS** | 1/1 | test_s2_resources_l28.py |
| S2-21 | taskset-only rejection | **PASS** | 1/1 | test_s2_resources_l28.py |
| S2-22 | in-scope resource proof | **PASS** | 3/3 | test_s2_resources_l28.py |
| S2-23 | L28 orchestration test | **PASS** | 2/2 | test_s2_resources_l28.py |
| S2-24 | Canon integration | **PASS** | 2/2 | test_s2_deps_producers.py |
| S2-25 | full frozen oracle suite | **PASS** | 2/2 | test_s2_deps_producers.py |
| S2-26 | semantic-config digest suite | **PASS** | 1/1 | test_s2_deps_producers.py |
| S2-27 | K0 generation | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-28 | K1 generation | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-29 | K2 generation | **PASS** | 10/10 | test_s2_contracts_history.py |
| S2-30 | K3/reference path | **PASS** | 2/2 | test_s2_contracts_history.py |
| S2-31 | deterministic contract bytes | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-32 | contract error fail-closed | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-33 | K2<->Canon alignment | **PASS** | 11/11 | test_s2_contracts_history.py |
| S2-34 | history partial-order model | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-35 | cut consistency | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-36 | artifact catalog immutability | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-37 | request-slot vs derivation-instance | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-38 | rederive identity semantics | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-39 | validator scheduler | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-40 | OTP scheduler | **PASS** | 2/2 | test_s2_contracts_history.py |
| S2-41 | consumer scheduler | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-42 | DST tests | **PASS** | 2/2 | test_s2_contracts_history.py |
| S2-43 | overlapping producer tests | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-44 | deterministic event-ledger replay | **PASS** | 1/1 | test_s2_contracts_history.py |
| S2-45 | failure classification | **PASS** | 6/6 | test_s2_deps_producers.py |
| S2-46 | producer provenance | **PASS** | 3/3 | test_s2_deps_producers.py |
| S2-47 | Session-1 orchestrator integration | **PASS** | 3/3 | test_s2_integration.py |
| S2-48 | fixture producer->Canon->contracts E2E | **PASS** | 3/3 | test_s2_contracts_history.py | test_s2_integration.py |
| S2-49 | REAL mode remains scientifically disabled | **PASS** | 1/1 | test_s2_integration.py |
| S2-50 | no real study data accessed | **PASS** | 2/2 | test_s2_integration.py |
