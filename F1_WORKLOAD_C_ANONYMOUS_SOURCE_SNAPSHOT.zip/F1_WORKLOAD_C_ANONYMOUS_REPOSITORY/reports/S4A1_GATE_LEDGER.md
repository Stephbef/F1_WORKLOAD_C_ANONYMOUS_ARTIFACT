| Gate | Requirement | Status | Tests (pass/run) | Evidence |
|---|---|---|---|---|
| S4A1-01 | input S3.1 identity verified | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-02 | blocked-report identity verified | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-03 | amendment created before validation | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-04 | router conflict resolved exactly as directive | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-05 | N0 semantics frozen | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-06 | N2 semantics frozen | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-07 | N3 semantics frozen | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-08 | N4 semantics frozen | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-09 | N4 selection rule frozen before outputs | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-10 | N6 semantics frozen | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-11 | capability matrix complete | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-12 | N0 implementation conforms | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-13 | N2 implementation conforms | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-14 | N3 implementation conforms | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-15 | N4 implementation conforms | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-16 | N6 implementation conforms | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-17 | A->B->A N3 behavior correct | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-18 | TTL boundary exact | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-19 | N6 date omission deliberate and tested | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-20 | no baseline history leakage | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-21 | N4 selection oracle tests PASS | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-22 | no VALIDATION accessed before refreeze | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-23 | no TEST outcome accessed | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-24 | complete baseline regression PASS | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-25 | amended semantic freeze complete | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-26 | VAL N3 pin uses actual producer validation date (not ARTIFACT_BORN date) | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-27 | cross-local-midnight validator completion preserves the original validation date in the N3 pin | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-28 | n3_pin_index control-plane timing non-overlapping and charged exactly once | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-29 | N3 pin/index creation-update and lookup costs represented without double counting | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-30 | baseline view construction charges only metadata actually required by the method | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-31 | N6 cache access exact-key restricted and invariant to unrelated historical artifacts | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-32 | A->B->A fixture gate proves event-identity non-resurrection with no vacuous assertion | **PASS** | 1/1 | test_s4a1_baselines.py |
| S4A1-33 | the three PI-confirmed baseline applications frozen (no longer awaiting confirmation) | **PASS** | 1/1 | test_s4a1_baselines.py |
