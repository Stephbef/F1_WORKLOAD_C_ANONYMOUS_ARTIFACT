| Gate | Requirement | Status | Tests (pass/run) | Evidence |
|---|---|---|---|---|
| S3-01 | PRE-S3 input package integrity verified (SHA256SUMS; source manifest; bundle HEAD = recorded PRE-S3 commit) | **PASS** | 1/1 | test_s3_campaign.py |
| S3-02 | PRE-S3 decision register unchanged (spec_interpretations.json SHA-256 = PRE-S3 record; PI_CONFIRMED) | **PASS** | 1/1 | test_s3_campaign.py |
| S3-03 | licence identifier table unchanged (SHA-256 = PRE-S3 record; PI_CONFIRMED) | **PASS** | 1/1 | test_s3_campaign.py |
| S3-04 | SCH-01 frozen policy last_successful_build used on every scientific path | **PASS** | 1/1 | test_s3_campaign.py |
| S3-05 | S1-01..S1-30 rerun PASS | **PASS** | 1/1 | test_s3_campaign.py |
| S3-06 | S2-01..S2-50 rerun PASS | **PASS** | 1/1 | test_s3_campaign.py |
| S3-07 | all PRE-S3 closure gates rerun PASS: P3-01..P3-26 (includes every V1.1 gate P3-01..P3-20 and the V1.2 gates P3-21..P3-26) | **PASS** | 1/1 | test_s3_campaign.py |
| S3-08 | Gamma admissible cuts per spec17 §5 (available <= t; service on every date of [t;t+6]; <= 2 superseding versions) incl. sensitivities | **PASS** | 1/1 | test_s3_engines.py |
| S3-09 | WitnessSearch deterministic and input-permutation invariant | **PASS** | 1/1 | test_s3_engines.py |
| S3-10 | no future-cut witness: every witness version available <= tick and every artifact completed <= tick (negative tests) | **PASS** | 1/1 | test_s3_engines.py |
| S3-11 | fixed-R enforced: cross-slot substitution rejected; only designated-slot instances considered | **PASS** | 1/1 | test_s3_engines.py |
| S3-12 | JointWitness provenance complete: one WitnessBinding per slot (artifact; contracts; all EvaluationResults at the witness cut; catalog-entry digest; birth context; provenance digest; TemporalEvidence) + GammaEvidence | **PASS** | 1/1 | test_s3_engines.py |
| S3-13 | K3 never usable as an ordinary admission contract (rejected) | **PASS** | 1/1 | test_s3_engines.py |
| S3-14 | admission decision order exactly as frozen (current -> historical witness -> repair -> no-artifact); action/mode representation per V1.1 | **PASS** | 1/1 | test_s3_engines.py |
| S3-15 | historical repair deterministic; OPT_hist vs OPT_current with frozen decision-time cost estimates; tie -> current | **PASS** | 1/1 | test_s3_engines.py |
| S3-16 | rederive(r;c) creates a new instance of the same slot; no synthetic historical state; no future information | **PASS** | 1/1 | test_s3_engines.py |
| S3-17 | A->B->A remain distinct state events in witness/repair; recurrence valid only through realized states | **PASS** | 1/1 | test_s3_engines.py |
| S3-18 | CostModel deterministic given the frozen ledger | **PASS** | 1/1 | test_s3_engines.py |
| S3-19 | cost-accounting symmetry and measurement parity: F1/N5 share the est(s;t) ledger; measurement rules and envelopes and are charged their own executions; N1 uses identical measurement methodology and the authoritative OTP envelope but is charged its OWN measured native executions | **PASS** | 1/1 | test_s3_engines.py |
| S3-20 | control-plane costs (evaluation; witness search; solver; catalog lookup) charged to the method that incurs them | **PASS** | 1/1 | test_s3_engines.py |
| S3-21 | failed producer attempts accounted; no work disappears | **PASS** | 1/1 | test_s3_engines.py |
| S3-22 | offline analysis/replay cost excluded from online cost | **PASS** | 1/1 | test_s3_engines.py |
| S3-23 | N5 history non-interference: N5 receives only CurrentCutView (= RequestBinding of sanitized BoundArtifacts); sentinel history/catalog/witness-index objects raise if touched | **PASS** | 1/1 | test_s3_engines.py |
| S3-24 | N5 current-cut parity: identical contracts; evaluator and verdicts as F1 at the current cut | **PASS** | 1/1 | test_s3_engines.py |
| S3-25 | N5 receives no F1 witnesses; historical summaries or cache hints (construction + runtime spies) | **PASS** | 1/1 | test_s3_engines.py |
| S3-26 | N1 native --loadStreet + cache.enabled active; cache persisted across eligible builds; instrumentation recorded | **PASS** | 2/2 | test_s3_engines.py |
| S3-27 | N1 resource envelope identical to F1 router production (same envelope digest) | **PASS** | 1/1 | test_s3_engines.py |
| S3-28 | N1 has no historical witness mechanism | **PASS** | 1/1 | test_s3_engines.py |
| S3-29 | N1 executed with the real pinned OTP on non-study fixtures (or BLOCKED with exact reason) | **PASS** | 1/1 | test_s3_engines.py |
| S3-30 | replay deterministic; reproduces every decision from the sealed ledger | **PASS** | 1/1 | test_s3_campaign.py |
| S3-31 | replay never consults future events and never mutates the source ledger | **PASS** | 1/1 | test_s3_campaign.py |
| S3-32 | mutation sample deterministic: ids sorted; ranked with the mutation seed; top ceil(5%·n) | **PASS** | 1/1 | test_s3_engines.py |
| S3-33 | mutation families exactly as frozen; invalid mutations fail closed | **PASS** | 1/1 | test_s3_engines.py |
| S3-34 | mutation detection semantics on fixtures (mutant contract admits where Canon differs -> missing dependence detected) | **PASS** | 1/1 | test_s3_engines.py |
| S3-35 | raw export complete (all frozen fields) | **PASS** | 1/1 | test_s3_campaign.py |
| S3-36 | raw export append-only and provenance-linked | **PASS** | 1/1 | test_s3_campaign.py |
| S3-37 | every aggregate recomputed from the raw export alone | **PASS** | 1/1 | test_s3_campaign.py |
| S3-38 | frozen analysis: unit; influence period; denominators; missing/failure/inconclusive rules exactly as frozen | **PASS** | 1/1 | test_s3_campaign.py |
| S3-39 | frozen analysis deterministic (seeded exact sign test; BCa B=9;999; wild-cluster Rademacher) | **PASS** | 1/1 | test_s3_campaign.py |
| S3-40 | Holm family exactly {H_witness(K0); H_repair(K0); H_hist(K2); H_native(K2)} | **PASS** | 1/1 | test_s3_campaign.py |
| S3-41 | namespace firewall: FIXTURE free; VALIDATION only under gate; TEST inaccessible | **PASS** | 1/1 | test_s3_campaign.py |
| S3-42 | change-class firewall (E1/E2/S1/R1) enforced | **PASS** | 1/1 | test_s3_campaign.py |
| S3-43 | no scientific result emitted (fixture marker on every output; no TEST data) | **PASS** | 1/1 | test_s3_campaign.py |
| S3-44 | no secret emitted (secret scan of all outputs) | **PASS** | 1/1 | test_s3_campaign.py |
| S3-45 | no live campaign: --real still refuses; no study API contacted | **PASS** | 1/1 | test_s3_campaign.py |
| S3-46 | orchestrator Phases 11-16 use real Session-3 engines in FIXTURE mode; Phase 00->18 COMPLETE | **PASS** | 1/1 | test_s3_campaign.py |
| S3-47 | fixture E2E with F1/N5/N1 reproduces identifiability traces T1-T4 (non-study) | **PASS** | 1/1 | test_s3_engines.py |
| S3-48 | mandatory negative-test battery (08/10/11/13 specs) all PASS | **PASS** | 1/1 | test_s3_campaign.py |
| S3-49 | static analysis clean (ruff; mypy; shellcheck) | **PASS** | 1/1 | test_s3_campaign.py |
| S3-50 | Session-3 package integrity and Session-4 handoff verified | **PASS** | 1/1 (packaging command; PACKAGE_VERIFICATION.json) |  |
| S3-51 | V1.2 interface file src/f1/workload_c/interfaces/session3.py (F1-WC-S3-INTERFACES-V1.2) SHA-256 unchanged through Session 3 (equals PRE_S3_FROZEN_DIGESTS.json) unless a formal pre-implementation amendment exists | **PASS** | 1/1 | test_s3_engines.py |
| S3-52 | exact est(s;t) median convention incl. even-n arithmetic median; reproduces V1_2_REFERENCE_VECTORS.json est cases | **PASS** | 1/1 | test_s3_engines.py |
| S3-53 | multi-slot repair: canonical serial order; exact target cut; t information boundary; fail-fast; attempted-work charging; reproduces repair_execution vectors | **PASS** | 1/1 | test_s3_engines.py |
| S3-54 | method-specific overlay isolation and binding-rule parity (identical ConsumerRequest; each method binds shared + own overlay; N5 invariant to F1 overlay); reproduces binding vector | **PASS** | 1/1 | test_s3_engines.py |
| S3-55 | N1 native cost observations are N1's own measured executions; distinct from the F1/N5 est ledger; with identical measurement/envelope rules; one-time preprocessing charged once per region | **PASS** | 2/2 | test_s3_engines.py |
| S3-56 | BCa and wild bootstrap use region as cluster with B = 9;999; frozen seeds; PCG64/numpy 2.4.4 and the frozen formulas; exact sign test; reproduces inference vectors | **PASS** | 1/1 | test_s3_engines.py |
| S3-57 | paired OPERATIONAL_CAP exclusion applies to HSR / repair / DeltaCost / H_hist / H_native | **PASS** | 1/1 | test_s3_1_corrections.py |
| S3-58 | regions with zero eligible paired cells give an undefined contrast; a measured zero stays a defined zero | **PASS** | 1/1 | test_s3_1_corrections.py |
| S3-59 | one-time N1 preprocessing survives per-tick exclusions and is charged exactly once per participating region | **PASS** | 1/1 | test_s3_1_corrections.py |
| S3-60 | catalog_lookup and online journal/fsync B costs measured and emitted without nested double counting | **PASS** | 1/1 | test_s3_1_corrections.py |
| S3-61 | real producer CPU seconds survive producer -> cost record -> raw export -> replay | **PASS** | 1/1 | test_s3_1_corrections.py |
| S3-62 | mutation subjects use Canon_D reference verdicts and input mutations measure Canon_D | **PASS** | 2/2 | test_s3_1_corrections.py |
| S3-63 | validator_date and validator_file mutation subjects are distinct and valid | **PASS** | 1/1 | test_s3_1_corrections.py |
| S3-64 | actual RealizedHistory journal populated / sealed / used for consistency checks | **PASS** | 1/1 | test_s3_1_corrections.py |
| S3-65 | ReplayItem source_event_ids are sealed history event ids; every SealedLedger digest verified | **PASS** | 1/1 | test_s3_1_corrections.py |
| S3-66 | DeltaCost per-unit mean and exact-binomial prevalence produced deterministically | **PASS** | 1/1 | test_s3_1_corrections.py |
