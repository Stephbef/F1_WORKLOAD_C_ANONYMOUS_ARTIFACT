| Gate | Requirement | Status | Tests (pass/run) | Evidence |
|---|---|---|---|---|
| OSC-01 | authoritative input identity | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-02 | complete scientific regression | **PASS** | 2/2 | test_oneshot_campaign.py |
| OSC-03 | launcher executable | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-04 | one-command path | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-05 | secret redaction | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-06 | target identity capture | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-07 | L28 hard-stop | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-08 | dependency verification | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-09 | network hard-stop | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-10 | disk-space hard-stop | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-11 | cache protocol pre-timing freeze | **PASS** | 4/4 | test_oneshot_campaign.py |
| OSC-12 | real population state | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-13 | 24-region deterministic selection | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-14 | 8/16 deterministic split | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-15 | test sealing | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-16 | OSM pinning (V3 rule; verified provenance) | **PASS** | 2/2 | test_oneshot_campaign.py |
| OSC-17 | real producer path | **PASS** | 3/3 | test_oneshot_campaign.py |
| OSC-18 | fixture forbidden in REAL | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-19 | validation readiness | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-20 | exactly 8 validation regions | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-21 | no test before authorization | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-22 | N4 exact candidate set | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-23 | N4 exact selection function | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-24 | N4 no F1 dependency | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-25 | validation incident classification | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-26 | source modification after validation forces stop | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-27 | unresolved E1 forces stop | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-28 | unresolved E2 forces stop | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-29 | S1 forces restart | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-30 | R1 forbidden | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-31 | validation closure | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-32 | campaign freeze | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-33 | automatic pretest audit | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-34 | authorization bound to freeze hash | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-35 | exactly 16 test regions | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-36 | no scientific retuning during test | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-37 | replay | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-38 | mutations | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-39 | analysis immutable | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-40 | safe-stop package | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-41 | resume identity | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-42 | concurrent-run lock | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-43 | idempotency | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-44 | dry run | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-45 | preflight-only | **PASS** | 2/2 | test_oneshot_campaign.py |
| OSC-46 | status command read-only | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-47 | no secrets in package | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-48 | final results package | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-49 | no fabricated real evidence | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-50 | end-to-end fixture state machine (cases A-H) | **PASS** | 6/6 | test_oneshot_campaign.py |
| OSC-51 | router semantic-config digest identical for consecutive build days | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-52 | changing a semantic config field changes the digest | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-53 | K2 still rejects a router whose service coverage does not contain D | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-54 | every router producer path uses the frozen absolute service bounds | **PASS** | 1/1 | test_oneshot_campaign.py |
| OSC-55 | no real producer can fall back to relative OTP service defaults | **PASS** | 1/1 | test_oneshot_campaign.py |
