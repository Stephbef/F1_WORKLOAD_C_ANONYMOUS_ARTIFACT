#!/usr/bin/env python3
"""FIXTURE_STUB_BINARY stand-in for gtfs-validator 8.0.1 (ENGINEERING ONLY — never a real producer).
Accepts the real CLI shape (-i -o -d -c -svu -t) plus --stub-behavior {ok,nonzero,timeout,corrupt,oom}.
Deterministic notices: missing required files -> ERROR missing_required_file; feed_info.txt absent -> WARNING
missing_recommended_file; a stop_times row with arrival after departure -> ERROR stop_time_with_arrival_before_previous_departure_time-like."""
import argparse, io, json, os, sys, time, zipfile
p = argparse.ArgumentParser(add_help=False)
p.add_argument("-i"); p.add_argument("-o"); p.add_argument("-d"); p.add_argument("-c"); p.add_argument("-t")
p.add_argument("-svu", action="store_true"); p.add_argument("--stub-behavior", default="ok")
a = p.parse_args()
b = a.stub_behavior
if b == "timeout":
    time.sleep(3600)
if b == "nonzero":
    print("stub: simulated crash", file=sys.stderr); sys.exit(3)
if b == "oom":
    os.kill(os.getpid(), 9)
os.makedirs(a.o, exist_ok=True)
if b == "corrupt":
    open(os.path.join(a.o, "report.json"), "w").write('{"summary": {"validatorVersion": "FIX'); sys.exit(0)
notices = []
with zipfile.ZipFile(a.i) as z:
    names = {n.split("/")[-1].lower() for n in z.namelist()}
    for req in ("agency.txt", "stops.txt", "routes.txt", "trips.txt", "stop_times.txt"):
        if req not in names:
            notices.append({"code": "missing_required_file", "severity": "ERROR", "totalNotices": 1})
    if "calendar.txt" not in names and "calendar_dates.txt" not in names:
        notices.append({"code": "missing_calendar_and_calendar_date_files", "severity": "ERROR", "totalNotices": 1})
    if "feed_info.txt" not in names:
        notices.append({"code": "missing_recommended_file", "severity": "WARNING", "totalNotices": 1})
    if "stop_times.txt" in names:
        raw = z.read([n for n in z.namelist() if n.lower().endswith("stop_times.txt")][0]).decode("utf-8-sig")
        if "99:99:99" in raw:
            notices.append({"code": "invalid_time", "severity": "ERROR", "totalNotices": raw.count("99:99:99")})
notices.sort(key=lambda n: (n["code"], n["severity"]))
rep = {"summary": {"validatorVersion": "FIXTURE-STUB-of-8.0.1", "dateForValidation": a.d, "countryCode": a.c,
                   "threads": a.t, "stub": True}, "notices": notices}
json.dump(rep, open(os.path.join(a.o, "report.json"), "w"), sort_keys=True)
print("stub validator done")
