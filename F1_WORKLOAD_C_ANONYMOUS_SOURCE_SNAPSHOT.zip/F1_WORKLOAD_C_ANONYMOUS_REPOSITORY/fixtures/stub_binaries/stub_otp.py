#!/usr/bin/env python3
"""FIXTURE_STUB_BINARY stand-in for OTP 2.10.0 (ENGINEERING ONLY). Accepts `--buildStreet DIR` and
`--loadStreet --save DIR`; writes a deterministic stub graph (canonical JSON of the declared semantic inputs).
--stub-behavior {ok,nonzero,timeout,oom}. Attempts no network access; reads only local files in DIR."""
import hashlib, json, os, sys, time
args = sys.argv[1:]
beh = "ok"
if "--stub-behavior" in args:
    i = args.index("--stub-behavior"); beh = args[i + 1]; del args[i:i + 2]
if beh == "timeout": time.sleep(3600)
if beh == "nonzero": print("stub otp crash", file=sys.stderr); sys.exit(4)
if beh == "oom": os.kill(os.getpid(), 9)
d = args[-1]
cfg = json.load(open(os.path.join(d, "build-config.json")))
if "--buildStreet" in args:
    osm = [o["source"] for o in cfg.get("osm", [])]
    h = hashlib.sha256(b"".join(open(os.path.join(d, s), "rb").read() for s in osm)).hexdigest()
    json.dump({"stub": "FIXTURE_STUB_BINARY", "street_from_osm": h}, open(os.path.join(d, "streetGraph.obj"), "w"))
    print("stub street graph built"); sys.exit(0)
street = json.load(open(os.path.join(d, "streetGraph.obj")))
feeds = []
for f in sorted(cfg["transitFeeds"], key=lambda x: x["feedId"]):
    feeds.append([f["feedId"], hashlib.sha256(open(os.path.join(d, f["source"]), "rb").read()).hexdigest()])
g = {"stub": "FIXTURE_STUB_BINARY", "otp": "stub-of-2.10.0", "street": street["street_from_osm"], "feeds": feeds,
     "config": {k: v for k, v in sorted(cfg.items()) if k not in ("transitFeeds", "osm")}}
open(os.path.join(d, "graph.obj"), "w").write(json.dumps(g, sort_keys=True))
print("stub transit graph saved")
