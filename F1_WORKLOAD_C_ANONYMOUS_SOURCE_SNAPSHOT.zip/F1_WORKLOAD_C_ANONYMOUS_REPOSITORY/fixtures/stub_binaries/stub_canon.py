#!/usr/bin/env python3
"""FIXTURE_STUB_BINARY stand-in for CanonExtractFinal (ENGINEERING ONLY). Same argv shape:
graph.obj D1,D2,.. out configSha osmSha otpSha -> prints 'CANON11_SHA256 <hex> records <n>' over a stub record set."""
import hashlib, json, sys
g, D, out, cfg, osm, otp = sys.argv[1:7]
graph = json.load(open(g))
recs = ["0schema|F1-OTP-CANON-1.3-FIXTURE-STUB", "0otp|stub|" + otp, "0config|" + cfg, "0osm|" + osm, "0horizon|" + D]
recs += sorted("feed|%s|%s" % (f, h) for f, h in graph["feeds"])
blob = "\n".join(recs).encode()
open(out, "wb").write(blob)
print("CANON11_SHA256 %s records %d" % (hashlib.sha256(blob).hexdigest(), len(recs) - 5))
