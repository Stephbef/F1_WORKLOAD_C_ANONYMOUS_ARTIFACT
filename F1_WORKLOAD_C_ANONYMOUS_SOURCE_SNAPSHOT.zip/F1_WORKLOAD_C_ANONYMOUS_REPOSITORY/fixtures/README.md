# Workload-C Session-1 fixtures — ENGINEERING FIXTURE ONLY — NOT SCIENTIFIC DATA

The fixture population is generated deterministically at run time by `src/f1/workload_c/fixturegen/`
(no randomness, no study feed bytes): 122 synthetic feeds (123 catalog records incl. one duplicate), 3,021 dataset
records, ~3,000 synthetic GTFS ZIPs (~6 MB). `expected/fixture_population_expected.json` freezes the expected
eligible regions (33), the controlled exclusions (24), the selected 24 (rank order) and the 8/16 split.
These expectations are test oracles for the engineering pipeline only.
