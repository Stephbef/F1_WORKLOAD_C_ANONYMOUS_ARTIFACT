#!/usr/bin/env bash
# F1 SIGMOD 2027 — Workload C — ONE-SHOT CAMPAIGN LAUNCHER (authoritative target server).
#   ./run_f1_workload_c_campaign.sh --mobility-token-file /secure/path/token --work-root /data/f1_workload_c [--new-campaign|--resume]
#   ./run_f1_workload_c_campaign.sh --dry-run        --work-root /data/f1_workload_c
#   ./run_f1_workload_c_campaign.sh --preflight-only --mobility-token-file /secure/path/token --work-root /data/f1_workload_c
# Default (no mode flag) = --new-campaign. The launcher owns the preregistered state machine; it never patches source,
# never changes configuration and never continues past a fail-closed SAFE STOP.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"
PY="${PYTHON:-python3}"
args=("$@")
mode_given=0
for a in "${args[@]}"; do
  case "$a" in --new-campaign|--resume|--dry-run|--preflight-only) mode_given=1 ;; esac
done
if [ "$mode_given" -eq 0 ]; then args+=("--new-campaign"); fi
if [ -f "$HERE/../F1_WORKLOAD_C_ONE_SHOT_SERVER_CAMPAIGN_FINAL.zip" ]; then
  F1_WC_PACKAGE_SHA256="$(sha256sum "$HERE/../F1_WORKLOAD_C_ONE_SHOT_SERVER_CAMPAIGN_FINAL.zip" | cut -d' ' -f1)"
  export F1_WC_PACKAGE_SHA256
fi
set +x                                   # never echo the command line (token file path only; the token is never read here)
PYTHONPATH="$HERE/src" exec "$PY" -m f1.workload_c.oneshot.cli "${args[@]}"
