import sys

from f1.runner.cli import main

sys.exit(main())
