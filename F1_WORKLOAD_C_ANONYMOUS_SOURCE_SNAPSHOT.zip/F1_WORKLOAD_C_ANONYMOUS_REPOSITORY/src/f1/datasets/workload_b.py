"""Workload B acquisition.

Sources (frozen in configs/workload_b.yaml and datasets/workload_b/datasets_manifest.json):
  * tlc_yellow : NYC TLC yellow-taxi monthly parquet files; table version m = rolling window of the last
                 `window_months` monthly files ending at month m (a retention-limited fact table);
                 R = taxi zone lookup (single version) for referential integrity.
  * owid_covid : owid/covid-19-data git history of public/data/owid-covid-data.csv, weekly snapshots.
  * nyt_covid  : nytimes/covid-19-data git history of us-counties.csv, weekly snapshots (negative control:
                 massive row churn, stable schema).
CSV snapshots are converted once to parquet with deterministic pyarrow type inference; any type drift between
versions is natural and kept. Every downloaded file is sha256-recorded; a mismatch on re-acquisition aborts.
"""
from __future__ import annotations

import io
import json
import subprocess
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from ..common.util import CAS, DAY, F1Error, atomic_write_json, iso_of, parse_iso, read_json, sha256_bytes
from .workload_a import UA, clone_blobless, git, path_history, show


def _download(url: str, timeout: int = 600) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    last = None
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except (urllib.error.URLError, TimeoutError) as e:
            last = e
            time.sleep(10 * (attempt + 1))
    raise F1Error(f"download failed: {url}: {last}")


def csv_to_parquet(data: bytes) -> bytes:
    import pyarrow.csv as pacsv
    import pyarrow.parquet as pq
    t = pacsv.read_csv(io.BytesIO(data), read_options=pacsv.ReadOptions(block_size=1 << 26))
    buf = io.BytesIO()
    pq.write_table(t, buf, compression="snappy", write_statistics=True)
    return buf.getvalue()


def _months(start: str, end: str) -> list[str]:
    y, m = map(int, start.split("-"))
    ye, me = map(int, end.split("-"))
    out = []
    while (y, m) <= (ye, me):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


def _month_end_ts(ym: str) -> float:
    y, m = map(int, ym.split("-"))
    nxt = datetime(y + (m == 12), 1 if m == 12 else m + 1, 1, tzinfo=timezone.utc)
    return nxt.timestamp() - 1


def acquire_tlc(ds: dict, cas: CAS, out: Path, pinned: dict | None, log=print) -> dict:
    if out.exists():
        return read_json(out)
    files = {}
    for ym in _months(ds["first_month"], ds["last_month"]):
        url = ds["url_template"].format(ym=ym)
        b = _download(url)
        h = sha256_bytes(b)
        if pinned and ym in pinned and pinned[ym] != h:
            raise F1Error(f"TLC {ym}: sha256 {h} != frozen {pinned[ym]} (source changed)")
        files[ym] = {"url": url, "sha256": cas.put(b, compress=False), "bytes": len(b)}
        log(f"[acquire] tlc {ym}: {len(b) / 1e6:.1f} MB")
    ref_bytes = _download(ds["ref_url"])
    ref_pq = csv_to_parquet(ref_bytes)
    ref = {"url": ds["ref_url"], "sha256_source": sha256_bytes(ref_bytes), "content_ref": cas.put(ref_pq, compress=False)}
    months = sorted(files)
    w = int(ds["window_months"])
    versions = []
    for i in range(w - 1, len(months)):
        win = months[i - w + 1: i + 1]
        tree = cas.put_tree_refs({f"{ym}.parquet": files[ym]["sha256"] for ym in win})
        versions.append({"vid": months[i], "ts": _month_end_ts(months[i]), "content_ref": tree})
    rec = {"name": ds["name"], "kind": "tlc", "files": files, "ref": ref, "versions": versions}
    atomic_write_json(out, rec)
    return rec


def acquire_git_csv(ds: dict, cache: Path, cas: CAS, out: Path, log=print) -> dict:
    if out.exists():
        return read_json(out)
    d = clone_blobless(ds["git_url"], cache / (ds["name"] + ".git"))
    end_commit = ds.get("pinned_end_commit") or git(d, "rev-parse", "HEAD").strip()
    hist = path_history(d, end_commit, ds["path"])
    lo, hi = parse_iso(ds["start"]), parse_iso(ds["end"])
    weekly: dict[str, tuple[str, float]] = {}
    for sha, ct in hist:
        if not (lo <= ct <= hi):
            continue
        wk = datetime.fromtimestamp(ct, tz=timezone.utc).strftime("%G-W%V")
        if wk not in weekly or ct >= weekly[wk][1]:
            weekly[wk] = (sha, ct)
    versions, last = [], None
    for wk in sorted(weekly):
        sha, ct = weekly[wk]
        b = show(d, sha, ds["path"])
        if b is None:
            continue
        pq_bytes = csv_to_parquet(b)
        ref = cas.put_tree_refs({"data.parquet": cas.put(pq_bytes, compress=False)})
        if ref == last:
            continue
        versions.append({"vid": wk, "ts": ct, "commit": sha, "content_ref": ref, "source_sha256": sha256_bytes(b)})
        last = ref
        log(f"[acquire] {ds['name']} {wk}: {len(b) / 1e6:.1f} MB csv")
    rec = {"name": ds["name"], "kind": "git_csv", "git_url": ds["git_url"], "end_commit": end_commit,
           "path": ds["path"], "versions": versions}
    atomic_write_json(out, rec)
    return rec


def acquire(bcfg: dict, root: Path, cas: CAS, log=print) -> dict:
    out_dir = root / "workload_b"
    cache = root / "cache" / "git"
    summary = {}
    for ds in bcfg["datasets"]:
        p = out_dir / f"{ds['name']}.json"
        try:
            if ds["kind"] == "tlc":
                rec = acquire_tlc(ds, cas, p, ds.get("pinned_sha256"), log)
            else:
                rec = acquire_git_csv(ds, cache, cas, p, log)
            summary[ds["name"]] = {"status": "ok", "versions": len(rec["versions"])}
        except F1Error as e:
            summary[ds["name"]] = {"status": "failed", "error": str(e)}
            log(f"[acquire] {ds['name']} FAILED: {e}")
    atomic_write_json(out_dir / "acquisition_summary.json", summary)
    return summary
