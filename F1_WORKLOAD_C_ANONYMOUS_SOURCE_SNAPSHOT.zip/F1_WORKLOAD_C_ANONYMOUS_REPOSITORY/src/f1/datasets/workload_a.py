"""Workload A acquisition.

select_repos(): algorithmic, pre-registered selection of exactly N Rust repositories:
  candidates = GitHub search `language:Rust` sorted by stars (desc), excluding forks/archived/dev-exclusions;
  keep the first N satisfying ALL filters (evaluated on a blobless clone, no API rate cost):
    F1 Cargo.lock present at repo root at the pinned end commit;
    F2 >= min_history_months of history before the window end;
    F3 >= min_lock_commits Cargo.lock-changing first-parent commits inside the analysis window;
    F4 Cargo.lock parses (TOML) at the end commit with >= min_registry_packages crates.io packages;
    F5 binary target at the end commit (src/main.rs or [[bin]] in Cargo.toml) — "executable enough".
  then a seeded shuffle assigns n_validation repositories to the validation split, the rest to test.
acquire(): pulls lockfile/policy/rev/tag histories, advisory-DB daily snapshots (validated by the pinned
cargo-audit; unparsable days are excluded and recorded), and the license table (immutable per crate version).
"""
from __future__ import annotations

import json
import os
import random
import subprocess
import time
import tomllib
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

from ..common.util import CAS, DAY, F1Error, atomic_write_json, iso_of, parse_iso, read_json, sha256_obj

UA = "f1-research-harness/0.1 (reproducible research; contact via repository)"


# ---------------------------------------------------------------------------------------------
# git helpers
# ---------------------------------------------------------------------------------------------
def git(repo: Path, *args, check=True, binary=False, timeout=3600) -> bytes | str:
    p = subprocess.run(["git", "-C", str(repo)] + list(args), capture_output=True, timeout=timeout)
    if check and p.returncode != 0:
        raise F1Error(f"git {' '.join(args)} failed in {repo}: {p.stderr.decode(errors='replace')[-500:]}")
    return p.stdout if binary else p.stdout.decode("utf-8", "replace")


def clone_blobless(url: str, dest: Path) -> Path:
    if (dest / "HEAD").exists():
        git(dest, "fetch", "--quiet", "origin", "+refs/heads/*:refs/heads/*", "+refs/tags/*:refs/tags/*", check=False)
        return dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    p = subprocess.run(["git", "clone", "--quiet", "--bare", "--filter=blob:none", url, str(dest)],
                       capture_output=True, timeout=7200)
    if p.returncode != 0:
        raise F1Error(f"clone failed {url}: {p.stderr.decode(errors='replace')[-500:]}")
    return dest


def clone_full(url: str, dest: Path) -> Path:
    if (dest / "HEAD").exists():
        git(dest, "fetch", "--quiet", "origin", "+refs/heads/*:refs/heads/*", check=False)
        return dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    p = subprocess.run(["git", "clone", "--quiet", "--bare", url, str(dest)], capture_output=True, timeout=7200)
    if p.returncode != 0:
        raise F1Error(f"clone failed {url}: {p.stderr.decode(errors='replace')[-500:]}")
    return dest


def default_branch(repo: Path) -> str:
    ref = git(repo, "symbolic-ref", "HEAD", check=False).strip()
    return ref.replace("refs/heads/", "") if ref else "HEAD"


def rev_before(repo: Path, branch: str, ts: float) -> str | None:
    out = git(repo, "rev-list", "-1", "--first-parent", f"--before={int(ts)}", branch, check=False).strip()
    return out or None


def path_history(repo: Path, end_commit: str, path: str, since: float | None = None) -> list[tuple[str, float]]:
    args = ["log", "--first-parent", "--format=%H %ct", end_commit]
    if since is not None:
        args.insert(3, f"--since={int(since)}")
    out = git(repo, *args, "--", path, check=False)
    rows = []
    for line in out.splitlines():
        sha, ct = line.split()
        rows.append((sha, float(ct)))
    return sorted(rows, key=lambda r: r[1])


def show(repo: Path, commit: str, path: str) -> bytes | None:
    p = subprocess.run(["git", "-C", str(repo), "show", f"{commit}:{path}"], capture_output=True, timeout=600)
    return p.stdout if p.returncode == 0 else None


# ---------------------------------------------------------------------------------------------
# selection
# ---------------------------------------------------------------------------------------------
def github_search(page: int, per_page: int = 100, token: str | None = None) -> list[dict]:
    url = f"https://api.github.com/search/repositories?q=language:Rust&sort=stars&order=desc&per_page={per_page}&page={page}"
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/vnd.github+json",
                                               **({"Authorization": f"Bearer {token}"} if token else {})})
    for attempt in range(6):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.load(r)["items"]
        except urllib.error.HTTPError as e:
            if e.code in (403, 429) and attempt < 5:
                time.sleep(65)
                continue
            raise F1Error(f"GitHub search failed (HTTP {e.code}); set GITHUB_TOKEN or retry later") from e
    raise F1Error("GitHub search exhausted retries")


def evaluate_candidate(repo_dir: Path, wcfg: dict) -> tuple[bool, dict]:
    start, end = parse_iso(wcfg["window"]["birth_start"]), parse_iso(wcfg["window"]["horizon_end"])
    br = default_branch(repo_dir)
    end_commit = rev_before(repo_dir, br, end)
    info = {"default_branch": br, "end_commit": end_commit, "start_commit": rev_before(repo_dir, br, start),
            "window": [wcfg["window"]["birth_start"], wcfg["window"]["horizon_end"]]}
    if not end_commit:
        return False, info | {"reason": "no commit before window end"}
    lock = show(repo_dir, end_commit, "Cargo.lock")
    if lock is None:
        return False, info | {"reason": "F1: no Cargo.lock at root"}
    first = git(repo_dir, "rev-list", "--max-parents=0", "--first-parent", end_commit, check=False).split()
    first_ct = min(float(git(repo_dir, "show", "-s", "--format=%ct", c).strip()) for c in first) if first else end
    months = (end - first_ct) / (30.44 * DAY)
    info["history_months"] = round(months, 1)
    if months < wcfg["selection"]["min_history_months"]:
        return False, info | {"reason": "F2: history too short"}
    commits = [c for c in path_history(repo_dir, end_commit, "Cargo.lock") if start <= c[1] <= end]
    info["lock_commits_in_window"] = len(commits)
    if len(commits) < wcfg["selection"]["min_lock_commits"]:
        return False, info | {"reason": "F3: too few Cargo.lock commits in window"}
    try:
        from ..producers.rustsec import registry_packages
        n = len(registry_packages(lock.decode("utf-8")))
    except (tomllib.TOMLDecodeError, UnicodeDecodeError, KeyError) as e:
        return False, info | {"reason": f"F4: Cargo.lock unparsable ({e})"}
    info["registry_packages_at_end"] = n
    if n < wcfg["selection"]["min_registry_packages"]:
        return False, info | {"reason": "F4: too few registry packages"}
    has_main = show(repo_dir, end_commit, "src/main.rs") is not None
    cargo_toml = show(repo_dir, end_commit, "Cargo.toml") or b""
    has_bin = b"[[bin]]" in cargo_toml
    info["binary_target"] = bool(has_main or has_bin)
    if not (has_main or has_bin):
        return False, info | {"reason": "F5: no binary target at root"}
    return True, info | {"reason": "all filters satisfied"}


def select_repos(wcfg: dict, cache: Path, out_manifest: Path, token: str | None = None, log=print) -> dict:
    sel = wcfg["selection"]
    exclude = set(sel.get("exclude", []))
    chosen, rejected = [], []
    page = 1
    while len(chosen) < sel["n_repos"]:
        if page > sel.get("max_search_pages", 10):
            raise F1Error(f"only {len(chosen)} repositories satisfied the filters after {page - 1} pages")
        for it in github_search(page, token=token):
            if len(chosen) >= sel["n_repos"]:
                break
            full = it["full_name"]
            if it.get("fork") or it.get("archived") or full in exclude:
                rejected.append({"repo": full, "reason": "fork/archived/excluded"})
                continue
            d = cache / (full.replace("/", "__") + ".git")
            try:
                clone_blobless(it["clone_url"], d)
                ok, info = evaluate_candidate(d, wcfg)
            except F1Error as e:
                ok, info = False, {"reason": f"error: {e}"}
            rec = {"repo": full, "url": it["clone_url"], "stars_at_selection": it.get("stargazers_count"),
                   "rank": len(chosen) + len(rejected) + 1, **info}
            log(f"[select] {full}: {'KEEP' if ok else 'reject'} ({info.get('reason')})")
            rec["eligible"] = ok
            from ..common.util import append_jsonl
            append_jsonl(out_manifest.with_name("repos_selection_log.jsonl"), rec)
            (chosen if ok else rejected).append(rec)
        page += 1
    rng = random.Random(int(sel["split_seed"]))
    order = list(range(len(chosen)))
    rng.shuffle(order)
    val = set(order[: sel["n_validation"]])
    for i, r in enumerate(chosen):
        r["split"] = "validation" if i in val else "test"
        r["slug"] = r["repo"].replace("/", "__")
    body = {"workload": "A", "selection_procedure": "GitHub search language:Rust sorted by stars desc; first N passing F1-F5 in rank order; seeded validation/test split; no oracle information used",
            "criteria": sel, "window": wcfg["window"], "selected": chosen,
            "rejected_before_quota": rejected, "selected_at": iso_of(time.time())}
    body["manifest_sha256"] = sha256_obj({k: v for k, v in body.items() if k != "selected_at"})
    atomic_write_json(out_manifest, body)
    return body


# ---------------------------------------------------------------------------------------------
# acquisition
# ---------------------------------------------------------------------------------------------
POLICY_PATHS = ("deny.toml", ".cargo/audit.toml", "audit.toml")


def acquire_repo(rec: dict, wcfg: dict, cache: Path, cas: CAS, out_dir: Path) -> dict:
    out = out_dir / f"{rec['slug']}.json"
    if out.exists():
        return read_json(out)
    d = clone_blobless(rec["url"], cache / f"{rec['slug']}.git")
    end_commit = rec["end_commit"]
    if git(d, "cat-file", "-t", end_commit, check=False).strip() != "commit":
        raise F1Error(f"pinned end commit {end_commit} missing in {rec['repo']} (history rewritten?)")
    start = parse_iso(wcfg["window"]["birth_start"])

    def versions(path: str) -> list[dict]:
        hist = path_history(d, end_commit, path)
        before = [c for c in hist if c[1] < start]
        inwin = [c for c in hist if c[1] >= start]
        seq = ([before[-1]] if before else []) + inwin
        rows, last = [], None
        for sha, ct in seq:
            b = show(d, sha, path)
            if b is None:
                ref = None  # file deleted at this commit
            else:
                ref = cas.put(b)
            if ref != last:
                rows.append({"commit": sha, "ts": ct, "content_ref": ref})
                last = ref
        return rows

    locks = versions("Cargo.lock")
    if not locks or locks[0]["content_ref"] is None:
        raise F1Error(f"{rec['repo']}: no Cargo.lock at window start")
    policy_path, policies = None, []
    for pp in POLICY_PATHS:
        v = versions(pp)
        if any(r["content_ref"] for r in v):
            policy_path, policies = pp, v
            break
    revs = []
    for line in git(d, "log", "--first-parent", "--format=%H %ct", f"--since={int(start) - 400 * 86400}", end_commit).splitlines():
        sha, ct = line.split()
        revs.append({"commit": sha, "ts": float(ct)})
    revs.sort(key=lambda r: r["ts"])
    tags = []
    for line in git(d, "for-each-ref", "refs/tags", "--format=%(refname:short) %(objectname) %(*objectname)").splitlines():
        parts = line.split()
        name, obj = parts[0], parts[-1]
        if subprocess.run(["git", "-C", str(d), "merge-base", "--is-ancestor", obj, end_commit],
                          capture_output=True).returncode == 0:
            ct = float(git(d, "show", "-s", "--format=%ct", obj).strip())
            if ct >= start:
                tags.append({"tag": name, "commit": obj, "ts": ct})
    data = {"repo": rec["repo"], "slug": rec["slug"], "split": rec["split"], "end_commit": end_commit,
            "lock_versions": locks, "policy_path": policy_path, "policy_versions": policies,
            "revs": revs, "tags": sorted(tags, key=lambda t: t["ts"])}
    atomic_write_json(out, data)
    return data


def acquire_advisory_db(wcfg: dict, cache: Path, cas: CAS, out_path: Path, validate_bin: str | None, log=print) -> dict:
    if out_path.exists():
        return read_json(out_path)
    adb = wcfg["advisory_db"]
    d = clone_full(adb["url"], cache / "advisory-db.git")
    pin = adb.get("pinned_commit")
    if pin and git(d, "cat-file", "-t", pin, check=False).strip() != "commit":
        raise F1Error(f"pinned advisory-db commit {pin} missing")
    end_ref = pin or default_branch(d)
    start = parse_iso(wcfg["window"]["birth_start"]) - DAY
    end = parse_iso(wcfg["window"]["horizon_end"])
    days, tree_cache, valid_cache = [], {}, {}
    t = start
    while t <= end + 1e-6:
        day_end = t + DAY - 1
        c = git(d, "rev-list", "-1", f"--before={int(day_end)}", end_ref).strip()
        if not c:
            t += DAY
            continue
        tree = git(d, "rev-parse", f"{c}^{{tree}}").strip()
        if tree not in tree_cache:
            files = {}
            listing = git(d, "ls-tree", "-r", c, "--", "crates").splitlines()
            for line in listing:
                meta, path = line.split("\t", 1)
                _, typ, blob = meta.split()
                if typ != "blob":
                    continue
                files[path] = blob
            batch = subprocess.run(["git", "-C", str(d), "cat-file", "--batch"], input="\n".join(files.values()).encode() + b"\n",
                                   capture_output=True, timeout=600).stdout
            contents, pos = {}, 0
            for path, blob in files.items():
                hdr_end = batch.index(b"\n", pos)
                sha, typ, size = batch[pos:hdr_end].split()
                size = int(size)
                contents[path] = batch[hdr_end + 1: hdr_end + 1 + size]
                pos = hdr_end + 1 + size + 1
            tree_cache[tree] = cas.put_tree(contents)
        ref = tree_cache[tree]
        if ref not in valid_cache:
            valid_cache[ref] = validate_db(cas, ref, validate_bin) if validate_bin else {"ok": None, "error": "not validated"}
        ct = float(git(d, "show", "-s", "--format=%ct", c).strip())
        days.append({"day": iso_of(t)[:10], "commit": c, "ts": ct, "content_ref": ref, "validation": valid_cache[ref]})
        t += DAY
    bad = [x["day"] for x in days if x["validation"]["ok"] is False]
    if bad:
        log(f"[acquire] advisory-db: {len(bad)} unparsable daily snapshots excluded (first: {bad[:3]})")
    out = {"url": adb["url"], "end_ref": git(d, "rev-parse", end_ref).strip(), "days": days,
           "excluded_days": bad}
    atomic_write_json(out_path, out)
    return out


_PROBE_LOCK = b'version = 3\n\n[[package]]\nname = "smallvec"\nversion = "0.6.0"\nsource = "registry+https://github.com/rust-lang/crates.io-index"\n'


def validate_db(cas: CAS, ref: str, binary: str) -> dict:
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        db = Path(td) / "db"
        cas.materialize(ref, db)
        (Path(td) / "Cargo.lock").write_bytes(_PROBE_LOCK)
        p = subprocess.run([binary, "audit", "--db", str(db), "--no-fetch", "--stale", "--json", "--file",
                            str(Path(td) / "Cargo.lock")], capture_output=True, timeout=300,
                           env={"HOME": td, "PATH": "/usr/bin:/bin"})
        ok = p.returncode in (0, 1) and p.stdout.strip().startswith(b"{")
        return {"ok": ok, "error": None if ok else p.stderr.decode(errors="replace")[-300:]}


def collect_packages(repo_datas: list[dict], cas: CAS) -> list[str]:
    from ..producers.rustsec import registry_packages
    pk = set()
    for rd in repo_datas:
        for v in rd["lock_versions"]:
            if v["content_ref"]:
                pk.update(registry_packages(cas.get(v["content_ref"]).decode("utf-8")))
    return sorted(pk)


def fetch_license_table(packages: list[str], cache_path: Path, source: str, rate_s: float = 1.0, log=print) -> dict:
    """License metadata per published crate version (immutable). Sources: 'api' (crates.io API, rate-limited)."""
    table = read_json(cache_path) if cache_path.exists() else {}
    todo = [p for p in packages if p not in table]
    log(f"[acquire] license table: {len(table)} cached, {len(todo)} to fetch via {source}")
    for i, pv in enumerate(todo):
        name, ver = pv.rsplit("@", 1)
        url = f"https://crates.io/api/v1/crates/{name}/{ver}"
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        lic = None
        for attempt in range(4):
            try:
                with urllib.request.urlopen(req, timeout=60) as r:
                    lic = json.load(r)["version"].get("license")
                break
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    break
                time.sleep(5 * (attempt + 1))
            except (urllib.error.URLError, TimeoutError):
                time.sleep(5 * (attempt + 1))
        table[pv] = lic
        if i % 50 == 0:
            atomic_write_json(cache_path, table)
        time.sleep(rate_s)
    atomic_write_json(cache_path, table)
    return {p: table.get(p) for p in packages}


def acquire(manifest: dict, wcfg: dict, root: Path, cas: CAS, validate_bin: str | None, log=print) -> dict:
    cache = root / "cache" / "git"
    out_dir = root / "workload_a" / "repos"
    datas = []
    for rec in manifest["selected"]:
        log(f"[acquire] {rec['repo']}")
        datas.append(acquire_repo(rec, wcfg, cache, cas, out_dir))
    adb = acquire_advisory_db(wcfg, cache, cas, root / "workload_a" / "advisory_db.json", validate_bin, log)
    pkgs = collect_packages(datas, cas)
    table = fetch_license_table(pkgs, root / "workload_a" / "license_cache.json", wcfg["license"]["source"], log=log)
    lref = cas.put(json.dumps(table, sort_keys=True).encode())
    summary = {"repos": [d["slug"] for d in datas], "advisory_db_days": len(adb["days"]),
               "advisory_db_excluded_days": adb["excluded_days"], "license_table_ref": lref,
               "license_packages": len(pkgs), "license_unknown": sum(1 for v in table.values() if v is None)}
    atomic_write_json(root / "workload_a" / "acquisition_summary.json", summary)
    return summary
