"""Workload-independent features."""
from __future__ import annotations

from .lang import feature


@feature("content_hash")
def content_hash(view) -> str:
    """K0: the content reference itself (sha256 of the item's content)."""
    return view.content_ref


def k0_expr(birth_refs: dict[str, str]) -> dict:
    """kappa_hash: equality of captured read contents (D9)."""
    terms = [{"op": "eq", "a": {"op": "feat", "item": i, "f": "content_hash"}, "b": {"op": "const", "v": r}}
             for i, r in sorted(birth_refs.items())]
    return terms[0] if len(terms) == 1 else {"op": "and", "args": terms}
