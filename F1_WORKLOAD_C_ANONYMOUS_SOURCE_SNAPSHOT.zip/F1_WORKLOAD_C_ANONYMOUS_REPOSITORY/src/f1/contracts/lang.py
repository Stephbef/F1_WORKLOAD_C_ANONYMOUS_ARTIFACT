"""Admissibility contracts kappa_r (D8): deterministic, serialisable JSON ASTs over *features* of context items.

Nodes:
  {"op":"const","v":X}
  {"op":"feat","item":I,"f":NAME,"args":{...}}   value of registered feature NAME on item I's content
  {"op":"feat","items":[I,J],"f":NAME,...}       multi-item feature (used by K3 references / joins)
  {"op":"drop_keys","a":N,"b":N}  remove elements "KEY|..." of list a whose KEY is in list b
  {"op":"eq"|"ne"|"lt"|"le"|"gt"|"ge","a":N,"b":N}
  {"op":"and"|"or","args":[N,...]}   {"op":"not","a":N}
  {"op":"subset"|"setminus"|"intersect"|"in","a":N,"b":N}   (lists are treated as sets)
  {"op":"isempty","a":N}

The footprint of a contract is the set of items referenced by feat nodes; the evaluator can only load
those items (sandbox). Features are pure functions of content, hence kappa(c) depends only on the contents
of c restricted to the footprint (footprint transfer, T1a), which the evaluator exploits as a memo key.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable

from ..common.util import F1Error, canonical_json, sha256_obj

ORDER_OPS = {"lt", "le", "gt", "ge"}
CMP_OPS = {"eq", "ne"} | ORDER_OPS
SET_OPS = {"subset", "setminus", "intersect", "in", "drop_keys"}
BOOL_OPS = {"and", "or"}
ALL_OPS = {"const", "feat", "not", "isempty"} | CMP_OPS | SET_OPS | BOOL_OPS


class ContractError(F1Error):
    """Malformed or ill-disciplined contract."""


class FootprintViolation(ContractError):
    """A feature tried to read an item outside the declared footprint."""


# ---------------------------------------------------------------------------------------------
# Feature registry
# ---------------------------------------------------------------------------------------------
FEATURES: dict[str, Callable[..., Any]] = {}


def feature(name: str):
    def deco(fn):
        if name in FEATURES and FEATURES[name] is not fn:
            raise ContractError(f"feature {name} registered twice")
        FEATURES[name] = fn
        return fn
    return deco


# ---------------------------------------------------------------------------------------------
# Validation and static metrics
# ---------------------------------------------------------------------------------------------
def validate(node: Any) -> set[str]:
    """Validate an AST; return its footprint."""
    if not isinstance(node, dict) or "op" not in node:
        raise ContractError(f"malformed node: {node!r}")
    op = node["op"]
    if op not in ALL_OPS:
        raise ContractError(f"unknown op {op}")
    if op == "const":
        canonical_json(node["v"])
        return set()
    if op == "feat":
        if node.get("f") not in FEATURES:
            raise ContractError(f"unknown feature {node.get('f')}")
        its = feat_items(node)
        if not its or not all(isinstance(i, str) for i in its):
            raise ContractError("feat needs 'item' (str) or 'items' (list of str)")
        return set(its)
    if op in BOOL_OPS:
        if not node.get("args"):
            raise ContractError(f"{op} needs args")
        fp: set[str] = set()
        for a in node["args"]:
            fp |= validate(a)
        return fp
    if op in ("not", "isempty"):
        return validate(node["a"])
    return validate(node["a"]) | validate(node["b"])


def feat_items(node: dict) -> list:
    if "items" in node:
        return list(node["items"])
    return [node["item"]] if "item" in node else []


def walk(node: dict):
    yield node
    op = node["op"]
    if op in BOOL_OPS:
        for a in node["args"]:
            yield from walk(a)
    elif op in ("not", "isempty"):
        yield from walk(node["a"])
    elif op not in ("const", "feat"):
        yield from walk(node["a"])
        yield from walk(node["b"])


def disclosure_metrics(expr: dict) -> dict:
    feats = [n for n in walk(expr) if n["op"] == "feat"]
    return {
        "n_feature_refs": len(feats),
        "n_distinct_features": len({canonical_json(n) for n in feats}),
        "n_order_comparisons": sum(1 for n in walk(expr) if n["op"] in ORDER_OPS),
        "n_set_ops": sum(1 for n in walk(expr) if n["op"] in SET_OPS | {"isempty"}),
        "n_boolean_branches": sum(1 for n in walk(expr) if n["op"] in ("or", "not")),
        "metadata_bytes": len(canonical_json(expr).encode()),
    }


def assert_k1_structure(expr: dict) -> None:
    """G3: a K1 contract may only state equality of disclosed features to recorded birth values.

    Allowed: and(eq(feat, const), ...) or a single eq(feat, const). Forbidden: thresholds/order
    comparisons, disjunction/negation (branch logic), set algebra (executable surrogate rules).
    """
    conj = expr["args"] if expr["op"] == "and" else [expr]
    for c in conj:
        if c["op"] != "eq":
            raise ContractError(f"K1 violates disclosure discipline: op {c['op']}")
        kinds = sorted([c["a"]["op"], c["b"]["op"]])
        if kinds != ["const", "feat"]:
            raise ContractError("K1 equality must compare one feature to one recorded constant")


@dataclass
class Contract:
    artifact_id: str
    cls: str
    footprint: list
    expr: dict
    meta: dict

    @property
    def cid(self) -> str:
        return sha256_obj({"a": self.artifact_id, "c": self.cls, "e": self.expr})

    def to_json(self) -> dict:
        return {"cid": self.cid, "artifact_id": self.artifact_id, "cls": self.cls,
                "footprint": sorted(self.footprint), "expr": self.expr, "meta": self.meta}

    @staticmethod
    def build(artifact_id: str, cls: str, expr: dict, meta: dict | None = None) -> "Contract":
        fp = validate(expr)
        if cls == "K1":
            assert_k1_structure(expr)
        m = dict(meta or {})
        m["disclosure"] = disclosure_metrics(expr)
        return Contract(artifact_id, cls, sorted(fp), expr, m)

    @staticmethod
    def from_json(d: dict) -> "Contract":
        c = Contract(d["artifact_id"], d["cls"], list(d["footprint"]), d["expr"], d.get("meta") or {})
        fp = validate(c.expr)
        if sorted(fp) != sorted(c.footprint):
            raise ContractError(f"declared footprint {c.footprint} != syntactic footprint {sorted(fp)}")
        return c


# ---------------------------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------------------------
class ItemView:
    """What a feature function may see: one item's content reference and a loader."""

    def __init__(self, item: str, content_ref: str, loader):
        self.item = item
        self.content_ref = content_ref
        self.loader = loader


def _as_set(v):
    if isinstance(v, (list, tuple, set, frozenset)):
        return frozenset(canonical_json(x) if isinstance(x, (dict, list)) else x for x in v)
    raise ContractError(f"set operation on non-collection {type(v)}")


def _eval(node: dict, views: dict[str, ItemView], fcache: dict) -> Any:
    op = node["op"]
    if op == "const":
        return node["v"]
    if op == "feat":
        its = feat_items(node)
        for item in its:
            if item not in views:
                raise FootprintViolation(f"feature on item {item} outside sandboxed footprint {sorted(views)}")
        key = (tuple((i, views[i].content_ref) for i in its), node["f"], canonical_json(node.get("args") or {}))
        if key not in fcache:
            args = node.get("args") or {}
            if "items" in node:
                fcache[key] = FEATURES[node["f"]]([views[i] for i in its], **args)
            else:
                fcache[key] = FEATURES[node["f"]](views[its[0]], **args)
        return fcache[key]
    if op == "and":
        return all(bool(_eval(a, views, fcache)) for a in node["args"])
    if op == "or":
        return any(bool(_eval(a, views, fcache)) for a in node["args"])
    if op == "not":
        return not bool(_eval(node["a"], views, fcache))
    if op == "isempty":
        return len(_as_set(_eval(node["a"], views, fcache))) == 0
    a = _eval(node["a"], views, fcache)
    b = _eval(node["b"], views, fcache)
    if op == "eq":
        return canonical_json(a) == canonical_json(b)
    if op == "ne":
        return canonical_json(a) != canonical_json(b)
    if op in ORDER_OPS:
        if a is None or b is None:
            return False  # undefined statistic never satisfies a region constraint (conservative)
        return {"lt": a < b, "le": a <= b, "gt": a > b, "ge": a >= b}[op]
    if op == "subset":
        return _as_set(a) <= _as_set(b)
    if op == "in":
        return (canonical_json(a) if isinstance(a, (dict, list)) else a) in _as_set(b)
    if op == "setminus":
        return sorted(_as_set(a) - _as_set(b), key=str)
    if op == "intersect":
        return sorted(_as_set(a) & _as_set(b), key=str)
    if op == "drop_keys":
        drop = _as_set(b)
        return sorted([x for x in a if str(x).split("|", 1)[0] not in drop], key=str)
    raise ContractError(f"unhandled op {op}")


class Evaluator:
    """Sandboxed contract evaluator with footprint-transfer memoisation and cost accounting."""

    def __init__(self, loader):
        self.loader = loader
        self.memo: dict[tuple, bool] = {}
        self.fcache: dict = {}
        self.stats = {"evaluations": 0, "memo_hits": 0, "uncached_seconds": 0.0}

    def evaluate(self, contract: Contract, content_of: Callable[[str], str]) -> tuple[bool, float, bool]:
        """content_of(item) -> content ref at the cut. Returns (value, seconds, memo_hit)."""
        refs = tuple((i, content_of(i)) for i in sorted(contract.footprint))
        key = (contract.cid, refs)
        self.stats["evaluations"] += 1
        if key in self.memo:
            self.stats["memo_hits"] += 1
            return self.memo[key], 0.0, True
        t0 = time.process_time()  # CPU seconds: commensurable with producer CPU cost (all threads)
        views = {i: ItemView(i, r, self.loader) for i, r in refs}
        val = bool(_eval(contract.expr, views, self.fcache))
        dt = time.process_time() - t0
        self.stats["uncached_seconds"] += dt
        self.memo[key] = val
        return val, dt, False
