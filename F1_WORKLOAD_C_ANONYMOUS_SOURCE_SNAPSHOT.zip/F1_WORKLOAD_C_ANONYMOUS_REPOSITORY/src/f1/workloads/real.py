"""Workload A (Rust supply chain) and Workload B (expensive data-quality certification)."""
from __future__ import annotations

import bisect
from pathlib import Path

from ..common.util import DAY, F1Error, load_yaml, parse_iso, read_json
from ..core.gamma import Gamma
from ..core.history import History, Version
from ..producers.cargo_audit import CargoAuditProducer
from ..producers.dq import DQProducer
from ..producers.license_spdx import LicenseProducer
from .base import ClusterSpec, ConsumerEvent, Workload, latest_born, schedule_ticks, seeded_sample


class WorkloadA(Workload):
    name = "A"

    def __init__(self, cfg, cas, data_root):
        super().__init__(cfg, cas, data_root)
        self.w = cfg["workload_a"]
        self.start = parse_iso(self.w["window"]["birth_start"])
        self.bend = parse_iso(self.w["window"]["birth_end"])
        self.hend = parse_iso(self.w["window"]["horizon_end"])
        self._repo: dict[str, dict] = {}
        self._adb = None

    def _manifest(self):
        p = Path(self.cfg["paths"]["manifest_a"])
        if not p.exists():
            raise F1Error(f"workload A manifest missing: {p} (run `make freeze` first)")
        return read_json(p)

    def clusters(self):
        return [ClusterSpec(r["slug"], r["split"], {"repo": r["repo"]}) for r in self._manifest()["selected"]]

    def _repo_data(self, slug):
        if slug not in self._repo:
            self._repo[slug] = read_json(self.data_root / "workload_a" / "repos" / f"{slug}.json")
        return self._repo[slug]

    def _adb_data(self):
        if self._adb is None:
            self._adb = read_json(self.data_root / "workload_a" / "advisory_db.json")
        return self._adb

    def build_history(self, cluster):
        rd = self._repo_data(cluster.name)
        adb = self._adb_data()
        summ = read_json(self.data_root / "workload_a" / "acquisition_summary.json")
        vs = []
        last = None
        for v in rd["lock_versions"]:
            if v["content_ref"] is None or v["content_ref"] == last:
                continue
            vs.append(Version("S", "s:" + v["commit"][:12], v["ts"], v["content_ref"], (("rev", v["commit"]),)))
            last = v["content_ref"]
        last = None
        for d in adb["days"]:
            if d["validation"]["ok"] is False or d["content_ref"] == last:
                continue
            vs.append(Version("V", "v:" + d["day"], d["ts"], d["content_ref"], (("rev", d["commit"]),)))
            last = d["content_ref"]
        empty = self.cas.put(b"")
        pvs = rd["policy_versions"] or []
        if not pvs:
            vs.append(Version("P", "p:default", 0.0, empty, (("kind", "default"),)))
        else:
            last = None
            for i, v in enumerate(pvs):
                ref = v["content_ref"] or empty
                if ref == last:
                    continue
                vs.append(Version("P", "p:" + v["commit"][:12], v["ts"], ref, (("rev", v["commit"]), ("path", rd["policy_path"]))))
                last = ref
            if vs and min(x.ts for x in vs if x.item == "P") > self.start:
                vs.append(Version("P", "p:absent", 0.0, empty, (("kind", "absent-before-first-version"),)))
        vs.append(Version("L", "l:frozen", 0.0, summ["license_table_ref"]))
        return History(vs)

    def producers(self, cluster):
        tools = self.cfg["tools"]
        return {
            "cargo-audit": CargoAuditProducer(tools["cargo_audit"]["path"], Path(self.cfg["paths"]["work"]) / "dbcache",
                                              timeout_s=self.w["producer_timeout_s"],
                                              expected_sha256=tools["cargo_audit"].get("sha256")),
            "license-spdx": LicenseProducer(self.w["license"]["default_allow"]),
        }

    def births(self, cluster, h):
        """Natural, independently operated producer schedules (pre-registered in workload_a.yaml):
        vulnerability scanner = periodic security service: nightly at `vuln_daily_utc_hour` + whenever the advisory
                                database content changes (`vuln_on_db_change`); NOT on Cargo.lock changes unless
                                `vuln_on_lock_change` is set (synchronised negative control);
        license evaluator     = dependency/policy-triggered compliance: on every Cargo.lock change and every policy-file
                                change (+ once at window start).
        No delays, skips or failures are injected: asynchrony arises only from the differing triggers."""
        sch = self.w["schedules"]
        lag = float(sch["trigger_lag_s"])
        out = []
        n_days = int((self.bend - self.start) // DAY) + 1
        for d in range(n_days):
            out.append((self.start + d * DAY + float(sch["vuln_daily_utc_hour"]) * 3600, "cargo-audit"))
        if sch.get("vuln_on_db_change", False):
            for v in h.items["V"]:
                if self.start <= v.ts <= self.bend:
                    out.append((v.ts + lag, "cargo-audit"))
        out.append((self.start, "license-spdx"))
        for v in h.items["S"]:
            if self.start <= v.ts <= self.bend:
                if sch.get("vuln_on_lock_change", False):
                    out.append((v.ts + lag, "cargo-audit"))
                if sch["license_on_lock_change"]:
                    out.append((v.ts + lag, "license-spdx"))
        for v in h.items["P"]:
            if self.start <= v.ts <= self.bend and sch["license_on_policy_change"]:
                out.append((v.ts + lag, "license-spdx"))
        return sorted(set(b for b in out if self.start <= b[0] <= self.bend and h.latest_cut(b[0]) is not None))

    def admission_class(self, cluster):
        return "MEDIUM_CPU"  # loads the full artifact catalogue (~GBs) and evaluates contracts single-threaded

    def unary_sample(self, cluster, artifacts):
        k = int(self.w["unary"]["births_per_type"])
        out = []
        for typ in sorted({a.artifact_type for a in artifacts}):
            pool = sorted([a for a in artifacts if a.artifact_type == typ], key=lambda a: (a.birth_time, a.artifact_id))
            out += seeded_sample(pool, k, [self.cfg["seed"], cluster.name, typ])
        return out

    def unary_ticks(self, cluster, h, birth_t):
        u = self.w["unary"]
        return schedule_ticks(birth_t, self.hend, u["dense_days"], u["dense_step_days"], u["sparse_until_days"], u["sparse_step_days"])

    def revs_at(self, cluster, h, t, items):
        rd = self._repo_data(cluster.name)
        rts = [r["ts"] for r in rd["revs"]]
        i = bisect.bisect_right(rts, t) - 1
        repo_rev = rd["revs"][i]["commit"] if i >= 0 else None
        days = self._adb_data()["days"]
        dts = [d["ts"] for d in days]
        j = bisect.bisect_right(dts, t) - 1
        db_rev = days[j]["commit"] if j >= 0 else None
        m = {"S": repo_rev, "P": repo_rev, "V": db_rev, "L": "frozen"}
        return {k: m[k] for k in items}

    def consumer_events(self, cluster, h, artifacts):
        """Consumer scenarios (pre-registered):
        primary_async_joint    — dashboard ticks; latest vulnerability + latest license artifact produced by their
                                 natural, unsynchronised schedules; Gamma = S last-k x V window, P and L latest
                                 (NO policy grace).
        secondary_policy_grace — identical, but P may be the previous policy within a grace window (sensitivity only).
        control_release        — real release tags; S fixed to the release lockfile (negative control).
        """
        evs = []
        g = self.w["gamma"]
        sec = self.w.get("secondary_policy_grace", {}) or {}
        n_days = int((self.bend - self.start) // DAY)
        hour = float(self.w["consumer"]["dashboard_utc_hour"])
        for d in range(1, n_days + 1):
            t = self.start + d * DAY + hour * 3600
            rv, rl = latest_born(artifacts, "vuln_gate", t), latest_born(artifacts, "lic_gate", t)
            if rv is None or rl is None:
                continue
            R = sorted([rv.artifact_id, rl.artifact_id])
            for k in g["s_last_k"]:
                for dv in g["v_window_days"]:
                    cell = f"k{k}-v{dv}"
                    gm = Gamma(f"async-{cell}", t, {"S": {"last_k": k}, "V": {"window_s": dv * DAY},
                                                   "P": {"latest": True}, "L": {"latest": True}})
                    evs.append(ConsumerEvent(f"{cluster.name}:async:{d}:{cell}", "primary_async_joint", cluster.name, t,
                                             R, gm.to_json(), cell))
                    for gp in sec.get("p_grace_days", []) or []:
                        if gp <= 0:
                            continue
                        c2 = f"{cell}-g{gp}"
                        gm2 = Gamma(f"grace-{c2}", t, {"S": {"last_k": k}, "V": {"window_s": dv * DAY},
                                                       "P": {"window_s": gp * DAY}, "L": {"latest": True}})
                        evs.append(ConsumerEvent(f"{cluster.name}:grace:{d}:{c2}", "secondary_policy_grace", cluster.name,
                                                 t, R, gm2.to_json(), c2))
        for tag in self._repo_data(cluster.name)["tags"]:
            t = tag["ts"]
            if not (self.start <= t <= self.bend):
                continue
            s = h.current("S", t)
            rv, rl = latest_born(artifacts, "vuln_gate", t + 1), latest_born(artifacts, "lic_gate", t + 1)
            if s is None or rv is None or rl is None:
                continue
            for dv in g["v_window_days"]:
                cell = f"rel-v{dv}"
                gm = Gamma(f"rel-{cell}", t + 1, {"S": {"fixed": [s.vid]}, "V": {"window_s": dv * DAY},
                                                 "P": {"latest": True}, "L": {"latest": True}})
                evs.append(ConsumerEvent(f"{cluster.name}:rel:{tag['tag']}:{cell}", "control_release", cluster.name, t + 1,
                                         sorted([rv.artifact_id, rl.artifact_id]), gm.to_json(), cell))
        return evs


class WorkloadB(Workload):
    name = "B"

    def __init__(self, cfg, cas, data_root):
        super().__init__(cfg, cas, data_root)
        self.b = cfg["workload_b"]
        self._data: dict[str, dict] = {}

    def _ds_cfg(self, name):
        for d in self.b["datasets"]:
            if d["name"] == name:
                return d
        raise F1Error(f"unknown dataset {name}")

    def clusters(self):
        summ_p = self.data_root / "workload_b" / "acquisition_summary.json"
        summ = read_json(summ_p) if summ_p.exists() else {}
        out = []
        for d in self.b["datasets"]:
            if summ.get(d["name"], {}).get("status") == "ok":
                out.append(ClusterSpec(d["name"], "mixed", {"role": d.get("role", "primary")}))
        return out

    def _rec(self, name):
        if name not in self._data:
            self._data[name] = read_json(self.data_root / "workload_b" / f"{name}.json")
        return self._data[name]

    def build_history(self, cluster):
        rec = self._rec(cluster.name)
        vs = [Version("D", "d:" + v["vid"], v["ts"], v["content_ref"]) for v in rec["versions"]]
        if rec.get("ref"):
            vs.append(Version("R", "r:frozen", 0.0, rec["ref"]["content_ref"]))
        return History(vs)

    def producers(self, cluster):
        ds = self._ds_cfg(cluster.name)
        pol = load_yaml(Path(self.cfg["paths"]["configs"]) / "dq_policies" / ds["dq_policy"])
        rc = ds.get("resource_class", "MEDIUM_CPU")
        th = int(self.cfg["server"]["classes"][rc].get("threads", 1))
        return {"dq-cert": DQProducer(pol["checks"], uses_ref=bool(self._rec(cluster.name).get("ref")), policy_id=pol["id"],
                                      resource_class=rc, threads=th)}

    def admission_class(self, cluster):
        return self._ds_cfg(cluster.name).get("resource_class", "MEDIUM_CPU")

    def _birth_versions(self, cluster, h):
        ds = self._ds_cfg(cluster.name)
        chain = h.items["D"]
        hv = int(ds["horizon_versions"])
        idx = list(range(int(ds.get("first_birth_index", 0)), len(chain) - 1, int(ds["birth_every"])))
        return [chain[i] for i in idx if i + 1 < len(chain)], hv

    def births(self, cluster, h):
        vs, _ = self._birth_versions(cluster, h)
        return [(v.ts + 1, "dq-cert") for v in vs]

    def prepare(self, cluster, h):
        """Temporal split (frozen): the first third of births of each dataset tunes TTL (validation)."""
        b = sorted(t for t, _ in self.births(cluster, h))
        self._split_time = getattr(self, "_split_time", {})
        self._split_time[cluster.name] = b[len(b) // 3] if b else float("inf")

    def birth_split(self, cluster, t):
        st = getattr(self, "_split_time", {}).get(cluster.name)
        if st is None:
            raise F1Error("WorkloadB.prepare() must run before birth_split()")
        return "validation" if t < st else "test"

    def unary_ticks(self, cluster, h, birth_t):
        ds = self._ds_cfg(cluster.name)
        later = [v.ts + 1 for v in h.items["D"] if v.ts + 1 > birth_t]
        return later[: int(ds["horizon_versions"])]

    def revs_at(self, cluster, h, t, items):
        cut = h.latest_cut(t)
        return {i: cut[i] for i in items} if cut else {}
