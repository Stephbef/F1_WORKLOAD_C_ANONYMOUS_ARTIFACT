"""Workload abstraction. A workload supplies clusters, histories, producers, a birth schedule, unary evaluation
ticks and consumer events. The admission engine is workload-agnostic: adding a new producer family
(e.g. an AI-agent producer for a Distributed Intelligence case study) only requires a Producer subclass
and a Workload subclass; nothing in admission/, repair/, oracle/ or statistics/ changes.
"""
from __future__ import annotations

import json
import random
from dataclasses import dataclass, field
from pathlib import Path

from ..common.util import CAS, DAY, F1Error, sha256_obj
from ..core.gamma import Gamma
from ..core.history import History


@dataclass
class ClusterSpec:
    name: str
    split: str           # "validation" | "test" | "dev"
    meta: dict = field(default_factory=dict)


@dataclass
class ConsumerEvent:
    event_id: str
    scenario: str
    cluster: str
    t: float
    artifact_ids: list
    gamma: dict
    cell: str


class Workload:
    name = "abstract"

    def __init__(self, cfg: dict, cas: CAS, data_root: Path):
        self.cfg = cfg
        self.cas = cas
        self.data_root = Path(data_root)

    # -- required by the runner --
    def clusters(self) -> list[ClusterSpec]:
        raise F1Error(f"{type(self).__name__} must implement clusters()")

    def build_history(self, cluster: ClusterSpec) -> History:
        raise F1Error(f"{type(self).__name__} must implement build_history()")

    def producers(self, cluster: ClusterSpec) -> dict:
        raise F1Error(f"{type(self).__name__} must implement producers()")

    def births(self, cluster: ClusterSpec, h: History) -> list[tuple[float, str]]:
        raise F1Error(f"{type(self).__name__} must implement births()")

    def prepare(self, cluster: ClusterSpec, h: History) -> None:
        """Optional per-cluster preparation hook (e.g. temporal split boundaries)."""
        return None

    def birth_split(self, cluster: ClusterSpec, t: float) -> str:
        return cluster.split

    def unary_ticks(self, cluster: ClusterSpec, h: History, birth_t: float) -> list[float]:
        raise F1Error(f"{type(self).__name__} must implement unary_ticks()")

    def unary_sample(self, cluster: ClusterSpec, artifacts: list) -> list:
        """Artifacts entering the unary population (default: all)."""
        return artifacts

    def admission_class(self, cluster: ClusterSpec) -> str:
        return "LIGHT_CPU"

    def consumer_events(self, cluster: ClusterSpec, h: History, artifacts: list) -> list[ConsumerEvent]:
        return []

    def revs_at(self, cluster: ClusterSpec, h: History, t: float, items: list[str]) -> dict:
        """Source revision identifiers for version pinning (B1); default = version ids."""
        cut = h.latest_cut(t)
        return {i: cut[i] for i in items} if cut else {}


def schedule_ticks(birth_t: float, end_t: float, dense_days: int, dense_step_days: float,
                   sparse_until_days: int, sparse_step_days: float) -> list[float]:
    ticks, d = [], dense_step_days
    while d <= dense_days + 1e-9:
        ticks.append(birth_t + d * DAY)
        d += dense_step_days
    d = dense_days + sparse_step_days
    while d <= sparse_until_days + 1e-9:
        ticks.append(birth_t + d * DAY)
        d += sparse_step_days
    return [t for t in ticks if t <= end_t]


def seeded_sample(items: list, k: int, seed_material) -> list:
    if len(items) <= k:
        return list(items)
    rng = random.Random(int(sha256_obj(seed_material)[:16], 16))
    idx = sorted(rng.sample(range(len(items)), k))
    return [items[i] for i in idx]


def latest_born(artifacts: list, artifact_type: str, t: float):
    best = None
    for a in artifacts:
        if a.artifact_type == artifact_type and a.birth_time <= t:
            if best is None or (a.birth_time, a.artifact_id) > (best.birth_time, best.artifact_id):
                best = a
    return best
