"""Synthetic workload: deterministic, seeded, fully local. ENGINEERING ONLY — its outputs are never results."""
from __future__ import annotations

import json
import random

from ..common.util import DAY, sha256_obj
from ..core.gamma import Gamma
from ..core.history import History, Version
from ..producers.synthetic import SyntheticProducer
from .base import ClusterSpec, ConsumerEvent, Workload, schedule_ticks

T0 = 1_700_000_000.0  # fixed epoch for synthetic histories


class SyntheticNamed(SyntheticProducer):
    def __init__(self, pid: str, **params):
        super().__init__(**params)
        self.producer_id = pid


class SyntheticWorkload(Workload):
    name = "synthetic"

    def _c(self):
        return self.cfg["synthetic"]

    def clusters(self):
        n = int(self._c()["n_clusters"])
        return [ClusterSpec(f"syn{i:02d}", "validation" if i % 3 == 0 else "test") for i in range(n)]

    def build_history(self, cluster):
        c = self._c()
        rng = random.Random(int(sha256_obj([c["seed"], cluster.name])[:12], 16))
        vs = []
        x = [8.0, 9.0]
        for d in range(int(c["n_x_versions"])):
            x = [round(max(0.0, v + rng.uniform(-0.9, 0.9)), 2) for v in x]
            ref = self.cas.put(json.dumps(x).encode())
            vs.append(Version("X", f"x{d:03d}", T0 + d * DAY, ref))
        step = max(1, int(c["n_x_versions"]) // int(c["n_p_versions"]))
        for k in range(int(c["n_p_versions"])):
            pol = {"version": f"v{k + 1}", "limit": float(c["limit"])}
            vs.append(Version("P", f"p{k}", T0 + k * step * DAY, self.cas.put(json.dumps(pol, sort_keys=True).encode())))
        return History(vs)

    def producers(self, cluster):
        pp = self._c().get("producer_params", {}) or {}
        return {pid: SyntheticNamed(pid, **(pp.get(pid) or {})) for pid in ("syn-a", "syn-b")}

    def births(self, cluster, h):
        c = self._c()
        bd = int(c["birth_days"])
        out = [(T0 + d * DAY + 3600, "syn-a") for d in range(bd)]
        out += [(T0 + d * DAY + 7200, "syn-b") for d in range(0, bd, 3)]
        return sorted(out)

    def unary_ticks(self, cluster, h, birth_t):
        end = T0 + (int(self._c()["n_x_versions"]) - 1) * DAY + 43200
        return schedule_ticks(birth_t, end, int(self._c()["horizon_days"]), 1, int(self._c()["horizon_days"]), 1)

    def consumer_events(self, cluster, h, artifacts):
        c = self._c()
        evs = []
        for d in range(1, int(c["birth_days"])):
            t = T0 + d * DAY + 43200
            ra = max((x for x in artifacts if x.producer_id == "syn-a" and x.birth_time <= t), key=lambda x: x.birth_time, default=None)
            rb = max((x for x in artifacts if x.producer_id == "syn-b" and x.birth_time <= t), key=lambda x: x.birth_time, default=None)
            if ra is None or rb is None:
                continue
            for k in c["gamma_x_last_k"]:
                for w in c["gamma_p_window_days"]:
                    cell = f"xk{k}-pw{w}"
                    scenario = "primary_async_joint" if w == 0 else "secondary_policy_grace"
                    rules = {"X": {"last_k": k}, "P": {"latest": True} if w == 0 else {"window_s": w * DAY}}
                    g = Gamma(f"dash-{cell}-{d}", t, rules)
                    evs.append(ConsumerEvent(f"{cluster.name}-d{d}-{cell}", scenario, cluster.name, t,
                                             sorted([ra.artifact_id, rb.artifact_id]), g.to_json(), cell))
        return evs
