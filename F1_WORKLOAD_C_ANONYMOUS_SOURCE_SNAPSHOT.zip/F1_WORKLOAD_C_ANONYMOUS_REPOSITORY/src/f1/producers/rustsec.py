"""Cargo.lock / RustSec advisory parsing, Cargo semver requirement matching, workload-A features.

This module is used ONLY by the producer-side contract emitter and by contract features. It is our own
re-implementation of the advisory matching rule; any divergence from cargo-audit's behaviour shows up in
the experiment as a K2/K3 unsound admission of cause U1 (evaluator/producer mismatch). It is never
"fixed" against oracle outcomes after the freeze.
"""
from __future__ import annotations

import hashlib
import re
import tomllib
from dataclasses import dataclass

from ..common.util import canonical_json, sha256_obj
from ..contracts.lang import feature

CRATES_IO_SOURCES = ("registry+https://github.com/rust-lang/crates.io-index", "sparse+https://index.crates.io/")


# ---------------------------------------------------------------------------------------------
# Cargo.lock
# ---------------------------------------------------------------------------------------------
def parse_lock(text: str) -> list[dict]:
    data = tomllib.loads(text)
    pkgs = []
    for p in data.get("package", []) or []:
        src = p.get("source")
        pkgs.append({"name": p["name"], "version": p["version"], "source": src})
    return pkgs


def registry_packages(text: str) -> list[str]:
    out = set()
    for p in parse_lock(text):
        if p["source"] and p["source"].startswith(CRATES_IO_SOURCES):
            out.add(f"{p['name']}@{p['version']}")
    return sorted(out)


# ---------------------------------------------------------------------------------------------
# Semver (Cargo flavour)
# ---------------------------------------------------------------------------------------------
_VER = re.compile(r"^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.\-]+))?(?:\+[0-9A-Za-z.\-]+)?$")


@dataclass(frozen=True, order=False)
class Ver:
    major: int
    minor: int
    patch: int
    pre: tuple = ()

    def key(self):
        # pre-release sorts before release; numeric identifiers before alphanumeric
        pk = tuple((0, int(x), "") if x.isdigit() else (1, 0, x) for x in self.pre)
        return (self.major, self.minor, self.patch, 0 if self.pre else 1, pk)


def parse_ver(s: str) -> Ver:
    m = _VER.match(s.strip())
    if not m:
        raise ValueError(f"bad version {s!r}")
    pre = tuple(m.group(4).split(".")) if m.group(4) else ()
    return Ver(int(m.group(1)), int(m.group(2)), int(m.group(3)), pre)


_CMP = re.compile(r"^\s*(=|>=|<=|>|<|~|\^)?\s*(\*|[xX]|\d+)(?:\.(\*|[xX]|\d+))?(?:\.(\*|[xX]|\d+))?(?:-([0-9A-Za-z.\-]+))?(?:\+[0-9A-Za-z.\-]+)?\s*$")


def _comparators(req: str) -> list[tuple]:
    """Each comparator -> (lo, lo_incl, hi, hi_incl, pre_triple) with lo/hi Ver or None (unbounded)."""
    out = []
    for part in req.split(","):
        part = part.strip()
        if not part:
            continue
        m = _CMP.match(part)
        if not m:
            raise ValueError(f"bad requirement {part!r}")
        op = m.group(1)
        raw = [m.group(2), m.group(3), m.group(4)]
        n = 0
        for x in raw:
            if x is None or x in ("*", "x", "X"):
                break
            n += 1
        if n < 3 and op is None and any(x in ("*", "x", "X") for x in raw if x is not None):
            op = "="  # wildcard forms I.*, I.J.* behave like partial '='
        op = op or "^"
        I = int(raw[0]) if n >= 1 else 0
        J = int(raw[1]) if n >= 2 else 0
        K = int(raw[2]) if n >= 3 else 0
        pre = tuple(m.group(5).split(".")) if (m.group(5) and n == 3) else ()
        v = Ver(I, J, K, pre)
        ptri = (I, J, K) if pre else None
        if n == 0:
            out.append((None, True, None, True, None)); continue
        if op == "=":
            if n == 3: c = (v, True, v, True)
            elif n == 2: c = (Ver(I, J, 0), True, Ver(I, J + 1, 0), False)
            else: c = (Ver(I, 0, 0), True, Ver(I + 1, 0, 0), False)
        elif op == ">":
            if n == 3: c = (v, False, None, True)
            elif n == 2: c = (Ver(I, J + 1, 0), True, None, True)
            else: c = (Ver(I + 1, 0, 0), True, None, True)
        elif op == ">=":
            c = (v if n == 3 else Ver(I, J, 0), True, None, True)
        elif op == "<":
            c = (None, True, v if n == 3 else Ver(I, J, 0), False)
        elif op == "<=":
            if n == 3: c = (None, True, v, True)
            elif n == 2: c = (None, True, Ver(I, J + 1, 0), False)
            else: c = (None, True, Ver(I + 1, 0, 0), False)
        elif op == "~":
            if n >= 2: c = (v if n == 3 else Ver(I, J, 0), True, Ver(I, J + 1, 0), False)
            else: c = (Ver(I, 0, 0), True, Ver(I + 1, 0, 0), False)
        else:  # caret
            if n == 3:
                hi = Ver(I + 1, 0, 0) if I > 0 else (Ver(0, J + 1, 0) if J > 0 else Ver(0, 0, K + 1))
                c = (v, True, hi, False)
            elif n == 2:
                c = (Ver(I, J, 0), True, Ver(I + 1, 0, 0) if I > 0 else Ver(0, J + 1, 0), False)
            else:
                c = (Ver(I, 0, 0), True, Ver(I + 1, 0, 0), False)
        out.append(c + (ptri,))
    return out


def _cmp_match(c, v: Ver) -> bool:
    lo, lo_incl, hi, hi_incl, _ = c
    k = v.key()
    if lo is not None and (k < lo.key() or (k == lo.key() and not lo_incl)):
        return False
    if hi is not None and (k > hi.key() or (k == hi.key() and not hi_incl)):
        return False
    return True


def req_matches(req: str, version: str) -> bool:
    v = parse_ver(version)
    comps = _comparators(req)
    if not all(_cmp_match(c, v) for c in comps):
        return False
    if v.pre:
        # semver rule: a pre-release only matches if a comparator names a pre-release on the same triple
        return any(c[4] == (v.major, v.minor, v.patch) for c in comps)
    return True


# ---------------------------------------------------------------------------------------------
# Advisory database
# ---------------------------------------------------------------------------------------------
_FRONT = re.compile(r"```toml\s*\n(.*?)\n```", re.S)


def parse_advisory(text: str, path: str) -> dict | None:
    if path.endswith(".md"):
        m = _FRONT.search(text)
        if not m:
            return None
        data = tomllib.loads(m.group(1))
    elif path.endswith(".toml"):
        data = tomllib.loads(text)
    else:
        return None
    adv = data.get("advisory", {})
    ver = data.get("versions", {}) or {}
    return {
        "id": adv.get("id"), "package": adv.get("package"),
        "informational": adv.get("informational"),
        "withdrawn": adv.get("withdrawn") is not None,
        "patched": list(ver.get("patched", []) or adv.get("patched_versions", []) or []),
        "unaffected": list(ver.get("unaffected", []) or adv.get("unaffected_versions", []) or []),
    }


def load_db(loader, ref: str) -> dict[str, list[dict]]:
    def parse(L, r):
        by_pkg: dict[str, list[dict]] = {}
        for rel, bref in L.tree(r).items():
            if not rel.startswith("crates/"):
                continue
            try:
                a = parse_advisory(L.text(bref), rel)
            except Exception:
                a = None  # unparsable entries are skipped identically by K2/K3 (recorded via db_parse_errors)
            if a and a["id"] and a["package"]:
                by_pkg.setdefault(a["package"], []).append(a)
        return by_pkg
    return loader.parsed("rustsec-db", ref, parse)


# ---------------------------------------------------------------------------------------------
# RustSec range semantics (differs from Cargo semver matching; verified differentially against cargo-audit 0.22.2)
#  * operators =, >, >=, <, <= : partial versions are ZERO-FILLED ("> 1.2" means "> 1.2.0", "<= 1.2" means "<= 1.2.0")
#  * ^ and ~ (and bare): Cargo caret/tilde bounds
#  * containment uses plain semver ORDER (no Cargo pre-release exclusion rule)
#  * wildcards and overlapping patched/unaffected ranges make cargo-audit reject the whole database; such snapshots
#    are excluded at acquisition (validate_db), so they never reach evaluation.
# ---------------------------------------------------------------------------------------------
def _rs_bounds(req: str) -> list[tuple]:
    out = []
    for part in req.split(","):
        part = part.strip()
        if not part:
            continue
        m = _CMP.match(part)
        if not m:
            raise ValueError(f"bad requirement {part!r}")
        op = m.group(1) or "^"
        raw = [m.group(2), m.group(3), m.group(4)]
        if any(x in ("*", "x", "X") for x in raw if x is not None):
            raise ValueError(f"wildcard not supported by RustSec: {part!r}")
        n = sum(1 for x in raw if x is not None)
        I = int(raw[0]); J = int(raw[1]) if n >= 2 else 0; K = int(raw[2]) if n >= 3 else 0
        pre = tuple(m.group(5).split(".")) if (m.group(5) and n == 3) else ()
        v = Ver(I, J, K, pre)
        if op == "=":
            out.append((v, True, v, True))
        elif op == ">":
            out.append((v, False, None, True))
        elif op == ">=":
            out.append((v, True, None, True))
        elif op == "<":
            out.append((None, True, v, False))
        elif op == "<=":
            out.append((None, True, v, True))
        elif op == "~":
            hi = Ver(I, J + 1, 0) if n >= 2 else Ver(I + 1, 0, 0)
            out.append((v, True, hi, False))
        else:  # caret
            if n == 3:
                hi = Ver(I + 1, 0, 0) if I > 0 else (Ver(0, J + 1, 0) if J > 0 else Ver(0, 0, K + 1))
            elif n == 2:
                hi = Ver(I + 1, 0, 0) if I > 0 else Ver(0, J + 1, 0)
            else:
                hi = Ver(I + 1, 0, 0)
            out.append((v, True, hi, False))
    return out


def rustsec_matches(req: str, version: str) -> bool:
    v = parse_ver(version)
    k = v.key()
    for lo, lo_incl, hi, hi_incl in _rs_bounds(req):
        if lo is not None and (k < lo.key() or (k == lo.key() and not lo_incl)):
            return False
        if hi is not None and (k > hi.key() or (k == hi.key() and not hi_incl)):
            return False
    return True


def vulnerable(adv: dict, version: str) -> bool:
    try:
        if any(rustsec_matches(r, version) for r in adv["patched"]):
            return False
        if any(rustsec_matches(r, version) for r in adv["unaffected"]):
            return False
    except ValueError:
        return True  # conservative: unparsable requirement treated as affecting (such DBs are excluded upstream)
    return True


def affecting_triples(db: dict, packages: list[str]) -> list[str]:
    out = set()
    for pv in packages:
        name, version = pv.rsplit("@", 1)
        for adv in db.get(name, []):
            if adv["withdrawn"] or adv["informational"]:
                continue
            if vulnerable(adv, version):
                out.add(f"{adv['id']}|{name}|{version}")
    return sorted(out)


# ---------------------------------------------------------------------------------------------
# Policy file (deny.toml / audit.toml / default)
# ---------------------------------------------------------------------------------------------
def parse_policy(text: str) -> dict:
    try:
        return tomllib.loads(text) if text.strip() else {}
    except tomllib.TOMLDecodeError:
        return {"__unparsable__": hashlib.sha256(text.encode()).hexdigest()}


def policy_ignores_from(pol: dict) -> list[str]:
    adv = pol.get("advisories", {}) or {}
    out = []
    for e in adv.get("ignore", []) or []:
        if isinstance(e, str):
            out.append(e)
        elif isinstance(e, dict) and "id" in e:
            out.append(e["id"])
    return sorted(set(out))


def allowed_licenses_from(pol: dict, default: list[str]) -> list[str]:
    lic = pol.get("licenses")
    if isinstance(lic, dict) and "allow" in lic:
        return sorted(set(str(x) for x in lic.get("allow") or []))
    return sorted(set(default))


# ---------------------------------------------------------------------------------------------
# Features
# ---------------------------------------------------------------------------------------------
def _policy(view):
    return view.loader.parsed("policy", view.content_ref, lambda L, r: parse_policy(L.text(r)))


@feature("lock_packages")
def f_lock_packages(view):
    return view.loader.parsed("lock-pkgs", view.content_ref, lambda L, r: registry_packages(L.text(r)))


@feature("advisory_slice_digest")
def f_advisory_slice_digest(view, crates):
    tree = view.loader.tree(view.content_ref)
    want = set(crates)
    sl = {rel: b for rel, b in tree.items() if rel.startswith("crates/") and rel.split("/")[1] in want}
    return sha256_obj(sl)


@feature("affecting_triples")
def f_affecting_triples(view, packages):
    return affecting_triples(load_db(view.loader, view.content_ref), packages)


@feature("policy_section_hash")
def f_policy_section_hash(view, section):
    pol = _policy(view)
    if "__unparsable__" in pol:
        return "unparsable:" + pol["__unparsable__"]
    return sha256_obj(pol.get(section))


@feature("policy_ignores")
def f_policy_ignores(view):
    return policy_ignores_from(_policy(view))


@feature("k3_vuln")
def f_k3_vuln(views, mode):
    by = {x.item: x for x in views}
    pkgs = f_lock_packages(by["S"])
    trip = affecting_triples(load_db(by["V"].loader, by["V"].content_ref), pkgs)
    ign = set(policy_ignores_from(_policy(by["P"])))
    rep = sorted(t for t in trip if t.split("|", 1)[0] not in ign)
    return rep if mode == "report" else ("FAIL" if rep else "PASS")
