"""Hermetic producer execution (R7, R8).

Each run happens in a fresh sandbox directory with HOME/CARGO_HOME inside it, fixed locale/TZ,
SOURCE_DATE_EPOCH = cut time, PYTHONHASHSEED=0. Network isolation: `unshare -rn` (private network
namespace, no root) when available, otherwise an HTTP(S) proxy black-hole (recorded; weaker).
Read tracing: strace (open/openat/connect) when available; Python jobs additionally run an in-process
audit hook. The methods actually used are recorded in every RunResult; nothing is silently assumed.
"""
from __future__ import annotations

import os
import re
import resource
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict, dataclass, field
from functools import lru_cache
from pathlib import Path

from ..common.util import F1Error


@dataclass
class RunResult:
    status: str                       # ok | error | timeout | unavailable
    returncode: int | None
    stdout: bytes = field(repr=False, default=b"")
    stderr_tail: str = ""
    cpu_s: float = 0.0
    wall_s: float = 0.0
    max_rss_kb: int = 0
    reads: list = field(default_factory=list)
    hidden_reads: list = field(default_factory=list)
    net_attempts: int = 0
    trace_method: str = "none"
    net_method: str = "none"

    def record(self) -> dict:
        d = asdict(self)
        d.pop("stdout")
        d["reads"] = d["reads"][:200]
        d["hidden_reads"] = d["hidden_reads"][:200]
        return d


@lru_cache(maxsize=1)
def unshare_available() -> bool:
    if shutil.which("unshare") is None:
        return False
    try:
        return subprocess.run(["unshare", "-rn", "true"], capture_output=True, timeout=10).returncode == 0
    except Exception:
        return False


@lru_cache(maxsize=1)
def strace_available() -> bool:
    if shutil.which("strace") is None:
        return False
    try:
        r = subprocess.run(["strace", "-f", "-qq", "-e", "trace=openat", "-o", "/dev/null", "true"],
                           capture_output=True, timeout=10)
        return r.returncode == 0
    except Exception:
        return False


_OPEN_RE = re.compile(r'^(?:\[pid\s+)?\d*\]?\s*(open|openat|connect)\((.*)\)\s+=\s+(-?\d+)')
_PATH_RE = re.compile(r'"((?:[^"\\]|\\.)*)"')

SYSTEM_PREFIXES = ("/proc/", "/dev/", "/sys/", "/etc/localtime", "/usr/share/zoneinfo", "/etc/ld.so",
                   "/lib", "/usr/lib", "/lib64", "/usr/lib64", "/etc/nsswitch.conf", "/etc/passwd",
                   "/etc/group", "/etc/host.conf", "/etc/gai.conf",
                   "/etc/ssl/", "/usr/lib/ssl/", "/etc/pki/tls/")  # library-init configuration, never context data


def parse_strace(path: Path, allowed: list[str]) -> tuple[list[str], list[str], int]:
    reads, hidden, net = set(), set(), 0
    allowed = [str(Path(a).resolve()) for a in allowed]
    if not path.exists():
        return [], [], 0
    for line in path.read_text(errors="replace").splitlines():
        m = _OPEN_RE.search(line)
        if not m:
            continue
        call, args, ret = m.group(1), m.group(2), int(m.group(3))
        if call == "connect":
            if "AF_INET" in args or "AF_INET6" in args:
                net += 1
            continue
        pm = _PATH_RE.search(args)
        if not pm or ret < 0:
            continue
        p = pm.group(1)
        if not p.startswith("/"):
            continue
        rp = os.path.normpath(p)
        reads.add(rp)
        if any(rp == a or rp.startswith(a + os.sep) for a in allowed):
            continue
        if rp.startswith(SYSTEM_PREFIXES):
            continue
        hidden.add(rp)
    return sorted(reads), sorted(hidden), net


def python_allowed_prefixes() -> list[str]:
    import site
    pre = {sys.prefix, sys.base_prefix, sys.exec_prefix, str(Path(__file__).resolve().parents[2])}
    for p in list(site.getsitepackages()) + [site.getusersitepackages()]:
        pre.add(p)
    for p in sys.path:
        if p and os.path.isdir(p):
            pre.add(p)
    return sorted(pre)


def run_hermetic(argv: list[str], sandbox: Path, *, timeout: float, epoch: float,
                 allowed_read_prefixes: list[str], trace: bool = True, extra_env: dict | None = None,
                 ok_codes: tuple = (0,)) -> RunResult:
    from ..common.firewall import assert_may_execute_producers
    assert_may_execute_producers()
    sandbox = Path(sandbox)
    home = sandbox / "home"
    home.mkdir(parents=True, exist_ok=True)
    env = {
        "PATH": "/usr/bin:/bin", "HOME": str(home), "CARGO_HOME": str(home / ".cargo"),
        "LC_ALL": "C", "LANG": "C", "TZ": "UTC", "SOURCE_DATE_EPOCH": str(int(epoch)),
        "PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1", "TMPDIR": str(sandbox / "tmp"),
        "NO_COLOR": "1",
    }
    (sandbox / "tmp").mkdir(exist_ok=True)
    if extra_env:
        env.update(extra_env)
    cmd = list(argv)
    trace_method = "none"
    tracefile = sandbox / "strace.txt"
    if trace and strace_available():
        cmd = ["strace", "-f", "-qq", "-e", "trace=open,openat,connect", "-o", str(tracefile)] + cmd
        trace_method = "strace"
    if unshare_available():
        cmd = ["unshare", "-rn"] + cmd
        net_method = "unshare-netns"
    else:
        env.update({"http_proxy": "http://127.0.0.1:9", "https_proxy": "http://127.0.0.1:9",
                    "HTTP_PROXY": "http://127.0.0.1:9", "HTTPS_PROXY": "http://127.0.0.1:9", "no_proxy": ""})
        net_method = "proxy-blackhole"
    r0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    t0 = time.perf_counter()
    try:
        p = subprocess.run(cmd, cwd=str(sandbox), env=env, capture_output=True, timeout=timeout)
        status = "ok" if p.returncode in ok_codes else "error"
        rc, out, err = p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as e:
        status, rc, out, err = "timeout", None, e.stdout or b"", e.stderr or b""
    wall = time.perf_counter() - t0
    r1 = resource.getrusage(resource.RUSAGE_CHILDREN)
    cpu = (r1.ru_utime - r0.ru_utime) + (r1.ru_stime - r0.ru_stime)
    allowed = [str(sandbox)] + list(allowed_read_prefixes) + [str(Path(argv[0]).resolve().parent)]
    reads, hidden, net = parse_strace(tracefile, allowed) if trace_method == "strace" else ([], [], 0)
    return RunResult(status=status, returncode=rc, stdout=out, stderr_tail=(err or b"")[-2000:].decode("utf-8", "replace"),
                     cpu_s=cpu, wall_s=wall, max_rss_kb=int(r1.ru_maxrss), reads=reads, hidden_reads=hidden,
                     net_attempts=net, trace_method=trace_method, net_method=net_method)


class Sandbox:
    def __init__(self, base: Path | None = None, keep: bool = False):
        self.base = base
        self.keep = keep
        self.path: Path | None = None

    def __enter__(self) -> Path:
        self.path = Path(tempfile.mkdtemp(prefix="f1sb-", dir=str(self.base) if self.base else None))
        return self.path

    def __exit__(self, *exc):
        if self.path and not self.keep:
            shutil.rmtree(self.path, ignore_errors=True)
