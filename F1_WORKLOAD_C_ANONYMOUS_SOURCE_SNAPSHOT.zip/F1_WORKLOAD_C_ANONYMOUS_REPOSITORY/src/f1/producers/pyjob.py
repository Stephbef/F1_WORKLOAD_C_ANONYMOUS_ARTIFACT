"""Entry point for Python producer jobs run inside the hermetic sandbox.

Usage: python -m f1.producers.pyjob job.json
The audit hook is installed *after* imports so that it records the job's data accesses, not module loading.
"""
from __future__ import annotations

import json
import os
import sys


def main() -> int:
    job = json.load(open(sys.argv[1]))
    kind = job["kind"]
    if kind == "synthetic":
        from .synthetic import run_job
    elif kind == "license":
        from .license_spdx import run_job
    elif kind == "dq":
        from .dq import run_job
    else:
        print(f"unknown job kind {kind}", file=sys.stderr)
        return 3
    opens, net = [], [0]

    def hook(event, args):
        if event == "open":
            p = args[0]
            if isinstance(p, (str, bytes, os.PathLike)):
                opens.append(os.path.realpath(os.fsdecode(p)))
        elif event == "socket.connect":
            net[0] += 1

    sys.addaudithook(hook)
    out = run_job(job["inputs"], job["params"])
    trace = {"opens": sorted(set(opens) - {os.path.realpath(job["out"]), os.path.realpath(job["trace"])}), "net": net[0]}
    with open(job["out"], "w") as f:
        json.dump(out, f, sort_keys=True)
    with open(job["trace"], "w") as f:
        json.dump(trace, f, sort_keys=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
