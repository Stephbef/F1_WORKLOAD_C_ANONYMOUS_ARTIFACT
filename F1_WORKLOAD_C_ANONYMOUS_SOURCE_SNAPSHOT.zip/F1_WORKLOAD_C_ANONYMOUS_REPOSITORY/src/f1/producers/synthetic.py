"""Synthetic producer for engineering tests only (never a scientific workload).

Items: X = JSON list of exposures, P = JSON policy {"version": str, "limit": float}.
Output: {"tier": "LOW"|"HIGH", "policy_version": str}; LOW iff max(X) <= limit.
Failure-injection params: hidden_read (path read outside the sandbox), nondeterministic, crash, sleep_s.
"""
from __future__ import annotations

import json
import os
import random
import time

from ..contracts.lang import feature
from .base import PythonJobProducer


def run_job(inputs: dict, params: dict) -> dict:
    if params.get("crash"):
        raise RuntimeError("injected producer crash")
    if params.get("sleep_s"):
        time.sleep(float(params["sleep_s"]))
    xs = json.load(open(inputs["X"]))
    pol = json.load(open(inputs["P"]))
    if params.get("hidden_read"):
        open(params["hidden_read"]).read()
    tier = "LOW" if max(xs) <= float(pol["limit"]) else "HIGH"
    if params.get("nondeterministic") and random.SystemRandom().random() < 0.5:
        tier = "HIGH" if tier == "LOW" else "LOW"
    return {"tier": tier, "policy_version": pol["version"]}


def _load_json(view):
    return view.loader.parsed("json", view.content_ref, lambda L, r: json.loads(L.text(r)))


@feature("syn_max")
def syn_max(view):
    return max(_load_json(view))


@feature("syn_policy_version")
def syn_policy_version(view):
    return _load_json(view)["version"]


@feature("syn_policy")
def syn_policy(view):
    return _load_json(view)


@feature("syn_tier")
def syn_tier(views):
    xs, pol = _load_json(views[0]), _load_json(views[1])
    return {"tier": "LOW" if max(xs) <= float(pol["limit"]) else "HIGH", "policy_version": pol["version"]}


class SyntheticProducer(PythonJobProducer):
    producer_id = "synthetic"
    read_items = ["P", "X"]
    artifact_types = ["tier"]
    job_kind = "synthetic"
    timeout_s = 60.0

    def __init__(self, **params):
        self._params = dict(params)
        if "timeout_s" in params:
            self.timeout_s = float(params["timeout_s"])

    def params(self) -> dict:
        return {k: v for k, v in self._params.items() if k != "timeout_s"}

    def project(self, output, artifact_type):
        return output

    def contracts(self, artifact_type, cut, h, loader, output):
        xs = json.loads(loader.text(h.content(cut, "X")))
        pol = json.loads(loader.text(h.content(cut, "P")))
        fx = {"op": "feat", "item": "X", "f": "syn_max"}
        fpv = {"op": "feat", "item": "P", "f": "syn_policy_version"}
        k1 = {"op": "and", "args": [
            {"op": "eq", "a": fx, "b": {"op": "const", "v": max(xs)}},
            {"op": "eq", "a": {"op": "feat", "item": "P", "f": "syn_policy"}, "b": {"op": "const", "v": pol}}]}
        le = {"op": "le", "a": fx, "b": {"op": "const", "v": float(pol["limit"])}}
        region = le if output["tier"] == "LOW" else {"op": "not", "a": le}
        k2 = {"op": "and", "args": [region, {"op": "eq", "a": fpv, "b": {"op": "const", "v": pol["version"]}}]}
        k3 = {"op": "eq", "a": {"op": "feat", "items": ["X", "P"], "f": "syn_tier"}, "b": {"op": "const", "v": output}}
        return {"K1": k1, "K2": k2, "K3": k3}
