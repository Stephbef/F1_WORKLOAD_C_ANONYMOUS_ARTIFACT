"""Producer interface (R6). A producer is opaque to the admission side: only its outputs, captured
read-set, cost and the contracts its co-located wrapper emits ever reach the catalog."""
from __future__ import annotations

import json
import os
import sys
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from ..common.util import CAS, F1Error, canonical_json, sha256_obj
from ..core.history import Cut, History
from .hermetic import SYSTEM_PREFIXES, RunResult, Sandbox, python_allowed_prefixes, run_hermetic

SRC_ROOT = str(Path(__file__).resolve().parents[2])


class Producer(ABC):
    producer_id: str = "abstract"
    read_items: list[str] = []
    artifact_types: list[str] = []
    timeout_s: float = 3600.0
    resource_class: str = "LIGHT_CPU"
    threads: int = 1

    @abstractmethod
    def version_digest(self) -> str:
        """Digest identifying the exact producer implementation (binary hash or source+params hash)."""

    @abstractmethod
    def execute(self, cut: Cut, h: History, cas: CAS, work: Path) -> tuple[RunResult, Any]:
        """Run hermetically at `cut`; return (run record, canonical output or None)."""

    @abstractmethod
    def project(self, output: Any, artifact_type: str) -> Any:
        """Projection of the full output onto one artifact type's value."""

    def equivalent(self, artifact_type: str, a: Any, b: Any) -> bool:
        return canonical_json(a) == canonical_json(b)

    @abstractmethod
    def contracts(self, artifact_type: str, cut: Cut, h: History, loader, output: Any) -> dict:
        """Producer-side contract emitter. Returns {"K1": expr|None, "K2": expr|None, "K3": expr|None}."""

    def birth_refs(self, cut: Cut, h: History) -> dict:
        return {i: h.content(cut, i) for i in self.read_items}


class PythonJobProducer(Producer):
    """Producer implemented as a Python job executed in a hermetic subprocess (audit-hook traced)."""
    job_kind: str = "abstract"

    def params(self) -> dict:
        return {}

    def version_digest(self) -> str:
        import inspect
        mod = sys.modules[type(self).__module__]
        src = inspect.getsource(mod)
        return sha256_obj({"kind": self.job_kind, "src": src, "params": self.params()})[:16]

    def materialize(self, cut: Cut, h: History, cas: CAS, sandbox: Path) -> dict:
        inputs = {}
        for item in self.read_items:
            ref = h.content(cut, item)
            dest = sandbox / "in" / item
            cas.materialize(ref, dest)
            inputs[item] = str(dest)
        return inputs

    def execute(self, cut: Cut, h: History, cas: CAS, work: Path) -> tuple[RunResult, Any]:
        from ..common.firewall import assert_may_execute_producers
        assert_may_execute_producers()  # Ax-O: never inside the admission role
        work.mkdir(parents=True, exist_ok=True)
        with Sandbox(base=work) as sb:
            inputs = self.materialize(cut, h, cas, sb)
            job = {"kind": self.job_kind, "inputs": inputs, "params": self.params(),
                   "out": str(sb / "out.json"), "trace": str(sb / "pytrace.json")}
            (sb / "job.json").write_text(json.dumps(job))
            epoch = max(h.version(i, cut[i]).ts for i in cut)
            res = run_hermetic([sys.executable, "-m", "f1.producers.pyjob", str(sb / "job.json")], sb,
                               timeout=self.timeout_s, epoch=epoch, allowed_read_prefixes=python_allowed_prefixes(),
                               extra_env={"PYTHONPATH": SRC_ROOT, "F1_THREADS": str(self.threads),
                                          "OMP_NUM_THREADS": str(self.threads)})
            out = None
            if res.status == "ok" and (sb / "out.json").exists():
                out = json.loads((sb / "out.json").read_text())
                tr = json.loads((sb / "pytrace.json").read_text()) if (sb / "pytrace.json").exists() else {}
                allowed = [str(sb)] + python_allowed_prefixes()
                hidden = [p for p in tr.get("opens", [])
                          if not any(p == a or p.startswith(a.rstrip("/") + "/") for a in allowed)
                          and not p.startswith(SYSTEM_PREFIXES)]
                res.hidden_reads = sorted(set(res.hidden_reads) | set(hidden))
                res.net_attempts += int(tr.get("net", 0))
                if res.trace_method == "none":
                    res.trace_method = "audithook"
                else:
                    res.trace_method += "+audithook"
            elif res.status == "ok":
                res.status = "error"
            return res, out
