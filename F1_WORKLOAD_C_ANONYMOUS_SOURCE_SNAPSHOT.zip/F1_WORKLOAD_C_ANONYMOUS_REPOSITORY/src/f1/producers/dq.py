"""P_DQ: deterministic full-data quality certification over an evolving analytical table.

Items: D = table version (tree of parquet files), optionally R = reference table (parquet) for
referential-integrity checks. The check suite is a frozen policy (configs/dq_policies/*.yaml) whose
thresholds come from published data dictionaries, never from the data.

Check: {"id": str, "stat": {"kind": ..., ...}, "op": "le"|"ge", "thr": number}; passes iff stat op thr.
A statistic that cannot be computed (missing column, empty table) is None and the check FAILS.
Outputs: gate (PASS iff all checks pass), issues (sorted failing ids), stats ({id: value}).

The statistics library below is shared verbatim by the producer and by contract features; K2/K3 are therefore
exact by construction w.r.t. the statistics (no U1 from re-implementation), and their evaluation cost is real.
"""
from __future__ import annotations

import glob
import os
from pathlib import Path

from ..contracts.lang import feature
from .base import PythonJobProducer

STAT_KINDS = ("present", "type_is", "row_count", "null_fraction", "out_of_range_fraction", "quantile",
              "cardinality", "duplicate_fraction", "outside_set_fraction", "ref_missing_fraction",
              "negative_increment_fraction")


def _type_cat(t) -> str:
    import pyarrow as pa
    if pa.types.is_boolean(t): return "bool"
    if pa.types.is_integer(t): return "int"
    if pa.types.is_floating(t) or pa.types.is_decimal(t): return "float"
    if pa.types.is_string(t) or pa.types.is_large_string(t) or pa.types.is_dictionary(t): return "string"
    if pa.types.is_timestamp(t): return "timestamp"
    if pa.types.is_date(t): return "date"
    if pa.types.is_null(t): return "null"
    return "other"


class TableSource:
    """Lazy column access over the parquet files of one table version (column projection, permissive promotion)."""

    def __init__(self, files: list[str]):
        import pyarrow.parquet as pq
        self.files = sorted(files)
        self._schemas = [pq.read_schema(f) for f in self.files]
        self._cols: dict[str, object] = {}

    def columns(self) -> dict[str, str]:
        out: dict[str, str] = {}
        for sch in self._schemas:
            for f in sch:
                c = _type_cat(f.type)
                prev = out.get(f.name)
                if prev is None or prev == "null":
                    out[f.name] = c
                elif c not in (prev, "null"):
                    out[f.name] = "float" if {prev, c} <= {"int", "float"} else "mixed"
        return dict(sorted(out.items()))

    def num_rows(self) -> int:
        import pyarrow.parquet as pq
        return sum(pq.ParquetFile(f).metadata.num_rows for f in self.files)

    def column(self, name: str):
        import pyarrow as pa
        import pyarrow.parquet as pq
        if name in self._cols:
            return self._cols[name]
        chunks = []
        for f, sch in zip(self.files, self._schemas):
            n = pq.ParquetFile(f).metadata.num_rows
            if name in sch.names:
                col = pq.read_table(f, columns=[name]).column(name)
                chunks.append(col)
            else:
                chunks.append(pa.nulls(n))
        if not chunks:
            return None
        types = {c.type for c in chunks if not pa.types.is_null(c.type)}
        target = None
        if len(types) == 1:
            target = types.pop()
        elif types and all(pa.types.is_integer(t) or pa.types.is_floating(t) for t in types):
            target = pa.float64()
        elif types:
            target = pa.string()
        arrs = []
        for c in chunks:
            c = c.combine_chunks() if isinstance(c, pa.ChunkedArray) else c
            if target is not None and c.type != target:
                c = c.cast(target, safe=False) if not pa.types.is_null(c.type) else pa.nulls(len(c), type=target)
            arrs.append(c)
        out = pa.chunked_array(arrs, type=target or pa.null())
        self._cols[name] = out
        return out


def compute_stat(spec: dict, src: TableSource, ref: TableSource | None = None):
    import numpy as np
    import pyarrow as pa
    import pyarrow.compute as pc
    kind = spec["kind"]
    cols = src.columns()
    if kind == "row_count":
        return src.num_rows()
    if kind == "present":
        return 1.0 if spec["col"] in cols else 0.0
    if kind == "type_is":
        c = cols.get(spec["col"])
        return None if c is None else (1.0 if c in spec["types"] else 0.0)
    if kind in ("duplicate_fraction", "negative_increment_fraction"):
        need = list(spec.get("cols") or []) + [x for x in (spec.get("order"), spec.get("value")) if x]
        if any(c not in cols for c in need):
            return None
    elif spec.get("col") not in cols:
        return None
    n = src.num_rows()
    if n == 0:
        return None
    if kind == "null_fraction":
        return float(src.column(spec["col"]).null_count) / n
    if kind == "out_of_range_fraction":
        col = src.column(spec["col"])
        nn = n - col.null_count
        if nn == 0:
            return None
        try:
            outside = pc.or_(pc.less(col, spec["lo"]), pc.greater(col, spec["hi"]))
        except (pa.ArrowNotImplementedError, pa.ArrowInvalid, TypeError):
            return None
        return float(pc.sum(outside.cast(pa.int64())).as_py() or 0) / nn
    if kind == "quantile":
        col = src.column(spec["col"])
        try:
            q = pc.quantile(col, q=float(spec["q"]), interpolation="linear", skip_nulls=True)
        except (pa.ArrowNotImplementedError, pa.ArrowInvalid, TypeError):
            return None
        v = q[0].as_py() if len(q) else None
        return None if v is None else float(v)
    if kind == "cardinality":
        return int(pc.count_distinct(src.column(spec["col"]), mode="only_valid").as_py())
    if kind == "outside_set_fraction":
        col = src.column(spec["col"])
        nn = n - col.null_count
        if nn == 0:
            return None
        vals = pa.array(spec["values"])
        try:
            if col.type != vals.type:
                col = col.cast(vals.type, safe=False)
            inside = pc.is_in(col, value_set=vals)
        except (pa.ArrowNotImplementedError, pa.ArrowInvalid, TypeError):
            return None
        bad = pc.sum(pc.and_(pc.invert(inside), pc.is_valid(col)).cast(pa.int64())).as_py() or 0
        return float(bad) / nn
    if kind == "ref_missing_fraction":
        if ref is None or spec["ref_col"] not in ref.columns():
            return None
        col, rcol = src.column(spec["col"]), ref.column(spec["ref_col"])
        nn = n - col.null_count
        if nn == 0:
            return None
        try:
            rvals = pc.unique(rcol.cast(col.type, safe=False)).drop_null() if rcol.type != col.type else pc.unique(rcol).drop_null()
            bad = pc.sum(pc.and_(pc.invert(pc.is_in(col, value_set=rvals)), pc.is_valid(col)).cast(pa.int64())).as_py() or 0
        except (pa.ArrowNotImplementedError, pa.ArrowInvalid, TypeError):
            return None
        return float(bad) / nn
    if kind == "duplicate_fraction":
        keys = list(spec["cols"])
        t = pa.table({k: src.column(k) for k in keys})
        distinct = t.group_by(keys).aggregate([]).num_rows
        return 1.0 - float(distinct) / n
    if kind == "negative_increment_fraction":
        g, o, v = list(spec["cols"]), spec["order"], spec["value"]
        t = pa.table({**{k: src.column(k) for k in g}, o: src.column(o), v: src.column(v)})
        idx = pc.sort_indices(t, sort_keys=[(k, "ascending") for k in g] + [(o, "ascending")])
        t = t.take(idx)
        try:
            vals = t.column(v).cast(pa.float64(), safe=False).to_numpy(zero_copy_only=False)
        except (pa.ArrowInvalid, pa.ArrowNotImplementedError):
            return None
        m = len(vals)
        if m < 2:
            return None
        same = np.ones(m - 1, dtype=bool)
        for k in g:
            col = t.column(k)
            eq = pc.equal(col.slice(1), col.slice(0, m - 1))
            same &= np.asarray(pc.fill_null(eq, False).to_numpy(zero_copy_only=False), dtype=bool)
        d = vals[1:] - vals[:-1]
        valid = same & ~np.isnan(d)
        if valid.sum() == 0:
            return None
        return float((d[valid] < 0).sum()) / float(valid.sum())
    raise ValueError(f"unknown stat kind {kind}")


def run_checks(checks: list[dict], src: TableSource, ref: TableSource | None) -> dict:
    stats, issues = {}, []
    for ch in checks:
        v = compute_stat(ch["stat"], src, ref)
        stats[ch["id"]] = v
        ok = v is not None and (v <= ch["thr"] if ch["op"] == "le" else v >= ch["thr"])
        if not ok:
            issues.append(ch["id"])
    return {"gate": "FAIL" if issues else "PASS", "issues": sorted(issues), "stats": stats}


def _files_in(d: str) -> list[str]:
    return sorted(glob.glob(os.path.join(d, "**", "*.parquet"), recursive=True))


def set_threads(n: int) -> None:
    import pyarrow as pa
    n = max(1, int(n))
    pa.set_cpu_count(n)
    pa.set_io_thread_count(max(2, n))


def run_job(inputs: dict, params: dict) -> dict:
    set_threads(int(os.environ.get("F1_THREADS", "1")))
    src = TableSource(_files_in(inputs["D"]))
    ref = None
    if "R" in inputs:
        ref = TableSource([inputs["R"]] if os.path.isfile(inputs["R"]) else _files_in(inputs["R"]))
    return run_checks(params["checks"], src, ref)


# ---------------------------------------------------------------------------------------------
# Features (same library, evaluated on CAS-resident parquet without copying)
# ---------------------------------------------------------------------------------------------
def _source(view) -> TableSource:
    def build(L, r):
        cas = L.cas
        if cas.is_tree(r):
            files = [str(cas.raw_path(b) or _spill(cas, b)) for _, b in sorted(L.tree(r).items())]
        else:
            files = [str(cas.raw_path(r) or _spill(cas, r))]
        return TableSource(files)
    return view.loader.parsed("dq-table", view.content_ref, build)


def _spill(cas, h) -> Path:
    import tempfile
    p = Path(tempfile.gettempdir()) / "f1-spill" / (h + ".parquet")
    if not p.exists():
        cas._materialize_blob(h, p)
    return p


@feature("dq_stat")
def f_dq_stat(view_or_views, stat):
    if isinstance(view_or_views, list):
        by = {v.item: v for v in view_or_views}
        return compute_stat(stat, _source(by["D"]), _source(by["R"]) if "R" in by else None)
    return compute_stat(stat, _source(view_or_views), None)


@feature("k3_dq")
def f_k3_dq(views, checks, mode):
    by = {v.item: v for v in views}
    out = run_checks(checks, _source(by["D"]), _source(by["R"]) if "R" in by else None)
    return out["gate"] if mode == "gate" else out["issues"]


class DQProducer(PythonJobProducer):
    producer_id = "dq-cert"
    artifact_types = ["dq_gate", "dq_issues"]
    job_kind = "dq"
    timeout_s = 7200.0

    def __init__(self, checks: list[dict], uses_ref: bool, policy_id: str, resource_class: str = "MEDIUM_CPU", threads: int = 1):
        self.checks = checks
        self.resource_class = resource_class
        self.threads = threads
        self.uses_ref = uses_ref
        self.policy_id = policy_id
        self.read_items = ["D", "R"] if uses_ref else ["D"]

    def params(self):
        return {"checks": self.checks, "policy_id": self.policy_id}

    def project(self, output, artifact_type):
        return output["gate"] if artifact_type == "dq_gate" else output["issues"]

    def _stat_node(self, ch):
        items = ["D", "R"] if ch["stat"]["kind"] == "ref_missing_fraction" and self.uses_ref else None
        node = {"op": "feat", "f": "dq_stat", "args": {"stat": ch["stat"]}}
        if items:
            node["items"] = items
        else:
            node["item"] = "D"
        return node

    def contracts(self, artifact_type, cut, h, loader, output):
        stats = output["stats"]
        # K1: which statistics influenced the result + their recorded birth values; no thresholds, no logic.
        k1 = {"op": "and", "args": [{"op": "eq", "a": self._stat_node(ch), "b": {"op": "const", "v": stats[ch["id"]]}}
                                    for ch in self.checks]}

        def passes(ch):
            return {"op": ch["op"], "a": self._stat_node(ch), "b": {"op": "const", "v": ch["thr"]}}

        failing = set(output["issues"])
        if artifact_type == "dq_gate" and output["gate"] == "PASS":
            k2 = {"op": "and", "args": [passes(ch) for ch in self.checks]}
        elif artifact_type == "dq_gate":
            k2 = {"op": "or", "args": [{"op": "not", "a": passes(ch)} for ch in self.checks if ch["id"] in failing]}
        else:
            k2 = {"op": "and", "args": [passes(ch) if ch["id"] not in failing else {"op": "not", "a": passes(ch)}
                                        for ch in self.checks]}
        mode = "gate" if artifact_type == "dq_gate" else "issues"
        k3 = {"op": "eq", "a": {"op": "feat", "items": self.read_items, "f": "k3_dq",
                                "args": {"checks": self.checks, "mode": mode}},
              "b": {"op": "const", "v": self.project(output, artifact_type)}}
        return {"K1": k1, "K2": k2, "K3": k3}
