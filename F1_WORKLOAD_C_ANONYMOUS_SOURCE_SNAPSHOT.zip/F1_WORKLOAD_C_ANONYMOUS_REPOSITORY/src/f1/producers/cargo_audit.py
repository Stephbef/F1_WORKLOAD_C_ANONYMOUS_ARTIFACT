"""P_vuln: cargo-audit (pinned static binary) run offline against the advisory DB of the cut.

Inputs (RS): S = Cargo.lock, V = RustSec advisory DB tree, P = policy file (deny.toml/audit.toml/default).
Policy semantics (frozen): advisories.ignore entries of P are passed as --ignore flags.
Outputs: report = sorted "ID|crate|version" for vulnerabilities (informational warnings excluded),
gate = FAIL iff report non-empty. cargo-audit exit codes 0 (clean) and 1 (vulnerabilities) are success.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from ..common.util import CAS, F1Error, sha256_file, sha256_obj
from ..core.history import Cut, History
from .base import Producer
from .hermetic import RunResult, Sandbox, run_hermetic
from .rustsec import parse_policy, policy_ignores_from, registry_packages


class CargoAuditProducer(Producer):
    producer_id = "cargo-audit"
    read_items = ["P", "S", "V"]
    artifact_types = ["vuln_report", "vuln_gate"]

    def __init__(self, binary: str, db_cache: str | Path, timeout_s: float = 600.0, expected_sha256: str | None = None):
        self.binary = str(Path(binary).resolve())
        if not os.path.exists(self.binary):
            raise F1Error(f"cargo-audit binary not found: {self.binary}")
        self.sha = sha256_file(self.binary)
        if expected_sha256 and self.sha != expected_sha256:
            raise F1Error(f"cargo-audit binary digest {self.sha} != frozen {expected_sha256}")
        self.db_cache = Path(db_cache)
        self.timeout_s = timeout_s

    def version_digest(self) -> str:
        return self.sha[:16]

    def _db_dir(self, cas: CAS, ref: str) -> Path:
        """Materialise a DB version once into a content-addressed cache dir (read-only reuse)."""
        d = self.db_cache / ref
        if not (d / ".complete").exists():
            tmp = self.db_cache / (ref + ".tmp" + str(os.getpid()))
            cas.materialize(ref, tmp)
            (tmp / ".complete").write_text("ok")
            try:
                tmp.rename(d)
            except OSError:
                import shutil
                shutil.rmtree(tmp, ignore_errors=True)  # another worker won the race
        return d

    def execute(self, cut: Cut, h: History, cas: CAS, work: Path) -> tuple[RunResult, object]:
        from ..common.firewall import assert_may_execute_producers
        assert_may_execute_producers()  # Ax-O: never inside the admission role
        work.mkdir(parents=True, exist_ok=True)
        with Sandbox(base=work) as sb:
            proj = sb / "proj"
            proj.mkdir()
            cas.materialize(h.content(cut, "S"), proj / "Cargo.lock")
            pol = parse_policy(cas.get(h.content(cut, "P")).decode("utf-8", "replace"))
            ignores = policy_ignores_from(pol)
            db = self._db_dir(cas, h.content(cut, "V"))
            argv = [self.binary, "audit", "--db", str(db), "--no-fetch", "--stale", "--json",
                    "--file", str(proj / "Cargo.lock")]
            for i in ignores:
                argv += ["--ignore", i]
            epoch = max(h.version(i, cut[i]).ts for i in cut)
            res = run_hermetic(argv, sb, timeout=self.timeout_s, epoch=epoch,
                               allowed_read_prefixes=[str(db)], ok_codes=(0, 1))
            if res.status != "ok":
                return res, None
            try:
                d = json.loads(res.stdout.decode("utf-8"))
                vl = d["vulnerabilities"]["list"]
                report = sorted({f"{x['advisory']['id']}|{x['package']['name']}|{x['package']['version']}" for x in vl})
            except Exception as e:
                res.status = "error"
                res.stderr_tail += f"\n[harness] unparsable cargo-audit output: {e}"
                return res, None
            return res, {"report": report, "gate": "FAIL" if report else "PASS"}

    def project(self, output, artifact_type):
        return output["report"] if artifact_type == "vuln_report" else output["gate"]

    def contracts(self, artifact_type, cut, h, loader, output):
        pkgs = registry_packages(loader.text(h.content(cut, "S")))
        crates = sorted({p.rsplit("@", 1)[0] for p in pkgs})
        f_pk = {"op": "feat", "item": "S", "f": "lock_packages"}
        pin_pkgs = {"op": "eq", "a": f_pk, "b": {"op": "const", "v": pkgs}}
        # birth values of disclosed features (computed by the wrapper from its own inputs)
        from ..contracts.lang import FEATURES, ItemView
        vV = ItemView("V", h.content(cut, "V"), loader)
        vP = ItemView("P", h.content(cut, "P"), loader)
        slice_d = FEATURES["advisory_slice_digest"](vV, crates=crates)
        sec_h = FEATURES["policy_section_hash"](vP, section="advisories")
        k1 = {"op": "and", "args": [
            pin_pkgs,
            {"op": "eq", "a": {"op": "feat", "item": "V", "f": "advisory_slice_digest", "args": {"crates": crates}},
             "b": {"op": "const", "v": slice_d}},
            {"op": "eq", "a": {"op": "feat", "item": "P", "f": "policy_section_hash", "args": {"section": "advisories"}},
             "b": {"op": "const", "v": sec_h}}]}
        applicable = {"op": "drop_keys",
                      "a": {"op": "feat", "item": "V", "f": "affecting_triples", "args": {"packages": pkgs}},
                      "b": {"op": "feat", "item": "P", "f": "policy_ignores"}}
        if artifact_type == "vuln_report":
            k2 = {"op": "and", "args": [pin_pkgs, {"op": "eq", "a": applicable, "b": {"op": "const", "v": output["report"]}}]}
        elif output["gate"] == "PASS":
            k2 = {"op": "and", "args": [pin_pkgs, {"op": "isempty", "a": applicable}]}
        else:
            k2 = {"op": "and", "args": [pin_pkgs, {"op": "not", "a": {"op": "isempty", "a": {
                "op": "intersect", "a": applicable, "b": {"op": "const", "v": output["report"]}}}}]}
        mode = "report" if artifact_type == "vuln_report" else "gate"
        k3 = {"op": "eq", "a": {"op": "feat", "items": ["P", "S", "V"], "f": "k3_vuln", "args": {"mode": mode}},
              "b": {"op": "const", "v": self.project(output, artifact_type)}}
        return {"K1": k1, "K2": k2, "K3": k3}
