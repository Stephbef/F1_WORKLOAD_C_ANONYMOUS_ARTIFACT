"""P_license: deterministic SPDX license gate (frozen wrapper; chosen because cargo-deny needs crate sources
and `cargo metadata`, which cannot be replayed hermetically offline without a vendored registry).

Inputs (RS): S = Cargo.lock, L = license table {"name@version": "SPDX expr" | null} (immutable per published
version; a single frozen version), P = policy file. Allowed set = P.licenses.allow if present, else the frozen
default list. Semantics (frozen, documented divergences from cargo-deny): "A/B" legacy syntax = OR;
"X WITH Y" counts as X; "X+" counts as X; missing/unparsable expression = violation.
Outputs: gate PASS/FAIL; issues = sorted "name@version|expr" violations.
"""
from __future__ import annotations

import json
import re

from ..contracts.lang import feature
from .base import PythonJobProducer
from .rustsec import allowed_licenses_from, parse_policy, registry_packages

_TOK = re.compile(r"\(|\)|[A-Za-z0-9.\-+:]+")


def dnf(expr: str | None) -> list[frozenset] | None:
    """Disjunctive normal form: list of alternative license sets; None if missing/unparsable."""
    if not expr or not isinstance(expr, str):
        return None
    toks = _TOK.findall(expr.replace("/", " OR "))
    pos = 0

    def peek():
        return toks[pos] if pos < len(toks) else None

    def take():
        nonlocal pos
        t = toks[pos]
        pos += 1
        return t

    def atom():
        t = peek()
        if t is None:
            raise ValueError("unexpected end")
        if t == "(":
            take()
            r = disj()
            if peek() != ")":
                raise ValueError("missing )")
            take()
            return r
        if t.upper() in ("AND", "OR", "WITH", ")"):
            raise ValueError(f"unexpected {t}")
        lic = take().rstrip("+")
        if peek() and peek().upper() == "WITH":
            take()
            take()  # exception identifier ignored (documented)
        return [frozenset([lic])]

    def conj():
        r = atom()
        while peek() and peek().upper() == "AND":
            take()
            rhs = atom()
            r = [a | b for a in r for b in rhs]
        return r

    def disj():
        r = conj()
        while peek() and peek().upper() == "OR":
            take()
            r = r + conj()
        return r

    try:
        out = disj()
        if pos != len(toks):
            return None
        return sorted(set(out), key=lambda s: sorted(s))
    except (ValueError, IndexError):
        return None


def satisfied(expr: str | None, allowed: set) -> bool:
    alts = dnf(expr)
    return bool(alts) and any(a <= allowed for a in alts)


def evaluate(pkgs: list[str], table: dict, allowed: list[str]) -> dict:
    al = set(allowed)
    issues = sorted(f"{p}|{table.get(p)}" for p in pkgs if not satisfied(table.get(p), al))
    return {"gate": "FAIL" if issues else "PASS", "issues": issues}


def run_job(inputs: dict, params: dict) -> dict:
    pkgs = registry_packages(open(inputs["S"], encoding="utf-8").read())
    table = json.load(open(inputs["L"]))
    pol = parse_policy(open(inputs["P"], encoding="utf-8").read())
    return evaluate(pkgs, table, allowed_licenses_from(pol, params["default_allow"]))


def _table(view):
    return view.loader.parsed("lictable", view.content_ref, lambda L, r: json.loads(L.text(r)))


@feature("license_slice_digest")
def f_license_slice(view, packages):
    from ..common.util import sha256_obj
    t = _table(view)
    return sha256_obj({p: t.get(p) for p in packages})


@feature("allowed_licenses")
def f_allowed(view, default):
    pol = view.loader.parsed("policy", view.content_ref, lambda L, r: parse_policy(L.text(r)))
    return allowed_licenses_from(pol, default)


@feature("k3_license")
def f_k3_license(views, mode, default):
    by = {v.item: v for v in views}
    pkgs = view_pkgs(by["S"])
    pol = by["P"].loader.parsed("policy", by["P"].content_ref, lambda L, r: parse_policy(L.text(r)))
    out = evaluate(pkgs, _table(by["L"]), allowed_licenses_from(pol, default))
    return out["gate"] if mode == "gate" else out["issues"]


def view_pkgs(view):
    return view.loader.parsed("lock-pkgs", view.content_ref, lambda L, r: registry_packages(L.text(r)))


class LicenseProducer(PythonJobProducer):
    producer_id = "license-spdx"
    read_items = ["L", "P", "S"]
    artifact_types = ["lic_gate", "lic_issues"]
    job_kind = "license"
    timeout_s = 600.0

    def __init__(self, default_allow: list[str]):
        self.default_allow = sorted(default_allow)

    def params(self):
        return {"default_allow": self.default_allow}

    def project(self, output, artifact_type):
        return output["gate"] if artifact_type == "lic_gate" else output["issues"]

    def contracts(self, artifact_type, cut, h, loader, output):
        from ..contracts.lang import FEATURES, ItemView
        pkgs = registry_packages(loader.text(h.content(cut, "S")))
        table = json.loads(loader.text(h.content(cut, "L")))
        pin = {"op": "eq", "a": {"op": "feat", "item": "S", "f": "lock_packages"}, "b": {"op": "const", "v": pkgs}}
        vL, vP = ItemView("L", h.content(cut, "L"), loader), ItemView("P", h.content(cut, "P"), loader)
        k1 = {"op": "and", "args": [
            pin,
            {"op": "eq", "a": {"op": "feat", "item": "L", "f": "license_slice_digest", "args": {"packages": pkgs}},
             "b": {"op": "const", "v": FEATURES["license_slice_digest"](vL, packages=pkgs)}},
            {"op": "eq", "a": {"op": "feat", "item": "P", "f": "policy_section_hash", "args": {"section": "licenses"}},
             "b": {"op": "const", "v": FEATURES["policy_section_hash"](vP, section="licenses")}}]}
        allowed = {"op": "feat", "item": "P", "f": "allowed_licenses", "args": {"default": self.default_allow}}

        def sat_expr(e):
            alts = dnf(e)
            if not alts:
                return {"op": "const", "v": False}
            return {"op": "or", "args": [{"op": "subset", "a": {"op": "const", "v": sorted(a)}, "b": allowed} for a in alts]}

        exprs = sorted({table.get(p) for p in pkgs}, key=lambda x: (x is None, str(x)))
        birth_allowed = set(allowed_licenses_from(parse_policy(loader.text(h.content(cut, "P"))), self.default_allow))
        status = {e: satisfied(e, birth_allowed) for e in exprs}
        if artifact_type == "lic_gate" and output["gate"] == "PASS":
            terms = [sat_expr(e) for e in exprs] or [{"op": "const", "v": True}]
            k2 = {"op": "and", "args": [pin] + terms}
        elif artifact_type == "lic_gate":
            bad = [e for e in exprs if not status[e]]
            k2 = {"op": "and", "args": [pin, {"op": "or", "args": [{"op": "not", "a": sat_expr(e)} for e in bad]}]}
        else:
            terms = [sat_expr(e) if status[e] else {"op": "not", "a": sat_expr(e)} for e in exprs]
            k2 = {"op": "and", "args": [pin] + (terms or [{"op": "const", "v": True}])}
        mode = "gate" if artifact_type == "lic_gate" else "issues"
        k3 = {"op": "eq", "a": {"op": "feat", "items": ["L", "P", "S"], "f": "k3_license",
                                "args": {"mode": mode, "default": self.default_allow}},
              "b": {"op": "const", "v": self.project(output, artifact_type)}}
        return {"K1": k1, "K2": k2, "K3": k3}
