"""Environment detector (R1): records the actual machine capabilities; never assumes them."""
from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

from ..common.util import atomic_write_json, now_iso


def _run(cmd: list[str], timeout: int = 20) -> tuple[int | None, str]:
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout)
        return p.returncode, (p.stdout + p.stderr).decode("utf-8", "replace").strip()
    except (FileNotFoundError, subprocess.TimeoutExpired, PermissionError) as e:
        return None, f"{type(e).__name__}: {e}"


def _meminfo() -> dict:
    out = {}
    try:
        for line in open("/proc/meminfo"):
            k, v = line.split(":", 1)
            if k in ("MemTotal", "MemAvailable"):
                out[k] = round(int(v.split()[0]) / 1024 / 1024, 1)
    except OSError:
        out["error"] = "/proc/meminfo unreadable"
    return out


def _cpu() -> dict:
    model = None
    try:
        for line in open("/proc/cpuinfo"):
            if line.startswith("model name"):
                model = line.split(":", 1)[1].strip()
                break
    except OSError:
        model = "unreadable"
    return {"logical_cpus": os.cpu_count(), "model": model,
            "affinity": len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None}


def detect(cfg: dict) -> dict:
    from ..producers.hermetic import strace_available, unshare_available
    root = Path(cfg.get("root", "."))
    data = Path(cfg.get("paths", {}).get("data", root))
    data.mkdir(parents=True, exist_ok=True)
    du = shutil.disk_usage(data)
    rep = {
        "generated_at": now_iso(),
        "host": platform.node(), "platform": platform.platform(), "kernel": platform.release(),
        "os_release": dict(l.strip().split("=", 1) for l in open("/etc/os-release") if "=" in l) if os.path.exists("/etc/os-release") else {},
        "python": {"version": sys.version.split()[0], "executable": sys.executable},
        "glibc": platform.libc_ver(),
        "cpu": _cpu(), "memory_gb": _meminfo(),
        "disk": {"path": str(data), "total_gb": round(du.total / 1e9, 1), "free_gb": round(du.free / 1e9, 1)},
        "isolation": {"unshare_netns": unshare_available(), "strace": strace_available()},
        "tools": {}, "containers": {}, "gpu": {}, "python_packages": {},
    }
    rc, out = _run(["lscpu"])
    rep["cpu"]["lscpu"] = {l.split(":", 1)[0].strip(): l.split(":", 1)[1].strip() for l in out.splitlines()
                           if ":" in l and l.split(":", 1)[0].strip() in ("Model name", "Socket(s)", "Core(s) per socket",
                                                                           "Thread(s) per core", "NUMA node(s)", "CPU(s)")} if rc == 0 else None
    rc, out = _run(["df", "-T", str(data)])
    rep["disk"]["filesystem"] = out.splitlines()[-1].split()[1] if rc == 0 and len(out.splitlines()) > 1 else None
    rc, out = _run(["nvcc", "--version"])
    rep["cuda_toolkit"] = out.splitlines()[-1] if rc == 0 and out else None
    for tool, args in {"git": ["--version"], "cargo": ["--version"], "rustc": ["--version"], "gcc": ["--version"],
                       "strace": ["-V"], "unshare": ["--version"]}.items():
        rc, out = _run([tool] + args)
        rep["tools"][tool] = {"available": rc == 0, "version": out.splitlines()[0] if rc == 0 and out else None}
    for c in ("docker", "podman", "apptainer", "singularity", "micromamba", "conda"):
        rc, out = _run([c, "--version"])
        rep["containers"][c] = {"available": rc == 0, "version": out.splitlines()[0] if rc == 0 and out else None}
    rc, out = _run(["nvidia-smi", "--query-gpu=index,name,memory.total,driver_version", "--format=csv,noheader"])
    rc2, out2 = _run(["nvidia-smi"])
    rep["gpu_cuda_driver_api"] = next((l.split("CUDA Version:")[1].split("|")[0].strip() for l in out2.splitlines() if "CUDA Version" in l), None) if rc2 == 0 else None
    rep["gpu"] = {"nvidia_smi": rc == 0, "devices": out.splitlines() if rc == 0 else [], "note": "GPU is not required by the primary workloads"}
    rep["container"] = {"inside_container": os.path.exists("/.dockerenv") or bool(os.environ.get("APPTAINER_CONTAINER") or os.environ.get("SINGULARITY_CONTAINER")),
                        "image": os.environ.get("F1_CONTAINER_IMAGE")}
    for mod in ("numpy", "pyarrow", "yaml", "matplotlib", "pytest", "pulp", "highspy"):
        try:
            m = __import__(mod)
            rep["python_packages"][mod] = getattr(m, "__version__", "present")
        except Exception as e:
            rep["python_packages"][mod] = None
    ca = (cfg.get("tools") or {}).get("cargo_audit") or {}
    if ca.get("path"):
        p = Path(ca["path"])
        if p.exists():
            from ..common.util import sha256_file
            rc, out = _run([str(p), "--version"])
            rep["tools"]["cargo_audit"] = {"available": rc == 0, "version": out, "sha256": sha256_file(p),
                                           "expected_sha256": ca.get("sha256")}
        else:
            rep["tools"]["cargo_audit"] = {"available": False, "path": str(p)}
    return rep


def require(rep: dict, cfg: dict) -> list[str]:
    """Hard requirements for the configured workloads; returns a list of problems (empty = OK)."""
    probs = []
    v = tuple(int(x) for x in rep["python"]["version"].split(".")[:2])
    if v < (3, 11):
        probs.append(f"Python >= 3.11 required (tomllib); found {rep['python']['version']}")
    for mod in ("numpy", "pyarrow", "yaml", "matplotlib"):
        if not rep["python_packages"].get(mod):
            probs.append(f"python package missing: {mod}")
    if not rep["tools"]["git"]["available"]:
        probs.append("git missing")
    wls = cfg.get("workloads", [])
    if "A" in wls:
        ca = rep["tools"].get("cargo_audit", {})
        if not ca.get("available"):
            probs.append("cargo-audit binary missing (run scripts/fetch_tools.sh)")
        elif ca.get("expected_sha256") and ca["sha256"] != ca["expected_sha256"]:
            probs.append("cargo-audit binary digest differs from the frozen digest")
    need_gb = float((cfg.get("server") or {}).get("min_free_disk_gb", 0))
    if rep["disk"]["free_gb"] < need_gb:
        probs.append(f"free disk {rep['disk']['free_gb']} GB < required {need_gb} GB")
    if (cfg.get("server") or {}).get("require_network_isolation") and not rep["isolation"]["unshare_netns"]:
        probs.append("network isolation (unshare -rn) unavailable but required by server.yaml")
    return probs


def lock(cfg: dict) -> dict:
    """environment_lock.json: exact interpreter, packages, tool digests and code state used for the campaign."""
    from importlib import metadata
    pk = sorted(f"{d.metadata['Name']}=={d.version}" for d in metadata.distributions() if d.metadata.get("Name"))
    rep = detect(cfg)
    root = Path(cfg.get("root", "."))
    rc, commit = _run(["git", "-C", str(root), "rev-parse", "HEAD"])
    return {"generated_at": now_iso(), "python": rep["python"], "platform": rep["platform"], "glibc": rep["glibc"],
            "python_packages": pk, "tools": rep["tools"], "container": rep["container"],
            "git_commit": commit if rc == 0 else None}


def write_reports(rep: dict, out_dir: Path, stem: str = "environment_report") -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json(out_dir / f"{stem}.json", rep)
    md = ["# Environment report", "", f"Generated {rep['generated_at']} on `{rep['host']}`", "",
          f"- platform: {rep['platform']}", f"- glibc: {rep['glibc']}", f"- python: {rep['python']['version']} ({rep['python']['executable']})",
          f"- CPU: {rep['cpu']}", f"- memory (GB): {rep['memory_gb']}", f"- disk: {rep['disk']}",
          f"- isolation: {rep['isolation']}", f"- GPU: {rep['gpu']}", f"- CUDA (driver API): {rep.get('gpu_cuda_driver_api')}",
          f"- CUDA toolkit: {rep.get('cuda_toolkit')}", f"- container: {rep.get('container')}", "", "## Tools", ""]
    md += [f"- {k}: {v}" for k, v in rep["tools"].items()]
    md += ["", "## Containers / environment managers", ""] + [f"- {k}: {v}" for k, v in rep["containers"].items()]
    md += ["", "## Python packages", ""] + [f"- {k}: {v}" for k, v in rep["python_packages"].items()]
    (out_dir / f"{stem}.md").write_text("\n".join(md) + "\n")
