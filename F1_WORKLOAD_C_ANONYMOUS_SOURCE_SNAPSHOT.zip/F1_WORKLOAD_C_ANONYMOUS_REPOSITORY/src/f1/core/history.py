"""Versioned context history H_t (D1-D4).

- Each item has a totally ordered version chain (A1).
- Causal/derivation edges (x,v) -> (y,w) between items; the history is a DAG, no global total order.
- A cut assigns one version per item; it is consistent iff for every selected (y, c(y)) and every
  event (x, v) that happened-before it, v <= c(x) in x's order (frontier form of consistent cuts).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator

from ..common.util import F1Error, sha256_obj

Cut = dict  # item -> version id


@dataclass(frozen=True)
class Version:
    item: str
    vid: str
    ts: float
    content: str  # CAS hash of the version's content
    meta: tuple = ()  # sorted (key, value) pairs; e.g. (("rev", "<git sha>"),)

    def meta_dict(self) -> dict:
        return dict(self.meta)


def cut_key(cut: Cut) -> str:
    return "|".join(f"{k}={cut[k]}" for k in sorted(cut))


class History:
    def __init__(self, versions: list[Version], edges: list[tuple[tuple[str, str], tuple[str, str]]] | None = None):
        self.items: dict[str, list[Version]] = {}
        for v in versions:
            self.items.setdefault(v.item, []).append(v)
        self._idx: dict[tuple[str, str], int] = {}
        for item, chain in self.items.items():
            chain.sort(key=lambda v: (v.ts, v.vid))
            seen = set()
            for i, v in enumerate(chain):
                if v.vid in seen:
                    raise F1Error(f"duplicate version id {item}:{v.vid}")
                seen.add(v.vid)
                self._idx[(item, v.vid)] = i
        self.edges = list(edges or [])
        for (x, v), (y, w) in self.edges:
            if (x, v) not in self._idx or (y, w) not in self._idx:
                raise F1Error(f"edge references unknown version: {(x, v)} -> {(y, w)}")
            if x == y:
                raise F1Error("intra-item edges are implied by the version order; do not declare them")
        self._req = self._compute_requirements()

    # ---- structure -------------------------------------------------------------------------
    def _compute_requirements(self) -> dict[tuple[str, str], dict[str, int]]:
        """req[(y,w)][x] = largest index of a version of x that happened-before (y,w) (x != y)."""
        parents: dict[tuple[str, str], list[tuple[str, str]]] = {k: [] for k in self._idx}
        for item, chain in self.items.items():
            for i in range(1, len(chain)):
                parents[(item, chain[i].vid)].append((item, chain[i - 1].vid))
        for src, dst in self.edges:
            parents[dst].append(src)
        # Kahn topological order
        children: dict[tuple[str, str], list[tuple[str, str]]] = {k: [] for k in self._idx}
        indeg = {k: 0 for k in self._idx}
        for d, ps in parents.items():
            for p in ps:
                children[p].append(d)
                indeg[d] += 1
        order, frontier = [], sorted([k for k, n in indeg.items() if n == 0])
        while frontier:
            k = frontier.pop()
            order.append(k)
            for c in children[k]:
                indeg[c] -= 1
                if indeg[c] == 0:
                    frontier.append(c)
        if len(order) != len(self._idx):
            raise F1Error("history contains a causal cycle")
        req: dict[tuple[str, str], dict[str, int]] = {}
        for k in order:
            r: dict[str, int] = {}
            for p in parents[k]:
                px, _ = p
                for x, i in req[p].items():
                    if r.get(x, -1) < i:
                        r[x] = i
                if px != k[0]:
                    pi = self._idx[p]
                    if r.get(px, -1) < pi:
                        r[px] = pi
            r.pop(k[0], None)
            req[k] = r
        return req

    def idx(self, item: str, vid: str) -> int:
        try:
            return self._idx[(item, vid)]
        except KeyError:
            raise F1Error(f"unknown version {item}:{vid}") from None

    def version(self, item: str, vid: str) -> Version:
        return self.items[item][self.idx(item, vid)]

    def item_names(self) -> list[str]:
        return sorted(self.items)

    def versions_upto(self, item: str, t: float) -> list[Version]:
        return [v for v in self.items[item] if v.ts <= t]

    def current(self, item: str, t: float) -> Version | None:
        cur = None
        for v in self.items[item]:
            if v.ts <= t:
                cur = v
            else:
                break
        return cur

    def latest_cut(self, t: float) -> Cut | None:
        """c-hat_t: latest version of every item at time t (None if some item has no version yet)."""
        cut = {}
        for item in self.items:
            v = self.current(item, t)
            if v is None:
                return None
            cut[item] = v.vid
        return cut

    def requires(self, item: str, vid: str) -> dict[str, int]:
        return self._req[(item, vid)]

    def is_consistent(self, cut: Cut) -> bool:
        if set(cut) != set(self.items):
            return False
        for y, w in cut.items():
            if (y, w) not in self._req:
                return False
            for x, i in self._req[(y, w)].items():
                if self.idx(x, cut[x]) < i:
                    return False
        return True

    def compatible(self, partial: Cut, item: str, vid: str) -> bool:
        """Can (item=vid) be added to a partial cut without violating consistency among assigned items?"""
        r = self._req[(item, vid)]
        vi = self.idx(item, vid)
        for x, w in partial.items():
            if x in r and self.idx(x, w) < r[x]:
                return False
            rx = self._req[(x, w)]
            if item in rx and vi < rx[item]:
                return False
        return True

    def content(self, cut: Cut, item: str) -> str:
        return self.version(item, cut[item]).content

    def fingerprint(self) -> str:
        return sha256_obj({
            "versions": [[v.item, v.vid, float(v.ts), v.content, [list(m) for m in v.meta]]
                         for i in sorted(self.items) for v in self.items[i]],
            "edges": sorted([list(a) + list(b) for a, b in self.edges]),
        })

    # ---- enumeration -----------------------------------------------------------------------
    def enumerate_cuts(self, allowed: dict[str, list[str]], limit: int | None = None) -> Iterator[Cut]:
        """Enumerate consistent cuts whose per-item versions lie in `allowed` (ordered preference lists).

        Deterministic order: lexicographic by the preference order of `allowed` over sorted item names.
        Uses backtracking with incremental consistency pruning.
        """
        items = sorted(self.items)
        missing = [i for i in items if i not in allowed]
        if missing:
            raise F1Error(f"allowed-version map missing items {missing}")
        n = 0
        partial: Cut = {}

        def rec(k: int):
            nonlocal n
            if limit is not None and n >= limit:
                return
            if k == len(items):
                n += 1
                yield dict(partial)
                return
            it = items[k]
            for vid in allowed[it]:
                if self.compatible(partial, it, vid):
                    partial[it] = vid
                    yield from rec(k + 1)
                    del partial[it]
                    if limit is not None and n >= limit:
                        return

        yield from rec(0)

    # ---- persistence -----------------------------------------------------------------------
    def to_rows(self, cluster: str) -> list[dict]:
        parents: dict[tuple[str, str], list[str]] = {}
        for (x, v), (y, w) in self.edges:
            parents.setdefault((y, w), []).append(f"{x}:{v}")
        rows = []
        for item in sorted(self.items):
            for v in self.items[item]:
                rows.append({
                    "cluster": cluster, "item_id": item, "version_id": v.vid, "timestamp": float(v.ts),
                    "content_ref": v.content, "causal_parents": sorted(parents.get((item, v.vid), [])),
                    "meta": dict(v.meta),
                })
        return rows

    @staticmethod
    def from_rows(rows: list[dict]) -> "History":
        vs, edges = [], []
        for r in rows:
            vs.append(Version(r["item_id"], r["version_id"], float(r["timestamp"]), r["content_ref"],
                              tuple(sorted((r.get("meta") or {}).items()))))
            for p in r.get("causal_parents") or []:
                x, v = p.split(":", 1)
                edges.append(((x, v), (r["item_id"], r["version_id"])))
        return History(vs, edges)


def write_history_parquet(rows: list[dict], path: str | Path) -> None:
    """history.parquet with columns item_id, version_id, timestamp, content_ref, causal_parents (+cluster, meta)."""
    import json as _json
    import pyarrow as pa
    import pyarrow.parquet as pq
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    table = pa.table({
        "cluster": [r["cluster"] for r in rows],
        "item_id": [r["item_id"] for r in rows],
        "version_id": [r["version_id"] for r in rows],
        "timestamp": pa.array([r["timestamp"] for r in rows], type=pa.float64()),
        "content_ref": [r["content_ref"] for r in rows],
        "causal_parents": pa.array([r["causal_parents"] for r in rows], type=pa.list_(pa.string())),
        "meta_json": [_json.dumps(r.get("meta") or {}, sort_keys=True) for r in rows],
    })
    tmp = str(path) + ".tmp"
    pq.write_table(table, tmp)
    Path(tmp).replace(path)


def read_history_parquet(path: str | Path) -> dict[str, list[dict]]:
    import json as _json
    import pyarrow.parquet as pq
    t = pq.read_table(path).to_pylist()
    out: dict[str, list[dict]] = {}
    for r in t:
        r["meta"] = _json.loads(r.pop("meta_json") or "{}")
        out.setdefault(r["cluster"], []).append(r)
    return out
