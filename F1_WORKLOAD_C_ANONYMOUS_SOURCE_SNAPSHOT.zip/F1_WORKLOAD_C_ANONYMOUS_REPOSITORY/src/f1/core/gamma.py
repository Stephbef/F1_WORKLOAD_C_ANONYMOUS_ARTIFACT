"""Consumer envelope Gamma (D10). Gamma never reads contracts.

JSON form:
  {"id": "dash-k3-v1d-g0", "t": <epoch>, "rules": {"S": {"last_k": 3}, "V": {"window_s": 86400}, ...},
   "default": "latest"}

Rules per item (version must have ts <= t):
  {"latest": true}          only the version current at t
  {"last_k": k}             the k most recent versions
  {"window_s": w}           every version that was current at some instant in [t-w, t]
  {"fixed": [vid, ...]}     explicit set (e.g. the lockfile of a release commit)
  {"any": true}             every version up to t
Items without a rule follow `default` ("latest" unless stated).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..common.util import F1Error, sha256_obj
from .history import Cut, History


@dataclass
class Gamma:
    gid: str
    t: float
    rules: dict = field(default_factory=dict)
    default: str = "latest"

    def __post_init__(self):
        self.t = float(self.t)

    def to_json(self) -> dict:
        return {"id": self.gid, "t": float(self.t), "rules": self.rules, "default": self.default}

    @staticmethod
    def from_json(d: dict) -> "Gamma":
        return Gamma(d["id"], float(d["t"]), dict(d.get("rules") or {}), d.get("default", "latest"))

    def digest(self) -> str:
        return sha256_obj(self.to_json())

    def allowed(self, h: History) -> dict[str, list[str]]:
        """Allowed versions per item, most recent first (deterministic preference order)."""
        out: dict[str, list[str]] = {}
        for item in h.item_names():
            rule = self.rules.get(item, {self.default: True} if self.default != "any" else {"any": True})
            upto = h.versions_upto(item, self.t)
            if not upto:
                out[item] = []
                continue
            if "latest" in rule:
                sel = [upto[-1]]
            elif "last_k" in rule:
                k = int(rule["last_k"])
                if k < 1:
                    raise F1Error("last_k must be >= 1")
                sel = upto[-k:]
            elif "window_s" in rule:
                w = float(rule["window_s"])
                lo = self.t - w
                cur_at_lo = None
                sel = []
                for v in upto:
                    if v.ts <= lo:
                        cur_at_lo = v
                    else:
                        sel.append(v)
                if cur_at_lo is not None:
                    sel = [cur_at_lo] + sel
            elif "fixed" in rule:
                fx = set(rule["fixed"])
                sel = [v for v in upto if v.vid in fx]
            elif "any" in rule:
                sel = upto
            else:
                raise F1Error(f"unknown Gamma rule for {item}: {rule}")
            out[item] = [v.vid for v in reversed(sel)]
        return out

    def contains(self, h: History, cut: Cut) -> bool:
        al = self.allowed(h)
        return all(cut.get(i) in set(al[i]) for i in h.item_names())
