"""Run context: merged configuration, paths, workload factory, history cache, checkpointed job pool."""
from __future__ import annotations

import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from ..common.loader import Loader
from ..common.util import CAS, F1Error, append_jsonl, load_yaml, read_jsonl, sha256_obj

REPO_ROOT = Path(__file__).resolve().parents[3]


def load_config(path: str | Path) -> dict:
    path = Path(path).resolve()
    cfg = load_yaml(path)
    base = path.parent
    merged: dict = {}
    for inc in cfg.get("include", []) or []:
        sub = load_yaml(base / inc)
        for k, v in sub.items():
            merged[k] = v
    for k, v in cfg.items():
        if k != "include":
            merged[k] = v
    root = Path(merged.get("root") or REPO_ROOT)
    merged["root"] = str(root)
    paths = merged.setdefault("paths", {})
    for k, v in list(paths.items()):
        if isinstance(v, str) and not os.path.isabs(v):
            paths[k] = str((root / v).resolve())
    tools = merged.get("tools", {})
    for t in tools.values():
        if isinstance(t, dict) and "path" in t and not os.path.isabs(t["path"]):
            t["path"] = str((root / t["path"]).resolve())
    merged["config_path"] = str(path)
    merged["config_sha256"] = sha256_obj({k: v for k, v in merged.items() if k not in ("config_path",)})
    return merged


class RunContext:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        p = cfg["paths"]
        self.run_dir = Path(p["outputs"]) / cfg["run_name"]
        self.raw = self.run_dir / "raw"
        self.processed = self.run_dir / "processed"
        self.stats_dir = self.run_dir / "statistics"
        self.manifests = self.run_dir / "manifests"
        self.logs = self.run_dir / "logs"
        self.oracle_dir = self.run_dir / "oracle"
        self.stages = self.run_dir / "stages"
        self.figures = Path(p.get("figures", self.run_dir / "figures"))
        self.tables = Path(p.get("tables", self.run_dir / "tables"))
        for d in (self.raw, self.processed, self.stats_dir, self.manifests, self.logs, self.stages):
            d.mkdir(parents=True, exist_ok=True)
        self.cas = CAS(Path(p["data"]) / "cas")
        self.data_root = Path(p["data"])
        self.work = Path(p["work"])
        self.work.mkdir(parents=True, exist_ok=True)
        self._loader = None
        self._wl: dict[str, object] = {}
        self._hist: dict[tuple[str, str], object] = {}

    @property
    def loader(self) -> Loader:
        if self._loader is None:
            self._loader = Loader(self.cas)
        return self._loader

    def log(self, msg: str) -> None:
        line = f"[{time.strftime('%H:%M:%S')}] {msg}"
        print(line, flush=True)
        with open(self.logs / "run.log", "a") as f:
            f.write(line + "\n")

    def workload(self, name: str):
        if name not in self._wl:
            if name == "synthetic":
                from ..workloads.synthetic import SyntheticWorkload
                self._wl[name] = SyntheticWorkload(self.cfg, self.cas, self.data_root)
            elif name == "A":
                from ..workloads.real import WorkloadA
                self._wl[name] = WorkloadA(self.cfg, self.cas, self.data_root)
            elif name == "B":
                from ..workloads.real import WorkloadB
                self._wl[name] = WorkloadB(self.cfg, self.cas, self.data_root)
            else:
                raise F1Error(f"unknown workload {name}")
        return self._wl[name]

    def history(self, wl_name: str, cluster: str):
        key = (wl_name, cluster)
        if key not in self._hist:
            from ..core.history import History, read_history_parquet
            rows = read_history_parquet(self.raw / f"history_{wl_name}.parquet").get(cluster)
            if rows is None:
                raise F1Error(f"no history for {wl_name}/{cluster}")
            self._hist[key] = History.from_rows(rows)
        return self._hist[key]

    def cluster_spec(self, wl_name: str, cluster: str):
        for c in self.workload(wl_name).clusters():
            if c.name == cluster:
                return c
        raise F1Error(f"unknown cluster {wl_name}/{cluster}")

    def stage_done(self, name: str) -> bool:
        return (self.stages / f"{name}.done").exists()

    def mark_done(self, name: str, info: dict) -> None:
        from ..common.util import atomic_write_json, now_iso
        atomic_write_json(self.stages / f"{name}.done", {"finished_at": now_iso(), **info})


# ---------------------------------------------------------------------------------------------
# checkpointed, adaptive process pool
# ---------------------------------------------------------------------------------------------
_WORKER_CTX: RunContext | None = None


def _worker_init(config_path: str, role: str) -> None:
    global _WORKER_CTX
    from ..common.firewall import install_role_guard
    cfg = load_config(config_path)
    ctx = RunContext(cfg)
    install_role_guard(role, ctx.oracle_dir)
    import f1.producers.rustsec, f1.producers.license_spdx, f1.producers.dq, f1.producers.synthetic  # noqa: F401 (feature registry)
    import f1.contracts.features_generic  # noqa: F401
    from ..producers.dq import set_threads
    set_threads(1)  # default: one compute thread per worker; jobs raise it to their class allowance explicitly
    _WORKER_CTX = ctx


def _worker_call(fn_path: str, job: dict) -> dict:
    import importlib
    mod, fn = fn_path.rsplit(".", 1)
    f = getattr(importlib.import_module(mod), fn)
    try:
        return f(_WORKER_CTX, job)
    except Exception as e:  # recorded per job; the stage decides whether failures are fatal
        import traceback
        return {"key": job["key"], "status": "harness_error", "error": f"{type(e).__name__}: {e}",
                "traceback": traceback.format_exc()[-3000:]}


CLASS_ORDER = ("HEAVY_CPU_RAM_IO", "MEDIUM_CPU", "LIGHT_CPU")  # longest-processing-time first


def class_limits(srv: dict) -> dict:
    """Safe worker limit per resource class: min(W_CPU, W_RAM, W_IO, cap) (T-E)."""
    out = {}
    for cls, prof in srv["classes"].items():
        w_cpu = int(float(srv["cpu_budget_cores"]) // float(prof["cpu"]))
        w_ram = int(float(srv["ram_budget_gb"]) // float(prof["ram_gb"]))
        w_io = int(float(srv["io_budget_mb_s"]) // float(prof["io_mb_s"])) if float(prof.get("io_mb_s", 0)) > 0 else 10 ** 9
        out[cls] = max(1, min(w_cpu, w_ram, w_io, int(srv["max_workers"])))
    return out


class ResourceBudget:
    """Admission control for concurrent jobs: the sum of reservations never exceeds the CPU/RAM/IO budgets."""

    def __init__(self, srv: dict):
        self.srv = srv
        self.cap = {"cpu": float(srv["cpu_budget_cores"]), "ram": float(srv["ram_budget_gb"]), "io": float(srv["io_budget_mb_s"])}
        self.used = {"cpu": 0.0, "ram": 0.0, "io": 0.0}
        self.prof = {c: dict(p) for c, p in srv["classes"].items()}
        self.limits = class_limits(srv)
        self.running = {c: 0 for c in self.prof}
        self.peak = {"cpu": 0.0, "ram": 0.0, "io": 0.0, "jobs": 0}

    def need(self, cls: str) -> dict:
        p = self.prof[cls]
        return {"cpu": float(p["cpu"]), "ram": float(p["ram_gb"]), "io": float(p.get("io_mb_s", 0))}

    def fits(self, cls: str) -> bool:
        if self.running[cls] >= self.limits[cls]:
            return False
        n = self.need(cls)
        if sum(self.running.values()) == 0:
            return True  # a single job always runs (budget smaller than one job only serialises)
        return all(self.used[k] + n[k] <= self.cap[k] + 1e-9 for k in n)

    def acquire(self, cls: str) -> None:
        n = self.need(cls)
        for k in n:
            self.used[k] += n[k]
            self.peak[k] = max(self.peak[k], self.used[k])
        self.running[cls] += 1
        self.peak["jobs"] = max(self.peak["jobs"], sum(self.running.values()))

    def release(self, cls: str, measured_rss_kb: int = 0) -> None:
        n = self.need(cls)
        for k in n:
            self.used[k] = max(0.0, self.used[k] - n[k])
        self.running[cls] -= 1
        if measured_rss_kb:
            gb = measured_rss_kb / 1024 / 1024
            if gb * 1.2 > self.prof[cls]["ram_gb"]:   # adapt upward only (never optimistic)
                self.prof[cls]["ram_gb"] = round(gb * 1.2, 3)
                self.limits = class_limits({**self.srv, "classes": self.prof})


def _write_status(ctx: RunContext, label: str, budget: ResourceBudget, done: int, total: int, force=False, _last=[0.0]) -> None:
    now = time.time()
    if not force and now - _last[0] < 0.5:
        return
    _last[0] = now
    import json as _json
    tmp = ctx.run_dir / ".worker_status.tmp"
    tmp.write_text(_json.dumps({"t": now, "label": label, "running": budget.running, "used": budget.used,
                                "done": done, "total": total}))
    os.replace(tmp, ctx.run_dir / "worker_status.json")


def run_jobs(ctx: RunContext, jobs: list[dict], fn_path: str, results_path: Path, role: str, label: str) -> list[dict]:
    """Resource-aware, checkpointed execution. Each job carries 'rclass' (LIGHT_CPU | MEDIUM_CPU | HEAVY_CPU_RAM_IO).
    Jobs are dispatched heavy-first (LPT) whenever their reservation fits the CPU/RAM/IO budget and the class limit.
    Completed keys are skipped on resume; harness errors are retried; producer failures are kept as results."""
    srv = ctx.cfg["server"]
    done = {r["key"] for r in read_jsonl(results_path) if r.get("status") != "harness_error"}
    todo = [j for j in jobs if j["key"] not in done]
    ctx.log(f"[{label}] {len(jobs)} jobs, {len(done)} already done, {len(todo)} to run; class limits {class_limits(srv)}")
    if not todo:
        return _latest(results_path)
    from collections import deque
    queues = {c: deque() for c in srv["classes"]}
    for j in todo:
        queues[j.get("rclass", "LIGHT_CPU")].append(j)
    budget = ResourceBudget(srv)
    abort = os.environ.get("F1_TEST_ABORT_AFTER_JOBS", "")  # engineering test hook "label:N" (simulated crash)
    n_done, t0 = 0, time.time()
    if int(srv["max_workers"]) == 1 and srv.get("inline_when_single", False):
        _worker_init(ctx.cfg["config_path"], role)
        for cls in CLASS_ORDER:
            while queues.get(cls):
                j = queues[cls].popleft()
                budget.acquire(cls)
                r = _worker_call(fn_path, j)
                budget.release(cls)
                append_jsonl(results_path, r)
                n_done += 1
                if abort.startswith(label + ":") and n_done >= int(abort.split(":")[1]):
                    raise F1Error(f"[test-hook] simulated crash in {label} after {abort.split(':')[1]} jobs")
        return _latest(results_path)
    from concurrent.futures import FIRST_COMPLETED, wait
    with ProcessPoolExecutor(max_workers=int(srv["max_workers"]), initializer=_worker_init,
                             initargs=(ctx.cfg["config_path"], role)) as ex:
        running: dict = {}
        last_log = time.time()
        while any(queues.values()) or running:
            dispatched = True
            while dispatched:
                dispatched = False
                for cls in CLASS_ORDER:
                    if queues.get(cls) and budget.fits(cls):
                        j = queues[cls].popleft()
                        budget.acquire(cls)
                        running[ex.submit(_worker_call, fn_path, j)] = cls
                        dispatched = True
                        break
            _write_status(ctx, label, budget, n_done, len(todo))
            fin, _ = wait(list(running), return_when=FIRST_COMPLETED)
            for f in fin:
                cls = running.pop(f)
                r = f.result()
                rss = int((r.get("run") or {}).get("max_rss_kb", 0) or r.get("max_rss_kb_self", 0) or 0)
                budget.release(cls, rss)
                append_jsonl(results_path, r)
                n_done += 1
                if abort.startswith(label + ":") and n_done >= int(abort.split(":")[1]):
                    raise F1Error(f"[test-hook] simulated crash in {label} after {abort.split(':')[1]} jobs")
            if time.time() - last_log > 30:
                last_log = time.time()
                ctx.log(f"[{label}] {n_done}/{len(todo)} done ({n_done / max(1e-9, time.time() - t0):.2f} jobs/s, "
                        f"running={budget.running}, used={ {k: round(v, 1) for k, v in budget.used.items()} })")
        _write_status(ctx, label, budget, n_done, len(todo), force=True)
    ctx.log(f"[{label}] finished {n_done} jobs; peak reservation {budget.peak}")
    return _latest(results_path)


def _latest(results_path: Path) -> list[dict]:
    """Last record per key (a retried harness error is superseded by its retry)."""
    last: dict = {}
    for r in read_jsonl(results_path):
        last[r["key"]] = r
    return list(last.values())
