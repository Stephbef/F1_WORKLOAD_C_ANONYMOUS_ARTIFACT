"""Pipeline stages, evaluation side: admission (role=admission), seal, oracle (role=oracle)."""
from __future__ import annotations

import math
import random
import resource
import time
from pathlib import Path

from ..admission.engine import CLASSES, AdmissionEngine, effective_contracts
from ..catalog.artifact import Catalog
from ..common.firewall import FirewallViolation, seal, verify_seal
from ..common.util import F1Error, atomic_write_json, read_json, read_jsonl, sha256_obj, write_jsonl
from ..contracts.lang import Evaluator
from ..core.gamma import Gamma
from ..core.history import cut_key
from ..repair.solvers import ilp_available, opt_bnb, opt_bruteforce, opt_ilp
from .context import RunContext, run_jobs


# ---------------------------------------------------------------------------------------------
# admission (executed in a separate process with the admission role guard installed)
# ---------------------------------------------------------------------------------------------
def _cluster_artifacts(ctx: RunContext, wl: str, cluster: str) -> dict:
    return {a.artifact_id: a for a in Catalog(ctx.raw / "catalog.jsonl").load() if a.workload == wl and a.cluster == cluster}


def _sampled(key: str, fraction: float, seed) -> bool:
    if fraction >= 1.0:
        return True
    if fraction <= 0.0:
        return False
    return int(sha256_obj([seed, key])[:8], 16) / 0xFFFFFFFF < fraction


def job_admission(ctx: RunContext, job: dict) -> dict:
    """Admission-side evaluation of one cluster (role=admission: producers cannot be executed here).

    Unary cost model (primary, order-independent): one content-addressed parse cache per class (immutable snapshots
    only) + a FRESH evaluator per pair (no decision/feature reuse across pairs); parse-miss CPU is amortised evenly
    over the class's evaluations. A seeded sample of fully cold evaluations (fresh cache) is kept as sensitivity.
    Joint/repair: warm steady-state service per class; repair fast path (no solver when a witness exists); costs split
    into shared decision cost (contracts at the current cut, needed by F1 and by current-cut repair alike) and
    F1-specific cost (extra witness search + repair optimisation)."""
    from ..common.loader import Loader
    from ..producers.dq import set_threads
    set_threads(int(job.get("threads", 1)))
    wl, cluster = job["wl"], job["cluster"]
    h = ctx.history(wl, cluster)
    arts = _cluster_artifacts(ctx, wl, cluster)
    out_dir = ctx.raw / "admission"
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{wl}__{cluster}"
    rcfg = ctx.cfg["repair"]
    seed = ctx.cfg["seed"]
    cold_frac = float(ctx.cfg.get("costs", {}).get("cold_sample_fraction", 0.02))
    engines, journals, unary_loaders = {}, {}, {}
    for cls in CLASSES:
        jp = out_dir / f"{stem}.{cls}.journal.jsonl.tmp"
        if jp.exists():
            jp.unlink()
        journals[cls] = jp
        engines[cls] = AdmissionEngine(h, Evaluator(Loader(ctx.cas)), journal_path=jp)
        unary_loaders[cls] = Loader(ctx.cas)
    # ---- unary ----
    urows = []
    cluster_pairs = sorted((p for p in read_jsonl(ctx.raw / "unary_pairs.jsonl") if p["wl"] == wl and p["cluster"] == cluster),
                           key=lambda p: (p["t"], p["pair_id"]))
    n_eval = {cls: 0 for cls in CLASSES}
    for p in cluster_pairs:
        a = arts[p["artifact_id"]]
        row = {"pair_id": p["pair_id"], "artifact_id": a.artifact_id}
        for cls in CLASSES:
            eng = engines[cls]
            e, _ = eng.kappa_eff(a, cls, p["cut"])                     # warm decision (journal-free)
            L = unary_loaders[cls]
            miss0 = L.stats["miss_cpu_s"]
            fresh = AdmissionEngine(h, Evaluator(L))
            t1 = time.process_time()
            ec, esc = fresh.kappa_eff(a, cls, p["cut"])
            check = time.process_time() - t1
            miss = L.stats["miss_cpu_s"] - miss0
            if ec != e:
                raise F1Error(f"cache-dependent contract evaluation for {a.artifact_id} {cls} (warm {e} vs fresh {ec})")
            n_eval[cls] += 1
            r, _ = eng.kappa_raw(a, cls, p["cut"])                       # diagnostic only (not charged)
            row[f"{cls}_eff"], row[f"{cls}_raw"] = e, r
            row[f"{cls}_eval_compute_s"] = max(0.0, esc - miss)          # evaluation excluding parse misses
            row[f"{cls}_check_compute_s"] = max(0.0, check - miss)
            row[f"{cls}_fallback"] = effective_contracts(a, cls)[1]
            if _sampled(p["pair_id"] + cls, cold_frac, seed):
                cold = AdmissionEngine(h, Evaluator(Loader(ctx.cas, enabled=False)))
                t2 = time.process_time()
                ecold, ecs = cold.kappa_eff(a, cls, p["cut"])
                if ecold != e:
                    raise F1Error(f"uncached evaluation differs for {a.artifact_id} {cls}")
                row[f"{cls}_eval_cold_s"] = ecs
        row["B1"] = all(a.birth_revs.get(i) == p["revs"].get(i) for i in a.read_set)
        row["B2"] = row["K0_raw"]
        urows.append(row)
    amort = {cls: (unary_loaders[cls].stats["miss_cpu_s"] / n_eval[cls]) if n_eval[cls] else 0.0 for cls in CLASSES}
    for row in urows:
        for cls in CLASSES:
            row[f"{cls}_parse_amortised_s"] = amort[cls]
            row[f"{cls}_eval_s"] = row[f"{cls}_eval_compute_s"] + amort[cls]
            row[f"{cls}_check_s"] = row[f"{cls}_check_compute_s"] + amort[cls]
    # ---- joint + repair ----
    jrows, rrows = [], []
    for e in read_jsonl(ctx.raw / "joint_events.jsonl"):
        if e["wl"] != wl or e["cluster"] != cluster:
            continue
        R = [arts[i] for i in e["R"]]
        g = Gamma.from_json(e["gamma"])
        allowed = g.allowed(h)
        cands = list(h.enumerate_cuts(allowed))
        costs = [a.cost_s for a in R]
        jrow = {"event_id": e["event_id"], "n_cuts": len(cands)}
        for cls in CLASSES:
            eng = engines[cls]
            st = eng.ev.stats
            # (1) SHARED decision cost: contracts at the current (freshest) cut — needed by F1 and by current-cut repair
            ev0, t0 = st["uncached_seconds"], time.process_time()
            cur_sat = [eng.kappa_eff(a, cls, cands[0])[0] for a in R] if cands else [False] * len(R)
            shared_total, shared_eval = time.process_time() - t0, st["uncached_seconds"] - ev0
            # (2) F1-specific: witness search beyond the current cut
            ev1, t1 = st["uncached_seconds"], time.process_time()
            rec = eng.admit(R, cls, g, event_id=e["event_id"], t=e["t"])
            adm_total, adm_eval = time.process_time() - t1, st["uncached_seconds"] - ev1
            fps = [sorted(set().union(*[set(c.footprint) for c in effective_contracts(a, cls)[0]])) for a in R]

            def satf(i, cut, _R=R, _cls=cls, _eng=eng):
                v, _ = _eng.kappa_eff(_R[i], _cls, cut)
                return v
            # (3) repair: FAST PATH when a witness exists (Q = empty, solver not invoked)
            if rec["witness"] is not None:
                res = {"opt_cost": 0.0, "opt_cut": rec["witness"], "Q": [], "nodes": 0, "feasible": True}
                sol_total = sol_eval = 0.0
                solver_invoked = False
            else:
                ev2, t2 = st["uncached_seconds"], time.process_time()
                res = opt_bnb(h, allowed, costs, satf, fps)
                sol_total, sol_eval = time.process_time() - t2, st["uncached_seconds"] - ev2
                solver_invoked = True
            # (4) diagnostics and validation (never charged)
            sat = [[eng.kappa_eff(a, cls, c)[0] for c in cands] for a in R]
            unary = [any(x) for x in sat]
            widx = next((k for k in range(len(cands)) if all(x[k] for x in sat)), None)
            if (rec["witness"] is None) != (widx is None) or (widx is not None and cut_key(rec["witness"]) != cut_key(cands[widx])):
                raise F1Error(f"admission/witness-vector disagreement on {e['event_id']} {cls}")
            jrow[f"{cls}_unary"] = unary
            jrow[f"{cls}_admitted"] = widx is not None
            jrow[f"{cls}_witness"] = rec["witness"]
            jrow[f"{cls}_witness_idx"] = widx
            jrow[f"{cls}_K3_at_witness"] = ([engines["K3"].kappa_eff(a, "K3", rec["witness"])[0] for a in R]
                                            if rec["witness"] is not None else None)
            cur_cost = sum(costs[i] for i in range(len(R)) if not cur_sat[i]) if cands else math.inf
            rrow = {"event_id": e["event_id"], "cls": cls, "opt_cost": res["opt_cost"], "opt_Q": res["Q"],
                    "opt_cut": res["opt_cut"], "nodes": res["nodes"], "feasible": res["feasible"],
                    "solver_invoked": solver_invoked, "recompute_all": sum(costs), "n_cuts": len(cands),
                    "n_artifacts": len(R), "current_cut": cands[0] if cands else None, "current_cut_cost": cur_cost,
                    # exclusive CPU components (sum = everything charged to the F1 path)
                    "shared_decision_s": shared_total,
                    "contract_eval_s": shared_eval + adm_eval + sol_eval,
                    "admission_excl_s": max(0.0, adm_total - adm_eval),
                    "solver_excl_s": max(0.0, sol_total - sol_eval),
                    "f1_specific_s": adm_total + sol_total,
                    "witness_s": adm_total, "solver_s": sol_total}
            # validation of the fast path / exact solver (not charged)
            if len(cands) <= int(rcfg["bruteforce_crosscheck_max_cuts"]):
                bf = opt_bruteforce(h, allowed, costs, satf)
                rrow["bruteforce_cost"] = bf["opt_cost"]
                rrow["bruteforce_agrees"] = (bf["opt_cost"] == res["opt_cost"]) or \
                    (math.isfinite(bf["opt_cost"]) and abs(bf["opt_cost"] - res["opt_cost"]) <= 1e-9)
                if not rrow["bruteforce_agrees"]:
                    raise F1Error(f"repair result disagrees with brute force on {e['event_id']} {cls}")
            if (rcfg.get("ilp_crosscheck") and ilp_available() and len(cands) <= int(rcfg["ilp_crosscheck_max_cuts"])
                    and _sampled(e["event_id"] + cls, float(rcfg.get("ilp_crosscheck_fraction", 1.0)), seed)):
                il = opt_ilp(h, allowed, costs, satf, fps)
                rrow["ilp_cost"] = il["opt_cost"]
                rrow["ilp_agrees"] = abs((il["opt_cost"] if math.isfinite(il["opt_cost"]) else 1e300) -
                                         (res["opt_cost"] if math.isfinite(res["opt_cost"]) else 1e300)) <= 1e-6
                if not rrow["ilp_agrees"]:
                    raise F1Error(f"ILP solver disagrees with exact solver on {e['event_id']} {cls}")
            rrows.append(rrow)
        jrows.append(jrow)
    write_jsonl(out_dir / f"{stem}.unary.jsonl", urows)
    write_jsonl(out_dir / f"{stem}.joint.jsonl", jrows)
    write_jsonl(out_dir / f"{stem}.repair.jsonl", rrows)
    for cls, jp in journals.items():
        final = out_dir / f"{stem}.{cls}.journal.jsonl"
        if jp.exists():
            jp.replace(final)
        else:
            final.write_text("")
    return {"key": job["key"], "status": "ok", "unary": len(urows), "joint": len(jrows), "repair": len(rrows),
            "evaluator": {cls: e.ev.stats for cls, e in engines.items()},
            "parse_cache": {cls: unary_loaders[cls].stats for cls in CLASSES},
            "history_versions": sum(len(v) for v in h.items.values()), "artifacts": len(arts),
            "max_rss_kb_self": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}


def stage_admission(ctx: RunContext) -> dict:
    jobs = []
    for wl_name in ctx.cfg["workloads"]:
        wlo = ctx.workload(wl_name)
        for c in wlo.clusters():
            rc = wlo.admission_class(c)
            jobs.append({"key": f"{wl_name}__{c.name}", "wl": wl_name, "cluster": c.name, "rclass": rc,
                         "threads": int(ctx.cfg["server"]["classes"][rc].get("threads", 1))})
    res = run_jobs(ctx, jobs, "f1.runner.stages_eval.job_admission", ctx.raw / "admission_jobs.jsonl", "admission", "admission")
    bad = [r for r in res if r.get("status") != "ok"]
    if bad:
        raise F1Error(f"admission failed for {[b['key'] for b in bad]}: {bad[0].get('error')}")
    merged = {"unary": [], "joint": [], "repair": []}
    for j in jobs:
        for kind in merged:
            merged[kind] += list(read_jsonl(ctx.raw / "admission" / f"{j['key']}.{kind}.jsonl"))
    write_jsonl(ctx.raw / "unary_admission.jsonl", merged["unary"])
    write_jsonl(ctx.raw / "joint_admission.jsonl", merged["joint"])
    write_jsonl(ctx.raw / "repair.jsonl", merged["repair"])
    return {k: len(v) for k, v in merged.items()}


def admission_side_files(ctx: RunContext) -> list[Path]:
    files = [ctx.raw / n for n in ("catalog.jsonl", "production_runs.jsonl", "unary_pairs.jsonl", "joint_events.jsonl",
                                   "unary_admission.jsonl", "joint_admission.jsonl", "repair.jsonl")]
    files += sorted((ctx.raw / "admission").glob("*.journal.jsonl"))
    for wl in ctx.cfg["workloads"]:
        files.append(ctx.raw / f"history_{wl}.parquet")
    return files


def stage_seal(ctx: RunContext) -> dict:
    sp = ctx.run_dir / "SEAL.json"
    if sp.exists():
        rec = verify_seal(sp)
        return {"resumed": True, "files": len(rec["files"])}
    rec = seal(admission_side_files(ctx), sp, extra={"config_sha256": ctx.cfg["config_sha256"]})
    return {"files": len(rec["files"])}


# ---------------------------------------------------------------------------------------------
# oracle (executed in a separate process with role=oracle, only after the seal verifies)
# ---------------------------------------------------------------------------------------------
def job_oracle(ctx: RunContext, job: dict) -> dict:
    from .stages_prod import _producers
    h = ctx.history(job["wl"], job["cluster"])
    p = _producers(ctx, job["wl"], job["cluster"])[job["pid"]]
    if p.version_digest() != job["version"]:
        return {"key": job["key"], "status": "version_mismatch", "error": f"{p.version_digest()} != {job['version']}"}
    res, out = p.execute(job["cut"], h, ctx.cas, ctx.work / "oracle_sandboxes")
    return {"key": job["key"], "rkey": job["rkey"], "rep": job["rep"], "wl": job["wl"], "pid": job["pid"],
            "status": res.status if out is not None else "error", "output": out, "run": res.record()}


def stage_oracle(ctx: RunContext) -> dict:
    verify_seal(ctx.run_dir / "SEAL.json")
    ctx.oracle_dir.mkdir(parents=True, exist_ok=True)
    from .stages_prod import _producers
    arts = {a.artifact_id: a for a in Catalog(ctx.raw / "catalog.jsonl").load()}

    def rkey(a, cut):
        h = ctx.history(a.workload, a.cluster)
        p = _producers(ctx, a.workload, a.cluster)[a.producer_id]
        return sha256_obj([a.workload, a.cluster, a.producer_id, a.run["version"], p.birth_refs(cut, h)])

    need: dict[str, dict] = {}
    requested = [0]
    req_by_source = {}

    def want(a, cut):
        k = rkey(a, cut)
        requested[0] += 1
        if k not in need:
            p = _producers(ctx, a.workload, a.cluster)[a.producer_id]
            need[k] = {"key": f"{k}:0", "rkey": k, "rep": 0, "wl": a.workload, "cluster": a.cluster,
                       "pid": a.producer_id, "cut": cut, "version": a.run["version"],
                       "rclass": getattr(p, "resource_class", "LIGHT_CPU")}
        return k

    pair_keys, event_keys = {}, {}
    r0 = requested[0]
    for p in read_jsonl(ctx.raw / "unary_pairs.jsonl"):
        pair_keys[p["pair_id"]] = want(arts[p["artifact_id"]], p["cut"])
    req_by_source["unary_pairs"] = requested[0] - r0
    r0 = requested[0]
    for e in read_jsonl(ctx.raw / "joint_events.jsonl"):
        h = ctx.history(e["wl"], e["cluster"])
        cands = list(h.enumerate_cuts(Gamma.from_json(e["gamma"]).allowed(h)))
        event_keys[e["event_id"]] = [[want(arts[i], c) for c in cands] for i in e["R"]]
    req_by_source["joint_candidate_cuts"] = requested[0] - r0
    r0 = requested[0]
    # determinism protocol: extra replicas at every birth input + a seeded sample of oracle inputs
    det = ctx.cfg["determinism"]
    jobs = list(need.values())
    births = {}
    for a in arts.values():
        k = want(a, a.birth_cut)
        births[a.run["production_key"]] = k
    req_by_source["artifact_birth_cuts"] = requested[0] - r0
    jobs = list(need.values())
    rng = random.Random(int(ctx.cfg["seed"]))
    sample = rng.sample(sorted(need), max(1, int(len(need) * float(det["sample_fraction"])))) if need else []
    extra = []
    for k in sorted(set(births.values())):
        for r in range(1, int(det["birth_replicas"]) + 1):
            extra.append(dict(need[k], key=f"{k}:{r}", rep=r))
    for k in sample:
        extra.append(dict(need[k], key=f"{k}:s", rep="s"))
    from collections import Counter
    atomic_write_json(ctx.oracle_dir / "oracle_requests.json", {
        "requested_instances": requested[0], "requested_by_source": req_by_source, "unique_inputs": len(need),
        "dedup_hits": requested[0] - len(need), "replica_jobs": sum(1 for x in extra if x["rep"] != "s"),
        "sample_jobs": sum(1 for x in extra if x["rep"] == "s"),
        "jobs_total": len(jobs) + len(extra),
        "jobs_by_workload": dict(Counter(x["wl"] for x in jobs + extra)),
        "jobs_by_producer": dict(Counter(x["pid"] for x in jobs + extra))})
    runs = run_jobs(ctx, jobs + extra, "f1.runner.stages_eval.job_oracle", ctx.oracle_dir / "oracle_runs.jsonl", "oracle", "oracle")
    by = {}
    for r in runs:
        by.setdefault(r["rkey"] if "rkey" in r else r["key"].split(":")[0], {})[str(r.get("rep", 0))] = r
    from ..common.util import canonical_json
    nondet = {}
    for k, reps in by.items():
        outs = {rep: canonical_json(r.get("output")) for rep, r in reps.items() if r.get("status") == "ok"}
        nondet[k] = len(set(outs.values())) > 1
    from .stages_prod import _producers as _pp

    def use(a, k):
        r = by.get(k, {}).get("0")
        if r is None or r.get("status") != "ok":
            return None
        p = _pp(ctx, a.workload, a.cluster)[a.producer_id]
        return bool(p.equivalent(a.artifact_type, p.project(r["output"], a.artifact_type), a.value))

    urows = []
    for p in read_jsonl(ctx.raw / "unary_pairs.jsonl"):
        a = arts[p["artifact_id"]]
        k = pair_keys[p["pair_id"]]
        orun = by.get(k, {}).get("0", {})
        ov = None
        if orun.get("status") == "ok":
            ov = _pp(ctx, a.workload, a.cluster)[a.producer_id].project(orun["output"], a.artifact_type)
        urows.append({"pair_id": p["pair_id"], "use": use(a, k), "oracle_nondeterministic": nondet.get(k, False),
                      "birth_nondeterministic": nondet.get(births[a.run["production_key"]], False),
                      "oracle_status": orun.get("status"), "oracle_value": ov,
                      "oracle_hidden_reads": (orun.get("run") or {}).get("hidden_reads", []),
                      "oracle_net_attempts": (orun.get("run") or {}).get("net_attempts", 0)})
    jrows = []
    for e in read_jsonl(ctx.raw / "joint_events.jsonl"):
        R = [arts[i] for i in e["R"]]
        U = [[use(a, k) for k in ks] for a, ks in zip(R, event_keys[e["event_id"]])]
        complete = all(u is not None for row in U for u in row)
        n = len(U[0]) if U else 0
        W = complete and any(all(U[i][c] for i in range(len(R))) for c in range(n))
        costs = [a.cost_s for a in R]
        opt_o = min((sum(costs[i] for i in range(len(R)) if not U[i][c]) for c in range(n)), default=math.inf) if complete else None
        jrows.append({"event_id": e["event_id"], "complete": complete, "oracle_unary": [any(bool(x) for x in row) for row in U],
                      "oracle_use_matrix": ["".join("?" if x is None else ("1" if x else "0") for x in row) for row in U],
                      "oracle_W_nonempty": W if complete else None, "oracle_opt_cost": opt_o,
                      "nondeterministic": any(nondet.get(k, False) for ks in event_keys[e["event_id"]] for k in ks)})
    write_jsonl(ctx.oracle_dir / "unary_oracle.jsonl", urows)
    write_jsonl(ctx.oracle_dir / "joint_oracle.jsonl", jrows)
    atomic_write_json(ctx.oracle_dir / "determinism.json", {
        "inputs_checked": len(by), "nondeterministic_inputs": sorted(k for k, v in nondet.items() if v),
        "birth_inputs": len(set(births.values()))})
    return {"oracle_inputs": len(need), "replica_jobs": len(extra), "unary": len(urows), "joint": len(jrows),
            "nondeterministic_inputs": sum(nondet.values())}
