"""Pipeline stages, reporting side: metrics (the ONLY join of admission and oracle outputs), statistics,
figures, tables, reproducibility report and run summary. No interpretation is generated: reports state
definitions, coverage, exclusions and the numbers computed from raw tables."""
from __future__ import annotations

import json
import math
import platform
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

from ..catalog.artifact import Catalog
from ..common.firewall import verify_seal
from ..common.util import atomic_write_json, now_iso, read_json, read_jsonl, sha256_file, write_jsonl
from ..statistics.disagreements import joint_disagreements, summarize_soundness, unary_disagreements
from ..statistics.metrics import CLASSES, joint_metrics, repair_metrics, scalability_summary, unary_metrics
from .context import RunContext

METRIC_DEFINITIONS = {
    "M1": "P[kappa_hash(r,c)=0 AND OracleUse(r,c)=1] over test pairs (r, c-hat_t); also P[OracleUse=1 | kappa_hash=0] and the version-pinning (B1) variant.",
    "M2": "P[TTL_tau(r,c)=1 AND OracleUse(r,c)=0]; TTL_tau = [age <= tau]; tau* chosen on validation pairs maximising recall - false-admission rate; full curve reported.",
    "M3": "Per class K in {K0..K3}, kappa_eff = K OR K0: recall P[kappa_eff=1|Use=1], unsafe P[kappa_eff=1 AND Use=0], conditional P[Use=0|kappa_eff=1], evaluation cost (uncached time with per-class caches; memo hits within a class cost 0), metadata size, disclosure metrics; G1 net benefit = avoided producer CPU (true reuse only) - contract evaluation time.",
    "dRecall/dNB": "Incremental over K0 (kappa_eff^K = K OR K0): dRecall = recall(K) - recall(K0) per artifact over usable pairs; dNB per pair = [K0 rejects AND K accepts AND OracleUse]*cost_r - (eval_K - eval_K0) - (admission overhead_K - admission overhead_K0), CPU seconds measured COLD (fresh caches per evaluation: order-independent, conservative); a warm steady-state cache variant is reported as sensitivity; reuse K0 already provides is never credited to K.",
    "M4": "Per consumer event: all artifacts individually acceptable somewhere in Gamma AND no common witness. M4_oracle uses OracleUse; naive composition error = all unary-contract checks pass AND no oracle witness. PRIMARY = primary_async_joint (no policy grace); secondary_policy_grace and control_release are sensitivity/control only.",
    "M5": "raw: 1 - OPT_kappa/Cost_baseline; net: (Cost_baseline - OPT_kappa - contract_eval - admission - solver)/Cost_baseline with exclusive CPU components; baselines = recompute-all and current-cut repair (the current-cut baseline is not charged for its own contract checks: conservative against OPT); repair overheads use a warm steady-state service model (per-cluster caches, chronological events).",
    "U1-U4": "unsafe admissions classified as U4 nondeterminism > U3 hidden context > U1 implementation mismatch (transparent reference also accepts) > U2 missing decision dependence (transparent reference rejects); see processed/disagreements.jsonl.",
    "aggregation": "macro = mean over units (artifacts or events) of per-unit rates; micro = pooled; 95% CI from a two-stage cluster bootstrap (clusters = repositories/datasets).",
}


def _write_table(path: Path, rows: list[dict]) -> None:
    import pyarrow as pa
    import pyarrow.parquet as pq
    if not rows:
        path.with_suffix(".empty").write_text("no rows\n")
        return
    norm = [{k: (json.dumps(v, sort_keys=True) if isinstance(v, (dict, list)) else v) for k, v in r.items()} for r in rows]
    keys = sorted({k for r in norm for k in r})
    pq.write_table(pa.table({k: [r.get(k) for r in norm] for k in keys}), path)


def stage_metrics(ctx: RunContext) -> dict:
    verify_seal(ctx.run_dir / "SEAL.json")
    arts = {a.artifact_id: a for a in Catalog(ctx.raw / "catalog.jsonl").load()}
    pairs = {p["pair_id"]: p for p in read_jsonl(ctx.raw / "unary_pairs.jsonl")}
    ua = {r["pair_id"]: r for r in read_jsonl(ctx.raw / "unary_admission.jsonl")}
    uo = {r["pair_id"]: r for r in read_jsonl(ctx.oracle_dir / "unary_oracle.jsonl")}
    excl = defaultdict(int)
    hidden_arts = {a.artifact_id for a in arts.values() if a.run.get("hidden_reads")}
    joined = []
    for pid, p in pairs.items():
        a = arts[p["artifact_id"]]
        o = uo.get(pid)
        if o is None or o["use"] is None:
            excl["oracle_failed_or_missing"] += 1
            continue
        if o["oracle_nondeterministic"] or o["birth_nondeterministic"]:
            excl["nondeterministic_producer_input"] += 1
            continue
        r = dict(ua[pid])
        r.update({"wl": p["wl"], "cluster": p["cluster"], "split": p["split"], "artifact_type": p["artifact_type"],
                  "age_s": p["age_s"], "use": o["use"], "cost_s": a.cost_s, "hidden_read_artifact": a.artifact_id in hidden_arts,
                  "oracle_hidden_reads": bool(o.get("oracle_hidden_reads"))})
        joined.append(r)
    _write_table(ctx.processed / "unary_joined.parquet", joined)
    events = {e["event_id"]: e for e in read_jsonl(ctx.raw / "joint_events.jsonl")}
    jo = {r["event_id"]: r for r in read_jsonl(ctx.oracle_dir / "joint_oracle.jsonl")}
    jj, rj = [], []
    for r in read_jsonl(ctx.raw / "joint_admission.jsonl"):
        e, o = events[r["event_id"]], jo.get(r["event_id"])
        if o is None or not o["complete"]:
            excl["joint_event_oracle_incomplete"] += 1
            continue
        if o["nondeterministic"]:
            excl["joint_event_nondeterministic"] += 1
            continue
        jj.append({**r, "wl": e["wl"], "cluster": e["cluster"], "scenario": e["scenario"], "cell": e["cell"],
                   "oracle_unary": o["oracle_unary"], "oracle_W_nonempty": o["oracle_W_nonempty"]})
    ok_events = {r["event_id"] for r in jj}
    for r in read_jsonl(ctx.raw / "repair.jsonl"):
        if r["event_id"] not in ok_events:
            continue
        e = events[r["event_id"]]
        rj.append({**r, "wl": e["wl"], "cluster": e["cluster"], "scenario": e["scenario"], "cell": e["cell"],
                   "oracle_opt_cost": jo[r["event_id"]]["oracle_opt_cost"]})
    _write_table(ctx.processed / "joint_joined.parquet", jj)
    _write_table(ctx.processed / "repair_joined.parquet", rj)
    # ---- U1–U4 disagreement classification (includes pairs excluded from primary metrics, e.g. U4) ----
    def h_content(a, cut):
        hh = ctx.history(a.workload, a.cluster)
        return {i: hh.content(cut, i) for i in a.read_set}
    udis = unary_disagreements(pairs, ua, {k: v for k, v in uo.items() if v.get("use") is not None}, arts, h_content)
    jad = {r["event_id"]: r for r in read_jsonl(ctx.raw / "joint_admission.jsonl")}
    jdis = joint_disagreements(events, jad, jo, arts)
    write_jsonl(ctx.processed / "disagreements.jsonl", udis + jdis)
    st = ctx.cfg["statistics"]
    B, seed = int(st["bootstrap"]), int(ctx.cfg["seed"])
    ttl = [h * 3600.0 for h in ctx.cfg["ttl_grid_hours"]]
    alpha = 1 - float(st.get("ci", 0.95))
    res = {"generated_at": now_iso(), "engineering_only": bool(ctx.cfg.get("engineering_only")),
           "definitions": METRIC_DEFINITIONS, "exclusions": dict(excl), "by_workload": {},
           "soundness": summarize_soundness(joined, udis, alpha),
           "disagreement_counts": {lab: sum(1 for x in udis + jdis if x["label"] == lab)
                                   for lab in ("U1", "U2", "U3", "U4", "UNDETERMINED")},
           "scalability": scalability_summary(rj)}
    for wl in ctx.cfg["workloads"]:
        w = {"unary": {}, "joint": None, "repair": None}
        types = sorted({r["artifact_type"] for r in joined if r["wl"] == wl})
        for typ in types:
            rows = [r for r in joined if r["wl"] == wl and r["artifact_type"] == typ]
            w["unary"][typ] = unary_metrics(rows, ttl, B, seed)
            clean = [r for r in rows if not r["hidden_read_artifact"]]
            if len(clean) != len(rows):
                w["unary"][typ + "__excluding_A3_violations"] = unary_metrics(clean, ttl, B, seed)
        jrows = [r for r in jj if r["wl"] == wl]
        if jrows:
            w["joint"] = joint_metrics(jrows, B, seed)
            w["repair"] = repair_metrics([r for r in rj if r["wl"] == wl], B, seed)
        res["by_workload"][wl] = w
    atomic_write_json(ctx.stats_dir / "metrics.json", res)
    return {"unary_joined": len(joined), "joint_joined": len(jj), "repair_joined": len(rj), "exclusions": dict(excl)}


def stage_ledger(ctx: RunContext) -> dict:
    """Canonical ledger with exact reconciliation assertions (fails the run on any mismatch)."""
    from ..statistics.ledger import write
    L = write(ctx.run_dir, ctx.cfg["workloads"])
    return {"artifacts": L["artifacts"]["total"], "oracle_runs": (L.get("oracle") or {}).get("runs_total"),
            "repair_rows": L["admission"]["repair_rows"], "solver_invocations": L["admission"]["solver_invocations"]}


def stage_statistics(ctx: RunContext) -> dict:
    """Per-cluster distributions (medians/quantiles) of the primary unary quantities."""
    import numpy as np
    import pyarrow.parquet as pq
    p = ctx.processed / "unary_joined.parquet"
    rows = pq.read_table(p).to_pylist() if p.exists() else []
    dist = {}
    by = defaultdict(list)
    for r in rows:
        if r["split"] == "test":
            by[(r["wl"], r["artifact_type"], r["cluster"])].append(r)
    for (wl, typ, cl), rs in sorted(by.items()):
        d = {"n": len(rs), "oracle_use_rate": float(np.mean([x["use"] for x in rs])),
             "M1": float(np.mean([(not x["K0_raw"]) and x["use"] for x in rs]))}
        for cls in CLASSES:
            useful = [x for x in rs if x["use"]]
            d[f"{cls}_recall"] = float(np.mean([x[f"{cls}_eff"] for x in useful])) if useful else None
            d[f"{cls}_unsafe"] = float(np.mean([x[f"{cls}_eff"] and not x["use"] for x in rs]))
        ages = [x["age_s"] / 86400 for x in rs]
        d["age_days_quantiles"] = {q: float(np.quantile(ages, q)) for q in (0.1, 0.25, 0.5, 0.75, 0.9)}
        dist.setdefault(wl, {}).setdefault(typ, {})[cl] = d
    summ = {}
    for wl, types in dist.items():
        for typ, cls_ in types.items():
            vals = [v["M1"] for v in cls_.values()]
            summ[f"{wl}/{typ}"] = {"clusters": len(vals), "M1_cluster_quantiles": {q: float(np.quantile(vals, q)) for q in (0.1, 0.25, 0.5, 0.75, 0.9)} if vals else None}
    atomic_write_json(ctx.stats_dir / "per_cluster_distributions.json", {"per_cluster": dist, "summary": summ})
    return {"clusters": sum(len(t) for w in dist.values() for t in w.values())}


def stage_gates(ctx: RunContext) -> dict:
    """Evaluate the pre-registered decision gates G1–G6 (frozen config) from metrics only."""
    from ..common.util import load_yaml
    from ..contracts.lang import ContractError, assert_k1_structure
    from ..statistics.gates import evaluate, to_markdown
    gp = Path(ctx.cfg["paths"]["configs"]) / "decision_gates.yaml"
    gcfg = load_yaml(gp)
    m = read_json(ctx.stats_dir / "metrics.json")
    arts = Catalog(ctx.raw / "catalog.jsonl").load()
    k1_ok, disc = {}, {}
    for a in arts:
        k1 = a.contracts.get("K1")
        if k1:
            try:
                assert_k1_structure(k1["expr"])
            except ContractError:
                k1_ok[a.workload] = False
        k1_ok.setdefault(a.workload, True)
        for cls in ("K1", "K2", "K3"):
            c = a.contracts.get(cls)
            if c:
                d = disc.setdefault(a.workload, {}).setdefault(f"{a.artifact_type}/{cls}", {"n": 0, "order_comparisons": 0, "distinct_features": 0, "metadata_bytes": 0})
                dm = c["meta"]["disclosure"]
                d["n"] += 1
                d["order_comparisons"] += dm["n_order_comparisons"]
                d["distinct_features"] += dm["n_distinct_features"]
                d["metadata_bytes"] += dm["metadata_bytes"]
    for w in disc.values():
        for d in w.values():
            n = max(1, d.pop("n"))
            for k in list(d):
                d[k + "_mean"] = d.pop(k) / n
    g = evaluate(m, m.get("soundness", {}), k1_ok, disc, gcfg)
    g["gates_config_file"] = str(gp)
    g["gates_config_file_sha256"] = sha256_file(gp)
    g["engineering_only"] = bool(ctx.cfg.get("engineering_only"))
    atomic_write_json(ctx.stats_dir / "DECISION_GATES.json", g)
    (ctx.stats_dir / "DECISION_GATES.md").write_text(to_markdown(g, g["engineering_only"]))
    atomic_write_json(ctx.run_dir / "DECISION_GATES.json", g)
    (ctx.run_dir / "DECISION_GATES.md").write_text(to_markdown(g, g["engineering_only"]))
    return {wl: {k: v["outcome"] for k, v in gs.items()} for wl, gs in g["by_workload"].items()}


def _banner(ctx, ax):
    if ctx.cfg.get("engineering_only"):
        ax.text(0.5, 0.5, "ENGINEERING ONLY", transform=ax.transAxes, fontsize=22, color="red", alpha=0.15,
                ha="center", va="center", rotation=25)


def stage_figures(ctx: RunContext) -> dict:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    m = read_json(ctx.stats_dir / "metrics.json")
    ctx.figures.mkdir(parents=True, exist_ok=True)
    made = []
    labels = {"K0": "K0 hash", "K1": "K1 features", "K2": "K2 regions", "K3": "K3 transparent (ref.)"}
    for wl, w in m["by_workload"].items():
        for typ, u in w["unary"].items():
            if "__" in typ:
                continue
            # central figure: recall vs unsafe admission, marker size = evaluation cost, TTL curve overlaid
            fig, axs = plt.subplots(1, 2, figsize=(10, 4))
            ax = axs[0]
            curve = [c for c in u["ttl_curve"] if c["recall"] is not None and c["M2"] is not None]
            if curve:
                ax.plot([c["M2"] for c in curve], [c["recall"] for c in curve], "o-", color="gray", label="TTL (complete curve)")
            costs = [u["M3"][c]["eval_seconds_mean"] or 0.0 for c in CLASSES]
            cmax = max(costs) or 1.0
            for cls, cst in zip(CLASSES, costs):
                rec, uns = u["M3"][cls]["recall"]["macro"], u["M3"][cls]["unsafe_admission"]["macro"]
                if rec is not None and uns is not None:
                    ax.scatter([uns], [rec], s=40 + 400 * cst / cmax, label=labels[cls], zorder=3,
                               marker="x" if cls == "K3" else "o")
            ax.set_xlabel("unsafe admission  P[accept AND not usable]")
            ax.set_ylabel("reuse recall  P[accept | usable]")
            ax.set_title(f"{wl}/{typ}: reuse vs safety (size = eval cost)")
            ax.legend(fontsize=7)
            _banner(ctx, ax)
            ax = axs[1]
            xs, ys, lo, hi = [], [], [], []
            for i, cls in enumerate(("K1", "K2", "K3")):
                d = u["incremental_vs_K0"][cls]["delta_recall"]
                if d["mean"] is None:
                    continue
                xs.append(i); ys.append(d["mean"])
                lo.append(d["mean"] - (d["lo"] if d["lo"] is not None else d["mean"]))
                hi.append((d["hi"] if d["hi"] is not None else d["mean"]) - d["mean"])
            if xs:
                ax.errorbar(xs, ys, yerr=[lo, hi], fmt="o-", capsize=4)
            ax.axhline(0, color="k", lw=0.5)
            ax.set_xticks(range(3))
            ax.set_xticklabels(["K1\nfeatures", "K2\nregions", "K3\ntransparent (ref.)"])
            ax.set_ylabel("dRecall vs K0 (macro, 95% CI)")
            ax.set_title("Disclosure ladder")
            _banner(ctx, ax)
            fig.tight_layout()
            f = ctx.figures / f"tradeoff_{wl}_{typ}.pdf"
            fig.savefig(f)
            plt.close(fig)
            made.append(f.name)
        j = w.get("joint") or {}
        for sc in sorted({k.split("/")[0] for k in j}):
            g = j.get(f"{sc}/ALL")
            if not g:
                continue
            fig, axs = plt.subplots(1, 3, figsize=(13, 3.8))
            bars = [g["n_events"], g["individually_acceptable_events"], g["anomaly_count"],
                    g["K2"]["naive_false_compositions"]]
            axs[0].bar(range(4), bars)
            axs[0].set_xticks(range(4))
            axs[0].set_xticklabels(["events", "individually\nacceptable", "no common\nwitness", "naive false\n(K2)"], fontsize=7)
            axs[0].set_title(f"{wl}: {sc}")
            per = g["anomalies_per_cluster"]
            axs[1].bar(range(len(per)), list(per.values()))
            axs[1].set_title("anomalies per repository/dataset")
            axs[1].set_xticks([])
            cells = sorted(k for k in j if k.startswith(sc + "/") and not k.endswith("/ALL"))
            axs[2].bar(range(len(cells)), [j[c]["M4_oracle"]["macro"] or 0.0 for c in cells])
            axs[2].set_xticks(range(len(cells)))
            axs[2].set_xticklabels([c.split("/", 1)[1] for c in cells], rotation=90, fontsize=6)
            axs[2].set_title("M4_oracle by Gamma cell")
            for ax in axs:
                _banner(ctx, ax)
            fig.tight_layout()
            f = ctx.figures / f"joint_{wl}_{sc}.pdf"
            fig.savefig(f)
            plt.close(fig)
            made.append(f.name)
        r = w.get("repair") or {}
        keys = [k for k in r if k.endswith("/ALL/K2") or k.endswith("/ALL/K0") or k.endswith("/ALL/K1")]
        if keys:
            fig, ax = plt.subplots(figsize=(max(6, 1.6 * len(keys)), 4))
            width = 0.15
            for i, k in enumerate(sorted(keys)):
                v = r[k]
                ov = sum(v["overhead_total_s"].values())
                vals = [v["recompute_all_total_s"], v["current_cut_total_s"], v["opt_cost_total_s"], ov, v["opt_cost_total_s"] + ov]
                for jx, val in enumerate(vals):
                    ax.bar(i + (jx - 2) * width, val, width, label=["recompute-all", "current-cut", "OPT raw", "overhead", "OPT + overhead"][jx] if i == 0 else None)
            ax.set_xticks(range(len(keys)))
            ax.set_xticklabels(sorted(keys), rotation=20, fontsize=6)
            ax.set_ylabel("CPU seconds (total)")
            ax.set_title(f"Repair cost — {wl}")
            ax.legend(fontsize=7)
            _banner(ctx, ax)
            fig.tight_layout()
            f = ctx.figures / f"repair_{wl}.pdf"
            fig.savefig(f)
            plt.close(fig)
            made.append(f.name)
    return {"figures": made}


def _fmt(x):
    if x is None:
        return "--"
    if isinstance(x, float):
        return f"{x:.3f}"
    return str(x)


def _csv(path, rows):
    import csv
    if not rows:
        path.with_suffix(".empty").write_text("no rows\n")
        return
    keys = sorted({k for r in rows for k in r})
    with open(path, "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=keys)
        wr.writeheader()
        for r in rows:
            wr.writerow(r)


def stage_tables(ctx: RunContext) -> dict:
    m = read_json(ctx.stats_dir / "metrics.json")
    ctx.tables.mkdir(parents=True, exist_ok=True)
    rows = []
    for wl, w in m["by_workload"].items():
        for typ, u in w["unary"].items():
            base = {"workload": wl, "artifact_type": typ, "n_pairs_test": u["n_pairs_test"],
                    "M1": u["M1_hash_overinvalidation"]["macro"], "M1_lo": u["M1_hash_overinvalidation"]["ci"]["lo"],
                    "M1_hi": u["M1_hash_overinvalidation"]["ci"]["hi"],
                    "M1_B1": u["M1_version_pinning_overinvalidation"]["macro"],
                    "tau_star_h": (u["tau_star_s"] / 3600) if u["tau_star_s"] else None,
                    "M2": (u["M2_ttl_unsafe_admission_at_tau_star"] or {}).get("macro")}
            for cls in CLASSES:
                base[f"{cls}_recall"] = u["M3"][cls]["recall"]["macro"]
                base[f"{cls}_unsafe"] = u["M3"][cls]["unsafe_admission"]["macro"]
                base[f"{cls}_unsafe_count"] = u["M3"][cls]["unsafe_count"]
                base[f"{cls}_eval_s"] = u["M3"][cls]["eval_seconds_mean"]
            for cls in ("K1", "K2", "K3"):
                inc = u["incremental_vs_K0"][cls]
                base[f"{cls}_dRecall"] = inc["delta_recall"]["mean"]
                base[f"{cls}_dRecall_lo"] = inc["delta_recall"]["lo"]
                base[f"{cls}_dRecall_hi"] = inc["delta_recall"]["hi"]
                base[f"{cls}_dNB_per_pair_s"] = inc["delta_nb_per_pair_s"]["mean"]
                base[f"{cls}_dNB_lo"] = inc["delta_nb_per_pair_s"]["lo"]
                base[f"{cls}_dNB_hi"] = inc["delta_nb_per_pair_s"]["hi"]
                base[f"{cls}_recovered_pairs"] = inc["totals"]["recovered_pairs"]
                base[f"{cls}_incremental_unsafe_pairs"] = inc["totals"]["incremental_unsafe_pairs"]
            rows.append(base)
    _csv(ctx.tables / "unary_summary.csv", rows)
    cols = ["workload", "artifact_type", "n_pairs_test", "M1", "K0_recall", "K1_recall", "K2_recall", "K3_recall",
            "K1_dRecall", "K2_dRecall", "K1_dNB_per_pair_s", "K2_dNB_per_pair_s", "K1_unsafe", "K2_unsafe"]
    tex = ["\\begin{tabular}{ll" + "r" * (len(cols) - 2) + "}", "\\toprule",
           " & ".join(c.replace("_", "\\_") for c in cols) + " \\\\", "\\midrule"]
    for r in rows:
        tex.append(" & ".join(_fmt(r.get(c)).replace("_", "\\_") for c in cols) + " \\\\")
    tex += ["\\bottomrule", "\\end{tabular}"]
    (ctx.tables / "unary_summary.tex").write_text("\n".join(tex) + "\n")
    jrows, rrows = [], []
    for wl, w in m["by_workload"].items():
        for key, g in (w.get("joint") or {}).items():
            r = {"workload": wl, "group": key, "n_events": g["n_events"], "individually_acceptable": g["individually_acceptable_events"],
                 "anomalies": g["anomaly_count"], "M4_oracle": g["M4_oracle"]["macro"], "M4_lo": g["M4_oracle"]["ci"]["lo"],
                 "M4_hi": g["M4_oracle"]["ci"]["hi"], "clusters_with_anomaly": g["clusters_with_oracle_joint_failure"],
                 "clusters": g["clusters_total"]}
            for cls in CLASSES:
                r[f"{cls}_naive_false"] = g[cls]["naive_false_compositions"]
            jrows.append(r)
        for key, g in (w.get("repair") or {}).items():
            rrows.append({"workload": wl, "group": key, "n_events": g["n_events"],
                          "M5_raw_vs_all": g["M5_savings_vs_recompute_all"]["macro"],
                          "M5_raw_vs_current": g["M5_savings_vs_current_cut"]["macro"],
                          "M5_net_vs_all": g["M5_net_vs_recompute_all"]["mean"], "M5_net_vs_all_lo": g["M5_net_vs_recompute_all"]["lo"],
                          "M5_net_vs_current": g["M5_net_vs_current_cut"]["mean"], "M5_net_vs_current_lo": g["M5_net_vs_current_cut"]["lo"],
                          "net_total_vs_current_s": g["net_repair_benefit_total_s"].get("vs_current_cut"),
                          "events_raw_pos_net_neg_vs_current": g["events_raw_positive_net_negative"].get("vs_current_cut"),
                          "overhead_s": sum(g["overhead_total_s"].values()), "bruteforce_agreement": g["bruteforce_agreement"]})
    _csv(ctx.tables / "joint_summary.csv", jrows)
    _csv(ctx.tables / "repair_summary.csv", rrows)
    sd = [{"key": k, **v} for k, v in (m.get("soundness") or {}).items()]
    _csv(ctx.tables / "soundness_summary.csv", sd)
    return {"tables": sorted(p.name for p in ctx.tables.iterdir())}


def _git_commit() -> str | None:
    try:
        r = subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, cwd=Path(__file__).resolve().parents[3])
        return r.stdout.decode().strip() or None
    except Exception:
        return None


def stage_report(ctx: RunContext, stage_log: list[dict]) -> dict:
    m = read_json(ctx.stats_dir / "metrics.json") if (ctx.stats_dir / "metrics.json").exists() else {}
    gates = read_json(ctx.stats_dir / "DECISION_GATES.json") if (ctx.stats_dir / "DECISION_GATES.json").exists() else {}
    det = read_json(ctx.oracle_dir / "determinism.json") if (ctx.oracle_dir / "determinism.json").exists() else {}
    arts = Catalog(ctx.raw / "catalog.jsonl").load() if (ctx.raw / "catalog.jsonl").exists() else []
    failures = list(read_jsonl(ctx.raw / "birth_failures.jsonl"))
    hidden = [a.artifact_id for a in arts if a.run.get("hidden_reads")]
    contract_err = [a.artifact_id for a in arts if a.run.get("contract_errors")]
    eng = bool(ctx.cfg.get("engineering_only"))
    freeze_path = Path(ctx.cfg["paths"]["frozen"])
    rep = {
        "run_name": ctx.cfg["run_name"], "ENGINEERING_ONLY": eng, "generated_at": now_iso(), "git_commit": _git_commit(),
        "config_sha256": ctx.cfg["config_sha256"], "seed": ctx.cfg["seed"], "workloads": ctx.cfg["workloads"],
        "python": sys.version, "platform": platform.platform(), "stages": stage_log,
        "observed_facts": {"artifacts": len(arts), "clusters": sorted({f"{a.workload}/{a.cluster}" for a in arts}),
                           "failed_births": len(failures), "nondeterministic_inputs": len(det.get("nondeterministic_inputs", [])),
                           "a3_hidden_read_artifacts": len(hidden), "contract_emitter_errors": len(contract_err),
                           "exclusions": m.get("exclusions"), "disagreement_counts": m.get("disagreement_counts"),
                           "trace_methods": sorted({str(a.run.get("trace_method")) for a in arts}),
                           "network_isolation": sorted({str(a.run.get("net_method")) for a in arts})},
        "canonical_ledger": read_json(ctx.stats_dir / "LEDGER.json") if (ctx.stats_dir / "LEDGER.json").exists() else None,
        "server_resources": read_json(ctx.stats_dir / "server_resource_summary.json") if (ctx.stats_dir / "server_resource_summary.json").exists() else None,
        "statistical_estimates": "statistics/metrics.json (macro/micro, cluster-bootstrap CIs, numerators/denominators)",
        "decision_gates": {wl: {k: v["outcome"] for k, v in gs.items()} for wl, gs in (gates.get("by_workload") or {}).items()},
        "formal_guarantees": [
            "WSA (T1): every recorded admission carries a witness c* in Cuts(H_t) ∩ Gamma at which every kappa_eff holds; re-verified by journal replay.",
            "Footprint transfer (T1a): kappa depends only on footprint contents; memoisation is exact.",
            "Conservative fallback (T2): kappa_hash ⊆ Use_r under A3 (complete read capture) and A4 (replay-closed acceptance).",
            "Repair validity: re-deriving Q* at c* makes the set admissible at c* (kappa_hash holds at the new birth cut).",
        ],
        "assumptions": [
            "A6 (external obligation): declared contracts are sound (kappa ⊆ Use_r). NOT provable under opacity; only empirically bounded (G2).",
            "A3: complete read capture (violations traced and reported as U3).",
            "A4: replay-closed acceptance; producers deterministic (violations detected and reported as U4).",
            "OracleUse = equivalence with the SAME pinned producer replayed at c (stability relative to B_p, not world truth).",
        ],
        "metric_definitions": METRIC_DEFINITIONS,
        "freeze_manifest": read_json(freeze_path) if freeze_path.exists() else None,
        "seal": read_json(ctx.run_dir / "SEAL.json") if (ctx.run_dir / "SEAL.json").exists() else None,
        "environment": read_json(ctx.manifests / "environment_report.json") if (ctx.manifests / "environment_report.json").exists() else None,
    }
    atomic_write_json(ctx.run_dir / "RUN_REPORT.json", rep)
    md = [f"# RUN REPORT — {rep['run_name']}", ""]
    if eng:
        md += ["**ENGINEERING ONLY — NOT SCIENTIFIC RESULTS**", ""]
    md += [f"Generated {rep['generated_at']} · git `{rep['git_commit']}` · config `{rep['config_sha256'][:16]}` · seed {rep['seed']}", "",
           "This report separates observed facts, statistical estimates, formal guarantees and assumptions. It contains no interpretation.", "",
           "## Stages", ""]
    for st in stage_log:
        md.append(f"- `{st['stage']}`: {st['status']} ({st.get('seconds', 0):.1f}s)")
    md += ["", "## Observed facts", "", "```", json.dumps(rep["observed_facts"], indent=2, default=str)[:6000], "```", "",
           "## Statistical estimates", "", "See `statistics/metrics.json`, `statistics/per_cluster_distributions.json` and the tables directory.", "",
           "## Decision gates (pre-registered; mechanical outcomes)", ""]
    for wl, gs in rep["decision_gates"].items():
        md.append(f"- Workload {wl}: " + ", ".join(f"{k}={v}" for k, v in gs.items()))
    md += ["", "Details: `DECISION_GATES.md`.", "", "## Formal guarantees (hold by construction under the stated assumptions)", ""]
    md += [f"- {x}" for x in rep["formal_guarantees"]]
    md += ["", "## Assumptions (not proven by this run)", ""] + [f"- {x}" for x in rep["assumptions"]]
    md += ["", "## Metric definitions", ""] + [f"- **{k}**: {v}" for k, v in METRIC_DEFINITIONS.items()]
    (ctx.run_dir / "RUN_REPORT.md").write_text("\n".join(md) + "\n")
    if freeze_path.exists():
        import shutil
        for suffix in (".json", ".md"):
            src = freeze_path.with_suffix(suffix)
            if src.exists():
                shutil.copyfile(src, ctx.manifests / ("FREEZE_MANIFEST" + suffix))
    return {"report": str(ctx.run_dir / "RUN_REPORT.md")}
