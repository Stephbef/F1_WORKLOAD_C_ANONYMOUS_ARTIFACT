"""Pipeline stages, production side: manifests, environment, datasets, histories, births, populations."""
from __future__ import annotations

import json
import math
from pathlib import Path

from ..catalog.artifact import Artifact, Catalog
from ..common.util import F1Error, atomic_write_json, canonical_json, read_json, read_jsonl, sha256_file, sha256_obj, write_jsonl
from ..contracts.features_generic import k0_expr
from ..contracts.lang import Contract, ContractError
from ..core.history import History, cut_key, write_history_parquet
from .context import RunContext, run_jobs

CLASSES = ("K0", "K1", "K2", "K3")


# ---------------------------------------------------------------------------------------------
# S0 manifests / S1 environment / S2 datasets
# ---------------------------------------------------------------------------------------------
def stage_verify_manifests(ctx: RunContext) -> dict:
    wls = ctx.cfg["workloads"]
    fp = Path(ctx.cfg["paths"]["frozen"])
    if wls == ["synthetic"] and not fp.exists():
        return {"mode": "synthetic (engineering) — no freeze manifest present"}
    if not fp.exists():
        raise F1Error(f"no freeze manifest at {fp}: run `make freeze` (pre-registration) before the full run")
    frozen = read_json(fp)
    from .cli import code_sha256
    if frozen.get("code_sha256") != code_sha256():
        raise F1Error("source code changed since the freeze; refusing to run (create a new, explicitly versioned campaign)")
    gates = Path(ctx.cfg["paths"]["configs"]) / "decision_gates.yaml"
    if frozen.get("decision_gates_sha256") != sha256_file(gates):
        raise F1Error("decision gates changed since the freeze; refusing to run")
    checks = {}
    for key, path in frozen["files"].items():
        if not Path(path).exists():
            raise F1Error(f"frozen file missing: {path}")
        h = sha256_file(path)
        if h != frozen["sha256"][key]:
            raise F1Error(f"frozen file changed since freeze: {path}")
        checks[key] = h
    atomic_write_json(ctx.manifests / "frozen_manifest_verified.json", {"frozen": frozen, "verified": checks})
    return {"verified": checks}


def stage_env(ctx: RunContext) -> dict:
    from ..env.detect import detect, require
    rep = detect(ctx.cfg)
    atomic_write_json(ctx.manifests / "environment_report.json", rep)
    problems = require(rep, ctx.cfg)
    if problems:
        raise F1Error("environment check failed: " + "; ".join(problems))
    return {"ok": True}


def stage_datasets(ctx: RunContext) -> dict:
    out = {}
    for wl in ctx.cfg["workloads"]:
        if wl == "synthetic":
            out[wl] = "generated"
            continue
        if wl == "A":
            from ..datasets.workload_a import acquire
            man = read_json(ctx.cfg["paths"]["manifest_a"])
            out[wl] = acquire(man, ctx.cfg["workload_a"], ctx.data_root, ctx.cas,
                              ctx.cfg["tools"]["cargo_audit"]["path"], log=ctx.log)
        if wl == "B":
            from ..datasets.workload_b import acquire
            out[wl] = acquire(ctx.cfg["workload_b"], ctx.data_root, ctx.cas, log=ctx.log)
            failed = [k for k, v in out[wl].items() if v["status"] != "ok"]
            if failed:
                ctx.log(f"[datasets] workload B sources unavailable: {failed} (recorded; see acquisition_summary.json)")
    atomic_write_json(ctx.manifests / "datasets_acquired.json", out)
    return out


# ---------------------------------------------------------------------------------------------
# S3 histories
# ---------------------------------------------------------------------------------------------
def stage_histories(ctx: RunContext) -> dict:
    info = {}
    for wl_name in ctx.cfg["workloads"]:
        wl = ctx.workload(wl_name)
        rows = []
        for c in wl.clusters():
            h = wl.build_history(c)
            rows += h.to_rows(c.name)
            info[f"{wl_name}/{c.name}"] = {i: len(v) for i, v in h.items.items()} | {"fingerprint": h.fingerprint()}
        if not rows:
            raise F1Error(f"workload {wl_name}: no clusters/histories (acquisition failed?)")
        write_history_parquet(rows, ctx.raw / f"history_{wl_name}.parquet")
    atomic_write_json(ctx.manifests / "histories.json", info)
    return {"clusters": len(info)}


# ---------------------------------------------------------------------------------------------
# S4 births (production)
# ---------------------------------------------------------------------------------------------
_PROD_CACHE: dict = {}


def _producers(ctx: RunContext, wl_name: str, cluster: str) -> dict:
    k = (wl_name, cluster)
    if k not in _PROD_CACHE:
        wl = ctx.workload(wl_name)
        _PROD_CACHE[k] = wl.producers(ctx.cluster_spec(wl_name, cluster))
    return _PROD_CACHE[k]


def job_produce(ctx: RunContext, job: dict) -> dict:
    """Run one producer at one cut and emit its outputs + producer-side contracts (birth only)."""
    h = ctx.history(job["wl"], job["cluster"])
    p = _producers(ctx, job["wl"], job["cluster"])[job["pid"]]
    from ..producers.dq import set_threads
    set_threads(getattr(p, "threads", 1))  # contract generation in the worker stays within the class CPU reservation
    cut = job["cut"]
    res, out = p.execute(cut, h, ctx.cas, ctx.work / "sandboxes")
    rec = {"key": job["key"], "wl": job["wl"], "cluster": job["cluster"], "pid": job["pid"], "cut": cut,
           "status": res.status, "run": res.record(), "version": p.version_digest(),
           "birth_refs": p.birth_refs(cut, h)}
    if res.status != "ok" or out is None:
        return rec
    rec["output"] = out
    rec["values"], rec["contracts"], rec["contract_errors"] = {}, {}, {}
    for typ in p.artifact_types:
        val = p.project(out, typ)
        rec["values"][typ] = val
        cs = {"K0": Contract.build("", "K0", k0_expr(rec["birth_refs"])).to_json()}
        try:
            exprs = p.contracts(typ, cut, h, ctx.loader, out)
        except Exception as e:  # recorded: the class falls back to K0 for this artifact
            exprs = {}
            rec["contract_errors"][typ] = f"emitter: {type(e).__name__}: {e}"
        for cls in ("K1", "K2", "K3"):
            if exprs.get(cls) is None:
                continue
            try:
                c = Contract.build("", cls, exprs[cls])
                # well-formedness (D8): every emitted contract must accept its own birth cut
                from ..contracts.lang import Evaluator
                ok, _, _ = Evaluator(ctx.loader).evaluate(c, lambda i: h.content(cut, i))
                if not ok:
                    raise ContractError(f"{cls} does not accept its birth cut (ill-formed)")
                cs[cls] = c.to_json()
            except ContractError as e:
                rec["contract_errors"].setdefault(typ, "")
                rec["contract_errors"][typ] += f" {cls}: {e};"
        rec["contracts"][typ] = cs
    return rec


def stage_births(ctx: RunContext) -> dict:
    jobs, births = [], []
    unavailable = set(ctx.cfg.get("unavailable_producers", []) or [])
    for wl_name in ctx.cfg["workloads"]:
        wl = ctx.workload(wl_name)
        for c in wl.clusters():
            h = ctx.history(wl_name, c.name)
            wl.prepare(c, h)
            prods = _producers(ctx, wl_name, c.name)
            for t, pid in wl.births(c, h):
                cut = h.latest_cut(t)
                if cut is None:
                    continue
                p = prods[pid]
                refs = p.birth_refs(cut, h)
                key = sha256_obj([wl_name, c.name, pid, p.version_digest(), refs])
                births.append({"wl": wl_name, "cluster": c.name, "pid": pid, "t": t, "cut": cut, "key": key,
                               "split": wl.birth_split(c, t)})
                jobs.append({"key": key, "wl": wl_name, "cluster": c.name, "pid": pid, "cut": cut,
                             "rclass": getattr(p, "resource_class", "LIGHT_CPU")})
    write_jsonl(ctx.raw / "births_requested.jsonl", births)
    uniq = list({j["key"]: j for j in jobs}.values())
    results = run_jobs(ctx, uniq, "f1.runner.stages_prod.job_produce", ctx.raw / "production_runs.jsonl", "production", "births")
    by_key = {r["key"]: r for r in results}
    cat_path = ctx.raw / "catalog.jsonl"
    if cat_path.exists():
        cat_path.unlink()
    cat = Catalog(cat_path)
    failures, n_art = [], 0
    for b in births:
        r = by_key.get(b["key"])
        if r is None or r.get("status") != "ok":
            failures.append({"birth": b, "status": None if r is None else r.get("status"),
                             "error": None if r is None else (r.get("error") or (r.get("run") or {}).get("stderr_tail"))})
            continue
        wl = ctx.workload(b["wl"])
        cspec = ctx.cluster_spec(b["wl"], b["cluster"])
        h = ctx.history(b["wl"], b["cluster"])
        p = _producers(ctx, b["wl"], b["cluster"])[b["pid"]]
        cost = math.inf if b["pid"] in unavailable else float(r["run"]["cpu_s"])
        for typ, val in r["values"].items():
            aid = Artifact.make_id(b["wl"], b["cluster"], b["pid"], typ, b["t"], b["cut"])
            contracts = {}
            for cls, cj in r["contracts"][typ].items():
                cj = dict(cj)
                cj["artifact_id"] = aid
                contracts[cls] = Contract.from_json(cj).to_json()
            art = Artifact(artifact_id=aid, workload=b["wl"], cluster=b["cluster"], split=b["split"], producer_id=b["pid"],
                           artifact_type=typ, birth_time=b["t"], birth_cut=b["cut"],
                           birth_revs=wl.revs_at(cspec, h, b["t"], sorted(p.read_items)),
                           read_set=sorted(p.read_items), birth_refs=r["birth_refs"], value=val,
                           value_ref=ctx.cas.put(canonical_json(val).encode()), cost_s=cost, contracts=contracts,
                           run={"production_key": b["key"], "version": r["version"], "status": r["status"],
                                "hidden_reads": r["run"]["hidden_reads"], "trace_method": r["run"]["trace_method"],
                                "net_method": r["run"]["net_method"], "net_attempts": r["run"]["net_attempts"],
                                "contract_errors": r.get("contract_errors", {}).get(typ)})
            cat.append(art)
            n_art += 1
    write_jsonl(ctx.raw / "birth_failures.jsonl", failures)
    if n_art == 0:
        raise F1Error("no artifact could be produced; see birth_failures.jsonl")
    return {"births": len(births), "unique_runs": len(uniq), "artifacts": n_art, "failed_births": len(failures)}


# ---------------------------------------------------------------------------------------------
# S5 populations (shared by admission and oracle; neither reads the other's outputs)
# ---------------------------------------------------------------------------------------------
def stage_populations(ctx: RunContext) -> dict:
    from ..core.gamma import Gamma
    arts = Catalog(ctx.raw / "catalog.jsonl").load()
    pairs, events = [], []
    for wl_name in ctx.cfg["workloads"]:
        wl = ctx.workload(wl_name)
        for c in wl.clusters():
            h = ctx.history(wl_name, c.name)
            ca = [a for a in arts if a.workload == wl_name and a.cluster == c.name]
            for a in wl.unary_sample(c, ca):
                for t in wl.unary_ticks(c, h, a.birth_time):
                    cut = h.latest_cut(t)
                    if cut is None:
                        continue
                    pairs.append({"pair_id": sha256_obj([a.artifact_id, t])[:20], "wl": wl_name, "cluster": c.name,
                                  "artifact_id": a.artifact_id, "artifact_type": a.artifact_type, "split": a.split,
                                  "t": t, "age_s": t - a.birth_time, "cut": cut,
                                  "revs": wl.revs_at(c, h, t, a.read_set)})
            for ev in wl.consumer_events(c, h, ca):
                g = Gamma.from_json(ev.gamma)
                n = sum(1 for _ in h.enumerate_cuts(g.allowed(h)))
                events.append({"event_id": ev.event_id, "wl": wl_name, "scenario": ev.scenario, "cluster": ev.cluster,
                               "t": ev.t, "R": ev.artifact_ids, "gamma": ev.gamma, "cell": ev.cell, "n_candidate_cuts": n})
    write_jsonl(ctx.raw / "unary_pairs.jsonl", pairs)
    write_jsonl(ctx.raw / "joint_events.jsonl", events)
    return {"unary_pairs": len(pairs), "joint_events": len(events)}
