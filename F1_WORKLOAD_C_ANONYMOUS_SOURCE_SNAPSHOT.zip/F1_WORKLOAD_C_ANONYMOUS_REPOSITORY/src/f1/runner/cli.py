"""Command-line entry point.

  python -m f1 full    --config configs/experiment.yaml     # the single full-run command (resumable)
  python -m f1 stage   --config ... --name admission        # internal: run one stage (used for role isolation)
  python -m f1 select  --config ...                         # algorithmic repo selection (pre-registration)
  python -m f1 freeze  --config ...                         # freeze manifests + configs (pre-registration)
  python -m f1 env-check --config ...                       # environment report only
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

from ..common.util import F1Error, atomic_write_json, now_iso, read_json, sha256_file
from .context import RunContext, load_config

STAGES = ["verify_manifests", "env", "datasets", "histories", "births", "populations",
          "admission", "seal", "oracle", "metrics", "ledger", "statistics", "gates", "figures", "tables", "report"]
BANNER = "ENGINEERING ONLY — NOT SCIENTIFIC RESULTS"
ROLE = {"admission": "admission", "oracle": "oracle"}


def _import_features():
    import f1.contracts.features_generic  # noqa: F401
    import f1.producers.dq  # noqa: F401
    import f1.producers.license_spdx  # noqa: F401
    import f1.producers.rustsec  # noqa: F401
    import f1.producers.synthetic  # noqa: F401


def run_stage(ctx: RunContext, name: str, stage_log: list) -> dict:
    from . import stages_eval as E
    from . import stages_prod as P
    from . import stages_report as R
    fn = {"verify_manifests": P.stage_verify_manifests, "env": P.stage_env, "datasets": P.stage_datasets,
          "histories": P.stage_histories, "births": P.stage_births, "populations": P.stage_populations,
          "admission": E.stage_admission, "seal": E.stage_seal, "oracle": E.stage_oracle,
          "metrics": R.stage_metrics, "ledger": R.stage_ledger, "statistics": R.stage_statistics, "gates": R.stage_gates, "figures": R.stage_figures,
          "tables": R.stage_tables}.get(name)
    if name == "report":
        return R.stage_report(ctx, stage_log)
    if fn is None:
        raise F1Error(f"unknown stage {name}")
    return fn(ctx)


def cmd_stage(args) -> int:
    cfg = load_config(args.config)
    ctx = RunContext(cfg)
    role = ROLE.get(args.name, "orchestrator")
    from ..common.firewall import install_role_guard
    install_role_guard(role, ctx.oracle_dir)
    _import_features()
    info = run_stage(ctx, args.name, [])
    atomic_write_json(ctx.stages / f"{args.name}.result.json", info)
    return 0


def cmd_full(args) -> int:
    cfg = load_config(args.config)
    ctx = RunContext(cfg)
    _import_features()
    stage_log = []
    lp = ctx.manifests / "stage_log.json"
    if lp.exists():
        stage_log = read_json(lp)
    if cfg.get("engineering_only"):
        ctx.log(f"*** {BANNER} ***")
    ctx.log(f"=== full run '{cfg['run_name']}' config={cfg['config_sha256'][:16]} ===")
    run_manifest = ctx.manifests / "run_manifest.json"
    if not run_manifest.exists():
        atomic_write_json(run_manifest, {"started_at": now_iso(), "config_sha256": cfg["config_sha256"],
                                         "config_path": cfg["config_path"], "seed": cfg["seed"], "argv": sys.argv})
    else:
        prev = read_json(run_manifest)
        if prev["config_sha256"] != cfg["config_sha256"]:
            raise F1Error("configuration changed since this run started; refusing to resume (start a new run_name)")
    tel = _start_telemetry(ctx)
    try:
        return _run_stages(ctx, cfg, stage_log, lp, tel)
    finally:
        _stop_telemetry(ctx, tel)


def _start_telemetry(ctx):
    tcfg = ctx.cfg.get("telemetry") or {}
    if not tcfg.get("enabled", True):
        return None
    env = dict(os.environ)
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[2]) + os.pathsep + env.get("PYTHONPATH", "")
    return subprocess.Popen([sys.executable, "-m", "f1.telemetry.sampler", "--run-dir", str(ctx.run_dir), "--root-pid", str(os.getpid()),
                             "--interval", str(tcfg.get("interval_s", 2.0)), "--gpu-every", str(tcfg.get("gpu_every", 1)),
                             "--size-every", str(tcfg.get("size_every", 30))], env=env)


def _stop_telemetry(ctx, tel):
    if tel is None or tel.poll() is not None:
        return
    tel.terminate()
    try:
        tel.wait(timeout=30)
    except subprocess.TimeoutExpired:
        tel.kill()


def _run_stages(ctx, cfg, stage_log, lp, tel) -> int:
    for name in STAGES:
        if name != "report" and ctx.stage_done(name):
            ctx.log(f"[{name}] already complete — skipped (resume)")
            continue
        (ctx.run_dir / "telemetry_stage").write_text(name)
        if name == "report" and tel is not None:
            _stop_telemetry(ctx, tel)
            from ..telemetry.sampler import finalize
            finalize(ctx.run_dir)
        t0 = time.time()
        ctx.log(f"[{name}] start")
        try:
            if name in ROLE:
                # role isolation: separate interpreter with the role guard installed before any data access
                env = dict(os.environ)
                env["PYTHONPATH"] = str(Path(__file__).resolve().parents[2]) + os.pathsep + env.get("PYTHONPATH", "")
                p = subprocess.run([sys.executable, "-m", "f1", "stage", "--config", cfg["config_path"], "--name", name], env=env)
                if p.returncode != 0:
                    raise F1Error(f"stage {name} subprocess failed (exit {p.returncode}); see log above")
                info = read_json(ctx.stages / f"{name}.result.json")
            else:
                info = run_stage(ctx, name, stage_log)
        except Exception as e:
            stage_log.append({"stage": name, "status": "FAILED", "seconds": time.time() - t0, "error": f"{type(e).__name__}: {e}"})
            atomic_write_json(lp, stage_log)
            ctx.log(f"[{name}] FAILED: {e}")
            traceback.print_exc()
            return 2
        dt = time.time() - t0
        stage_log.append({"stage": name, "status": "ok", "seconds": dt, "info": info})
        atomic_write_json(lp, stage_log)
        if name != "report":
            ctx.mark_done(name, {"seconds": dt, "info": info})
        ctx.log(f"[{name}] done in {dt:.1f}s: {info}")
        if os.environ.get("F1_TEST_STOP_AFTER") == name:  # engineering test hook: simulate an interruption
            ctx.log(f"[test-hook] stopping after stage {name}")
            return 4
    atomic_write_json(ctx.run_dir / "RUN_COMPLETE.json", {"finished_at": now_iso()})
    if cfg.get("engineering_only"):
        ctx.log(f"*** {BANNER} ***")
    return 0


def cmd_select(args) -> int:
    cfg = load_config(args.config)
    from ..datasets.workload_a import select_repos
    out = Path(cfg["paths"]["manifest_a"])
    if out.exists() and not args.force:
        raise F1Error(f"{out} exists; refusing to re-select (pass --force to override before freezing)")
    select_repos(cfg["workload_a"], Path(cfg["paths"]["data"]) / "cache" / "git", out, token=os.environ.get("GITHUB_TOKEN"))
    print(f"wrote {out}")
    return 0


def code_sha256() -> str:
    import hashlib
    src = Path(__file__).resolve().parents[1]
    h = hashlib.sha256()
    for p in sorted(src.rglob("*.py")):
        h.update(str(p.relative_to(src)).encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def _git_state(root: Path) -> dict:
    def g(*a):
        r = subprocess.run(["git", "-C", str(root), *a], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 else None
    st = g("status", "--porcelain", "--untracked-files=no")
    return {"commit": g("rev-parse", "HEAD"), "dirty": bool(st) if st is not None else None}


def cmd_freeze(args) -> int:
    """Pre-registration: freeze configs (incl. decision gates), manifests, tools, code, protocol parameters."""
    cfg = load_config(args.config)
    fp = Path(cfg["paths"]["frozen"])
    if fp.exists() and not args.force:
        raise F1Error(f"{fp} already exists (frozen). Refusing to overwrite; start a new campaign (run_name + manifest path).")
    root = Path(cfg["root"])
    files = {"experiment_config": cfg["config_path"]}
    cdir = Path(cfg["paths"]["configs"])
    for p in sorted(cdir.rglob("*.yaml")):
        files[f"config:{p.relative_to(cdir)}"] = str(p)
    gates = cdir / "decision_gates.yaml"
    if not gates.exists():
        raise F1Error("configs/decision_gates.yaml missing: decision gates must be frozen")
    if "A" in cfg["workloads"]:
        files["manifest_a"] = cfg["paths"]["manifest_a"]
    if "B" in cfg["workloads"]:
        b = Path(cfg["paths"]["manifest_b"])
        if not b.exists():
            atomic_write_json(b, {"datasets": cfg["workload_b"]["datasets"], "note": "sources pinned by sha256 at acquisition"})
        files["manifest_b"] = str(b)
    for name, t in (cfg.get("tools") or {}).items():
        if isinstance(t, dict) and t.get("path"):
            files[f"tool:{name}"] = t["path"]
    missing = [k for k, v in files.items() if not Path(v).exists()]
    if missing:
        raise F1Error(f"cannot freeze, missing: {missing}")
    src = Path(__file__).resolve().parents[1]
    module_hashes = {str(p.relative_to(src)): sha256_file(p) for p in sorted(src.rglob("*.py"))}
    wa = cfg.get("workload_a") or {}
    rec = {
        "campaign": cfg["run_name"], "frozen_at": now_iso(), "engineering_only": bool(cfg.get("engineering_only")),
        "git": _git_state(root), "code_sha256": code_sha256(),
        "files": files, "sha256": {k: sha256_file(v) for k, v in files.items()},
        "decision_gates_sha256": sha256_file(gates),
        "protocol": {
            "contract_classes": "K0 hash/read-set pinning; K1 disclosed features = recorded birth values (structurally no thresholds/branches/logic); K2 decision regions; K3 transparent reference (violates opacity, reference only); kappa_eff = K OR K0",
            "contract_definition_modules": {k: v for k, v in module_hashes.items() if k.startswith(("contracts/", "producers/"))},
            "equivalence_relations": {"vuln_report": "canonical set of advisory|crate|version", "vuln_gate": "PASS/FAIL",
                                      "lic_gate": "PASS/FAIL", "lic_issues": "canonical violation set",
                                      "dq_gate": "PASS/FAIL", "dq_issues": "canonical failing-check set"},
            "gamma": {"primary_async_joint": wa.get("gamma"), "secondary_policy_grace": wa.get("secondary_policy_grace"),
                      "control_release": "S fixed to the release lockfile; V windows as primary"},
            "schedules": wa.get("schedules"), "window": wa.get("window"), "sampling": wa.get("unary"),
            "ttl": {"grid_hours": cfg.get("ttl_grid_hours"), "tuning": "validation split only; maximise recall - false-admission rate; complete test curve reported"},
            "seeds": {"seed": cfg.get("seed"), "selection_split_seed": (wa.get("selection") or {}).get("split_seed")},
            "statistics": cfg.get("statistics"), "determinism": cfg.get("determinism"), "repair": cfg.get("repair"),
            "cluster_units": "Workload A: repository; Workload B: dataset history",
        },
        "module_sha256": module_hashes,
    }
    atomic_write_json(fp, rec)
    md = [f"# FREEZE MANIFEST — campaign `{rec['campaign']}`", "",
          f"Frozen at {rec['frozen_at']} · git `{rec['git']['commit']}` (dirty={rec['git']['dirty']}) · code sha256 `{rec['code_sha256']}`", "",
          "Any change to these files, to the code, or to the decision gates after this point invalidates the campaign: "
          "`make full-experiment` refuses to run. A modified protocol requires a new, explicitly versioned campaign.", "",
          f"Decision gates sha256: `{rec['decision_gates_sha256']}`", "", "## Frozen files", "", "| key | sha256 |", "|---|---|"]
    md += [f"| {k} | `{v}` |" for k, v in rec["sha256"].items()]
    md += ["", "## Protocol", "", "```", json.dumps(rec["protocol"], indent=2, default=str)[:12000], "```"]
    fp.with_suffix(".md").write_text("\n".join(md) + "\n")
    print(f"frozen {len(files)} files + code ({rec['code_sha256'][:16]}) -> {fp}")
    return 0


def cmd_env(args) -> int:
    cfg = load_config(args.config)
    from ..env.detect import detect, require, write_reports
    rep = detect(cfg)
    out = Path(cfg["root"]) / "environment"
    write_reports(rep, out, "environment_check")
    probs = require(rep, cfg)
    print("environment OK" if not probs else "environment PROBLEMS (hard fail):\n  - " + "\n  - ".join(probs))
    return 0 if not probs else 3


def cmd_env_report(args) -> int:
    cfg = load_config(args.config)
    from ..env.detect import detect, write_reports
    rep = detect(cfg)
    write_reports(rep, Path(cfg["root"]) / "environment", f"environment_{args.phase}")
    print(f"wrote environment/environment_{args.phase}.json and .md")
    return 0


def cmd_env_lock(args) -> int:
    cfg = load_config(args.config)
    from ..env.detect import lock
    rec = lock(cfg)
    atomic_write_json(Path(cfg["root"]) / "environment" / "environment_lock.json", rec)
    print(f"wrote environment/environment_lock.json ({len(rec['python_packages'])} packages)")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="f1")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("full", "stage", "select", "freeze", "env-check", "env-report", "env-lock"):
        s = sub.add_parser(name)
        s.add_argument("--config", required=True)
        if name == "stage":
            s.add_argument("--name", required=True, choices=STAGES)
        if name in ("select", "freeze"):
            s.add_argument("--force", action="store_true")
        if name == "env-report":
            s.add_argument("--phase", required=True, choices=["before", "after"])
    args = ap.parse_args(argv)
    try:
        return {"full": cmd_full, "stage": cmd_stage, "select": cmd_select, "freeze": cmd_freeze, "env-check": cmd_env,
                "env-report": cmd_env_report, "env-lock": cmd_env_lock}[args.cmd](args)
    except F1Error as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
