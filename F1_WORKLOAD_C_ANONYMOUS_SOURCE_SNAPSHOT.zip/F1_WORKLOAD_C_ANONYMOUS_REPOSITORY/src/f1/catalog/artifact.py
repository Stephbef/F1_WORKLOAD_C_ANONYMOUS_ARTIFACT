"""Artifact r = <val, beta, RS, kappa, cost> (D6) and the catalog store."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from ..common.util import F1Error, append_jsonl, read_jsonl, sha256_obj
from ..contracts.lang import Contract


@dataclass
class Artifact:
    artifact_id: str
    workload: str
    cluster: str
    split: str
    producer_id: str
    artifact_type: str
    birth_time: float
    birth_cut: dict
    birth_revs: dict
    read_set: list
    birth_refs: dict          # item -> content ref at birth (captured read contents)
    value: object             # canonical materialised value (projection for this artifact type)
    value_ref: str
    cost_s: float             # cheapest available re-derivation cost (inf allowed)
    contracts: dict = field(default_factory=dict)  # cls -> Contract json
    run: dict = field(default_factory=dict)        # birth execution record (trace, status)

    def contract(self, cls: str) -> Contract | None:
        d = self.contracts.get(cls)
        return Contract.from_json(d) if d else None

    def to_json(self) -> dict:
        return {k: getattr(self, k) for k in self.__dataclass_fields__}

    @staticmethod
    def from_json(d: dict) -> "Artifact":
        return Artifact(**d)

    @staticmethod
    def make_id(workload: str, cluster: str, producer_id: str, artifact_type: str, birth_time: float, birth_cut: dict) -> str:
        return sha256_obj([workload, cluster, producer_id, artifact_type, birth_time, birth_cut])[:20]


class Catalog:
    def __init__(self, path: str | Path):
        self.path = Path(path)

    def append(self, a: Artifact) -> None:
        if a.cost_s is None or a.cost_s != a.cost_s:
            raise F1Error(f"artifact {a.artifact_id} has undefined cost")
        append_jsonl(self.path, a.to_json())

    def load(self) -> list[Artifact]:
        seen, out = set(), []
        for d in read_jsonl(self.path):
            if d["artifact_id"] in seen:
                continue  # idempotent resume: first record wins
            seen.add(d["artifact_id"])
            out.append(Artifact.from_json(d))
        return out

    def ids(self) -> set[str]:
        return {d["artifact_id"] for d in read_jsonl(self.path)}
