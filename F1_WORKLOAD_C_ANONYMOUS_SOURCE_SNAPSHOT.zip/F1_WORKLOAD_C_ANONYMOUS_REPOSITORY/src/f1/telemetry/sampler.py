"""Observational server telemetry (never read by any scientific decision).

Run as a separate process by the orchestrator:  python -m f1.telemetry.sampler --run-dir D --root-pid P --interval 2
Samples /proc (CPU per core, load, runnable, context switches, memory, swap, disk I/O) and the orchestrator's
process tree (CPU, RSS), the scheduler status file (active workers per class), the current stage, storage growth
and, if available, nvidia-smi. Appends JSON lines (flushed per sample); `finalize` converts to parquet and writes
per-stage summaries (mean, median, p90, p99, max).
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

CLK = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100
PAGE = os.sysconf("SC_PAGE_SIZE") if hasattr(os, "sysconf") else 4096


def _cpu_times():
    out = {}
    for line in open("/proc/stat"):
        if line.startswith("cpu"):
            f = line.split()
            vals = list(map(int, f[1:9]))
            idle = vals[3] + vals[4]
            out[f[0]] = (sum(vals), idle)
        elif line.startswith("ctxt"):
            out["ctxt"] = int(line.split()[1])
        elif line.startswith("procs_running"):
            out["procs_running"] = int(line.split()[1])
    return out


def _mem():
    m = {}
    for line in open("/proc/meminfo"):
        k, v = line.split(":", 1)
        m[k] = int(v.split()[0]) * 1024
    return {"total_gb": m["MemTotal"] / 2**30, "available_gb": m.get("MemAvailable", 0) / 2**30,
            "used_gb": (m["MemTotal"] - m.get("MemAvailable", 0)) / 2**30,
            "cache_gb": (m.get("Cached", 0) + m.get("Buffers", 0)) / 2**30,
            "swap_used_gb": (m.get("SwapTotal", 0) - m.get("SwapFree", 0)) / 2**30}


def _whole_disks() -> set:
    try:
        return {d for d in os.listdir("/sys/block") if not d.startswith(("loop", "ram", "zram"))}
    except OSError:
        return set()


_DISKS = _whole_disks()


def _disks():
    tot = {"r_sect": 0, "w_sect": 0, "r_io": 0, "w_io": 0, "io_ms": 0, "inflight": 0}
    try:
        for line in open("/proc/diskstats"):
            f = line.split()
            if f[2] not in _DISKS:
                continue
            tot["r_io"] += int(f[3]); tot["r_sect"] += int(f[5]); tot["w_io"] += int(f[7]); tot["w_sect"] += int(f[9])
            tot["inflight"] += int(f[11]); tot["io_ms"] += int(f[12])
    except OSError:
        pass
    return tot


def _proc_tree(root: int):
    """CPU ticks and RSS of the root process and all descendants."""
    parent, stats = {}, {}
    for d in os.listdir("/proc"):
        if not d.isdigit():
            continue
        try:
            with open(f"/proc/{d}/stat") as fh:
                raw = fh.read()
            rest = raw[raw.rindex(")") + 2:].split()
            pid = int(d)
            parent[pid] = int(rest[1])
            stats[pid] = (int(rest[11]) + int(rest[12]), int(rest[21]) * PAGE)
        except (OSError, ValueError, IndexError):
            continue
    tree, frontier = {root}, [root]
    children = {}
    for p, pp in parent.items():
        children.setdefault(pp, []).append(p)
    while frontier:
        x = frontier.pop()
        for c in children.get(x, []):
            if c not in tree:
                tree.add(c)
                frontier.append(c)
    ticks = sum(stats[p][0] for p in tree if p in stats)
    rss = sum(stats[p][1] for p in tree if p in stats)
    return ticks, rss, len(tree)


def _gpus():
    if shutil.which("nvidia-smi") is None:
        return None
    try:
        p = subprocess.run(["nvidia-smi", "--query-gpu=index,utilization.gpu,memory.used,power.draw,temperature.gpu",
                            "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=5)
        out = []
        for line in p.stdout.strip().splitlines():
            i, u, m, pw, t = [x.strip() for x in line.split(",")]
            out.append({"gpu": int(i), "util_pct": float(u), "mem_used_mb": float(m),
                        "power_w": float(pw) if pw not in ("[N/A]", "N/A") else None, "temp_c": float(t)})
        return out
    except Exception:
        return None


def _dir_size(path: Path) -> int:
    tot = 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                tot += os.lstat(os.path.join(root, f)).st_size
            except OSError:
                pass
    return tot


def run(run_dir: Path, root_pid: int, interval: float, gpu_every: int, size_every: int) -> None:
    out = run_dir / "raw" / "server_telemetry.jsonl"
    out.parent.mkdir(parents=True, exist_ok=True)
    stop = {"flag": False}
    signal.signal(signal.SIGTERM, lambda *a: stop.__setitem__("flag", True))
    prev_cpu, prev_disk, prev_tree, prev_t = _cpu_times(), _disks(), _proc_tree(root_pid)[0], time.time()
    n, size_b = 0, 0
    with open(out, "a") as fh:
        while not stop["flag"]:
            time.sleep(interval)
            now = time.time()
            dt = max(1e-6, now - prev_t)
            cpu, disk = _cpu_times(), _disks()
            ticks, rss, nproc = _proc_tree(root_pid)
            per_core = {}
            for k, val in cpu.items():
                if not k.startswith("cpu") or k not in prev_cpu:
                    continue
                tot, idle = val
                dtot, didle = tot - prev_cpu[k][0], idle - prev_cpu[k][1]
                per_core[k] = 100.0 * (1 - didle / dtot) if dtot > 0 else 0.0
            stage = (run_dir / "telemetry_stage").read_text().strip() if (run_dir / "telemetry_stage").exists() else "unknown"
            try:
                st = json.loads((run_dir / "worker_status.json").read_text())
                running = st.get("running", {})
            except (OSError, ValueError):
                running = {}
            if size_every and n % size_every == 0:
                size_b = _dir_size(run_dir)
            rec = {"t": now, "stage": stage,
                   "cpu_total_pct": per_core.pop("cpu", 0.0), "cpu_per_core_pct": [round(per_core[k], 1) for k in sorted(per_core, key=lambda x: int(x[3:]))],
                   "load": list(os.getloadavg()), "procs_running": cpu.get("procs_running"),
                   "ctx_switches_per_s": (cpu.get("ctxt", 0) - prev_cpu.get("ctxt", 0)) / dt,
                   **_mem(),
                   "exp_cpu_cores": (ticks - prev_tree) / CLK / dt, "exp_rss_gb": rss / 2**30, "exp_processes": nproc,
                   "workers_by_class": running, "workers_active": sum(running.values()) if running else 0,
                   "disk_read_mb_s": (disk["r_sect"] - prev_disk["r_sect"]) * 512 / 2**20 / dt,
                   "disk_write_mb_s": (disk["w_sect"] - prev_disk["w_sect"]) * 512 / 2**20 / dt,
                   "disk_read_iops": (disk["r_io"] - prev_disk["r_io"]) / dt, "disk_write_iops": (disk["w_io"] - prev_disk["w_io"]) / dt,
                   "disk_util_pct": min(100.0, (disk["io_ms"] - prev_disk["io_ms"]) / (10.0 * dt)), "disk_queue": disk["inflight"],
                   "run_dir_bytes": size_b,
                   "gpus": _gpus() if gpu_every and n % gpu_every == 0 else None}
            fh.write(json.dumps(rec) + "\n")
            fh.flush()
            prev_cpu, prev_disk, prev_tree, prev_t = cpu, disk, ticks, now
            n += 1


SUMMARY_FIELDS = ["cpu_total_pct", "exp_cpu_cores", "used_gb", "exp_rss_gb", "disk_read_mb_s", "disk_write_mb_s",
                  "disk_util_pct", "workers_active", "load1", "gpu_util_pct_max", "gpu_mem_used_mb_max"]


def finalize(run_dir: Path) -> dict:
    import numpy as np
    src = run_dir / "raw" / "server_telemetry.jsonl"
    rows = []
    if src.exists():
        for line in open(src):
            try:
                r = json.loads(line)
            except ValueError:
                continue  # a torn final line from a hard kill is skipped (observational data only)
            r["load1"] = r["load"][0]
            g = r.get("gpus") or []
            r["gpu_util_pct_max"] = max((x["util_pct"] for x in g), default=None)
            r["gpu_mem_used_mb_max"] = max((x["mem_used_mb"] for x in g), default=None)
            rows.append(r)
    summary = {"samples": len(rows), "by_stage": {}, "overall": {}}

    def stats(vals):
        v = np.array([x for x in vals if x is not None], dtype=float)
        if not len(v):
            return None
        return {"mean": float(v.mean()), "median": float(np.median(v)), "p90": float(np.quantile(v, .9)),
                "p99": float(np.quantile(v, .99)), "max": float(v.max())}
    for f in SUMMARY_FIELDS:
        summary["overall"][f] = stats([r.get(f) for r in rows])
    for stg in sorted({r["stage"] for r in rows}):
        rs = [r for r in rows if r["stage"] == stg]
        summary["by_stage"][stg] = {"samples": len(rs), **{f: stats([r.get(f) for r in rs]) for f in SUMMARY_FIELDS}}
    if rows:
        import pyarrow as pa
        import pyarrow.parquet as pq
        flat = [{k: (json.dumps(v) if isinstance(v, (list, dict)) else v) for k, v in r.items()} for r in rows]
        keys = sorted({k for r in flat for k in r})
        pq.write_table(pa.table({k: [r.get(k) for r in flat] for k in keys}), run_dir / "raw" / "server_telemetry.parquet")
    (run_dir / "statistics").mkdir(parents=True, exist_ok=True)
    (run_dir / "statistics" / "server_resource_summary.json").write_text(json.dumps(summary, indent=2))
    with open(run_dir / "statistics" / "server_resource_summary.csv", "w") as fh:
        fh.write("stage,metric,mean,median,p90,p99,max\n")
        for stg, d in summary["by_stage"].items():
            for f in SUMMARY_FIELDS:
                s = d.get(f)
                if s:
                    fh.write(f"{stg},{f},{s['mean']:.4f},{s['median']:.4f},{s['p90']:.4f},{s['p99']:.4f},{s['max']:.4f}\n")
    return summary


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--root-pid", type=int, required=True)
    ap.add_argument("--interval", type=float, default=2.0)
    ap.add_argument("--gpu-every", type=int, default=1)
    ap.add_argument("--size-every", type=int, default=30)
    a = ap.parse_args(argv)
    run(Path(a.run_dir), a.root_pid, a.interval, a.gpu_every, a.size_every)
    return 0


if __name__ == "__main__":
    sys.exit(main())
