"""Append-only, hash-chained JSONL journals.

Each line is canonical JSON with fields `seq` (0-based, contiguous), `prev` (SHA-256 of the previous line's
bytes, or 64 zeros) and the record body. `AppendOnlyJournal.verify()` replays the chain; any edited, deleted,
reordered or torn line raises LedgerIntegrityError. Writers open the file in O_APPEND mode, fsync every line
and never rewrite. Callers that persist the head (checkpoints) can detect truncation via `verify(expect_head=...)`.
All records pass through the Redactor before serialization (no secret can be journaled).
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Iterator

from ...common.util import canonical_json, sha256_bytes
from ..errors import LedgerIntegrityError
from ..security.secrets import REDACTOR

GENESIS = "0" * 64


class AppendOnlyJournal:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._seq, self._head = self._scan()

    def _scan(self) -> tuple[int, str]:
        seq, head = 0, GENESIS
        for rec, line in self._iter_raw():
            if rec.get("seq") != seq or rec.get("prev") != head:
                raise LedgerIntegrityError(f"journal chain broken at line {seq + 1} of {self.path.name}")
            head = sha256_bytes(line)
            seq += 1
        return seq, head

    def _iter_raw(self) -> Iterator[tuple[dict, bytes]]:
        if not self.path.exists():
            return
        data = self.path.read_bytes()
        if data and not data.endswith(b"\n"):
            raise LedgerIntegrityError(f"torn final line in {self.path.name}")
        for i, line in enumerate(data.split(b"\n")[:-1] if data else []):
            try:
                rec = json.loads(line)
            except json.JSONDecodeError as e:
                raise LedgerIntegrityError(f"corrupt line {i + 1} in {self.path.name}") from e
            if canonical_json(rec).encode("utf-8") != line:
                raise LedgerIntegrityError(f"non-canonical (edited) line {i + 1} in {self.path.name}")
            yield rec, line

    @property
    def head(self) -> str:
        return self._head

    @property
    def length(self) -> int:
        return self._seq

    def append(self, body: dict) -> dict:
        clean = REDACTOR.redact(dict(body))
        for k in ("seq", "prev"):
            clean.pop(k, None)
        rec = {"seq": self._seq, "prev": self._head, **clean}
        line = canonical_json(rec).encode("utf-8")
        fd = os.open(str(self.path), os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
        try:
            os.write(fd, line + b"\n")
            os.fsync(fd)
        finally:
            os.close(fd)
        self._seq += 1
        self._head = sha256_bytes(line)
        return rec

    def records(self) -> list[dict]:
        return [r for r, _ in self._iter_raw()]

    def verify(self, expect_head: str | None = None, expect_min_length: int | None = None) -> tuple[int, str]:
        seq, head = self._scan()
        if expect_min_length is not None and seq < expect_min_length:
            raise LedgerIntegrityError(f"journal {self.path.name} truncated: {seq} < {expect_min_length} records")
        if expect_head is not None and expect_min_length is not None:
            # the head recorded at length L must still be the hash of line L-1
            recs = list(self._iter_raw())
            if sha256_bytes(recs[expect_min_length - 1][1]) != expect_head:
                raise LedgerIntegrityError(f"journal {self.path.name} rewritten before recorded head")
        return seq, head


class StructuredLog:
    """Operational JSONL log with stable fields. Scientific headline metrics are never logged."""

    FIELDS = ("ts", "run_id", "phase", "component", "namespace", "region_id", "feed_id", "status", "error_class",
              "duration_s", "event", "message", "output_hashes")
    FORBIDDEN_KEYS = frozenset({"hsr_witness", "hsr_repair", "delta_e2e_history", "delta_cost_history",
                                "f1_vs_n5", "f1_vs_n1"})

    def __init__(self, path: str | Path, run_id: str, namespace: str, clock) -> None:
        self.journal = AppendOnlyJournal(path)
        self.run_id = run_id
        self.namespace = namespace
        self.clock = clock

    def emit(self, event: str, *, phase: str | None = None, component: str | None = None,
             status: str | None = None, region_id: str | None = None, feed_id: str | None = None,
             error_class: str | None = None, duration_s: float | None = None, message: str | None = None,
             output_hashes: dict | None = None, **extra: object) -> dict:
        bad = self.FORBIDDEN_KEYS & {k.lower() for k in extra}
        if bad:
            raise ValueError(f"scientific headline metrics may not be logged: {sorted(bad)}")
        rec = {"ts": self.clock.now(), "run_id": self.run_id, "phase": phase, "component": component,
               "namespace": self.namespace, "region_id": region_id, "feed_id": feed_id, "status": status,
               "error_class": error_class,
               "duration_s": None if duration_s is None else round(float(duration_s), 6),
               "event": event, "message": message, "output_hashes": output_hashes or {}}
        if extra:
            rec["extra"] = extra
        return self.journal.append(rec)
