"""Run-state machine and its append-only ledger.

States: PENDING, RUNNING, COMPLETE, FAILED, BLOCKED.
Valid transitions:
  PENDING -> RUNNING
  RUNNING -> COMPLETE | FAILED | BLOCKED
  FAILED  -> RUNNING      (explicit resume attempt; attempt counter increments)
  BLOCKED -> RUNNING      (explicit resume attempt once the external precondition is satisfied)
COMPLETE is terminal. Everything else raises InvalidTransitionError.

A phase may only become COMPLETE with an `outputs` map of committed immutable output hashes (the orchestrator
commits outputs durably *before* recording COMPLETE). The current state of every phase is derived purely by
replaying the hash-chained ledger.
"""
from __future__ import annotations

import enum
from pathlib import Path

from ..errors import InvalidTransitionError
from .journal import AppendOnlyJournal


class PhaseState(str, enum.Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETE = "COMPLETE"
    FAILED = "FAILED"
    BLOCKED = "BLOCKED"


TRANSITIONS: dict[PhaseState, frozenset[PhaseState]] = {
    PhaseState.PENDING: frozenset({PhaseState.RUNNING}),
    PhaseState.RUNNING: frozenset({PhaseState.COMPLETE, PhaseState.FAILED, PhaseState.BLOCKED}),
    PhaseState.FAILED: frozenset({PhaseState.RUNNING}),
    PhaseState.BLOCKED: frozenset({PhaseState.RUNNING}),
    PhaseState.COMPLETE: frozenset(),
}


def check_transition(old: PhaseState, new: PhaseState) -> None:
    if new not in TRANSITIONS[old]:
        raise InvalidTransitionError(f"invalid transition {old.value} -> {new.value}")


class RunStateLedger:
    def __init__(self, path: str | Path, run_id: str, phases: list[str], clock) -> None:
        self.journal = AppendOnlyJournal(path)
        self.run_id = run_id
        self.phases = list(phases)
        self.clock = clock
        self._state: dict[str, PhaseState] = {p: PhaseState.PENDING for p in self.phases}
        self._attempts: dict[str, int] = {p: 0 for p in self.phases}
        self._last: dict[str, dict] = {}
        for rec in self.journal.records():
            self._apply(rec, validate=True)

    def _apply(self, rec: dict, validate: bool) -> None:
        if rec.get("run_id") != self.run_id:
            raise InvalidTransitionError(f"ledger record belongs to run {rec.get('run_id')}")
        ph = rec["phase"]
        if ph not in self._state:
            raise InvalidTransitionError(f"unknown phase {ph}")
        old, new = PhaseState(rec["from"]), PhaseState(rec["to"])
        if old != self._state[ph]:
            raise InvalidTransitionError(f"ledger replay mismatch for {ph}: {old.value} recorded, "
                                         f"{self._state[ph].value} derived")
        if validate:
            check_transition(old, new)
        if new == PhaseState.RUNNING:
            self._attempts[ph] += 1
        self._state[ph] = new
        self._last[ph] = rec

    def state(self, phase: str) -> PhaseState:
        return self._state[phase]

    def attempts(self, phase: str) -> int:
        return self._attempts[phase]

    def last(self, phase: str) -> dict | None:
        return self._last.get(phase)

    def snapshot(self) -> dict[str, str]:
        return {p: s.value for p, s in self._state.items()}

    def transition(self, phase: str, new: PhaseState, *, config_digest: str, implementation_id: str,
                   inputs: dict | None = None, outputs: dict | None = None, error: dict | None = None,
                   note: str | None = None) -> dict:
        if phase not in self._state:
            raise InvalidTransitionError(f"unknown phase {phase}")
        old = self._state[phase]
        check_transition(old, new)
        if new == PhaseState.COMPLETE and not outputs:
            raise InvalidTransitionError(f"{phase}: COMPLETE requires committed output hashes")
        if new == PhaseState.RUNNING:
            idx = self.phases.index(phase)
            for prior in self.phases[:idx]:
                if self._state[prior] != PhaseState.COMPLETE:
                    raise InvalidTransitionError(f"{phase} may not start: prior phase {prior} is "
                                                 f"{self._state[prior].value} (hard gate)")
        rec = {"run_id": self.run_id, "phase": phase, "from": old.value, "to": new.value,
               "attempt": self._attempts[phase] + (1 if new == PhaseState.RUNNING else 0),
               "ts": self.clock.now(), "config_digest": config_digest, "implementation_id": implementation_id,
               "inputs": inputs or {}, "outputs": outputs or {}, "error": error, "note": note}
        written = self.journal.append(rec)
        self._apply(written, validate=False)
        return written
