"""In-scope resource proof. Executed INSIDE the constrained process: `python3 proof.py OUT.json ENVELOPE.json JAVA`.
Records /proc/self/status Cpus_allowed_list, /proc/self/cgroup, the effective cgroup path(s), CPU quota, cpuset,
memory limit (re-read from the cgroup files the process actually belongs to), the JVM's final flags for the
envelope's JVM arguments (-XX:+PrintFlagsFinal), Java version, locale and timezone, and decides
resource_envelope_verified. Nothing is inferred from the intended command line.
Roots overridable for engineering tests: F1_WC_PROC_ROOT, F1_WC_CGROUP_ROOT."""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path


def _rd(p: Path) -> str:
    try:
        return p.read_text().strip()
    except OSError:
        return "UNREADABLE"


def _ncpus(s: str) -> int:
    n = 0
    for part in s.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-")
            n += int(b) - int(a) + 1
        else:
            n += 1
    return n


def collect(envelope: dict, java: str | None) -> dict:
    proc = Path(os.environ.get("F1_WC_PROC_ROOT", "/proc"))
    cg_root = Path(os.environ.get("F1_WC_CGROUP_ROOT", "/sys/fs/cgroup"))
    status = _rd(proc / "self" / "status")
    m = re.search(r"^Cpus_allowed_list:\s*(\S+)", status, re.M)
    allowed = m.group(1) if m else "UNREADABLE"
    cg_lines = _rd(proc / "self" / "cgroup").splitlines()
    ctrl = {}
    for ln in cg_lines:
        parts = ln.split(":", 2)
        if len(parts) == 3:
            for c in (parts[1].split(",") if parts[1] else [""]):
                ctrl[c] = parts[2]
    v2_path = ctrl.get("")
    is_v1 = any(c in ctrl for c in ("cpu", "memory", "cpuset"))
    if is_v1:
        cpu_d = cg_root / "cpu" / ctrl.get("cpu", "/").lstrip("/")
        mem_d = cg_root / "memory" / ctrl.get("memory", "/").lstrip("/")
        set_d = cg_root / "cpuset" / ctrl.get("cpuset", "/").lstrip("/")
        cpu_max = f"{_rd(cpu_d / 'cpu.cfs_quota_us')} {_rd(cpu_d / 'cpu.cfs_period_us')}"
        mem_max = _rd(mem_d / "memory.limit_in_bytes")
        cpuset = _rd(set_d / "cpuset.cpus")
        eff = {"cpu": str(cpu_d), "memory": str(mem_d), "cpuset": str(set_d)}
        mode = "cgroup-v1"
    else:
        d = cg_root / (v2_path or "/").lstrip("/")
        cpu_max, mem_max = _rd(d / "cpu.max"), _rd(d / "memory.max")
        cpuset = _rd(d / "cpuset.cpus.effective")
        eff = {"unified": str(d)}
        mode = "cgroup-v2"
    jvm, jver = {}, "UNAVAILABLE"
    if java:
        flags = list(envelope["jvm_flags"])
        try:
            cp = subprocess.run([java] + flags + ["-XX:+PrintFlagsFinal", "-version"], capture_output=True, text=True,
                                timeout=120)
            for ln in cp.stdout.splitlines():
                mm = re.match(r"\s*\S+\s+(ActiveProcessorCount|InitialHeapSize|MaxHeapSize|UseG1GC)\s+:?=\s+(\S+)", ln)
                if mm:
                    jvm[mm.group(1)] = mm.group(2)
            jver = (cp.stderr.strip().splitlines() or ["UNAVAILABLE"])[0]
        except (OSError, subprocess.TimeoutExpired) as e:
            jver = f"FAILED: {e}"
    exp_q, exp_p = envelope["cpu_quota_us"], envelope["cpu_period_us"]
    parts = cpu_max.split()
    cpu_ok = len(parts) == 2 and parts[0] == str(exp_q) and parts[1] == str(exp_p)
    mem_ok = mem_max == str(envelope["memory_max_bytes"])
    set_ok = allowed != "UNREADABLE" and _ncpus(allowed) == envelope["cpus"] and \
        (cpuset == "UNREADABLE" or _ncpus(cpuset) == envelope["cpus"])
    xms = xmx = None
    for f in envelope["jvm_flags"]:
        if f.startswith("-Xms"):
            xms = f[4:]
        if f.startswith("-Xmx"):
            xmx = f[4:]

    def b(s):
        if s is None:
            return None
        mult = {"k": 1024, "m": 1024 ** 2, "g": 1024 ** 3}.get(s[-1].lower(), 1)
        return str(int(s[:-1]) * mult if s[-1].isalpha() else int(s))
    apc = next((f.split("=")[1] for f in envelope["jvm_flags"] if f.startswith("-XX:ActiveProcessorCount=")), None)
    jvm_ok = bool(jvm) and jvm.get("ActiveProcessorCount") == apc and jvm.get("MaxHeapSize") == b(xmx) and \
        jvm.get("InitialHeapSize") == b(xms) and jvm.get("UseG1GC") == ("true" if "-XX:+UseG1GC" in envelope["jvm_flags"] else "false")
    return {"schema": "F1-WC-TARGET-RESOURCE-RUNTIME-PROOF-1", "envelope_name": envelope["name"],
            "envelope_authoritative": envelope["authoritative"], "pid": os.getpid(), "cgroup_mode": mode,
            "proc_self_cgroup": cg_lines, "effective_cgroup_paths": eff, "cpu.max": cpu_max, "memory.max": mem_max,
            "cpuset.cpus.effective": cpuset, "Cpus_allowed_list": allowed, "visible_cpus": os.cpu_count(),
            "java_version": jver, "jvm_arguments": list(envelope["jvm_flags"]), "jvm_final_flags": jvm,
            "locale": {k: os.environ.get(k) for k in ("LANG", "LC_ALL")}, "timezone": os.environ.get("TZ"),
            "cpu_quota_ok": cpu_ok, "memory_max_ok": mem_ok, "cpuset_ok": set_ok, "jvm_ok": jvm_ok,
            "resource_envelope_verified": cpu_ok and mem_ok and set_ok and jvm_ok}


def prove_in_scope(manager, env, job: str, java: str | None = None, workdir: Path | None = None) -> dict:
    """Open a scope with the manager's backend, run this module INSIDE it, return the proof read back."""
    backend = manager.select()
    wd = Path(workdir or tempfile.mkdtemp(prefix="f1wc-proof-"))
    envp, outp = wd / "envelope.json", wd / "TARGET_RESOURCE_RUNTIME_PROOF.json"
    envp.write_text(json.dumps(env.to_dict()))
    with backend.open(env, job) as scope:
        argv = scope.wrapper + [sys.executable, str(Path(__file__)), str(outp), str(envp), java or ""]
        cp = subprocess.run(argv, capture_output=True, text=True, timeout=600,
                            env={"PATH": os.environ.get("PATH", ""), "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "TZ": "UTC",
                                 **{k: os.environ[k] for k in ("F1_WC_PROC_ROOT", "F1_WC_CGROUP_ROOT") if k in os.environ}})
    if cp.returncode != 0 or not outp.exists():
        return {"resource_envelope_verified": False, "backend": backend.name, "error": cp.stderr[-2000:]}
    res = json.loads(outp.read_text())
    res["backend"] = backend.name
    if backend.name == "noop-fixture":
        res["resource_envelope_verified"] = False         # no enforcement can never verify
        res["note"] = "noop backend: no enforcement"
    return res


if __name__ == "__main__":
    out, envf, java = sys.argv[1], sys.argv[2], (sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] else None)
    Path(out).write_text(json.dumps(collect(json.loads(Path(envf).read_text()), java), indent=1, sort_keys=True))
