"""Resource manager: capability detection and enforcement backends (Session 2).

Backends (selected by capability, never by distribution name):
  SystemdRunBackend  systemd-run --scope -p MemoryMax= -p CPUQuota= -p AllowedCPUs= (properties feature-detected)
  CgroupV2Backend    <root>/<job>/{cpu.max, memory.max, cpuset.cpus, cpuset.mems}; process attached via cgroup.procs
  CgroupV1Backend    <root>/{cpu,memory,cpuset}/<job>/{cpu.cfs_period_us, cpu.cfs_quota_us, memory.limit_in_bytes,
                     cpuset.cpus, cpuset.mems}; process attached via tasks
  NoopFixtureBackend no enforcement (FIXTURE only; a proof under it can never verify)
taskset alone is never accepted as enforcement (frozen: "taskset-only => BLOCKED").
Every limit actually applied is re-read from INSIDE the constrained process by `resources/proof.py`.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path

from ..config.spec import ProtocolSpec
from ..errors import WCError

ATTACH = Path(__file__).with_name("attach.py")


class ResourceEnforcementUnavailable(WCError):
    error_class = "RESOURCE_ENFORCEMENT_UNAVAILABLE"


def _parse_mem(s: str) -> int:
    m = re.fullmatch(r"(\d+)([KMGT]?)", s.strip().upper())
    if not m:
        raise ValueError(f"bad memory size {s!r}")
    return int(m.group(1)) * {"": 1, "K": 1024, "M": 1024 ** 2, "G": 1024 ** 3, "T": 1024 ** 4}[m.group(2)]


def _ncpus(cpuset: str) -> int:
    n = 0
    for part in cpuset.split(","):
        if "-" in part:
            a, b = part.split("-")
            n += int(b) - int(a) + 1
        elif part.strip():
            n += 1
    return n


@dataclass(frozen=True)
class ResourceEnvelope:
    name: str                     # OTP_AUTHORITATIVE | SANDBOX_NON_TARGET | ...
    component: str
    cpus: int
    cpuset: str
    cpu_quota_us: int
    cpu_period_us: int
    memory_max_bytes: int
    jvm_flags: tuple[str, ...]
    authoritative: bool

    def to_dict(self) -> dict:
        d = asdict(self)
        d["jvm_flags"] = list(self.jvm_flags)
        return d

    def expected_heap_bytes(self) -> tuple[int | None, int | None]:
        xms = xmx = None
        for f in self.jvm_flags:
            if f.startswith("-Xms"):
                xms = _parse_mem(f[4:])
            if f.startswith("-Xmx"):
                xmx = _parse_mem(f[4:])
        return xms, xmx


def otp_authoritative_envelope(spec: ProtocolSpec, cpuset: str = "0-7") -> ResourceEnvelope:
    p = spec["producers"]
    if _ncpus(cpuset) != p["otp_cpus"]:
        raise ValueError(f"cpuset {cpuset} does not provide exactly {p['otp_cpus']} cpus (no selective resizing)")
    period = 100000
    return ResourceEnvelope("OTP_AUTHORITATIVE", "otp", p["otp_cpus"], cpuset, p["otp_cpu_quota_percent"] * period // 100,
                            period, _parse_mem(p["otp_memory_max"]), tuple(p["otp_jvm_flags"]), True)


def sandbox_envelope(cpus: int = 1, cpuset: str = "0", memory: str = "1G", heap: str = "256m") -> ResourceEnvelope:
    """NON-AUTHORITATIVE envelope for engineering tests on small hosts; never acceptable for scientific execution."""
    return ResourceEnvelope("SANDBOX_NON_TARGET", "test", cpus, cpuset, 50000 * cpus, 100000, _parse_mem(memory),
                            (f"-XX:ActiveProcessorCount={cpus}", f"-Xms{heap}", f"-Xmx{heap}", "-XX:+UseG1GC",
                             "-Duser.timezone=UTC"), False)


@dataclass
class Capabilities:
    cgroup_root: str
    cgroup_fs: str
    v2_writable: bool
    v1_writable: dict
    systemd_run: bool
    systemd_properties: list = field(default_factory=list)
    taskset: bool = False
    detail: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


def _fs_type(root: Path) -> str:
    try:
        out = subprocess.run(["stat", "-fc", "%T", str(root)], capture_output=True, text=True, timeout=10).stdout.strip()
        return out or "unknown"
    except (OSError, subprocess.TimeoutExpired):
        return "unknown"


def detect_capabilities(cgroup_root: str | Path = "/sys/fs/cgroup", probe_systemd: bool = True,
                        fs_type: str | None = None) -> Capabilities:
    root = Path(cgroup_root)
    fst = fs_type or _fs_type(root)
    v2 = False
    if (root / "cgroup.controllers").exists() and fst in ("cgroup2fs", "cgroup2") and os.access(root, os.W_OK):
        ctrl = (root / "cgroup.controllers").read_text().split()
        v2 = {"cpu", "memory", "cpuset"} <= set(ctrl)
    v1 = {c: (root / c).is_dir() and os.access(root / c, os.W_OK) for c in ("cpu", "memory", "cpuset")}
    sd, props = False, []
    if probe_systemd and shutil.which("systemd-run"):
        for prop in ("MemoryMax=1G", "CPUQuota=100%", "AllowedCPUs=0"):
            try:
                r = subprocess.run(["systemd-run", "--scope", "--quiet", "-p", prop, "true"], capture_output=True,
                                   timeout=20)
                if r.returncode == 0:
                    props.append(prop.split("=")[0])
            except (OSError, subprocess.TimeoutExpired):
                pass
        sd = set(props) == {"MemoryMax", "CPUQuota", "AllowedCPUs"}
    return Capabilities(str(root), fst, v2, v1, sd, props, bool(shutil.which("taskset")))


class Scope:
    def __init__(self, backend: str, wrapper: list[str], paths: dict, teardown) -> None:
        self.backend, self.wrapper, self.paths, self._teardown = backend, wrapper, paths, teardown

    def close(self) -> None:
        if self._teardown:
            self._teardown()
            self._teardown = None

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


_SEQ = [0]


def _unique(job: str) -> str:
    _SEQ[0] += 1
    return f"f1wc_{job}_{os.getpid()}_{_SEQ[0]}"


def _write(p: Path, v: str) -> None:
    with open(p, "w") as f:
        f.write(v)


class CgroupV2Backend:
    name = "cgroup-v2"

    def __init__(self, root: str | Path = "/sys/fs/cgroup") -> None:
        self.root = Path(root)

    def open(self, env: ResourceEnvelope, job: str) -> Scope:
        d = self.root / _unique(job)
        d.mkdir(exist_ok=False)
        _write(d / "cpu.max", f"{env.cpu_quota_us} {env.cpu_period_us}")
        _write(d / "memory.max", str(env.memory_max_bytes))
        _write(d / "cpuset.cpus", env.cpuset)
        mems = (self.root / "cpuset.mems.effective")
        if mems.exists():
            _write(d / "cpuset.mems", mems.read_text().strip())
        wrapper = [sys.executable, str(ATTACH), "--v2", str(d), "--"]
        return Scope(self.name, wrapper, {"cgroup": str(d)}, lambda: _rmdir_quiet([d]))


class CgroupV1Backend:
    name = "cgroup-v1"

    def __init__(self, root: str | Path = "/sys/fs/cgroup") -> None:
        self.root = Path(root)

    def open(self, env: ResourceEnvelope, job: str) -> Scope:
        n = _unique(job)
        ds = {c: self.root / c / n for c in ("cpu", "memory", "cpuset")}
        for d in ds.values():
            d.mkdir(exist_ok=False)
        _write(ds["cpu"] / "cpu.cfs_period_us", str(env.cpu_period_us))
        _write(ds["cpu"] / "cpu.cfs_quota_us", str(env.cpu_quota_us))
        _write(ds["memory"] / "memory.limit_in_bytes", str(env.memory_max_bytes))
        if (ds["memory"] / "memory.memsw.limit_in_bytes").exists():
            try:
                _write(ds["memory"] / "memory.memsw.limit_in_bytes", str(env.memory_max_bytes))
            except OSError:
                pass
        _write(ds["cpuset"] / "cpuset.cpus", env.cpuset)
        parent_mems = self.root / "cpuset" / "cpuset.mems"
        _write(ds["cpuset"] / "cpuset.mems", parent_mems.read_text().strip() if parent_mems.exists() else "0")
        wrapper = [sys.executable, str(ATTACH), "--v1"] + [f"{c}={d}" for c, d in ds.items()] + ["--"]
        return Scope(self.name, wrapper, {c: str(d) for c, d in ds.items()}, lambda: _rmdir_quiet(list(ds.values())))


class SystemdRunBackend:
    name = "systemd-run"

    def open(self, env: ResourceEnvelope, job: str) -> Scope:
        w = ["systemd-run", "--scope", "--quiet", f"--unit=f1wc-{job}", "-p", f"MemoryMax={env.memory_max_bytes}",
             "-p", f"CPUQuota={env.cpu_quota_us * 100 // env.cpu_period_us}%", "-p", f"AllowedCPUs={env.cpuset}"]
        return Scope(self.name, w, {"unit": f"f1wc-{job}"}, None)


class NoopFixtureBackend:
    name = "noop-fixture"

    def open(self, env: ResourceEnvelope, job: str) -> Scope:
        return Scope(self.name, [], {}, None)


def _rmdir_quiet(ds: list[Path]) -> None:
    for d in ds:
        try:
            d.rmdir()
        except OSError:
            pass


class ResourceManager:
    """Concrete ResourceManager. `select()` picks systemd-run > cgroup v2 > cgroup v1; FIXTURE may fall back to
    Noop; taskset-only hosts are refused (ResourceEnforcementUnavailable)."""

    def __init__(self, caps: Capabilities, allow_noop: bool = False) -> None:
        self.caps = caps
        self.allow_noop = allow_noop

    def select(self):
        c = self.caps
        if c.systemd_run:
            return SystemdRunBackend()
        if c.v2_writable:
            return CgroupV2Backend(c.cgroup_root)
        if all(c.v1_writable.values()):
            return CgroupV1Backend(c.cgroup_root)
        if self.allow_noop:
            return NoopFixtureBackend()
        reason = "taskset-only host" if c.taskset else "no resource control"
        raise ResourceEnforcementUnavailable(
            f"{reason}: no systemd-run scope, no writable cgroup v2, no writable cgroup v1 (taskset alone is not accepted)")

    # Session-1 protocol compatibility --------------------------------------------------------------------------
    def lease(self, component: str) -> dict:
        return {"component": component, "backend": self.select().name}

    def prove_target(self, envelope: dict):
        from .proof import prove_in_scope
        from ..interfaces.protocols import ConformanceResult
        env = ResourceEnvelope(**{**envelope, "jvm_flags": tuple(envelope["jvm_flags"])})
        res = prove_in_scope(self, env, job="proof")
        return ConformanceResult("resource-proof", "PASS" if res["resource_envelope_verified"] else "BLOCKED", {}, False,
                                 res)


def write_envelope(env: ResourceEnvelope, path: Path) -> None:
    path.write_text(json.dumps(env.to_dict(), sort_keys=True, indent=1))
