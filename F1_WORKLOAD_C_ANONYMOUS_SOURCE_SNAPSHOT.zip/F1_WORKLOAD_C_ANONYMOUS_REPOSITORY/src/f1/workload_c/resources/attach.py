#!/usr/bin/env python3
"""Attach this process to the given cgroup(s), then exec the target argv (no shell).
  attach.py --v2 <cgroup dir> -- argv...
  attach.py --v1 cpu=<dir> memory=<dir> cpuset=<dir> -- argv..."""
import os
import sys


def main(a: list) -> None:
    sep = a.index("--")
    mode, targets, argv = a[0], a[1:sep], a[sep + 1:]
    pid = str(os.getpid())
    if mode == "--v2":
        with open(os.path.join(targets[0], "cgroup.procs"), "w") as f:
            f.write(pid)
    elif mode == "--v1":
        for t in targets:
            _, d = t.split("=", 1)
            with open(os.path.join(d, "tasks"), "w") as f:
                f.write(pid)
    else:
        raise SystemExit("bad mode")
    os.execvp(argv[0], argv)


if __name__ == "__main__":
    main(sys.argv[1:])
