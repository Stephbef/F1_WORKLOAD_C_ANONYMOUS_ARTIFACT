"""Per-phase execution context and output helpers used by phase implementations."""
from __future__ import annotations

import csv
import io
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ...common.util import atomic_write_bytes, canonical_json
from ..config.runtime import EffectiveConfig
from ..security.secrets import REDACTOR, SecretProvider
from ..state.journal import StructuredLog
from ..storage.blobstore import BlobStore, ManifestStore, SnapshotStore


@dataclass
class PhaseContext:
    cfg: EffectiveConfig
    run_id: str
    run_dir: Path
    phase_id: str
    blobs: BlobStore
    manifests: ManifestStore
    snapshots: SnapshotStore
    log: StructuredLog
    clock: Any
    secrets: SecretProvider | None
    adapters: dict
    services: dict
    implementation_id: str
    prior_outputs: dict = field(default_factory=dict)     # phase_id -> {relpath: sha256}
    written: dict = field(default_factory=dict)           # relpath -> True (outputs of this phase)

    @property
    def namespace(self) -> str:
        return self.cfg.namespace

    @property
    def mode(self) -> str:
        return self.cfg.mode

    @property
    def phase_dir(self) -> Path:
        return self.run_dir / "phases" / self.phase_id

    def rel(self, name: str) -> str:
        return f"phases/{self.phase_id}/{name}"

    # writers (atomic; content passes the redactor for text formats) --------------------------------------
    def write_bytes(self, name: str, data: bytes) -> str:
        atomic_write_bytes(self.phase_dir / name, data)
        r = self.rel(name)
        self.written[r] = True
        return r

    def write_json(self, name: str, obj: Any) -> str:
        return self.write_bytes(name, (json.dumps(REDACTOR.redact(obj), indent=2, sort_keys=True,
                                                  ensure_ascii=False) + "\n").encode("utf-8"))

    def write_jsonl(self, name: str, rows: list) -> str:
        return self.write_bytes(name, "".join(canonical_json(REDACTOR.redact(r)) + "\n" for r in rows).encode("utf-8"))

    def write_csv(self, name: str, rows: list[dict], fields: list[str]) -> str:
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=fields, lineterminator="\n", extrasaction="raise")
        w.writeheader()
        for r in rows:
            w.writerow({k: REDACTOR.redact_text(str(r.get(k, ""))) if r.get(k) is not None else "" for k in fields})
        return self.write_bytes(name, buf.getvalue().encode("utf-8"))

    # readers of prior phase outputs (hash-verified) -------------------------------------------------------
    def prior_path(self, phase_id: str, name: str) -> Path:
        rel = f"phases/{phase_id}/{name}"
        outs = self.prior_outputs.get(phase_id)
        if outs is None or rel not in outs:
            raise KeyError(f"{rel} is not a committed output of {phase_id}")
        from ...common.util import sha256_file
        from ..errors import CheckpointIntegrityError
        p = self.run_dir / rel
        if sha256_file(p) != outs[rel]:
            raise CheckpointIntegrityError(f"committed output changed since commit: {rel}")
        return p

    def read_prior_json(self, phase_id: str, name: str) -> Any:
        return json.loads(self.prior_path(phase_id, name).read_text(encoding="utf-8"))

    def read_prior_jsonl(self, phase_id: str, name: str) -> list:
        return [json.loads(x) for x in self.prior_path(phase_id, name).read_text(encoding="utf-8").splitlines() if x]

    def read_prior_csv(self, phase_id: str, name: str) -> list[dict]:
        with open(self.prior_path(phase_id, name), newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))
