"""Session-4A.1 fixture for the baseline traces (SYNTHETIC non-study feeds; ENGINEERING FIXTURE ONLY).

Region R:S4 (feeds A, B; America/Los_Angeles). Versions: A1 (day 1 00:10 local), B1 (day 1 00:20), A2 = changed
stop_times (day 2 03:00), A3 = SAME content as A1 (day 4 03:00) → A1→B→A2 style recurrence (A1 → A' → A1-content).
Consumer ticks 06:00 local on days 1–6. Frozen schedule (validator at availability, OTP 02:00, SCH-01).
"""
from __future__ import annotations

import shutil
from pathlib import Path

from ..config.spec import load_protocol_spec
from ..contracts.generators import ContractSystem
from ..engines.baselines_n import FixtureNativeOtpBuilder
from ..engines.baselines_s4 import S4BaselineRunner
from ..engines.core import CutContextFactoryImpl, InProcessFixtureProducer, RegionState, VersionInfo
from ..engines.runner import RegionCampaign
from ..ingestion.gtfs import canonical_content_hash
from ..interfaces import session3 as S
from ..scheduler.workload_c import FixtureDurationBackend, RegionScheduleInput, VersionAvailability, simulate
from ..storage.blobstore import BlobStore
from .e2e_s3 import TZ, _feed

AVAIL = {("A", 1): "2025-06-10T07:10:00Z", ("B", 1): "2025-06-10T07:20:00Z", ("A", 2): "2025-06-11T10:00:00Z",
         ("A", 3): "2025-06-13T10:00:00Z"}
TICKS = [f"2025-06-{d:02d}T13:00:00Z" for d in range(10, 16)]
WINDOW = ("2025-06-10T07:00:00Z", "2025-06-16T07:00:00Z")


def build(out: Path, outcomes: dict | None = None):
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    spec = load_protocol_spec()
    names = spec.gtfs_member_names
    blobs = BlobStore(out / "store")
    content = {("A", 1): _feed("A"), ("B", 1): _feed("B"), ("A", 2): _feed("A", headway_min=20), ("A", 3): _feed("A")}
    versions = {}
    for (f, i), z in content.items():
        ref = blobs.put(z, "application/zip", provenance={"fixture": f"S4/{f}{i}", "namespace": "FIXTURE"})
        versions[(f, i)] = VersionInfo(f, i, f"{f}#L{i}", canonical_content_hash(z, names), ref.sha256, AVAIL[(f, i)])
    region = RegionState("R:S4", TZ, ("A", "B"), versions, "osm:fixture", "semcfg:fixture", "otp:fixture-stub",
                         "validator:fixture-stub", "US", blobs)
    rin = RegionScheduleInput("R:S4", TZ, ("A", "B"),
                              tuple(VersionAvailability(v.feed_id, v.index, v.logical_version_id, v.available_utc)
                                    for v in sorted(versions.values(), key=lambda v: (v.available_utc, v.feed_id))),
                              *WINDOW)
    sched = simulate(spec, rin, FixtureDurationBackend())
    cs = ContractSystem(blobs, names)
    ctxf = CutContextFactoryImpl(region)

    def pf():
        return InProcessFixtureProducer(region, cs, ctxf, outcomes=outcomes)
    camp = RegionCampaign(region, sched.events, cs, pf, S.RunIdentityRecord("e2e-s4a1", "FIXTURE", "fixture", "fixture"),
                          out / "campaign", native_builder=FixtureNativeOtpBuilder(out / "n1"),
                          analysis_window_start=WINDOW[0])
    camp.produce_shared(max(TICKS))
    return camp, S4BaselineRunner(camp, pf)
