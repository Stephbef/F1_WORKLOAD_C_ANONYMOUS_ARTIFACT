"""Orchestrator Phases 11 and 13–16 wired to the real Session-3 engines.

FIXTURE mode runs the synthetic fixture population with deterministic in-process FIXTURE_STUB producers over a fixture
campaign window (consumer ticks on the FIXTURE dates); REAL mode stays refused earlier (Session 4 / L28 / PI gates).
Every output carries the fixture marker; no scientific result is produced.
"""
from __future__ import annotations

import json

from ... import workload_c
from ..config.spec import load_protocol_spec
from ..contracts.generators import ContractSystem
from ..engines.baselines_n import FixtureNativeOtpBuilder
from ..engines.core import CutContextFactoryImpl, InProcessFixtureProducer, RegionState, VersionInfo, local_date
from ..engines.mutation import FAMILIES, MutationEngineImpl, MutationSubjectStore, RouterSubject, ValSubject
from ..engines.replay import ReplayEngineImpl
from ..engines.runner import RegionCampaign
from ..engines.stats import FrozenAnalysisImpl, record_to_json
from ..errors import NamespaceViolation, PhaseFailed
from ..interfaces import session3 as S
from ..scheduler.workload_c import FixtureDurationBackend, RegionScheduleInput, VersionAvailability, simulate

FIXTURE_TICK_DATES = ("2025-06-03", "2025-11-04", "2026-03-03")
WINDOW = ("2025-04-01T00:00:00Z", "2026-03-05T00:00:00Z")


def _region_state(ctx, rid: str) -> RegionState:
    regs = {r["region_id"]: r for r in ctx.read_prior_json("05_eligible_regions", "regions.json")["regions"]}
    reg = regs[rid]
    feeds = tuple(sorted(f["feed_id"] for f in reg["feeds"]))
    lvs = [v for v in ctx.read_prior_jsonl("03_logical_versions", "logical_versions.jsonl") if v["feed_id"] in feeds]
    versions = {(v["feed_id"], v["index"]): VersionInfo(v["feed_id"], v["index"], v["logical_version_id"],
                                                        v["canonical_content_sha256"], v["raw_zip_sha256s"][0],
                                                        v["first_observed_utc"]) for v in lvs}
    pins = {p["region_id"]: p for p in ctx.read_prior_json("08_osm_pinning", "osm_pins.json")["pins"]}
    osm = str(pins.get(rid, {}).get("osm_sha256", "osm:fixture"))
    ns = "FIXTURE" if ctx.mode == "FIXTURE" else ctx.namespace
    return RegionState(rid, reg["timezone"] or "UTC", feeds, versions, osm, "semcfg:" + ctx.cfg.digest[:16],
                       "otp:fixture-stub", "validator:fixture-stub", "XX", ctx.blobs, ns)


def _campaign(ctx, rid: str, partition: str):
    spec = load_protocol_spec()
    r = _region_state(ctx, rid)
    rin = RegionScheduleInput(rid, r.tz, r.feeds, tuple(VersionAvailability(v.feed_id, v.index, v.logical_version_id,
                                                                            v.available_utc)
                                                        for v in sorted(r.versions.values(),
                                                                        key=lambda v: (v.available_utc, v.feed_id))),
                              *WINDOW)
    sched = simulate(spec, rin, FixtureDurationBackend())
    ticks = [e["t"] for e in sched.events if e["kind"] == "CONSUMER_TICK" and e["local_date"] in FIXTURE_TICK_DATES]
    cs = ContractSystem(ctx.blobs, spec.gtfs_member_names)
    ctxf = CutContextFactoryImpl(r)
    out = ctx.phase_dir / "regions" / rid.replace(":", "_").replace("+", "_")
    run = S.RunIdentityRecord(ctx.run_id, r.namespace, ctx.implementation_id, ctx.cfg.digest)
    camp = RegionCampaign(r, sched.events, cs, lambda: InProcessFixtureProducer(r, cs, ctxf), run, out,
                          native_builder=FixtureNativeOtpBuilder(out / "n1"), analysis_window_start=WINDOW[0])
    recs = camp.run(ticks) if ticks else []
    led = camp.seal()
    return camp, recs, led


def _rows(recs, partition: str, ns: str) -> list[dict]:
    out = []
    for r in recs:
        j = record_to_json(r)
        out.append({"record_id": r.record_digest[:32], "namespace": ns, "partition": partition,
                    "region_id": r.region_id, "marker": workload_c.FIXTURE_MARKER, "record": j})
    return out


def run_partition_s3(ctx, region_ids: list[str], partition: str, ns: str) -> tuple[list[dict], dict, dict]:
    rows, ledgers, camps = [], {}, {}
    for rid in region_ids:
        camp, recs, led = _campaign(ctx, rid, partition)
        rows += _rows(recs, partition, ns)
        ledgers[rid] = led
        camps[rid] = camp
    return rows, ledgers, camps


def ledger_to_json(led: S.SealedLedger) -> dict:
    return {"history_journal_sha256": led.history_journal_sha256, "catalog_journal_sha256s": [list(x) for x in
                                                                                             led.catalog_journal_sha256s],
            "contracts_sha256": led.contracts_sha256, "raw_export_sha256": led.raw_export_sha256,
            "cost_ledger_sha256": led.cost_ledger_sha256, "paths": [list(x) for x in led.paths]}


def ledger_from_json(d: dict) -> S.SealedLedger:
    return S.SealedLedger(d["history_journal_sha256"], tuple(tuple(x) for x in d["catalog_journal_sha256s"]),
                          d["contracts_sha256"], d["raw_export_sha256"], d["cost_ledger_sha256"],
                          tuple(tuple(x) for x in d["paths"]))


def phase11_validation(ctx) -> dict:
    rows = ctx.read_prior_csv("07_split_8_16", "validation_8.csv")
    ns = "VALIDATION" if ctx.mode == "REAL" else "FIXTURE"
    for r in rows:
        if r["namespace"] != ns:
            raise NamespaceViolation(f"validation region {r['region_id']} has namespace {r['namespace']}")
    recs, ledgers, _ = run_partition_s3(ctx, [r["region_id"] for r in rows], "validation", ns)
    ctx.write_jsonl("validation_raw.jsonl", recs)
    ctx.write_json("validation_ledgers.json", {rid: ledger_to_json(v) for rid, v in sorted(ledgers.items())})
    return {"n_records": len(recs), "n_regions": len(rows), "engine": "REAL_S3"}


def _mutations(ctx, camps: dict, canon_ref=None, val_ref=None) -> tuple[dict, list[dict]]:
    """Mutation sample per template over the campaign's shared artifacts. Comparison reference verdicts come ONLY from
    the authoritative reference paths (Canon_D for ROUTER, validator re-run for VAL). In FIXTURE mode with
    FIXTURE_STUB producers no reference path exists (no pinned OTP/OSM for the synthetic population), so every
    comparison carries reference None and the engine fails closed (INVALID_MUTATION, explicit reason) — a canonical
    hash is never substituted for Canon_D."""
    cls: dict = {}
    subj: dict = {}
    for camp in camps.values():
        r = camp.r
        for slot in camp.shared.slots():
            for e in camp.shared.instances(slot):
                if e.artifact_class == "ROUTER":
                    born = camp.shared_born[e.artifact_id]
                    D = list(CutContextFactoryImpl(r).context_for(_cut(r, e.birth_frontier), born).horizon)
                    feeds = {f: r.blobs.get(r.versions[(f, i)].raw_zip_sha256) for f, i in e.birth_frontier}
                    comps = []
                    for f, i in e.birth_frontier:
                        if (f, i + 1) in r.versions:
                            fb = {**feeds, f: r.blobs.get(r.versions[(f, i + 1)].raw_zip_sha256)}
                            ref = canon_ref.verdict(feeds, fb, D) if canon_ref is not None else None
                            comps.append((fb, D, ref, f"{f}:{i}->{i + 1}"))
                    cls[e.artifact_id], subj[e.artifact_id] = "ROUTER", RouterSubject(feeds, D, comps)
                else:
                    (f, i), = e.birth_frontier
                    z = r.blobs.get(r.versions[(f, i)].raw_zip_sha256)
                    d = local_date(camp.shared_born[e.artifact_id], r.tz).isoformat()
                    cls[e.artifact_id] = "VAL_REPORT"
                    other_d = "1999-01-01"
                    from ..engines.mutation import replace_member
                    zf = replace_member(z, "agency.txt", lambda b: b.replace(b"https://", b"not-a-url://"))
                    vcomps = [(z, other_d, val_ref.verdict(z, d, z, other_d) if val_ref else None, "date"),
                              (zf, d, val_ref.verdict(z, d, zf, d) if val_ref else None, "file:agency.txt")]
                    subj[e.artifact_id] = ValSubject(z, d, vcomps)
    eng = MutationEngineImpl(MutationSubjectStore(cls, subj), canon_reference=canon_ref)
    plans, results = {}, []
    for template in ("ROUTER", "VAL_REPORT"):
        ids = tuple(sorted(a for a, c in cls.items() if c == template))
        if not ids:
            continue
        plan = eng.plan(S.MutationPopulation(template, ids))
        plans[template] = {"n": len(ids), "selected": list(plan.selected), "families": list(plan.families)}
        for aid in plan.selected:
            for fam in FAMILIES:
                m = eng.apply(aid, fam)
                results.append({**m.__dict__, "template": template, "marker": workload_c.FIXTURE_MARKER})
    return plans, results


def _cut(r: RegionState, frontier):
    from ..history.realized import Cut
    return Cut.of(r.region_id, dict(frontier))


def phase13_campaign(ctx, rows_csv, ns) -> dict:
    recs, ledgers, camps = run_partition_s3(ctx, [r["region_id"] for r in rows_csv], "test", ns)
    ctx.write_jsonl("test_raw.jsonl", recs)
    ctx.write_json("test_ledgers.json", {rid: ledger_to_json(v) for rid, v in sorted(ledgers.items())})
    plans, results = _mutations(ctx, camps)
    ctx.write_json("mutation_plan.json", {"marker": workload_c.FIXTURE_MARKER, "plans": plans,
                                          "reference_paths": "UNAVAILABLE_IN_FIXTURE_STUB_MODE (fail closed)"})
    ctx.write_jsonl("mutation_results.jsonl", results)
    return {"n_records": len(recs), "n_regions": len(rows_csv), "n_mutations": len(results), "engine": "REAL_S3"}


def phase14_reconcile(ctx) -> dict:
    spec = load_protocol_spec()
    leds = ctx.read_prior_json("13_scientific_test_campaign", "test_ledgers.json")
    eng = ReplayEngineImpl(spec.gtfs_member_names)
    items, bad = [], []
    for rid, lj in sorted(leds.items()):
        rep = eng.replay(ledger_from_json(lj), ())
        for it in rep.items:
            items.append({"region_id": rid, "record_digest": it.record_digest, "status": it.status})
            if it.status != "REPRODUCED":
                bad.append({"region_id": rid, "detail": it.detail})
    n_raw = len(ctx.read_prior_jsonl("13_scientific_test_campaign", "test_raw.jsonl"))
    if bad or len(items) != n_raw:
        raise PhaseFailed(f"reconciliation: {len(bad)} not reproduced; replayed {len(items)} of {n_raw}")
    ctx.write_json("reconciliation.json", {"replayed": len(items), "expected": n_raw, "mismatches": [],
                                           "namespace": ctx.namespace, "engine": "REAL_S3"})
    ctx.write_jsonl("replay_items.jsonl", items)
    return {"replayed": len(items)}


def phase16_statistics(ctx, recs: list[dict], ns: str) -> dict:
    if any(r["partition"] != "test" for r in recs):
        raise NamespaceViolation("non-test partition record in test statistics input")
    rep = FrozenAnalysisImpl().run([r["record"] for r in recs], ns)
    desc = FrozenAnalysisImpl().descriptive([r["record"] for r in recs])
    ctx.write_json("descriptive_analysis.json", {"marker": workload_c.FIXTURE_MARKER, "namespace": ns, **desc,
                                                 "note": "descriptive only; NOT a Holm hypothesis"})
    doc = {"marker": workload_c.FIXTURE_MARKER, "namespace": rep.namespace, "raw_export_sha256": rep.raw_export_sha256,
           "n_units": sum(1 for _ in {(r["record"]["region_id"], tuple(u)) for r in recs
                                      for u in r["record"]["root_changes"]}),
           "per_region": {rid: dict(v) for rid, v in rep.per_region},
           "hypotheses": [h.__dict__ for h in rep.hypotheses], "scientific_results": "NONE (FIXTURE)",
           "engine": "REAL_S3"}
    ctx.write_json("statistics_report.json", json.loads(json.dumps(doc, default=list)))
    return {"n_units": doc["n_units"], "n_hypotheses": len(rep.hypotheses)}

