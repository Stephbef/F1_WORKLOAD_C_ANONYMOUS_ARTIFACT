"""Real FreezeSealManager (Session 2): a seal is SHA-256 over (kind, namespace, sorted {relpath: sha256}) of
committed immutable files; verification recomputes it from the files' current hashes. Replaces the Session-1 mock
for local freeze inputs (Phase 09) and raw-result sealing/verification."""
from __future__ import annotations

from ...common.util import sha256_obj
from ..errors import PhaseFailed
from ..interfaces.protocols import Seal


class FreezeSeal:
    def seal(self, kind: str, namespace: str, files: dict[str, str]) -> Seal:
        if not files:
            raise PhaseFailed(f"nothing to seal for {kind}")
        f = dict(sorted(files.items()))
        return Seal(kind, namespace, f, sha256_obj(["F1-WC-SEAL-1", kind, namespace, sorted(f.items())]), False)

    def verify(self, seal: Seal, files: dict[str, str]) -> None:
        f = dict(sorted(files.items()))
        if f != seal.files or sha256_obj(["F1-WC-SEAL-1", seal.kind, seal.namespace, sorted(f.items())]) != seal.seal_sha256:
            raise PhaseFailed(f"seal {seal.kind} verification failed")
