"""Session-2 command implementations: conformance suites, L28 runner, Session-2 fixture E2E (see campaign/cli.py)."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

from ..config.spec import load_protocol_spec
from ..deps.pins import BinaryMode, real_binaries_available, resolve
from ..resources.manager import (ResourceManager, detect_capabilities, otp_authoritative_envelope, sandbox_envelope)
from ..storage.blobstore import BlobStore
from ..timeutil import Clock


def make_producers(mode: BinaryMode, work: Path, envelope=None, isolate_network: bool = True, stub_behavior: str = "ok"):
    from ..producers.canon import CanonRunner
    from ..producers.otp import OtpRouterProducer
    from ..producers.validator import GtfsValidatorProducer
    spec = load_protocol_spec()
    deps = resolve(mode)
    work.mkdir(parents=True, exist_ok=True)
    blobs = BlobStore(work / "store")
    clock = Clock()
    env = envelope or sandbox_envelope(cpus=1, cpuset="0", memory="3G", heap="2G")
    canon = CanonRunner(spec, deps, work / "canon-cache", clock)
    otp = OtpRouterProducer(spec, deps, blobs, work / "jobs", clock, env, canon, isolate_network=isolate_network,
                            stub_behavior=stub_behavior)
    val = GtfsValidatorProducer(spec, deps, blobs, work / "jobs", clock, isolate_network=isolate_network,
                                stub_behavior=stub_behavior)
    return spec, deps, blobs, otp, val, canon


def run_conformance(suite: str, out: Path, mode: BinaryMode, work: Path | None = None) -> dict:
    from ..conformance import harness as H
    out.mkdir(parents=True, exist_ok=True)
    work = Path(work or tempfile.mkdtemp(prefix="f1wc-conf-"))
    summary: dict = {"mode": mode.value, "fixtures_verified": H.verify_fixtures()}
    if suite in ("config", "all"):
        rows = H.config_suite(out / "config_results.csv")
        summary["config"] = {"n": len(rows), "pass": sum(r["result"] == "PASS" for r in rows)}
    if suite in ("oracle", "determinism", "all"):
        spec, deps, blobs, otp, val, canon = make_producers(mode, work, isolate_network=True)
        b = H.FixtureBuilder(otp, canon, work / "builds")
        if suite in ("oracle", "all"):
            rows = H.oracle_suite(b, out / "oracle_results.csv")
            summary["oracle"] = {"n": len(rows), "pass": sum(r["result"] == "PASS" for r in rows),
                                 "digests_match_frozen_record": sum(r["matches_frozen_record"] == "True" for r in rows)}
        if suite in ("determinism", "all"):
            final = ["-XX:ActiveProcessorCount=8", "-Xmx24g", "-XX:+UseG1GC", "-Duser.timezone=UTC"]
            rows = H.determinism_suite(b, out / "determinism_results.csv", final, work / "alt-path" / "builds")
            summary["determinism"] = {"n": len(rows), "pass": sum(r["result"] == "PASS" for r in rows),
                                      "blocked": sum(r["result"] == "BLOCKED" for r in rows)}
    (out / "conformance_summary.json").write_text(json.dumps(summary, indent=1, sort_keys=True))
    return summary


def run_l28(out: Path, sandbox: bool, work: Path | None = None) -> dict:
    """Authoritative attempt (BLOCKED on small hosts) + optional sandbox rehearsal with a scaled envelope."""
    from ..conformance import harness as H
    from ..l28.runner import run_l28 as _run
    spec = load_protocol_spec()
    caps = detect_capabilities()
    mgr = ResourceManager(caps)
    real = real_binaries_available()
    java = resolve(BinaryMode.REAL_PINNED_BINARY).java if real else None
    work = Path(work or tempfile.mkdtemp(prefix="f1wc-l28-"))

    def suite_factory(base: Path):
        def suite(envelope, wrapper):
            mode = BinaryMode.REAL_PINNED_BINARY if real else BinaryMode.FIXTURE_STUB_BINARY
            _, _, _, otp, _, canon = make_producers(mode, base, envelope=envelope)
            otp.extra_wrappers = [wrapper] if wrapper else []
            b = H.FixtureBuilder(otp, canon, base / "builds")
            final = [f for f in envelope.jvm_flags]
            return H.determinism_suite(b, base / "determinism_results.csv", final, base / "alt" / "builds")
        return suite
    res = {"capabilities": caps.to_dict()}
    a = _run(mgr, otp_authoritative_envelope(spec), out / "authoritative", java, suite_factory(work / "auth"))
    res["authoritative"] = a.to_dict()
    if sandbox:
        env = sandbox_envelope(cpus=1, cpuset="0", memory="3G", heap="2G")
        s = _run(mgr, env, out / "sandbox", java, suite_factory(work / "sandbox"), require_host_minimums=False)
        res["sandbox_rehearsal"] = s.to_dict()
    (out / "L28_SUMMARY.json").write_text(json.dumps(res, indent=1, sort_keys=True))
    return res
