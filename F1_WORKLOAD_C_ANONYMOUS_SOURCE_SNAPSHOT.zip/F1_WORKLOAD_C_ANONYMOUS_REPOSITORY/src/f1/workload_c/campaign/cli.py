"""Command-line entry point: python -m f1.workload_c.campaign.cli {run,verify-frozen,secret-scan} ...

  run --fixture-mode            complete Phase 00 -> 18 in FIXTURE mode (real S1 engines + deterministic mocks)
  run --real                    refuses in Session 1: REAL_MODE_NOT_YET_IMPLEMENTATION_COMPLETE (exit 3)
  --inject PHASE=FAIL|BLOCKED   FIXTURE-only failure injection (repeatable)
  --crash-after PHASE           FIXTURE-only: os._exit(137) after outputs of PHASE are written, before COMPLETE
Exit codes: 0 COMPLETE, 1 FAILED, 2 BLOCKED, 3 REFUSED, 4 usage / identity error.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .. import FIXTURE_MARKER, REAL_MODE_REFUSAL, paths


def _run(a) -> int:
    from ..config.runtime import load_effective_config
    from ..errors import FailureInjectionNotAllowed, IncompatibleResumeError, CheckpointIntegrityError, WCError
    if a.real:
        print(json.dumps({"status": "REFUSED", "reason": REAL_MODE_REFUSAL,
                          "detail": "Session 3/4 engines (admission, repair, baselines, replay, statistics) and the "
                                    "freeze/implementation "
                                    "seals are incomplete; no real study API is contacted and no scientific work is executed"}))
        return 3
    if not a.fixture_mode:
        print("exactly one of --fixture-mode / --real is required", file=sys.stderr)
        return 4
    from .fixture import fixture_wiring
    from .orchestrator import FailureInjection, Orchestrator, resolve_phase
    cfg = load_effective_config(paths.CONFIG_DIR / "fixture.yaml")
    inj = FailureInjection()
    for item in a.inject or []:
        ph, _, act = item.partition("=")
        if act not in ("FAIL", "BLOCKED"):
            print(f"bad --inject {item}", file=sys.stderr)
            return 4
        inj.phase_actions[resolve_phase(ph)] = act
    if a.crash_after:
        inj.crash_after_outputs, inj.crash_mode = resolve_phase(a.crash_after), "exit"
    w = fixture_wiring(cfg)
    try:
        orch = Orchestrator(cfg, Path(a.run_root), a.run_id, secrets=w["secrets"], services=w["services"],
                            adapters=w["adapters"], clock=w["clock"], injection=inj)
        res = orch.run()
    except FailureInjectionNotAllowed as e:
        print(json.dumps({"status": "REFUSED", "error": e.to_record()}))
        return 3
    except (IncompatibleResumeError, CheckpointIntegrityError) as e:
        print(json.dumps({"status": "REFUSED", "error": e.to_record()}))
        return 4
    except WCError as e:
        print(json.dumps({"status": "FAILED", "error": e.to_record()}))
        return 1
    out = {"status": res.status, "run_id": res.run_id, "stopped_at": res.stopped_at, "run_dir": str(res.run_dir),
           "marker": FIXTURE_MARKER, "error": res.error}
    print(json.dumps(out, indent=2, sort_keys=True))
    return {"COMPLETE": 0, "FAILED": 1, "BLOCKED": 2}.get(res.status, 1)


def _verify_frozen(a) -> int:
    from ..config.spec import load_protocol_spec
    from ...common.util import sha256_file
    root = paths.FROZEN_SPECS
    bad, n = [], 0
    for line in (root / "FROZEN_SPECS_SHA256.txt").read_text(encoding="utf-8").splitlines():
        if line.strip():
            h, rel = line.split("  ", 1)
            n += 1
            if not (root / rel).is_file() or sha256_file(root / rel) != h:
                bad.append(rel)
    spec = load_protocol_spec()
    print(json.dumps({"verified": n, "bad": bad, "spec_digest": spec.digest}))
    return 0 if not bad else 1


def _secret_scan(a) -> int:
    from ..security.secrets import scan_paths
    from .fixture import FIXTURE_CANARY
    needles = [FIXTURE_CANARY] + list(a.needle or [])
    findings = scan_paths(a.paths, needles)
    print(json.dumps({"scanned": a.paths, "findings": findings}, indent=2))
    return 0 if not findings else 1


def _conformance(a) -> int:
    from ..deps.pins import BinaryMode
    from .s2 import run_conformance
    mode = BinaryMode.REAL_PINNED_BINARY if a.mode == "real" else BinaryMode.FIXTURE_STUB_BINARY
    s = run_conformance(a.suite, Path(a.out), mode, Path(a.work) if a.work else None)
    print(json.dumps(s, indent=1, sort_keys=True))
    ok = all(v["pass"] == v["n"] for v in s.values() if isinstance(v, dict) and "n" in v and "blocked" not in v) and \
        all(v["pass"] + v["blocked"] == v["n"] for v in s.values() if isinstance(v, dict) and "blocked" in v)
    return 0 if ok else 1


def _l28(a) -> int:
    from .s2 import run_l28
    r = run_l28(Path(a.out), a.sandbox, Path(a.work) if a.work else None)
    print(json.dumps({"authoritative": {k: r["authoritative"][k] for k in ("overall", "physical_l28", "reason")},
                      "sandbox_rehearsal": ({k: r["sandbox_rehearsal"][k] for k in ("overall", "physical_l28", "reason",
                                                                                  "tests")}
                                            if "sandbox_rehearsal" in r else None)}, indent=1))
    return 0


def _fixture_s2(a) -> int:
    from .e2e import run_fixture_e2e
    r = run_fixture_e2e(Path(a.out), a.mode)
    print(json.dumps(r["summary"], indent=1, sort_keys=True))
    return 0 if r["summary"]["invariants_ok"] else 1


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="f1-workload-c")
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    g = r.add_mutually_exclusive_group()
    g.add_argument("--fixture-mode", action="store_true")
    g.add_argument("--real", action="store_true")
    r.add_argument("--run-root", default=str(paths.REPO_ROOT / "outputs" / "workload_c"))
    r.add_argument("--run-id", default=None)
    r.add_argument("--inject", action="append")
    r.add_argument("--crash-after", default=None)
    r.set_defaults(fn=_run)
    v = sub.add_parser("verify-frozen")
    v.set_defaults(fn=_verify_frozen)
    s = sub.add_parser("secret-scan")
    s.add_argument("paths", nargs="+")
    s.add_argument("--needle", action="append")
    s.set_defaults(fn=_secret_scan)
    c = sub.add_parser("conformance")
    c.add_argument("--suite", choices=["oracle", "config", "determinism", "all"], default="all")
    c.add_argument("--mode", choices=["real", "stub"], default="real")
    c.add_argument("--out", required=True)
    c.add_argument("--work", default=None)
    c.set_defaults(fn=_conformance)
    lp = sub.add_parser("l28")
    lp.add_argument("--out", required=True)
    lp.add_argument("--sandbox", action="store_true")
    lp.add_argument("--work", default=None)
    lp.set_defaults(fn=_l28)
    fx = sub.add_parser("fixture-s2")
    fx.add_argument("--out", required=True)
    fx.add_argument("--mode", choices=["real", "stub", "auto"], default="auto")
    fx.set_defaults(fn=_fixture_s2)
    a = p.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
