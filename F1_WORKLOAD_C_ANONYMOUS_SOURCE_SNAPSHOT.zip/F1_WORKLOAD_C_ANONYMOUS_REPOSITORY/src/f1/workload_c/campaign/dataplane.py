"""Session-1 REAL engines for phases 02–07 (used in FIXTURE mode against the deterministic mock API)."""
from __future__ import annotations

import csv
import importlib.util
import io
import tempfile
from pathlib import Path

from ...common.util import sha256_obj
from ..api.caching import CachingTransport
from ..api.mobility import MobilityClient, ResponseRecord
from ..errors import (GtfsFormatError, MobilityError, PhaseBlocked, PhaseFailed, SourceLocatorError)
from ..ingestion.gtfs import ArchiveRecord, canonical_content_hash, summarize
from ..licensing.engine import LicenseEngine, LicenseEvidence
from ..regions.connectivity import build_graph
from ..regions.construct import construct_regions
from ..regions.dedup import deduplicate
from ..regions.eligibility import decide_feed, history_check
from ..regions.model import FeedFacts, FeedRecord
from ..regions.spatial import bbox, bbox_diagonal_m
from ..selection.hashrank import select_and_split, selection_proof_rows, split_proof_rows
from ..timeutil import to_canonical_utc
from ..versioning.logical import build_logical_versions, version_in_force, versions_by_feed
from .context import PhaseContext

VALID_STATUSES = {"active", "deprecated", "inactive", "development", "future"}


# ---------------------------------------------------------------------------------------------------------
# catalog parsing
def parse_feed(raw: dict) -> FeedRecord:
    errs: list[str] = []
    fid = raw.get("id")
    status = raw.get("status")
    if not isinstance(status, str) or status not in VALID_STATUSES:
        errs.append("status_invalid")
        status = status if isinstance(status, str) else None
    si = raw.get("source_info")
    if not isinstance(si, dict):
        errs.append("source_info_missing")
        si = {}
    auth = si.get("authentication_type")
    if not isinstance(auth, int) or isinstance(auth, bool):
        if si:
            errs.append("authentication_type_invalid")
        auth = None
    url = si.get("producer_url")
    if url is not None and not isinstance(url, str):
        errs.append("producer_url_invalid")
        url = None
    redirects = raw.get("redirects") or []
    red: list[str] = []
    if not isinstance(redirects, list):
        errs.append("redirects_invalid")
    else:
        for r in redirects:
            t = r.get("target_id") if isinstance(r, dict) else None
            if isinstance(t, str) and t:
                red.append(t)
            else:
                errs.append("redirect_target_invalid")
    lic_url = si.get("license_url")
    lic_id = si.get("license_id")
    return FeedRecord(feed_id=str(fid), metadata_valid=not errs, metadata_errors=tuple(sorted(set(errs))),
                      status=status, authentication_type=auth, producer_url=url,
                      provider=raw.get("provider") if isinstance(raw.get("provider"), str) else None,
                      feed_name=raw.get("feed_name") if isinstance(raw.get("feed_name"), str) else None,
                      redirects=tuple(sorted(red)), license_url=lic_url if isinstance(lic_url, str) else None,
                      license_id=lic_id if isinstance(lic_id, str) else None,
                      data_type=raw.get("data_type") if isinstance(raw.get("data_type"), str) else None)


def parse_dataset(raw: dict) -> tuple[dict | None, str | None]:
    did, t, url = raw.get("id"), raw.get("downloaded_at"), raw.get("hosted_url")
    if not isinstance(did, str) or not did:
        return None, "dataset_id_missing"
    if not isinstance(t, str):
        return None, "dataset_downloaded_at_missing"
    try:
        t = to_canonical_utc(t)
    except ValueError:
        return None, "dataset_downloaded_at_invalid"
    if not isinstance(url, str) or not url.startswith("https://"):
        return {"id": did, "observed": t, "hosted_url": None}, None
    return {"id": did, "observed": t, "hosted_url": url}, None


# ---------------------------------------------------------------------------------------------------------
# Phase 02 — Mobility snapshot
def phase02_snapshot(ctx: PhaseContext) -> dict:
    svc = ctx.services
    transport = CachingTransport(svc["transport"], ctx.blobs, ctx.phase_dir / "request_cache", ctx.clock,
                                 crash_after_fetches=svc.get("crash_after_fetches"))
    ns = ctx.namespace

    def recorder(rec: ResponseRecord) -> str:
        ref = ctx.blobs.put(rec.body, "application/json", provenance={"namespace": ns, "url": rec.url,
                                                                    "status": rec.status, "sha256": rec.sha256})
        return ref.sha256

    if ctx.secrets is None:
        raise PhaseBlocked("no SecretProvider configured for the Mobility client")
    client = MobilityClient(ctx.cfg.runtime["mobility"], ctx.secrets, transport, svc["sleeper"], ctx.clock, recorder)
    try:
        raw_feeds, cat_recs = client.list_gtfs_feeds()
    except MobilityError as e:
        if e.error_class in ("MOBILITY_AUTH_401", "MOBILITY_FORBIDDEN_403"):
            raise PhaseBlocked(f"Mobility catalog inaccessible: {e.error_class}") from None
        raise PhaseFailed(f"Mobility catalog snapshot failed: {e.error_class}") from None
    feeds, datasets, observations, provenance, anomalies = [], {}, [], [], list(client.stats.anomalies)
    for raw in sorted(raw_feeds, key=lambda r: str(r.get("id"))):
        rec = parse_feed(raw)
        errs = list(rec.metadata_errors)
        try:
            dsl, _ = client.list_datasets(rec.feed_id)
        except MobilityError as e:
            raise PhaseFailed(f"dataset listing failed for {rec.feed_id}: {e.error_class}") from None
        parsed = []
        for d in dsl:
            pd, err = parse_dataset(d)
            if err:
                errs.append(err)
            elif pd is not None:
                parsed.append(pd)
        if errs != list(rec.metadata_errors):
            rec = FeedRecord(**{**rec.__dict__, "metadata_valid": False,
                                "metadata_errors": tuple(sorted(set(errs)))})
        feeds.append(rec.to_dict())
        datasets[rec.feed_id] = sorted(parsed, key=lambda d: (d["observed"], d["id"]))
        for d in datasets[rec.feed_id]:
            ob = {"feed_id": rec.feed_id, "archive_id": d["id"], "archive_observed_utc": d["observed"],
                  "source_locator": {"hosted_url": d["hosted_url"], "dataset_id": d["id"]},
                  "raw_zip_sha256": None, "byte_size": None, "status": "OK", "error_class": None}
            try:
                if d["hosted_url"] is None:
                    raise SourceLocatorError("dataset has no hosted_url")
                r = client.download(d["hosted_url"])
                ref = ctx.blobs.put(r.body, "application/zip",
                                    provenance={"namespace": ns, "feed_id": rec.feed_id, "archive_id": d["id"],
                                                "source": "mobility-database-hosted-dataset"})
                ob.update(raw_zip_sha256=ref.sha256, byte_size=ref.size)
                provenance.append({"feed_id": rec.feed_id, "archive_id": d["id"], "retrieved_utc": r.retrieved_utc,
                                   "attempts": r.attempts})
            except SourceLocatorError as e:
                ob.update(status="SOURCE_LOCATOR_FAILURE", error_class=e.error_class)
            observations.append(ob)
    snapshot = {"schema": "F1-WC-MOBILITY-SNAPSHOT-1", "namespace": ns, "base_url": client.base,
                "n_feeds": len(feeds), "feeds": feeds, "datasets": datasets, "observations": observations,
                "anomalies": anomalies, "catalog_response_sha256": [r.sha256 for r in cat_recs]}
    snapshot["snapshot_content_sha256"] = sha256_obj({k: v for k, v in snapshot.items()})
    entries = {f"archive/{o['feed_id']}/{o['archive_id']}": o["raw_zip_sha256"] for o in observations
               if o["raw_zip_sha256"]}
    snap_id = ctx.snapshots.commit(f"mobility-{ctx.run_id}", entries, ns,
                                   meta={"snapshot_content_sha256": snapshot["snapshot_content_sha256"]})
    ctx.write_json("mobility_snapshot.json", snapshot)
    ctx.write_jsonl("retrieval_provenance.jsonl", provenance)
    ctx.write_json("client_stats.json", {"requests": client.stats.requests, "retries": client.stats.retries,
                                         "sleeps": client.stats.sleeps, "cache_hits": transport.hits,
                                         "cache_misses": transport.misses, "snapshot_manifest_sha256": snap_id})
    return {"n_feeds": len(feeds), "n_observations": len(observations), "snapshot_manifest_sha256": snap_id,
            "snapshot_content_sha256": snapshot["snapshot_content_sha256"], "retries": client.stats.retries}


# ---------------------------------------------------------------------------------------------------------
# Phase 03 — logical versions (+ conformance against the frozen tool)
def _load_frozen_tool(path: Path, name: str):
    import sys
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)  # type: ignore[arg-type]
    old = sys.dont_write_bytecode
    sys.dont_write_bytecode = True        # never write __pycache__ into frozen_specs/
    try:
        spec.loader.exec_module(mod)  # type: ignore[union-attr]
    finally:
        sys.dont_write_bytecode = old
    return mod


def phase03_logical_versions(ctx: PhaseContext) -> dict:
    snap = ctx.read_prior_json("02_mobility_snapshot", "mobility_snapshot.json")
    names = ctx.cfg.spec.gtfs_member_names
    feeds = {f["feed_id"]: f for f in snap["feeds"]}
    retrieved = {(r["feed_id"], r["archive_id"]): r["retrieved_utc"]
                 for r in ctx.read_prior_jsonl("02_mobility_snapshot", "retrieval_provenance.jsonl")}
    records: list[ArchiveRecord] = []
    for o in snap["observations"]:
        f = feeds[o["feed_id"]]
        status, err, canon = o["status"], o["error_class"], ""
        if status == "OK":
            data = ctx.blobs.get(o["raw_zip_sha256"])
            try:
                canon = canonical_content_hash(data, names)
            except GtfsFormatError as e:
                status, err = "MALFORMED_ARCHIVE", e.error_class
        records.append(ArchiveRecord(
            namespace=ctx.namespace, feed_id=o["feed_id"], archive_id=o["archive_id"],
            source_locator=o["source_locator"], archive_observed_utc=o["archive_observed_utc"],
            retrieved_utc=retrieved.get((o["feed_id"], o["archive_id"]), ""), raw_zip_sha256=o["raw_zip_sha256"] or "",
            canonical_content_sha256=canon, byte_size=o["byte_size"] or 0,
            license={"license_url": f["license_url"], "license_id": f["license_id"]},
            provenance={"snapshot_content_sha256": snap["snapshot_content_sha256"]}, status=status, error_class=err))
    versions = build_logical_versions(records, ctx.cfg.spec["logical_versions"]["logical_version_id_format"])
    # conformance: the frozen tool must produce the identical ledger from the same raw archives
    tool = _load_frozen_tool(ctx.cfg.spec.root / ctx.cfg.spec["sources"]["TOOL_LOGICAL_VERSIONS"]["path"],
                             "frozen_logical_versions")
    with tempfile.TemporaryDirectory(prefix="wc-lv-") as td:
        rows = []
        for r in records:
            if r.status != "OK":
                continue
            p = Path(td) / f"{r.raw_zip_sha256}.zip"
            if not p.exists():
                p.write_bytes(ctx.blobs.get(r.raw_zip_sha256))
            rows.append({"feed_id": r.feed_id, "archive_id": r.archive_id,
                         "archive_observed_utc": r.archive_observed_utc, "zip_path": str(p)})
        frozen = tool.build(rows)
    ours = [{"feed_id": v.feed_id, "logical_version_id": v.logical_version_id,
             "canonical_content_sha256": v.canonical_content_sha256, "first_observed_utc": v.first_observed_utc,
             "archive_ids": list(v.archive_ids)} for v in versions]
    if ours != frozen:
        raise PhaseFailed("logical-version ledger differs from frozen tools/logical_versions.py")
    ctx.write_jsonl("archive_records.jsonl", [r.to_dict() for r in records])
    ctx.write_jsonl("logical_versions.jsonl", [v.to_dict() for v in versions])
    ctx.write_csv("logical_versions.csv", [{**o, "archive_ids": ";".join(o["archive_ids"])} for o in ours],
                  ["feed_id", "logical_version_id", "canonical_content_sha256", "first_observed_utc", "archive_ids"])
    return {"n_archives": len(records), "n_logical_versions": len(versions),
            "frozen_tool_conformance": "PASS", "n_malformed": sum(r.status == "MALFORMED_ARCHIVE" for r in records)}


# ---------------------------------------------------------------------------------------------------------
# Phase 04 — license gate
def phase04_license(ctx: PhaseContext) -> dict:
    snap = ctx.read_prior_json("02_mobility_snapshot", "mobility_snapshot.json")
    eng = LicenseEngine(ctx.cfg.spec, ctx.cfg.license_table)
    out = []
    for f in sorted(snap["feeds"], key=lambda f: f["feed_id"]):
        ev = LicenseEvidence(feed_id=f["feed_id"], license_url=f["license_url"], license_id=f["license_id"],
                             source="mobility_catalog.source_info", evidence_sha256=snap["snapshot_content_sha256"])
        out.append(eng.classify(ev).to_dict())
    ctx.write_jsonl("license_decisions.jsonl", out)
    ctx.write_csv("license_ledger.csv", out, ["feed_id", "classification", "license_class", "attribution_required",
                                              "normalized_identity", "reason_code", "eligible",
                                              "redistribution_constraints", "processing_constraints"])
    counts: dict[str, int] = {}
    for d in out:
        counts[d["classification"]] = counts.get(d["classification"], 0) + 1
    return {"classification_counts": dict(sorted(counts.items())), "table_status": ctx.cfg.license_table.raw["status"]}


# ---------------------------------------------------------------------------------------------------------
# Phase 05 — eligible regions
def compute_feed_facts(ctx: PhaseContext, recs: dict[str, FeedRecord], archives: list[dict], versions: list[dict]
                       ) -> dict[str, FeedFacts]:
    p = ctx.cfg.interp.p
    R = float(p["earth_radius_m"])
    by_feed_arch: dict[str, list[ArchiveRecord]] = {}
    for a in archives:
        by_feed_arch.setdefault(a["feed_id"], []).append(ArchiveRecord(**a))
    from ..versioning.logical import LogicalVersion
    lvs = [LogicalVersion(**{**v, "archive_ids": tuple(v["archive_ids"]), "raw_zip_sha256s": tuple(v["raw_zip_sha256s"])})
           for v in versions]
    vbf = versions_by_feed(lvs)
    facts: dict[str, FeedFacts] = {}
    summary_cache: dict[str, object] = {}

    def summ(raw_sha: str):
        if raw_sha not in summary_cache:
            try:
                summary_cache[raw_sha] = summarize(ctx.blobs.get(raw_sha))
            except GtfsFormatError as e:
                summary_cache[raw_sha] = e
        return summary_cache[raw_sha]

    for fid in sorted(recs):
        arch = sorted(by_feed_arch.get(fid, []), key=lambda r: (r.archive_observed_utc, r.archive_id))
        ff = FeedFacts(feed_id=fid)
        ff.archive_failures = sum(a.status == "SOURCE_LOCATOR_FAILURE" for a in arch)
        ok = [a for a in arch if a.status == "OK"]
        ff.n_archives_ok = len(ok)
        if any(a.status == "MALFORMED_ARCHIVE" for a in arch):
            ff.malformed_reason = "MALFORMED_ARCHIVE"
        vs = vbf.get(fid, [])
        ff.n_logical_versions = len(vs)
        ff.history_ok, ff.history_reason, ff.max_gap_days = history_check(ctx.cfg, arch, vs)
        if vs:
            latest = vs[-1]
            ff.latest_lv, ff.latest_canonical_sha256 = latest.logical_version_id, latest.canonical_content_sha256
            latest_arch = ok[-1]
            ff.latest_zip_bytes = latest_arch.byte_size
            s = summ(latest.raw_zip_sha256s[-1])
            if isinstance(s, GtfsFormatError):
                ff.malformed_reason = ff.malformed_reason or "LATEST_VERSION_UNPARSEABLE"
            else:
                ff.latest_summary = s  # type: ignore[assignment]
                ff.bbox_diagonal_m = bbox_diagonal_m(s.stops, R)  # type: ignore[attr-defined]
            inf = version_in_force(vs, p["in_force_instant_utc"])
            if inf is not None:
                ff.in_force_lv, ff.in_force_canonical_sha256 = inf.logical_version_id, inf.canonical_content_sha256
                s2 = summ(inf.raw_zip_sha256s[0])
                if isinstance(s2, GtfsFormatError):
                    ff.malformed_reason = ff.malformed_reason or "IN_FORCE_VERSION_UNPARSEABLE"
                else:
                    ff.in_force_summary = s2  # type: ignore[assignment]
        facts[fid] = ff
    return facts


def phase05_regions(ctx: PhaseContext) -> dict:
    snap = ctx.read_prior_json("02_mobility_snapshot", "mobility_snapshot.json")
    archives = ctx.read_prior_jsonl("03_logical_versions", "archive_records.jsonl")
    versions = ctx.read_prior_jsonl("03_logical_versions", "logical_versions.jsonl")
    lic = {d["feed_id"]: d for d in ctx.read_prior_jsonl("04_license_gate", "license_decisions.jsonl")}
    recs = {f["feed_id"]: FeedRecord(**{**f, "metadata_errors": tuple(f["metadata_errors"]),
                                        "redirects": tuple(f["redirects"])}) for f in snap["feeds"]}
    facts = compute_feed_facts(ctx, recs, archives, versions)
    decisions = {fid: decide_feed(ctx.cfg, recs[fid], facts[fid], lic.get(fid)) for fid in sorted(recs)}
    eligible = [f for f, d in decisions.items() if d.eligible]
    dd = deduplicate(recs, facts, eligible, ctx.cfg.spec["dedup"]["merged_bundle_min_agency_overlap"])
    kept = sorted(f for f, d in dd.items() if d.kept)
    edges, evidence = build_graph(ctx.cfg, facts, kept)
    tz: dict[str, str | None] = {}
    for f in kept:
        s_in = facts[f].in_force_summary
        tz[f] = s_in.timezone if s_in is not None else None
    regions, split_log = construct_regions(ctx.cfg, kept, edges, {f: facts[f].latest_zip_bytes or 0 for f in kept},
                                           tz, {f: lic[f]["license_class"] for f in kept})
    R = float(ctx.cfg.interp.p["earth_radius_m"])
    eligible_rows, excluded_rows, region_docs = [], [], []
    for fid in sorted(recs):
        d = decisions[fid]
        if not d.eligible:
            excluded_rows.append({"entity_type": "feed", "entity_id": fid, "reason_code": d.primary_reason,
                                  "all_reasons": ";".join(d.reasons), "related_id": "", "detail": ""})
        elif not dd[fid].kept:
            excluded_rows.append({"entity_type": "feed", "entity_id": fid, "reason_code": dd[fid].reason,
                                  "all_reasons": dd[fid].reason, "related_id": dd[fid].collapsed_into or "",
                                  "detail": dd[fid].detail})
    for r in regions:
        row = r.to_row()
        stops = []
        for f in r.feed_ids:
            s_in = facts[f].in_force_summary
            if s_in is not None:
                stops.extend(s_in.stops)
        region_docs.append({**row, "edges": [[e.a, e.b, e.stop_pairs] for e in r.edges],
                            "bbox": list(bbox(stops)) if stops else None,
                            "feeds": [{"feed_id": f, "latest_lv": facts[f].latest_lv,
                                       "latest_canonical_sha256": facts[f].latest_canonical_sha256,
                                       "in_force_lv": facts[f].in_force_lv} for f in r.feed_ids]})
        if r.status == "ELIGIBLE":
            eligible_rows.append(row)
        else:
            excluded_rows.append({"entity_type": "region_candidate", "entity_id": r.region_id,
                                  "reason_code": r.reason, "all_reasons": r.reason, "related_id": "",
                                  "detail": f"n_feeds={len(r.feed_ids)}"})
    excluded_rows.sort(key=lambda x: (x["entity_type"], x["entity_id"]))
    fields_e = ["region_id", "n_feeds", "feed_ids", "timezone", "total_latest_zip_bytes", "n_edges",
                "min_edge_stop_pairs", "license_classes", "origin", "status", "reason"]
    ctx.write_csv("eligible_population.csv", eligible_rows, fields_e)
    ctx.write_csv("excluded_population.csv", excluded_rows,
                  ["entity_type", "entity_id", "reason_code", "all_reasons", "related_id", "detail"])
    ctx.write_jsonl("region_connectivity_evidence.jsonl", evidence)
    ctx.write_jsonl("feed_eligibility.jsonl", [{"feed_id": f, "eligible": d.eligible, "reasons": d.reasons,
                                                "facts": facts[f].audit()} for f, d in sorted(decisions.items())])
    ctx.write_jsonl("dedup_decisions.jsonl", [d.__dict__ for _, d in sorted(dd.items())])
    ctx.write_json("region_split_log.json", split_log)
    ctx.write_json("regions.json", {"namespace": ctx.namespace, "regions": region_docs,
                                    "interpretations_digest": ctx.cfg.interp.digest,
                                    "interpretations_status": ctx.cfg.interp.raw["status"], "earth_radius_m": R})
    return {"n_feeds": len(recs), "n_feed_eligible": len(eligible), "n_after_dedup": len(kept), "n_edges": len(edges),
            "n_region_candidates": len(regions), "n_eligible_regions": len(eligible_rows)}


# ---------------------------------------------------------------------------------------------------------
# Phases 06/07 — selection and split (+ conformance against the frozen tool)
def _frozen_selection(ctx: PhaseContext, ids: list[str]) -> list[dict]:
    """Run the frozen tool unmodified in a separate interpreter (it leaves its output file to be closed at exit)."""
    import subprocess
    import sys
    tool = ctx.cfg.spec.root / ctx.cfg.spec["sources"]["TOOL_HASHRANK"]["path"]
    with tempfile.TemporaryDirectory(prefix="wc-sel-") as td:
        inp, out = Path(td) / "eligible.csv", Path(td) / "out.csv"
        with open(inp, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["region_id"])
            for r in ids:
                w.writerow([r])
        cp = subprocess.run([sys.executable, str(tool), str(inp), str(out)], capture_output=True, text=True,
                            timeout=300, check=False)
        if cp.returncode != 0:
            raise PhaseFailed(f"frozen selection tool failed: {cp.stderr.strip()[-300:] or cp.stdout.strip()[-300:]}")
        return list(csv.DictReader(io.StringIO(out.read_text(encoding="utf-8"))))


def phase06_select(ctx: PhaseContext) -> dict:
    from ..errors import PopulationShortfall
    rows = ctx.read_prior_csv("05_eligible_regions", "eligible_population.csv")
    ids = [r["region_id"] for r in rows]
    try:
        res = select_and_split(ctx.cfg.spec, ids)
    except PopulationShortfall as e:
        raise PhaseFailed(str(e)) from None
    frozen = _frozen_selection(ctx, ids)
    if sorted(r["region_id"] for r in frozen) != sorted(res.selected) or \
            [r["region_id"] for r in frozen] != list(res.split_order):
        raise PhaseFailed("selection differs from frozen tools/select_regions_hashrank.py")
    proof = selection_proof_rows(ctx.cfg.spec, res)
    ctx.write_csv("selected_24.csv", [p for p in proof if p["selected"] == "1"],
                  ["selection_position", "region_id", "selection_rank_hex"])
    ctx.write_csv("selection_proof.csv", proof, ["selection_position", "region_id", "selection_rank_hex", "selected"])
    return {"n_eligible": len(ids), "n_selected": len(res.selected), "frozen_tool_conformance": "PASS",
            "selected_digest": sha256_obj(list(res.selected))}


def phase07_split(ctx: PhaseContext) -> dict:
    sel = ctx.read_prior_csv("06_select_24", "selected_24.csv")
    elig = ctx.read_prior_csv("05_eligible_regions", "eligible_population.csv")
    res = select_and_split(ctx.cfg.spec, [r["region_id"] for r in elig])
    if [r["region_id"] for r in sel] != list(res.selected):
        raise PhaseFailed("phase-06 selection does not reproduce (refusing to re-derive with a different input)")
    rows = split_proof_rows(ctx.cfg.spec, res)
    part_ns = {"VALIDATION": "VALIDATION", "TEST": "TEST"} if ctx.mode == "REAL" else \
        {"VALIDATION": "FIXTURE", "TEST": "FIXTURE"}
    for r in rows:
        r["namespace"] = part_ns[r["split"]]
    f = ["split_position", "region_id", "split", "namespace", "selection_rank_hex", "split_rank_hex"]
    ctx.write_csv("validation_8.csv", [r for r in rows if r["split"] == "VALIDATION"], f)
    ctx.write_csv("test_16.csv", [r for r in rows if r["split"] == "TEST"], f)
    ctx.write_csv("split_proof.csv", rows, f)
    return {"n_validation": len(res.validation), "n_test": len(res.test),
            "split_digest": sha256_obj([list(res.validation), list(res.test)])}
