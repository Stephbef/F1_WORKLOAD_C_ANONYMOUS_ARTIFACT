"""Session-2 deterministic fixture E2E (ENGINEERING FIXTURE ONLY — NOT SCIENTIFIC RESULTS).

synthetic non-study GTFS history (frozen oracle fixture feeds, 2008 dates) → S1 canonical hashes + logical versions
→ frozen Workload-C schedule (FIXTURE_DURATION_BACKEND) → validator + OTP producers (REAL_PINNED_BINARY when the
pinned binaries verify, else FIXTURE_STUB_BINARY) → Canon_D → K0/K1/K2 contracts (+ K3 reference on one artifact
of each class) → artifact catalog with fixed-R request slots (+ one rederive) → append-only realized history
→ contract evaluation at consumer ticks. No admission, no HSR, no baseline comparison.
"""
from __future__ import annotations

import json
import shutil
from datetime import date
from pathlib import Path

from ... import workload_c
from ...common.util import sha256_obj
from ..catalog.artifacts import ArtifactCatalog, designated_slots
from ..contracts.generators import ContractSystem, ReferencePath
from ..contracts.model import EvaluationContext, Level
from ..deps.pins import BinaryMode, real_binaries_available
from ..history.realized import Cut, RealizedHistory
from ..ingestion.gtfs import ArchiveRecord, canonical_content_hash
from ..producers.canon import horizon
from ..producers.otp import OtpFeedInput, OtpRequest
from ..producers.validator import ValidatorRequest
from ..scheduler.ledger import to_history
from ..scheduler.timeutil_local import parse
from ..scheduler.workload_c import FixtureDurationBackend, RegionScheduleInput, VersionAvailability, simulate
from ..versioning.logical import build_logical_versions
from .s2 import make_producers

FIX = workload_c.paths.FROZEN_SPECS / "authoritative" / "conformance" / "fixtures" / "oracle"
REGION, TZ = "R:fixA+fixB", "America/Los_Angeles"
HISTORY = [("fixA", "a1", "2008-05-30T18:00:00Z", "base/feedA.gtfs.zip"),
           ("fixB", "b1", "2008-05-30T19:00:00Z", "d6a/fb.zip"),
           ("fixA", "a1r", "2008-05-31T12:00:00Z", "base/feedA.gtfs.zip"),     # A,A repack-style re-observation
           ("fixA", "a2", "2008-06-01T20:00:00Z", "o5/feedA.gtfs.zip"),        # A,B
           ("fixA", "a3", "2008-06-03T20:00:00Z", "base/feedA.gtfs.zip")]      # A,B,A recurrence
WINDOW = ("2008-05-30T00:00:00Z", "2008-06-05T00:00:00Z")


def _local_date(t_utc: str) -> date:
    from zoneinfo import ZoneInfo
    return parse(t_utc).astimezone(ZoneInfo(TZ)).date()


def _all_verify(contracts) -> bool:
    for c in contracts:
        c.verify()                                  # raises on any byte/body mismatch
    return True


def run_fixture_e2e(out: Path, mode: str = "auto") -> dict:
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    bm = BinaryMode.REAL_PINNED_BINARY if (mode == "real" or (mode == "auto" and real_binaries_available())) \
        else BinaryMode.FIXTURE_STUB_BINARY
    spec, deps, blobs, otp, val, canon = make_producers(bm, out / "work")
    names = spec.gtfs_member_names
    # 1. archive records -> logical versions (Session-1 engines)
    recs, raw = [], {}
    for f, aid, t, rel in HISTORY:
        data = (FIX / rel).read_bytes()
        ref = blobs.put(data, "application/zip", provenance={"fixture": rel, "namespace": "FIXTURE"})
        raw[(f, aid)] = ref.sha256
        recs.append(ArchiveRecord("FIXTURE", f, aid, {"fixture": rel}, t, t, ref.sha256,
                                  canonical_content_hash(data, names), ref.size, {}, {}))
    lvs = build_logical_versions(recs)
    vinfo = {}
    for v in lvs:
        vinfo[(v.feed_id, v.index)] = {"logical_version_id": v.logical_version_id,
                                       "canonical_content_sha256": v.canonical_content_sha256,
                                       "raw_zip_sha256": v.raw_zip_sha256s[0], "available": v.first_observed_utc}
    # 2. schedule
    rin = RegionScheduleInput(REGION, TZ, ("fixA", "fixB"),
                              tuple(VersionAvailability(v.feed_id, v.index, v.logical_version_id, v.first_observed_utc)
                                    for v in lvs), *WINDOW)
    sched = simulate(spec, rin, FixtureDurationBackend(validator_s=600, otp_s=5400))
    hist = RealizedHistory(out / "history.jsonl")
    to_history(sched, hist)
    # 3. producers at each artifact birth; contracts; catalog
    cs = ContractSystem(blobs, names)
    cat = ArtifactCatalog(out / "catalog.jsonl")
    contracts, outcomes, evals = [], [], []
    slots = [s.slot_id for s in designated_slots(REGION, ["fixA", "fixB"])]
    osm = FIX / "base" / "street.osm.pbf"
    import hashlib
    osm_sha = hashlib.sha256(osm.read_bytes()).hexdigest()
    zdir = out / "work" / "zips"
    zdir.mkdir(parents=True, exist_ok=True)

    def zip_path(ref: str) -> str:
        p = zdir / f"{ref}.zip"
        if not p.exists():
            p.write_bytes(blobs.get(ref))
        return str(p)

    def ctx_for(frontier: dict, t_utc: str, sem=None, otp_sha=None, D=()) -> EvaluationContext:
        cut = Cut.of(REGION, frontier)
        feeds = {f: {k: vinfo[(f, i)][k] for k in ("logical_version_id", "canonical_content_sha256", "raw_zip_sha256")}
                 for f, i in frontier.items() if i > 0}
        return EvaluationContext(cut.cut_id, feeds, osm_sha, sem, otp_sha, val.binary_sha,
                                 _local_date(t_utc).isoformat(), "US", tuple(D))
    first_val = first_router = None
    for e in sched.events:
        if e["kind"] != "ARTIFACT_BORN":
            continue
        t = e["t"]
        if e["producer"] == "validator":
            f, i = e["feed_id"], e["birth_frontier"][e["feed_id"]]
            vi = vinfo[(f, i)]
            ctx = ctx_for({f: i}, t)
            vreq = ValidatorRequest(f"VAL:feed={f}", REGION, f, vi["logical_version_id"], vi["canonical_content_sha256"],
                                    zip_path(vi["raw_zip_sha256"]), str(ctx.consumer_date), "US", ctx.cut_id, "FIXTURE")
            o = val.produce(vreq)
            outcomes.append({"slot": vreq.request_slot, "failure_class": o.failure_class, "gate": (o.val_gate or {}).get("gate")})
            cids = []
            if o.val_report:
                art = {**o.val_report, "artifact_id": "VAL:" + o.val_report["report_digest"][:24]}
                for lv in (Level.K0, Level.K1, Level.K2, Level.K3):
                    c = cs.generate_val(art, ctx, lv.value)
                    contracts.append(c)
                    cids.append(c.contract_id)
                if first_val is None:
                    first_val = (art, vreq, [c for c in contracts if c.level == "K3"][-1])
            cat.add(request_slot=vreq.request_slot, producer_type="gtfs-validator", artifact_class="VAL_REPORT",
                    birth_cut_id=ctx.cut_id, birth_frontier=tuple(sorted({f: i}.items())),
                    logical_inputs=[(f, vi["logical_version_id"], vi["canonical_content_sha256"])], contract_ids=cids,
                    status=o.failure_class, provenance_digest=sha256_obj(o.provenance),
                    output_digests=[("report", (o.val_report or {}).get("report_digest", ""))],
                    cost={"wall_s": o.provenance["wall_s"], "cpu_s": o.provenance["cpu_s"]}, namespace="FIXTURE",
                    binary_mode=bm.value)
        else:
            fr = e["birth_frontier"]
            bd = _local_date(t)
            D = horizon(bd, spec["canon"]["horizon_days"])
            feeds = tuple(OtpFeedInput(f, vinfo[(f, i)]["logical_version_id"], vinfo[(f, i)]["canonical_content_sha256"],
                                       zip_path(vinfo[(f, i)]["raw_zip_sha256"])) for f, i in sorted(fr.items()))
            cut = Cut.of(REGION, fr)
            oreq = OtpRequest(f"ROUTER:region={REGION}", REGION, feeds, str(osm), TZ, bd.isoformat(), tuple(D), cut.cut_id,
                              "FIXTURE")
            oo = otp.produce(oreq)
            o = oo
            outcomes.append({"slot": oreq.request_slot, "failure_class": o.failure_class,
                             "canon": (o.router or {}).get("canon_digest")})
            cids = []
            if o.router:
                ctx = ctx_for(fr, t, o.semantic_config_digest, o.router["otp_sha256"], D)
                for lv in (Level.K0, Level.K1, Level.K2, Level.K3):
                    c = cs.generate_router(o.router, ctx, lv.value)
                    contracts.append(c)
                    cids.append(c.contract_id)
                if first_router is None:
                    first_router = (oo, oreq, [c for c in contracts if c.level == "K3"][-1])
                # contract evaluation at every later consumer tick (cut + consumer horizon), K0/K1/K2 only
                for tick in sched.events:
                    if tick["kind"] == "CONSUMER_TICK" and tick["t"] >= t:
                        tctx = ctx_for({k: v for k, v in tick["cut"].items()}, tick["t"], o.semantic_config_digest,
                                       o.router["otp_sha256"], horizon(_local_date(tick["t"]), spec["canon"]["horizon_days"]))
                        for c in contracts[-4:-1]:
                            r = cs.evaluate(c, tctx)
                            evals.append({"artifact": o.router["artifact_id"], "level": c.level, "tick": tick["t"],
                                          "cut": tctx.cut_id, "verdict": r.verdict, "reason": r.reason})
            cat.add(request_slot=oreq.request_slot, producer_type="otp", artifact_class="ROUTER", birth_cut_id=cut.cut_id,
                    birth_frontier=tuple(sorted(fr.items())),
                    logical_inputs=[(f.feed_id, f.logical_version_id, f.canonical_content_sha256) for f in feeds],
                    contract_ids=cids, status=o.failure_class, provenance_digest=sha256_obj(o.provenance),
                    output_digests=[("canon", (o.router or {}).get("canon_digest", "")),
                                    ("graph", (o.router or {}).get("graph_sha256", ""))],
                    cost={"wall_s": o.provenance["wall_s"], "cpu_s": o.provenance["cpu_s"]}, namespace="FIXTURE",
                    binary_mode=bm.value)
    # 4. K3 reference path on one artifact of each class
    ref = ReferencePath(val, otp, canon)
    k3 = {}
    if first_val:
        _, vr, vc = first_val
        k3["VAL"] = ref.val_k3(vc, vr).verdict
    if first_router:
        ro0, rr, rc0 = first_router
        birth_graph = Path(ro0.canon["canon_path"]).parent.parent / "graph" / "graph.obj"
        k3["ROUTER"] = ref.router_k3(rc0, birth_graph, rr, list(rr.horizon), out / "work" / "k3canon").verdict
    # 5. one explicit rederive (fixed-R): new instance for the SAME slot at a later cut
    last_tick = [e for e in sched.events if e["kind"] == "CONSUMER_TICK"][-1]
    slot = "VAL:feed=fixB"
    inst_before = len(cat.instances(slot))
    i = last_tick["cut"]["fixB"]
    vi = vinfo[("fixB", i)]
    rc = ctx_for({"fixB": i}, last_tick["t"])
    rq = ValidatorRequest(slot, REGION, "fixB", vi["logical_version_id"], vi["canonical_content_sha256"],
                          zip_path(vi["raw_zip_sha256"]), str(rc.consumer_date), "US", rc.cut_id + ":rederive", "FIXTURE")
    ro = val.produce(rq)
    red = cat.rederive(slot, rc.cut_id + ":rederive", producer_type="gtfs-validator", artifact_class="VAL_REPORT",
                       birth_frontier=(("fixB", i),), logical_inputs=[("fixB", vi["logical_version_id"],
                                                                        vi["canonical_content_sha256"])],
                       contract_ids=[], status=ro.failure_class, provenance_digest=sha256_obj(ro.provenance),
                       output_digests=[("report", (ro.val_report or {}).get("report_digest", ""))],
                       cost={"wall_s": ro.provenance["wall_s"], "cpu_s": ro.provenance["cpu_s"]}, namespace="FIXTURE",
                       binary_mode=bm.value)
    # 6. invariants + semantic digest (excludes timing/provenance which legitimately vary between runs)
    sem_entries = [{k: v for k, v in e.to_dict().items() if k not in ("provenance_digest", "cost")}
                   for s in cat.slots() for e in cat.instances(s)]
    inv = {
        "every_birth_catalogued": sum(1 for e in sched.events if e["kind"] == "ARTIFACT_BORN") + 1 == len(cat),
        "slots_are_designated": set(cat.slots()) <= set(slots),
        "rederive_same_slot_new_instance": red.request_slot == slot and red.instance == inst_before + 1
                                          and red.artifact_id != cat.instances(slot)[0].artifact_id,
        "all_contracts_verify": _all_verify(contracts),
        "k3_reference_valid": all(v == "VALID" for v in k3.values()) and len(k3) == 2,
        "no_error_verdicts": all(e["verdict"] in ("VALID", "INVALID") for e in evals),
        "history_journal_intact": RealizedHistory(out / "history.jsonl").order == hist.order,
        "binary_mode_recorded": all(e.binary_mode == bm.value for s in cat.slots() for e in cat.instances(s)),
    }
    summary = {"marker": workload_c.FIXTURE_MARKER, "binary_mode": bm.value, "n_logical_versions": len(lvs),
               "n_schedule_events": len(sched.events), "schedule_digest": sched.digest, "n_artifacts": len(cat),
               "n_contracts": len(contracts), "contract_digests": sorted(c.digest for c in contracts),
               "outcomes": outcomes, "k3": k3, "n_evaluations": len(evals),
               "evaluation_verdicts": sorted({(e["level"], e["verdict"]) for e in evals}),
               "semantic_digest": sha256_obj({"schedule": sched.events, "contracts": sorted(c.digest for c in contracts),
                                              "catalog": sem_entries, "evals": evals}),
               "invariants": inv, "invariants_ok": all(inv.values()), "scientific_results": "NONE"}
    (out / "E2E_SUMMARY.json").write_text(json.dumps(summary, indent=1, sort_keys=True, default=list))
    (out / "evaluations.jsonl").write_text("".join(json.dumps(e, sort_keys=True) + "\n" for e in evals))
    (out / "contracts.jsonl").write_text("".join(c.canonical_bytes.decode() + "\n" for c in contracts))
    (out / "schedule.json").write_text(json.dumps(sched.events, indent=1, sort_keys=True))
    return {"summary": summary}
