"""FIXTURE-mode wiring: deterministic mock Mobility API (through the real client), mock adapters, synthetic
canary credential, deterministic clock and sleeper. ENGINEERING FIXTURE ONLY — NOT SCIENTIFIC RESULTS."""
from __future__ import annotations

import hashlib

from ..api.mock import Fault, MockMobilityServer
from ..api.transport import RecordingSleeper
from ..config.runtime import EffectiveConfig
from ..errors import RealModeRefused
from ..fixturegen.population import build_fixture_population
from ..interfaces.mocks import (MockAdmissionEngine, MockBaseline, MockContractEvaluator, MockContractGenerator,
                                MockCostRecorder, MockFaults, MockFreezeSealManager, MockMutationEngine,
                                MockOracleEvaluator, MockOtpProducer, MockRepairEngine, MockReplayEngine,
                                MockResourceManager, MockStatisticsEngine, MockValidatorProducer)
from ..security.secrets import StaticSecretProvider
from ..timeutil import FixedTickClock

# Synthetic, publicly-known canary used as the mock refresh token. It is NOT a credential; it exists so that the
# secret scan can prove that a token value never reaches any persisted artifact.
FIXTURE_CANARY = "F1WC-FIXTURE-CANARY-" + hashlib.sha256(b"f1-wc-s1-fixture-canary").hexdigest()[:32]


def build_fixture_server(cfg: EffectiveConfig, scripted_faults: bool = True):
    pop = build_fixture_population()
    srv = MockMobilityServer(cfg.runtime["mobility"]["base_url"], pop.feeds, pop.datasets, pop.files,
                             pop.missing_files, refresh_token=FIXTURE_CANARY)
    if scripted_faults:
        srv.script("GET /v1/gtfs_feeds", [Fault(429, {"Retry-After": "2"}), Fault(503)])
        first = pop.feeds[0]["id"]
        srv.script(f"GET /v1/gtfs_feeds/{first}/datasets", [Fault(transport=True)])
    return pop, srv


def build_adapters(cfg: EffectiveConfig, faults: MockFaults | None = None) -> dict:
    f = faults or MockFaults()
    ev = MockContractEvaluator()
    return {"validator": MockValidatorProducer(f), "otp": MockOtpProducer(f), "resource_manager": MockResourceManager(f),
            "oracle": MockOracleEvaluator(f), "contract_gen": MockContractGenerator(), "contract_eval": ev,
            "admission": MockAdmissionEngine(ev), "repair": MockRepairEngine(),
            "baselines": {n: MockBaseline(n, ev) for n in ("N0", "N1", "N2", "N3", "N4", "N5", "N6")},
            "cost": MockCostRecorder(), "replay": MockReplayEngine(),
            "mutation": MockMutationEngine(cfg.spec.seed_bytes("mutation")), "statistics": MockStatisticsEngine(),
            "freeze_seal": MockFreezeSealManager(f)}


def fixture_wiring(cfg: EffectiveConfig, scripted_faults: bool = True, crash_after_fetches: int | None = None,
                   mock_faults: MockFaults | None = None) -> dict:
    if cfg.mode != "FIXTURE":
        raise RealModeRefused("fixture wiring requested outside FIXTURE mode")
    pop, srv = build_fixture_server(cfg, scripted_faults)
    services = {"transport": srv, "sleeper": RecordingSleeper(), "population": pop, "server": srv}
    if crash_after_fetches is not None:
        services["crash_after_fetches"] = crash_after_fetches
    return {"services": services, "adapters": build_adapters(cfg, mock_faults),
            "secrets": StaticSecretProvider({"MOBILITY_DB_TOKEN": FIXTURE_CANARY}),
            "clock": FixedTickClock(cfg.runtime["clock"]["start"] or "2026-10-08T00:00:00Z")}
