"""The explicit 19-phase one-shot campaign definition (00 → 18)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from . import dataplane as dp
from . import later_phases as lp


@dataclass(frozen=True)
class PhaseDef:
    number: int
    phase_id: str
    title: str
    engine: str          # REAL_S1 | MOCK_ADAPTER (later-session component behind a stable interface)
    runner: Callable


PHASES: tuple[PhaseDef, ...] = (
    PhaseDef(0, "00_bootstrap_preflight", "bootstrap/preflight", "REAL_S1", lp.phase00_preflight),
    PhaseDef(1, "01_l28_target_conformance", "L28 target-resource conformance", "REAL_S2", lp.phase01_l28),
    PhaseDef(2, "02_mobility_snapshot", "Mobility snapshot", "REAL_S1", dp.phase02_snapshot),
    PhaseDef(3, "03_logical_versions", "logical versions", "REAL_S1", dp.phase03_logical_versions),
    PhaseDef(4, "04_license_gate", "license gate", "REAL_S1", dp.phase04_license),
    PhaseDef(5, "05_eligible_regions", "eligible regions", "REAL_S1", dp.phase05_regions),
    PhaseDef(6, "06_select_24", "select 24", "REAL_S1", dp.phase06_select),
    PhaseDef(7, "07_split_8_16", "split 8/16", "REAL_S1", dp.phase07_split),
    PhaseDef(8, "08_osm_pinning", "OSM acquisition/pinning", "MOCK_ADAPTER", lp.phase08_osm),
    PhaseDef(9, "09_scientific_freeze", "scientific freeze", "REAL_S2", lp.phase09_freeze),
    PhaseDef(10, "10_implementation_conformance", "implementation conformance", "REAL_S2", lp.phase10_conformance),
    PhaseDef(11, "11_validation", "validation", "REAL_S3", lp.phase11_validation),
    PhaseDef(12, "12_campaign_gate_certificate", "campaign gate certificate", "MOCK_ADAPTER", lp.phase12_gate_certificate),
    PhaseDef(13, "13_scientific_test_campaign", "scientific test campaign", "REAL_S3", lp.phase13_test_campaign),
    PhaseDef(14, "14_result_reconciliation", "result reconciliation", "REAL_S3", lp.phase14_reconcile),
    PhaseDef(15, "15_raw_result_seal", "raw-result seal", "REAL_S3", lp.phase15_raw_seal),
    PhaseDef(16, "16_frozen_statistics", "frozen statistics", "REAL_S3", lp.phase16_statistics),
    PhaseDef(17, "17_result_package", "result package", "MOCK_ADAPTER", lp.phase17_package),
    PhaseDef(18, "18_final_verdict", "final verdict", "MOCK_ADAPTER", lp.phase18_verdict),
)
PHASE_IDS = tuple(p.phase_id for p in PHASES)
assert len(PHASES) == 19 and [p.number for p in PHASES] == list(range(19))
