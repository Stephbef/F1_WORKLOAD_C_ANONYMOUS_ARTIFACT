"""Session-3 fixture E2E — identifiability traces T1–T4 (provenance V4_13) on SYNTHETIC non-study feeds.
ENGINEERING FIXTURE ONLY — NOT SCIENTIFIC RESULTS.

Each trace is one 2-feed region (A, B; America/Los_Angeles) on local day d = 2025-06-10 with the frozen schedule
(validator at availability, OTP 02:00 local, consumer 06:00 local). Producers: deterministic in-process
FIXTURE_STUB producers (validator 600 s / otp 5400 s fixture durations; per-job overrides as the trace requires).
All arms run: F1(K0..K2), N5(K0..K2), N1.
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path

from ... import workload_c
from ..config.spec import load_protocol_spec
from ..contracts.generators import ContractSystem
from ..engines.baselines_n import FixtureNativeOtpBuilder
from ..engines.core import InProcessFixtureProducer, RegionState, VersionInfo
from ..engines.runner import RegionCampaign
from ..engines.stats import record_to_json
from ..fixturegen.gtfs_gen import FeedContent, FStop, build_zip
from ..ingestion.gtfs import canonical_content_hash
from ..interfaces import session3 as S
from ..scheduler.workload_c import FixtureDurationBackend, RegionScheduleInput, VersionAvailability, simulate
from ..storage.blobstore import BlobStore

TZ = "America/Los_Angeles"
STOPS = (FStop("s1", 37.77, -122.42), FStop("s2", 37.78, -122.41), FStop("s3", 37.79, -122.40))
TICK = "2025-06-10T13:00:00Z"                      # 06:00 local (PDT)


def _feed(key: str, **kw) -> bytes:
    return build_zip(FeedContent(key, ((f"ag{key}", f"Agency {key}", TZ),), STOPS, weekday_pattern="1111111", **kw))


def trace_feeds(trace: str) -> dict:
    a0 = _feed("A")
    b0 = _feed("B")
    if trace in ("T1", "T2"):
        a1 = _feed("A", headway_min=20)                                     # active stop_times change inside D
    elif trace == "T3":
        a1 = _feed("A", calendar_dates=(("S1", "20261225", 2),))           # change only beyond the horizon
    elif trace == "T4":
        a0 = _feed("A", service_end="20250612")                             # A0 does not cover D = [06-10, 06-16]
        a1 = _feed("A", headway_min=20)                                     # effective immediately
    else:
        raise ValueError(trace)
    return {"A0": a0, "A1": a1, "B0": b0}


WINDOW_START = "2025-06-10T07:00:00Z"
AVAIL = {"A0": "2025-06-10T07:10:00Z", "B0": "2025-06-10T07:20:00Z", "A1": "2025-06-10T10:00:00Z"}
VAL_A1_S = {"T1": 4 * 3600, "T2": 3600, "T3": 3600, "T4": 3600}           # T1: VAL(A1) runs past 06:00


def run_trace(trace: str, out: Path, producer_outcomes: dict | None = None) -> dict:
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    spec = load_protocol_spec()
    names = spec.gtfs_member_names
    blobs = BlobStore(out / "store")
    rid = f"R:{trace}"
    feeds = trace_feeds(trace)
    versions = {}
    for key, idx in (("A0", 1), ("A1", 2), ("B0", 1)):
        f = key[0]
        ref = blobs.put(feeds[key], "application/zip", provenance={"fixture": f"{trace}/{key}", "namespace": "FIXTURE"})
        versions[(f, idx)] = VersionInfo(f, idx, f"{f}#L{idx}", canonical_content_hash(feeds[key], names), ref.sha256,
                                         AVAIL[key])
    region = RegionState(rid, TZ, ("A", "B"), versions, "osm:fixture", "semcfg:fixture", "otp:fixture-stub",
                         "validator:fixture-stub", "US", blobs)
    rin = RegionScheduleInput(rid, TZ, ("A", "B"),
                              tuple(VersionAvailability(v.feed_id, v.index, v.logical_version_id, v.available_utc)
                                    for v in versions.values()), WINDOW_START, "2025-06-11T07:00:00Z")
    sched = simulate(spec, rin, FixtureDurationBackend(overrides={"validator|A|2": VAL_A1_S[trace]}))
    cs = ContractSystem(blobs, names)
    from ..engines.core import CutContextFactoryImpl
    ctxf = CutContextFactoryImpl(region)
    run = S.RunIdentityRecord(f"e2e-s3-{trace}", "FIXTURE", "fixture", "fixture")
    camp = RegionCampaign(region, sched.events, cs,
                          lambda: InProcessFixtureProducer(region, cs, ctxf, outcomes=producer_outcomes), run, out,
                          native_builder=FixtureNativeOtpBuilder(out / "n1"), analysis_window_start=WINDOW_START)
    recs = camp.run([TICK])
    ledger = camp.seal()
    rows = [record_to_json(r) for r in recs]
    (out / "decisions.json").write_text(json.dumps(rows, indent=1, sort_keys=True))
    summary = {(r["method"], r["level"]): {"action": r["action"], "mode": r["mode"], "witness_cut": r["witness_cut_id"],
                                           "failing": [s["slot_id"] for s in r["rederivations"]],
                                           "opt_current": r["opt_current"], "opt_hist": r["opt_hist"]}
               for r in rows}
    return {"marker": workload_c.FIXTURE_MARKER, "trace": trace, "decisions": summary, "records": rows,
            "raw_records": recs, "ledger": ledger, "campaign": camp, "region": region}


def run_all(out: Path) -> dict:
    res = {t: run_trace(t, out / t) for t in ("T1", "T2", "T3", "T4")}
    (out / "TRACES_SUMMARY.json").write_text(json.dumps(
        {t: {f"{m}/{k}": v for (m, k), v in r["decisions"].items()} for t, r in res.items()}, indent=1, sort_keys=True))
    return res
