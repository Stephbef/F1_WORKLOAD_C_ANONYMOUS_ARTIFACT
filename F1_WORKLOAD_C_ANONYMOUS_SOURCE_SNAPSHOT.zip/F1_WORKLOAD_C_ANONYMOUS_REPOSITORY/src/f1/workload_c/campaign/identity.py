"""Implementation/source identity: SHA-256 over the sorted (relative path, file SHA-256) list of every Python
source under src/f1 plus the frozen-spec manifest. Any code change yields a new implementation id, which
checkpoints bind (incompatible resume is refused)."""
from __future__ import annotations

import hashlib
from functools import lru_cache
from pathlib import Path

from .. import paths


@lru_cache(maxsize=None)
def implementation_id(root: str | None = None) -> str:
    r = Path(root) if root else paths.REPO_ROOT
    items = []
    for p in sorted((r / "src" / "f1").rglob("*.py")):
        if "__pycache__" in p.parts:
            continue
        items.append(f"{p.relative_to(r).as_posix()}:{hashlib.sha256(p.read_bytes()).hexdigest()}")
    fm = r / "frozen_specs" / "FROZEN_SPECS_SHA256.txt"
    if fm.exists():
        items.append("frozen_specs:" + hashlib.sha256(fm.read_bytes()).hexdigest())
    return "wc-s1:" + hashlib.sha256("\n".join(items).encode()).hexdigest()
