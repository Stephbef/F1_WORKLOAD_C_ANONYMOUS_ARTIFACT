"""One-shot 19-phase orchestrator with hard-gate semantics, durable state, checkpoints and resume.

Semantics:
  * PASS -> continue; FAIL/BLOCKED -> stop. No automatic adaptation, no best-effort continuation.
  * A phase enters RUNNING only if every earlier phase is COMPLETE (enforced by the ledger itself).
  * Outputs are written atomically and hashed, a namespaced phase manifest is committed to the ManifestStore,
    THEN the ledger records COMPLETE, THEN the checkpoint is written. A crash anywhere before COMPLETE leaves the
    phase RUNNING; resume marks it FAILED(INTERRUPTED) and re-runs only that phase.
  * Resume verifies run identity (implementation id, config digest incl. frozen spec, namespace, mode) and the
    hashes of every completed output; any mismatch refuses resume.
  * REAL mode refuses in Session 1 with REAL_MODE_NOT_YET_IMPLEMENTATION_COMPLETE before any I/O to APIs.
  * Failure injection (FAIL/BLOCKED at any phase, crash-after-outputs) is accepted only in FIXTURE mode.
"""
from __future__ import annotations

import os
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path

from ... import workload_c
from ...common.util import sha256_file
from ..checkpoint.store import CheckpointStore, RunIdentity
from ..config.runtime import EffectiveConfig
from ..errors import (CheckpointIntegrityError, FailureInjectionNotAllowed, MissingSecretError, PhaseBlocked,
                      PhaseFailed, RealModeRefused, WCError)
from ..security.secrets import REDACTOR, SecretProvider
from ..state.journal import StructuredLog
from ..state.run_state import PhaseState, RunStateLedger
from ..storage.blobstore import BlobStore, ManifestStore, SnapshotStore
from .context import PhaseContext
from .identity import implementation_id as _impl_id
from .phases import PHASE_IDS, PHASES


class InjectedCrash(BaseException):
    """FIXTURE/test-only: simulates abrupt process death after outputs are written but before COMPLETE."""


@dataclass
class FailureInjection:
    phase_actions: dict = field(default_factory=dict)      # phase_id -> "FAIL" | "BLOCKED"
    crash_after_outputs: str | None = None                 # phase_id
    crash_mode: str = "exception"                          # "exception" | "exit"

    def empty(self) -> bool:
        return not self.phase_actions and self.crash_after_outputs is None


@dataclass
class RunResult:
    run_id: str
    status: str                 # COMPLETE | FAILED | BLOCKED | REFUSED
    stopped_at: str | None
    states: dict
    run_dir: Path
    error: dict | None = None


def resolve_phase(token: str) -> str:
    for pid in PHASE_IDS:
        if token == pid or token == pid[:2] or token.lstrip("0") == pid[:2].lstrip("0") and token.isdigit():
            return pid
    raise ValueError(f"unknown phase {token!r}")


class Orchestrator:
    def __init__(self, cfg: EffectiveConfig, run_root: str | Path, run_id: str | None = None,
                 secrets: SecretProvider | None = None, services: dict | None = None, adapters: dict | None = None,
                 clock=None, injection: FailureInjection | None = None, implementation_id: str | None = None) -> None:
        self.cfg = cfg
        self.run_id = run_id or f"{cfg.runtime['run_id_prefix']}-{cfg.digest[:12]}"
        self.run_dir = Path(run_root) / cfg.namespace / self.run_id
        self.secrets = secrets
        self.services = services or {}
        self.adapters = adapters or {}
        self.clock = clock
        self.injection = injection or FailureInjection()
        self.impl = implementation_id or _impl_id()
        if not self.injection.empty() and not (cfg.mode == "FIXTURE" and cfg.runtime["failure_injection_allowed"]):
            raise FailureInjectionNotAllowed("failure injection is accepted only in FIXTURE mode")
        if secrets is None and cfg.mode == "FIXTURE":
            raise MissingSecretError("a SecretProvider is required (FIXTURE uses a synthetic StaticSecretProvider)")

    def identity(self) -> RunIdentity:
        return RunIdentity(run_id=self.run_id, implementation_id=self.impl, config_digest=self.cfg.digest,
                           spec_digest=self.cfg.spec.digest, namespace=self.cfg.namespace, mode=self.cfg.mode)

    def run(self) -> RunResult:
        if self.cfg.mode == "REAL":
            raise RealModeRefused(workload_c.REAL_MODE_REFUSAL + ": Session 3/4 engines and seals are incomplete")
        rd = self.run_dir
        rd.mkdir(parents=True, exist_ok=True)
        ident = self.identity()
        cps = CheckpointStore(rd / "checkpoints", rd)
        cps.verify_resume(ident)       # raises IncompatibleResumeError / CheckpointIntegrityError
        cps.bind_identity(ident)
        blobs = BlobStore(rd / "store")
        blobs.recover()
        manifests = ManifestStore(blobs)
        snapshots = SnapshotStore(blobs, manifests)
        ledger = RunStateLedger(rd / "ledger" / "run_state.jsonl", self.run_id, list(PHASE_IDS), self.clock)
        log = StructuredLog(rd / "logs" / "events.jsonl", self.run_id, self.cfg.namespace, self.clock)
        # checkpoint <-> ledger consistency (truncation / rewrite detection)
        for stored in cps.list():
            ledger.journal.verify(expect_head=stored["ledger_head"], expect_min_length=stored["ledger_length"])
            if ledger.state(stored["phase"]) != PhaseState.COMPLETE:
                raise CheckpointIntegrityError(f"checkpoint for {stored['phase']} but ledger says "
                                               f"{ledger.state(stored['phase']).value}")
        log.emit("RUN_START", component="orchestrator", status="RUNNING",
                 message=f"mode={self.cfg.mode} impl={self.impl[:20]} config={self.cfg.digest[:12]}")
        prior: dict[str, dict] = {}
        for ph in PHASES:
            pid = ph.phase_id
            st = ledger.state(pid)
            if st == PhaseState.COMPLETE:
                cp = cps.load(pid)
                if cp is None:
                    raise CheckpointIntegrityError(f"{pid} COMPLETE in ledger but checkpoint missing")
                cps.verify_outputs(cp)
                prior[pid] = cp["outputs"]
                log.emit("PHASE_REUSED", phase=pid, component="orchestrator", status="COMPLETE",
                         output_hashes={"manifest": cp["manifest_sha256"]})
                continue
            if st == PhaseState.RUNNING:   # stale RUNNING from an interrupted process
                ledger.transition(pid, PhaseState.FAILED, config_digest=self.cfg.digest, implementation_id=self.impl,
                                  error={"error_class": "INTERRUPTED", "message": "process interrupted"},
                                  note="resume: stale RUNNING")
                log.emit("PHASE_INTERRUPTED_DETECTED", phase=pid, component="orchestrator", status="FAILED",
                         error_class="INTERRUPTED")
            inputs = {p: dict(v) for p, v in prior.items()}
            ledger.transition(pid, PhaseState.RUNNING, config_digest=self.cfg.digest, implementation_id=self.impl,
                              inputs={p: _digest_map(v) for p, v in inputs.items()})
            log.emit("PHASE_START", phase=pid, component=ph.engine, status="RUNNING")
            t0 = time.monotonic()
            ctx = PhaseContext(cfg=self.cfg, run_id=self.run_id, run_dir=rd, phase_id=pid, blobs=blobs,
                               manifests=manifests, snapshots=snapshots, log=log, clock=self.clock,
                               secrets=self.secrets, adapters=self.adapters, services=self.services,
                               implementation_id=self.impl, prior_outputs=inputs)
            try:
                act = self.injection.phase_actions.get(pid)
                if act == "FAIL":
                    raise PhaseFailed(f"injected FAIL at {pid}")
                if act == "BLOCKED":
                    raise PhaseBlocked(f"injected BLOCKED at {pid}")
                summary = ph.runner(ctx)
                outputs = {rel: sha256_file(rd / rel) for rel in sorted(ctx.written)}
                if not outputs:
                    raise PhaseFailed(f"{pid} produced no durable output")
                man = manifests.put({"schema": "F1-WC-PHASE-MANIFEST-1", "kind": "phase_output",
                                     "namespace": self.cfg.namespace, "run_id": self.run_id, "phase": pid,
                                     "engine": ph.engine, "config_digest": self.cfg.digest,
                                     "implementation_id": self.impl,
                                     "inputs": {p: _digest_map(v) for p, v in inputs.items()},
                                     "outputs": outputs, "summary": REDACTOR.redact(summary)})
                if self.injection.crash_after_outputs == pid:
                    if self.injection.crash_mode == "exit":
                        os._exit(137)
                    raise InjectedCrash(f"injected crash after outputs of {pid}")
                ledger.transition(pid, PhaseState.COMPLETE, config_digest=self.cfg.digest,
                                  implementation_id=self.impl, outputs=outputs,
                                  note=f"manifest={man.sha256}")
                cps.write(self.identity(), pid, outputs, ledger.journal.head, ledger.journal.length, man.sha256)
                prior[pid] = outputs
                log.emit("PHASE_COMPLETE", phase=pid, component=ph.engine, status="COMPLETE",
                         duration_s=time.monotonic() - t0, output_hashes={"manifest": man.sha256})
            except PhaseBlocked as e:
                return self._stop(ledger, log, pid, PhaseState.BLOCKED, e, t0)
            except Exception as e:   # noqa: BLE001 - every failure is recorded and stops the run (hard gate)
                return self._stop(ledger, log, pid, PhaseState.FAILED, e, t0)
        log.emit("RUN_COMPLETE", component="orchestrator", status="COMPLETE",
                 message=workload_c.FIXTURE_MARKER if self.cfg.mode == "FIXTURE" else None)
        return RunResult(self.run_id, "COMPLETE", None, ledger.snapshot(), rd)

    def _stop(self, ledger, log, pid, state, exc, t0) -> RunResult:
        err = exc.to_record() if isinstance(exc, WCError) else {
            "error_class": "UNEXPECTED_" + type(exc).__name__, "type": type(exc).__name__, "message": str(exc),
            "traceback_tail": traceback.format_exc(limit=3)[-1500:]}
        err = REDACTOR.redact(err)
        ledger.transition(pid, state, config_digest=self.cfg.digest, implementation_id=self.impl, error=err)
        log.emit("PHASE_" + state.value, phase=pid, component="orchestrator", status=state.value,
                 error_class=err["error_class"], duration_s=time.monotonic() - t0, message=err["message"][:500])
        log.emit("RUN_STOPPED_HARD_GATE", component="orchestrator", status=state.value, phase=pid)
        return RunResult(self.run_id, state.value, pid, ledger.snapshot(), self.run_dir, err)


def _digest_map(m: dict) -> str:
    from ...common.util import sha256_obj
    return sha256_obj(m)
