"""Phases 00, 01 and 08–18. Phase 00 is a real Session-1 preflight; 01 and 08–18 call later-session components
exclusively through `interfaces.protocols` (MOCK adapters in FIXTURE mode). Glue code here only moves typed
results, enforces namespaces/authorization/seals, and writes manifests; it embeds no scientific behaviour."""
from __future__ import annotations

import platform
import sys

from ... import workload_c
from ...common.util import sha256_file, sha256_obj
from ..errors import PhaseBlocked, PhaseFailed
from ..interfaces.protocols import FeedVersionRef, Seal
from ..security.namespaces import (AuthorizationContext, IdentityCertificateVerifier, Namespace, TestExecutionGuard,
                                   make_certificate)
from .context import PhaseContext

FIXTURE_CUTS = ("2025-06-03T06:00:00Z", "2025-11-04T06:00:00Z", "2026-03-03T06:00:00Z")


def phase00_preflight(ctx: PhaseContext) -> dict:
    spec = ctx.cfg.spec
    manifest = spec.root / "FROZEN_SPECS_SHA256.txt"
    bad = []
    n = 0
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        h, rel = line.split("  ", 1)
        n += 1
        p = spec.root / rel
        if not p.is_file() or sha256_file(p) != h:
            bad.append(rel)
    if bad:
        raise PhaseFailed(f"frozen spec files changed or missing: {bad}")
    if sys.version_info < (3, 11):
        raise PhaseBlocked("Python >= 3.11 required")
    env = {"python": platform.python_version(), "implementation": platform.python_implementation(),
           "platform": platform.platform(terse=True), "machine": platform.machine()}
    from ..deps.pins import verify_all
    dep = [s.to_dict() for s in verify_all()]
    real_ok = all(s["status"] in ("VERIFIED", "VERIFIED_BY_VERSION") for s in dep)
    ctx.write_json("pinned_dependencies.json", {"statuses": dep, "all_real_pins_verified": real_ok,
                                                "binary_mode_available": "REAL_PINNED_BINARY" if real_ok
                                                else "FIXTURE_STUB_BINARY"})
    if ctx.mode == "REAL" and not real_ok:
        raise PhaseBlocked("pinned dependencies not verified (REAL requires REAL_PINNED_BINARY)")
    ctx.write_json("preflight.json", {
        "namespace": ctx.namespace, "mode": ctx.mode, "marker": workload_c.FIXTURE_MARKER if ctx.mode == "FIXTURE" else None,
        "frozen_specs_verified": n, "spec_digest": spec.digest, "config_digest": ctx.cfg.digest,
        "interpretations_status": ctx.cfg.interp.raw["status"], "license_table_status": ctx.cfg.license_table.raw["status"],
        "implementation_id": ctx.implementation_id, "environment": env, "gpu_required": False})
    return {"frozen_specs_verified": n}


def phase01_l28(ctx: PhaseContext) -> dict:
    """Session 2: the REAL L28 runner is executed with the AUTHORITATIVE envelope on this host. The physical result is
    recorded as-is (BLOCKED / NOT_EXECUTED_ON_TARGET on non-target hosts). FIXTURE mode passes the fixture gate on a
    recorded non-PASS result (never relabelled PASS); REAL mode requires overall PASS on the attested target."""
    from ..l28.runner import run_l28
    from ..resources.manager import ResourceManager, detect_capabilities, otp_authoritative_envelope
    if "l28_runner" in ctx.services:
        res = ctx.services["l28_runner"](ctx.phase_dir / "l28")
    else:
        def suite(envelope, wrapper):
            raise PhaseFailed("determinism suite requested on a host that passed the envelope checks; run "
                              "scripts/run_l28_fixture.sh / the server runbook instead of the fixture orchestrator")
        mgr = ResourceManager(detect_capabilities(probe_systemd=True), allow_noop=False)
        res = run_l28(mgr, otp_authoritative_envelope(ctx.cfg.spec), ctx.phase_dir / "l28", None, suite).to_dict()
    for f in sorted((ctx.phase_dir / "l28").glob("*")):
        ctx.written[ctx.rel("l28/" + f.name)] = True
    gate = "PASS" if (res["overall"] == "PASS" and res["physical_l28"] == "EXECUTED_ON_TARGET") else \
        ("FIXTURE_ONLY_ACCEPTED" if ctx.mode == "FIXTURE" else "BLOCKED")
    ctx.write_json("target_result.json", {"l28": res, "phase_gate": gate, "namespace": ctx.namespace,
                                          "physical_l28": res["physical_l28"]})
    if gate == "BLOCKED":
        raise PhaseBlocked(f"L28 not satisfied: {res['overall']} / {res['physical_l28']}")
    return {"overall": res["overall"], "physical_l28": res["physical_l28"], "phase_gate": gate}


def phase08_osm(ctx: PhaseContext) -> dict:
    regs = {r["region_id"]: r for r in ctx.read_prior_json("05_eligible_regions", "regions.json")["regions"]}
    sel = [r["region_id"] for r in ctx.read_prior_csv("06_select_24", "selected_24.csv")]
    pins = []
    for rid in sel:
        bb = regs[rid]["bbox"]
        pin = {"region_id": rid, "snapshot_date": "2025-04-01", "strategy": "complete_ways",
               "bbox_hull_plus_km": 5, "bbox": bb, "source": "MOCK:geofabrik", "mock": True}
        pin["sha256"] = sha256_obj(["MOCK-OSM", pin])
        pins.append(pin)
    ctx.write_json("osm_pins.json", {"namespace": ctx.namespace, "pins": pins})
    return {"n_pins": len(pins)}


def _committed(ctx: PhaseContext, phases: list[str]) -> dict[str, str]:
    out = {}
    for ph in phases:
        out.update(ctx.prior_outputs[ph])
    return out


def phase09_freeze(ctx: PhaseContext) -> dict:
    if ctx.mode == "REAL" and not ctx.cfg.interp.confirmed:
        raise PhaseBlocked("scientific freeze requires PI_CONFIRMED spec interpretations (SCIENTIFIC_SPEC_BLOCKER.md)")
    phases = [p for p in ctx.prior_outputs if p < "09"]
    from .seal import FreezeSeal
    files = _committed(ctx, phases)
    root = ctx.cfg.spec.root
    for line in (root / "FROZEN_SPECS_SHA256.txt").read_text().splitlines():      # freeze the local frozen inputs too
        if line.strip():
            h, rel = line.split("  ", 1)
            files["frozen_specs/" + rel] = h
    from ...common.util import sha256_file
    from .. import paths as _p
    for rel in ("configs/workload_c/pinned_dependencies.json", "configs/workload_c/spec_interpretations.json",
                "configs/workload_c/license_identifier_table.json"):
        files[rel] = sha256_file(_p.REPO_ROOT / rel)
    seal: Seal = FreezeSeal().seal("scientific-freeze", ctx.namespace, files)
    ctx.write_json("freeze_seal.json", {**seal.__dict__, "interpretations_status": ctx.cfg.interp.raw["status"],
                                        "config_digest": ctx.cfg.digest})
    return {"seal_sha256": seal.seal_sha256, "n_files": len(seal.files)}


def phase10_conformance(ctx: PhaseContext) -> dict:
    """Session 2 (real, local): frozen fixture integrity, frozen config suite C1–C8 through the integrated semantic
    config digest, K2↔Canon alignment over all 35 frozen oracle pairs, Canon source identity. The real-binary oracle
    and determinism suites (OTP builds) run via scripts/run_oracle_conformance.sh; their evidence is checked here when
    present (the fixture orchestrator does not rebuild 40 graphs per run)."""
    from ..conformance import harness as H
    from ..contracts.alignment import k2_canon_alignment
    n_fix = H.verify_fixtures()
    cfg_rows = H.config_suite(ctx.phase_dir / "config_results.csv")
    ctx.written[ctx.rel("config_results.csv")] = True
    al = k2_canon_alignment()
    tests = {r["test"]: r["result"] for r in cfg_rows}
    tests.update({f"K2ALIGN-{r['test']}": ("PASS" if r["sound"] else "FAIL") for r in al})
    overall = "PASS" if all(v == "PASS" for v in tests.values()) else "FAIL"
    ctx.write_json("implementation_conformance.json", {"overall": overall, "tests": tests, "mock": False,
                                                       "fixtures_verified": n_fix, "k2_alignment": al,
                                                       "namespace": ctx.namespace,
                                                       "canon_source_sha256": ctx.cfg.spec["sources"]["CANON06"]["sha256"]})
    if overall != "PASS":
        raise PhaseFailed("implementation conformance FAIL")
    return {"overall": overall, "n_tests": len(tests)}


def _run_partition(ctx: PhaseContext, region_ids: list[str], partition: str, unit_ns: str) -> list[dict]:
    regs = {r["region_id"]: r for r in ctx.read_prior_json("05_eligible_regions", "regions.json")["regions"]}
    pins = {p["region_id"]: p for p in ctx.read_prior_json("08_osm_pinning", "osm_pins.json")["pins"]}
    a = ctx.adapters
    out = []
    for rid in region_ids:
        feeds = [FeedVersionRef(f["feed_id"], f["latest_lv"], f["latest_canonical_sha256"]) for f in regs[rid]["feeds"]]
        vals = [a["validator"].validate(rid, fv, "2026-06-30", "XX", unit_ns) for fv in feeds]
        router = a["otp"].build(rid, feeds, pins[rid], ctx.cfg.digest, unit_ns)
        contracts = [a["contract_gen"].generate(router, k) for k in ("K0", "K1", "K2", "K3")] \
            if router.status == "OK" else []
        for cut in FIXTURE_CUTS:
            slot = f"{rid}|ROUTER"
            for eng_name, dec in (("F1", a["admission"].admit(slot, contracts, cut)),
                                  ("N5", a["baselines"]["N5"].decide(slot, cut, contracts)),
                                  ("N1", a["baselines"]["N1"].decide(slot, cut, contracts))):
                rec = {"record_id": sha256_obj([partition, rid, cut, eng_name])[:32], "namespace": unit_ns,
                       "partition": partition, "region_id": rid, "cut": cut, "engine": eng_name,
                       "action": dec.action, "witness": dec.witness, "router_artifact": router.artifact_id,
                       "router_status": router.status, "validation_artifacts": [v.artifact_id for v in vals],
                       "mock": True}
                out.append(rec)
                a["cost"].record({"namespace": unit_ns, "region_id": rid, "kind": f"decision:{eng_name}",
                                  "record_id": rec["record_id"]})
    return out


def phase11_validation(ctx: PhaseContext) -> dict:
    from . import s3_phases
    return s3_phases.phase11_validation(ctx)


def _auth_ctx(ctx: PhaseContext, freeze_seal: str) -> AuthorizationContext:
    ns = Namespace.TEST if ctx.mode == "REAL" else Namespace.FIXTURE
    return AuthorizationContext(namespace=ns, campaign_id=f"campaign:{ctx.run_id}", run_id=ctx.run_id,
                                freeze_seal_sha256=freeze_seal, implementation_id=ctx.implementation_id,
                                config_digest=ctx.cfg.digest)


def phase12_gate_certificate(ctx: PhaseContext) -> dict:
    seal = ctx.read_prior_json("09_scientific_freeze", "freeze_seal.json")
    conf = ctx.read_prior_json("10_implementation_conformance", "implementation_conformance.json")
    val = ctx.read_prior_jsonl("11_validation", "validation_raw.jsonl")
    if conf["overall"] != "PASS" or not val:
        raise PhaseFailed("campaign gate preconditions not met")
    if ctx.mode == "REAL":
        raise PhaseBlocked("real campaign certificate requires Session-4 PI authorization workflow")
    cert = make_certificate(_auth_ctx(ctx, seal["seal_sha256"]), issued_by="fixture-orchestrator", issuer_kind="FIXTURE")
    ctx.write_json("campaign_certificate.json", cert)
    return {"certificate_sha256": cert["certificate_sha256"], "issuer_kind": cert["issuer_kind"]}


def phase13_test_campaign(ctx: PhaseContext) -> dict:
    seal = ctx.read_prior_json("09_scientific_freeze", "freeze_seal.json")
    cert = ctx.read_prior_json("12_campaign_gate_certificate", "campaign_certificate.json")
    actx = _auth_ctx(ctx, seal["seal_sha256"])
    accepted = {"FIXTURE"} if ctx.mode == "FIXTURE" else {"PI_AUTHORIZED"}
    TestExecutionGuard(IdentityCertificateVerifier(accepted)).authorize(actx, cert)
    rows = ctx.read_prior_csv("07_split_8_16", "test_16.csv")
    ns = "TEST" if ctx.mode == "REAL" else "FIXTURE"
    from . import s3_phases
    return s3_phases.phase13_campaign(ctx, rows, ns)


def phase14_reconcile(ctx: PhaseContext) -> dict:
    from . import s3_phases
    return s3_phases.phase14_reconcile(ctx)


def phase15_raw_seal(ctx: PhaseContext) -> dict:
    files = _committed(ctx, ["13_scientific_test_campaign", "14_result_reconciliation"])
    from .seal import FreezeSeal
    seal = FreezeSeal().seal("raw-results", ctx.namespace, files)
    ctx.write_json("raw_result_seal.json", seal.__dict__)
    return {"seal_sha256": seal.seal_sha256}


def phase16_statistics(ctx: PhaseContext) -> dict:
    sd = ctx.read_prior_json("15_raw_result_seal", "raw_result_seal.json")
    files = _committed(ctx, ["13_scientific_test_campaign", "14_result_reconciliation"])
    from .seal import FreezeSeal
    FreezeSeal().verify(Seal(**sd), files)
    recs = ctx.read_prior_jsonl("13_scientific_test_campaign", "test_raw.jsonl")
    ns = "TEST" if ctx.mode == "REAL" else "FIXTURE"
    from . import s3_phases
    return s3_phases.phase16_statistics(ctx, recs, ns)


def phase17_package(ctx: PhaseContext) -> dict:
    files = _committed(ctx, sorted(ctx.prior_outputs))
    ctx.write_json("result_package_manifest.json", {"namespace": ctx.namespace, "marker": workload_c.FIXTURE_MARKER
                                                    if ctx.mode == "FIXTURE" else None, "files": files,
                                                    "package_digest": sha256_obj(files)})
    ctx.write_bytes("README_RESULTS.md", (f"# {workload_c.FIXTURE_MARKER}\n\nRun `{ctx.run_id}` — synthetic fixture "
                                          "population, mock later-session components. Contains no scientific "
                                          "result.\n").encode("utf-8"))
    return {"n_files": len(files)}


def phase18_verdict(ctx: PhaseContext) -> dict:
    pkg = ctx.read_prior_json("17_result_package", "result_package_manifest.json")
    verdict = {"run_id": ctx.run_id, "namespace": ctx.namespace, "mode": ctx.mode,
               "marker": workload_c.FIXTURE_MARKER if ctx.mode == "FIXTURE" else None,
               "verdict": "FIXTURE_ORCHESTRATION_COMPLETE" if ctx.mode == "FIXTURE" else "UNDEFINED_IN_S1",
               "package_digest": pkg["package_digest"], "phases_complete": sorted(ctx.prior_outputs) + [ctx.phase_id],
               "scientific_results": "NONE"}
    ctx.write_json("FINAL_VERDICT.json", verdict)
    return {"verdict": verdict["verdict"]}
