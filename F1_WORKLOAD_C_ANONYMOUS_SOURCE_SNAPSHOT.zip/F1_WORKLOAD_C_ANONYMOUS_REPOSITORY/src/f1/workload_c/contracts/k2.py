"""K2_D: per-feed SHA-256 of the routing-relevant GTFS input projection over ActiveClosure_D
(spec17 §6 ROUTER K2; 08_K2_CANON_FINAL_ALIGNMENT.md; field classification 03/09 matrices).

ActiveClosure_D mirrors Canon_D's active closure at GTFS-input level:
  services     : service_ids running on >= 1 date of D (calendar ∪ calendar_dates), recorded with their D dates only
  trips        : trips of active services — route, service, block_id (interlining), direction, wheelchair, bikes, cars
  stop_times   : of active trips — sequence order, stop, arrival/departure, pickup_type/drop_off_type (board/alight)
  frequencies  : of active trips — start, end, headway_secs, exact_times
  routes       : of active trips — agency_id, route_type, bikes_allowed (extension), network membership
                 (routes.network_id ∪ route_networks.txt)
  agencies     : of active routes — agency_id, agency_timezone
  stops        : stops served by active stop_times — lat/lon, wheelchair_boarding, parent, stop_timezone, location_type,
                 level index (levels.level_index), vehicle_type (extension); their parent stations (lat/lon, timezone);
                 entrances of active stations; boarding areas of active stops
  transfers    : transfers.txt rows whose both points reference active elements
  pathways     : pathways.txt rows touching an active element
Display-only fields (names, codes, descriptions, colours, URLs, headsigns, shapes, platform codes, level names,
fares, feed_info, translations) are excluded, exactly as the matrices classify them PROVEN IRRELEVANT. Generated
walk transfers / stop links depend on coordinates (included) and OSM (bound at contract level).
"""
from __future__ import annotations

import hashlib
from datetime import date

from ...common.util import canonical_json
from ..ingestion.gtfs import read_table

ROUTING_FILES = ("agency.txt", "stops.txt", "routes.txt", "trips.txt", "stop_times.txt", "calendar.txt",
                 "calendar_dates.txt", "frequencies.txt", "transfers.txt", "pathways.txt", "levels.txt",
                 "networks.txt", "route_networks.txt")
_WD = ("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday")


def _secs(t: str) -> str:
    t = (t or "").strip()
    if not t:
        return ""
    try:
        h, m, s = (int(x) for x in t.split(":"))
        return str(h * 3600 + m * 60 + s)
    except ValueError:
        return "BAD:" + t


def active_services(cal: list[dict], cal_dates: list[dict], D: list[str]) -> dict[str, list[str]]:
    run: dict[str, set[str]] = {}
    for d in D:
        dd = date.fromisoformat(d)
        ymd = dd.strftime("%Y%m%d")
        for r in cal:
            if r.get("start_date", "") <= ymd <= r.get("end_date", "") and r.get(_WD[dd.weekday()], "0") == "1":
                run.setdefault(r["service_id"], set()).add(d)
        for r in cal_dates:
            if r.get("date") == ymd:
                if r.get("exception_type") == "1":
                    run.setdefault(r["service_id"], set()).add(d)
                elif r.get("exception_type") == "2" and r["service_id"] in run:
                    run[r["service_id"]].discard(d)
    return {k: sorted(v) for k, v in sorted(run.items()) if v}


def k2_projection(zip_bytes: bytes, D: list[str]) -> list[str]:
    T = {f: read_table(zip_bytes, f) for f in ROUTING_FILES}
    rec: list[str] = []
    svc = active_services(T["calendar.txt"], T["calendar_dates.txt"], D)
    for s, ds in svc.items():
        rec.append("service|" + s + "|" + ",".join(ds))
    trips = {t["trip_id"]: t for t in T["trips.txt"] if t.get("service_id") in svc}
    routes_all = {r["route_id"]: r for r in T["routes.txt"]}
    agencies_all = {a.get("agency_id", ""): a for a in T["agency.txt"]}
    for tid, t in sorted(trips.items()):
        rec.append("trip|" + "|".join([tid, t.get("route_id", ""), t.get("service_id", ""), t.get("block_id", ""),
                                        t.get("direction_id", ""), t.get("wheelchair_accessible", ""),
                                        t.get("bikes_allowed", ""), t.get("cars_allowed", "")]))
    st_by: dict[str, list[dict]] = {}
    for r in T["stop_times.txt"]:
        if r.get("trip_id") in trips:
            st_by.setdefault(r["trip_id"], []).append(r)
    active_stops: set[str] = set()
    for tid, rows in sorted(st_by.items()):
        rows.sort(key=lambda r: int(r.get("stop_sequence", "0") or 0))
        seq = [(r.get("stop_id", ""), _secs(r.get("arrival_time", "")), _secs(r.get("departure_time", "")),
                r.get("pickup_type", ""), r.get("drop_off_type", "")) for r in rows]
        active_stops.update(s[0] for s in seq)
        rec.append("stoptimes|" + tid + "|" + ";".join("/".join(x) for x in seq))
    for r in T["frequencies.txt"]:
        if r.get("trip_id") in trips:
            rec.append("frequency|" + "|".join([r["trip_id"], _secs(r.get("start_time", "")), _secs(r.get("end_time", "")),
                                                 r.get("headway_secs", ""), r.get("exact_times", "")]))
    route_nets: dict[str, set[str]] = {}
    for r in T["route_networks.txt"]:
        route_nets.setdefault(r.get("route_id", ""), set()).add(r.get("network_id", ""))
    active_routes = sorted({t.get("route_id", "") for t in trips.values()})
    active_agencies = set()
    single_agency = next(iter(agencies_all)) if len(agencies_all) == 1 else None
    for rid in active_routes:
        rr: dict[str, str] = routes_all.get(rid, {})
        ag = rr.get("agency_id", "") or (single_agency if single_agency is not None else "")
        active_agencies.add(ag)
        nets = sorted(route_nets.get(rid, set()) | ({rr["network_id"]} if rr.get("network_id") else set()))
        rec.append("route|" + "|".join([rid, ag, rr.get("route_type", ""), rr.get("bikes_allowed", ""), ",".join(nets)]))
    for ag in sorted(active_agencies):
        a = agencies_all.get(ag, {})
        rec.append("agency|" + ag + "|" + a.get("agency_timezone", ""))
    stops = {s["stop_id"]: s for s in T["stops.txt"] if s.get("stop_id")}
    levels = {lv.get("level_id", ""): lv.get("level_index", "") for lv in T["levels.txt"]}
    active_stations = {stops[s].get("parent_station", "") for s in active_stops if s in stops} - {""}
    elems = set(active_stops) | active_stations
    for sid, srow in stops.items():
        lt = srow.get("location_type", "")
        par = srow.get("parent_station", "")
        if (lt == "2" and par in active_stations) or (lt == "4" and par in active_stops):
            elems.add(sid)
    for sid in sorted(elems):
        so = stops.get(sid)
        if so is None:
            rec.append("stop|" + sid + "|<missing>")
            continue
        lvl = levels.get(so.get("level_id", ""), "") if so.get("level_id") else ""
        rec.append("stop|" + "|".join([sid, so.get("location_type", ""), so.get("stop_lat", ""), so.get("stop_lon", ""),
                                        so.get("wheelchair_boarding", ""), so.get("parent_station", ""),
                                        so.get("stop_timezone", ""), lvl, so.get("vehicle_type", "")]))
    active_trips = set(trips)

    def point_ok(stop: str, route: str, trip: str) -> bool:
        if trip and trip not in active_trips:
            return False
        if route and route not in active_routes:
            return False
        return (not stop) or stop in elems
    for r in T["transfers.txt"]:
        if point_ok(r.get("from_stop_id", ""), r.get("from_route_id", ""), r.get("from_trip_id", "")) and \
                point_ok(r.get("to_stop_id", ""), r.get("to_route_id", ""), r.get("to_trip_id", "")):
            rec.append("transfer|" + "|".join(r.get(k, "") for k in ("from_stop_id", "to_stop_id", "from_route_id",
                                                                       "to_route_id", "from_trip_id", "to_trip_id",
                                                                       "transfer_type", "min_transfer_time")))
    for r in T["pathways.txt"]:
        if r.get("from_stop_id") in elems or r.get("to_stop_id") in elems:
            rec.append("pathway|" + "|".join(r.get(k, "") for k in ("pathway_id", "from_stop_id", "to_stop_id",
                                                                      "pathway_mode", "is_bidirectional", "length",
                                                                      "traversal_time", "stair_count", "max_slope",
                                                                      "min_width")))
    return sorted(rec)


def k2_feed_digest(zip_bytes: bytes, D: list[str]) -> str:
    return hashlib.sha256(canonical_json(["F1-WC-K2-1", D, k2_projection(zip_bytes, D)]).encode()).hexdigest()


def k1_file_hashes(zip_bytes: bytes, members: tuple[str, ...] | None, gtfs_names: frozenset[str]) -> dict[str, str]:
    """Per-file normalised hashes (same normalisation as the frozen canonical hash: BOM strip, CRLF->LF)."""
    from ..ingestion.gtfs import canonical_member_pairs
    pairs = canonical_member_pairs(zip_bytes, gtfs_names)
    out: dict[str, str] = {}
    for n, h in pairs:
        if members is None or n in members:
            out[n] = h if n not in out else hashlib.sha256((out[n] + h).encode()).hexdigest()
    return dict(sorted(out.items()))
