"""Immutable contract representation (K0/K1/K2/K3) and deterministic serialization.

A contract is generated at artifact birth only (never post hoc from later outcomes). Its canonical bytes are the
canonical JSON of its body; digest = SHA-256(bytes). Identical artifact + spec -> identical bytes/digest.
"""
from __future__ import annotations

import enum
import hashlib
import inspect
from dataclasses import dataclass, field

from ...common.util import canonical_json

CONTRACT_SCHEMA = "F1-WC-CONTRACT-1"


class Level(str, enum.Enum):
    K0 = "K0"
    K1 = "K1"
    K2 = "K2"
    K3 = "K3"


class Verdict(str, enum.Enum):
    VALID = "VALID"
    INVALID = "INVALID"
    ERROR = "ERROR"


def code_digest(*objs) -> str:
    """Digest of generator/evaluator source code (binds contract semantics to implementation identity)."""
    h = hashlib.sha256()
    for o in objs:
        h.update(inspect.getsource(o).encode())
    return h.hexdigest()


@dataclass(frozen=True)
class Contract:
    schema: str
    level: str
    artifact_class: str            # VAL_REPORT | VAL_GATE | ROUTER
    artifact_id: str
    request_slot: str
    birth_cut_id: str
    footprint: dict                # level-specific, references only immutable data (hashes / blob refs)
    generator_digest: str
    evaluator_digest: str
    canonical_bytes: bytes = field(repr=False, default=b"")
    digest: str = ""

    @staticmethod
    def build(level: str, artifact_class: str, artifact_id: str, request_slot: str, birth_cut_id: str, footprint: dict,
              generator_digest: str, evaluator_digest: str) -> "Contract":
        body = {"schema": CONTRACT_SCHEMA, "level": level, "artifact_class": artifact_class, "artifact_id": artifact_id,
                "request_slot": request_slot, "birth_cut_id": birth_cut_id, "footprint": footprint,
                "generator_digest": generator_digest, "evaluator_digest": evaluator_digest}
        b = canonical_json(body).encode("utf-8")
        return Contract(CONTRACT_SCHEMA, level, artifact_class, artifact_id, request_slot, birth_cut_id, footprint,
                        generator_digest, evaluator_digest, b, hashlib.sha256(b).hexdigest())

    @property
    def contract_id(self) -> str:
        return f"{self.level}:{self.digest[:24]}"

    @property
    def metadata_size(self) -> int:
        return len(self.canonical_bytes)

    def verify(self) -> None:
        again = Contract.build(self.level, self.artifact_class, self.artifact_id, self.request_slot, self.birth_cut_id,
                               self.footprint, self.generator_digest, self.evaluator_digest)
        if again.canonical_bytes != self.canonical_bytes or again.digest != self.digest:
            raise ValueError("contract bytes/digest do not match its body (tampered)")


@dataclass(frozen=True)
class EvaluationContext:
    """Candidate context: the cut's logical-version vector with immutable blob references, and the consumer horizon."""
    cut_id: str
    feeds: dict                    # feed_id -> {"logical_version_id", "canonical_content_sha256", "raw_zip_sha256"}
    osm_sha256: str | None = None
    semantic_config_digest: str | None = None
    otp_sha256: str | None = None
    validator_sha256: str | None = None
    consumer_date: str | None = None
    country: str | None = None
    horizon: tuple[str, ...] = ()
    service_window: tuple[str, str] | None = None


@dataclass(frozen=True)
class EvaluationResult:
    contract_id: str
    cut_id: str
    verdict: str
    reason: str
    evaluator_digest: str
