"""Contract generators (at birth) and evaluators for VAL and ROUTER artifacts (spec17 §6).

VAL    K0 = canonical hash + date + country + validator digest;  K1 = per-file normalised hashes;  K2 = K1;
       K3 = re-run the validator (reference path only).
ROUTER K0 = per-feed canonical hashes + OSM + semantic config + OTP;  K1 = per-file hashes of the routing files;
       K2_D = per-feed K2 projection digest over ActiveClosure_D (+ OSM, semantic config, OTP), valid while
       D ⊆ resolved service window;  K3 = rebuild + Canon_D 1.3 (reference path only).
Evaluators are deterministic, never invoke a producer for K0/K1/K2, and fail closed: any missing/unreadable
referenced data yields ERROR (never VALID). K3 through the ordinary evaluator is ERROR by construction.
"""
from __future__ import annotations

from ...common.util import sha256_obj
from ..storage.blobstore import BlobStore
from ..errors import WCError
from .k2 import ROUTING_FILES, k1_file_hashes, k2_feed_digest
from .model import Contract, EvaluationContext, EvaluationResult, Level, Verdict, code_digest


class ContractEvaluationError(WCError):
    error_class = "CONTRACT_EVALUATION_ERROR"


class ContractSystem:
    def __init__(self, blobs: BlobStore, gtfs_names: frozenset[str]) -> None:
        self.blobs = blobs
        self.names = gtfs_names
        self.gen_digest = code_digest(ContractSystem.generate_val, ContractSystem.generate_router, ContractSystem._footprint,
                                      k2_feed_digest, k1_file_hashes)
        self.eval_digest = code_digest(ContractSystem.evaluate, ContractSystem._footprint, k2_feed_digest, k1_file_hashes)

    # ---------------------------------------------------------------------------------------------- footprints
    def _feed_bytes(self, ref: dict) -> bytes:
        return self.blobs.get(ref["raw_zip_sha256"])            # verifies the immutable blob hash

    def _footprint(self, level: str, cls: str, ctx: EvaluationContext, slot_feeds: list[str]) -> dict:
        feeds = {}
        for f in sorted(slot_feeds):
            if f not in ctx.feeds:
                raise ContractEvaluationError(f"feed {f} absent from cut {ctx.cut_id}")
            feeds[f] = ctx.feeds[f]
        if cls in ("VAL_REPORT", "VAL_GATE"):
            (f, ref), = feeds.items()
            if level == Level.K0:
                return {"canonical_content_sha256": ref["canonical_content_sha256"], "date": ctx.consumer_date,
                        "country": ctx.country, "validator_sha256": ctx.validator_sha256}
            if level in (Level.K1, Level.K2):                   # VAL K2 = K1
                return {"files": k1_file_hashes(self._feed_bytes(ref), None, self.names),
                        "date": ctx.consumer_date, "country": ctx.country, "validator_sha256": ctx.validator_sha256}
        if cls == "ROUTER":
            common = {"osm_sha256": ctx.osm_sha256, "semantic_config_digest": ctx.semantic_config_digest,
                      "otp_sha256": ctx.otp_sha256}
            if level == Level.K0:
                return {**common, "feeds": {f: r["canonical_content_sha256"] for f, r in feeds.items()}}
            if level == Level.K1:
                return {**common, "feeds": {f: k1_file_hashes(self._feed_bytes(r), ROUTING_FILES, self.names)
                                            for f, r in feeds.items()}}
            if level == Level.K2:
                D = list(ctx.horizon)
                if not D:
                    raise ContractEvaluationError("K2_D requires a non-empty horizon D")
                return {**common, "D": D, "feeds": {f: k2_feed_digest(self._feed_bytes(r), D) for f, r in feeds.items()}}
        raise ContractEvaluationError(f"no footprint for {cls}/{level}")

    # ---------------------------------------------------------------------------------------------- generation
    def generate_val(self, artifact: dict, birth: EvaluationContext, level: str) -> Contract:
        if level == Level.K3:
            fp = {"reference": "rerun gtfs-validator", "report_digest": artifact["report_digest"],
                  "inputs": self._footprint(Level.K0, artifact["artifact_class"], birth, [artifact["feed_id"]])}
        else:
            fp = self._footprint(level, artifact["artifact_class"], birth, [artifact["feed_id"]])
        fp = {**fp, "slot_feeds": [artifact["feed_id"]],
              "birth_inputs": {artifact["feed_id"]: birth.feeds[artifact["feed_id"]]}}
        return Contract.build(level, artifact["artifact_class"], artifact.get("artifact_id", artifact["report_digest"]),
                              artifact["request_slot"], artifact["birth_cut_id"], fp, self.gen_digest, self.eval_digest)

    def generate_router(self, artifact: dict, birth: EvaluationContext, level: str) -> Contract:
        feeds = sorted(artifact["gtfs_logical_versions"])
        if level == Level.K3:
            fp = {"reference": "rebuild + Canon_D 1.3", "canon_digest_birth": artifact["canon_digest"],
                  "graph_sha256": artifact["graph_sha256"], "horizon_birth": artifact["horizon_D"]}
        else:
            fp = self._footprint(level, "ROUTER", birth, feeds)
        fp = {**fp, "slot_feeds": feeds, "birth_inputs": {f: birth.feeds[f] for f in feeds},
              "service_window": list(artifact["service_window"])}
        return Contract.build(level, "ROUTER", artifact["artifact_id"], artifact["request_slot"],
                              artifact["birth_cut_id"], fp, self.gen_digest, self.eval_digest)

    # ---------------------------------------------------------------------------------------------- evaluation
    def evaluate(self, c: Contract, ctx: EvaluationContext) -> EvaluationResult:
        def res(v: Verdict, why: str) -> EvaluationResult:
            return EvaluationResult(c.contract_id, ctx.cut_id, v.value, why, self.eval_digest)
        try:
            c.verify()
            if c.evaluator_digest != self.eval_digest:
                return res(Verdict.ERROR, "contract bound to a different evaluator implementation")
            if c.level == Level.K3:
                return res(Verdict.ERROR, "K3 is a reference path (producer re-execution); not ordinary evaluation")
            fp = dict(c.footprint)
            if c.level == Level.K2 and c.artifact_class == "ROUTER":
                D = list(ctx.horizon)
                win = fp.get("service_window")
                if not win or not D or not (win[0] <= min(D) and max(D) <= win[1]):
                    return res(Verdict.INVALID, "horizon D not within the resolved imported service window")
                birth_ctx = EvaluationContext(c.birth_cut_id, fp["birth_inputs"], fp["osm_sha256"],
                                              fp["semantic_config_digest"], fp["otp_sha256"], horizon=tuple(D))
                expect = self._footprint(Level.K2, "ROUTER", birth_ctx, fp["slot_feeds"])
            else:
                expect = {k: v for k, v in fp.items() if k not in ("slot_feeds", "birth_inputs", "service_window")}
            got = self._footprint(c.level, c.artifact_class, ctx, fp["slot_feeds"])
            return res(Verdict.VALID if sha256_obj(got) == sha256_obj(expect) else Verdict.INVALID,
                       "footprint equal" if sha256_obj(got) == sha256_obj(expect) else "footprint differs")
        except Exception as e:  # noqa: BLE001 - fail closed: any evaluation problem is ERROR, never VALID
            return res(Verdict.ERROR, f"{type(e).__name__}: {str(e)[:200]}")


class ReferencePath:
    """K3 / reference: explicit producer re-execution (oracle comparison). Never used by ordinary admission."""

    def __init__(self, validator=None, otp=None, canon=None) -> None:
        self.validator, self.otp, self.canon = validator, otp, canon

    def val_k3(self, c: Contract, rerun_request) -> EvaluationResult:
        out = self.validator.produce(rerun_request)
        if out.val_report is None:
            return EvaluationResult(c.contract_id, rerun_request.birth_cut_id, Verdict.ERROR.value,
                                    f"reference rerun produced no artifact ({out.failure_class})", "K3-reference")
        ok = out.val_report["report_digest"] == c.footprint["report_digest"]
        return EvaluationResult(c.contract_id, rerun_request.birth_cut_id, (Verdict.VALID if ok else Verdict.INVALID).value,
                                "report digest " + ("equal" if ok else "differs"), "K3-reference")

    def router_k3(self, c: Contract, birth_graph, rebuild_request, horizon: list[str], job_dir) -> EvaluationResult:
        out = self.otp.produce(rebuild_request)
        if out.router is None:
            return EvaluationResult(c.contract_id, rebuild_request.birth_cut_id, Verdict.ERROR.value,
                                    f"reference rebuild produced no artifact ({out.failure_class})", "K3-reference")
        r = out.router
        birth = self.canon.run(birth_graph, horizon, r["semantic_config_digest"], r["osm_sha256"], r["otp_sha256"],
                               c.artifact_id, job_dir)
        if birth.status != "OK":
            return EvaluationResult(c.contract_id, rebuild_request.birth_cut_id, Verdict.ERROR.value,
                                    "Canon of birth graph failed", "K3-reference")
        ok = birth.digest.sha256 == out.canon["digest"]["sha256"]
        return EvaluationResult(c.contract_id, rebuild_request.birth_cut_id, (Verdict.VALID if ok else Verdict.INVALID).value,
                                "Canon_D " + ("equal" if ok else "differs"), "K3-reference")
