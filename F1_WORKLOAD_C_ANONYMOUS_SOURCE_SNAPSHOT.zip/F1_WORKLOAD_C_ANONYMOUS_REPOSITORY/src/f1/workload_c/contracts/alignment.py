"""K2↔Canon alignment over the frozen oracle suite: for every frozen oracle pair, the K2_D contract-level digest
(per-feed K2 projection + OSM + semantic config) must change whenever Canon_D changes (soundness); agreement with
the frozen EQ/NE expectations is also reported. Pure Python over the frozen fixtures (no OTP needed)."""
from __future__ import annotations

import csv
import hashlib
import json
from datetime import date

from .. import paths
from ..producers.semconfig import semantic_config_digest
from .k2 import k2_feed_digest

CONF = paths.FROZEN_SPECS / "authoritative" / "conformance"
HORIZON = ["2008-06-03", "2008-06-04", "2008-06-05", "2008-06-06", "2008-06-07", "2008-06-08", "2008-06-09"]


def fixture_k2(fixture: str, D: list[str] = HORIZON) -> str:
    d = CONF / "fixtures" / "oracle" / fixture.split("@")[0]
    cfg = json.load(open(d / "build-config.json"))
    sem = semantic_config_digest(cfg, date(2008, 6, 1))
    osm = hashlib.sha256((d / "street.osm.pbf").read_bytes()).hexdigest()
    feeds = sorted((f["feedId"], k2_feed_digest((d / f["source"]).read_bytes(), D)) for f in cfg["transitFeeds"])
    return hashlib.sha256(json.dumps([sem, osm, feeds]).encode()).hexdigest()


def k2_canon_alignment() -> list[dict]:
    out = []
    for r in csv.DictReader(open(CONF / "expected" / "oracle_expected.csv")):
        k2 = "EQ" if fixture_k2(r["fixture_a"]) == fixture_k2(r["fixture_b"]) else "NE"
        out.append({"test": r["test"], "canon_expected": r["expected"], "k2": k2,
                    "sound": not (r["expected"] == "NE" and k2 == "EQ"), "agrees": k2 == r["expected"]})
    return out
