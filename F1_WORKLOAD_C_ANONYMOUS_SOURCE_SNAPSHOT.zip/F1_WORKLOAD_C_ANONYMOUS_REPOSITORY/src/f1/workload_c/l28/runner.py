"""L28 target-resource semantic-determinism runner (Python implementation of the frozen run_target_l26.sh logic).

Steps: (1) verify host (>= 8 CPUs, >= 32 GiB, real resource control; taskset-only => BLOCKED); (2) collect
environment; (3) open a scope with the AUTHORITATIVE OTP envelope via the ResourceManager and record the in-scope
TARGET_RESOURCE_RUNTIME_PROOF.json; (4) run the determinism suite D1–D10 + DF under the scope with the final JVM
flags; (5) compare with the frozen expected results; (6) write target_result.json.
Physical attestation: `physical_l28` is EXECUTED_ON_TARGET only when the host fingerprint matches the target spec
(Intel Xeon Silver 4314, >= 64 CPUs, >= 384 GB) AND the operator sets F1_WC_TARGET_ATTESTATION=1; otherwise
NOT_EXECUTED_ON_TARGET — a sandbox PASS is never reported as physical L28 PASS.
"""
from __future__ import annotations

import csv
import json
import os
import platform
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from .. import paths
from ..resources.manager import ResourceEnvelope, ResourceEnforcementUnavailable, ResourceManager
from ..resources.proof import prove_in_scope

EXPECTED = paths.FROZEN_SPECS / "authoritative" / "target_server_conformance" / "expected_results.csv"
TARGET_CPU_MODEL = "Xeon(R) Silver 4314"
TARGET_MIN_CPUS, TARGET_MIN_MEM_GIB = 64, 384
REQ_CPUS, REQ_MEM_GIB = 8, 32


@dataclass
class HostFacts:
    cpus: int
    mem_gib: int
    cpu_model: str
    taskset: bool

    @staticmethod
    def detect() -> "HostFacts":
        mem = 0
        for ln in open("/proc/meminfo"):
            if ln.startswith("MemTotal:"):
                mem = int(ln.split()[1]) // 1048576
        model = ""
        try:
            for ln in open("/proc/cpuinfo"):
                if ln.startswith("model name"):
                    model = ln.split(":", 1)[1].strip()
                    break
        except OSError:
            pass
        import shutil
        return HostFacts(os.cpu_count() or 0, mem, model or platform.processor(), bool(shutil.which("taskset")))


@dataclass
class L28Result:
    overall: str                          # PASS | FAIL | BLOCKED
    physical_l28: str                     # EXECUTED_ON_TARGET | NOT_EXECUTED_ON_TARGET
    reason: str
    host: dict
    proof: dict = field(default_factory=dict)
    tests: dict = field(default_factory=dict)
    envelope: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return dict(self.__dict__)


def attestation(h: HostFacts) -> str:
    on = TARGET_CPU_MODEL in h.cpu_model and h.cpus >= TARGET_MIN_CPUS and h.mem_gib >= TARGET_MIN_MEM_GIB
    return "EXECUTED_ON_TARGET" if on and os.environ.get("F1_WC_TARGET_ATTESTATION") == "1" else "NOT_EXECUTED_ON_TARGET"


def run_l28(manager: ResourceManager, envelope: ResourceEnvelope, out_dir: Path, java: str | None,
            suite: Callable[[ResourceEnvelope, list], list[dict]], host: HostFacts | None = None,
            require_host_minimums: bool = True) -> L28Result:
    """`suite(envelope, wrapper)` runs D1–D10+DF under the given scope wrapper and returns result rows."""
    out_dir.mkdir(parents=True, exist_ok=True)
    h = host or HostFacts.detect()
    phys = attestation(h)
    hd = h.__dict__.copy()

    def done(r: L28Result) -> L28Result:
        (out_dir / "target_result.json").write_text(json.dumps(r.to_dict(), indent=1, sort_keys=True))
        return r
    if require_host_minimums and (h.cpus < REQ_CPUS or h.mem_gib < REQ_MEM_GIB):
        return done(L28Result("BLOCKED", phys, f"host cannot instantiate envelope: {h.cpus} CPUs / {h.mem_gib} GiB "
                              f"(< {REQ_CPUS} / {REQ_MEM_GIB})", hd, envelope=envelope.to_dict()))
    try:
        backend = manager.select()
    except ResourceEnforcementUnavailable as e:
        return done(L28Result("BLOCKED", phys, str(e), hd, envelope=envelope.to_dict()))
    if backend.name == "noop-fixture" and envelope.authoritative:
        return done(L28Result("BLOCKED", phys, "no enforcement backend for the authoritative envelope", hd,
                              envelope=envelope.to_dict()))
    env_txt = out_dir / "environment_target.txt"
    with open(env_txt, "w") as f:
        for cmd in (["date", "-u", "+%FT%TZ"], ["lscpu"], ["free", "-h"], ["cat", "/proc/self/cgroup"], ["uname", "-a"]):
            try:
                f.write(f"== {' '.join(cmd)}\n" + subprocess.run(cmd, capture_output=True, text=True, timeout=30).stdout)
            except OSError:
                f.write(f"== {' '.join(cmd)}: unavailable\n")
    proof = prove_in_scope(manager, envelope, job="l28proof", java=java, workdir=out_dir)
    if not proof.get("resource_envelope_verified"):
        return done(L28Result("BLOCKED", phys, "runtime proof: envelope not verified inside constrained process", hd,
                              proof=proof, envelope=envelope.to_dict()))
    with backend.open(envelope, "l28suite") as scope:
        rows = suite(envelope, scope.wrapper)
    res = {r["test"]: r["result"] for r in rows}
    exp = [r["test"] for r in csv.DictReader(open(EXPECTED))]
    tests = {t: res.get(t, "MISSING") for t in exp}
    jvm_ok = all(f in envelope.jvm_flags for f in ("-XX:+UseG1GC",)) and envelope.authoritative
    if all(v == "PASS" for v in tests.values()):
        overall = "PASS" if jvm_ok else "FAIL"
        reason = "all expected tests PASS" if jvm_ok else "suite PASS but envelope is not the authoritative one"
    elif any(v == "BLOCKED" for v in tests.values()):
        overall, reason = "BLOCKED", "some determinism tests BLOCKED"
    else:
        overall, reason = "FAIL", "determinism test failure"
    return done(L28Result(overall, phys, reason, hd, proof=proof, tests=tests, envelope=envelope.to_dict()))
