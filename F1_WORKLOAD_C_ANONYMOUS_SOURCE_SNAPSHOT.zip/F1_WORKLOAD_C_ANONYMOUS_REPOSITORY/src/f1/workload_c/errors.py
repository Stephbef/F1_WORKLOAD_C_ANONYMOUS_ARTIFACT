"""Typed error hierarchy. Every error carries a stable machine-readable `error_class` code.

Error messages must never contain secret material; `security.secrets.Redactor` is applied to every
serialized error, and constructors are written so that they never capture request headers or tokens.
"""
from __future__ import annotations

from ..common.util import F1Error


class WCError(F1Error):
    error_class = "WC_ERROR"

    def __init__(self, message: str = "", **details: object) -> None:
        super().__init__(message)
        self.details = dict(details)

    def to_record(self) -> dict:
        return {"error_class": self.error_class, "type": type(self).__name__, "message": str(self),
                "details": {k: (v if isinstance(v, (int, float, bool, type(None))) else str(v))
                            for k, v in sorted(self.details.items())}}


class SpecValidationError(WCError):
    error_class = "SPEC_INVALID"


class StorageError(WCError):
    error_class = "STORAGE_ERROR"


class BlobMissingError(StorageError):
    error_class = "BLOB_MISSING"


class BlobCorruptionError(StorageError):
    error_class = "BLOB_CORRUPT"


class ImmutableOverwriteError(StorageError):
    error_class = "IMMUTABLE_OVERWRITE"


class HashMismatchError(StorageError):
    error_class = "HASH_MISMATCH"


class MobilityError(WCError):
    error_class = "MOBILITY_ERROR"
    retryable = False


class MobilityUnauthenticated(MobilityError):      # 401
    error_class = "MOBILITY_AUTH_401"


class MobilityForbidden(MobilityError):            # 403
    error_class = "MOBILITY_FORBIDDEN_403"


class MobilityNotFound(MobilityError):             # 404
    error_class = "MOBILITY_NOT_FOUND_404"


class MobilityRateLimited(MobilityError):          # 429 after bounded retries / Retry-After beyond cap
    error_class = "MOBILITY_RATE_LIMITED_429"
    retryable = True


class MobilityServerError(MobilityError):          # 5xx after bounded retries
    error_class = "MOBILITY_SERVER_5XX"
    retryable = True


class MobilityClientError(MobilityError):          # other 4xx
    error_class = "MOBILITY_CLIENT_4XX"


class MobilityMalformedResponse(MobilityError):
    error_class = "MOBILITY_MALFORMED_RESPONSE"


class MobilityTransportError(MobilityError):       # timeout / connection failure after bounded retries
    error_class = "MOBILITY_TRANSPORT"
    retryable = True


class MobilityPaginationError(MobilityError):
    error_class = "MOBILITY_PAGINATION_UNSTABLE"


class SourceLocatorError(MobilityError):
    error_class = "SOURCE_LOCATOR_FAILURE"


class MissingSecretError(WCError):
    error_class = "SECRET_MISSING"


class GtfsFormatError(WCError):
    error_class = "GTFS_MALFORMED"


class PopulationShortfall(WCError):
    error_class = "B1_POPULATION_TARGET_UNSATISFIED"


class NamespaceViolation(WCError):
    error_class = "NAMESPACE_VIOLATION"


class TestAuthorizationError(WCError):
    error_class = "TEST_AUTHORIZATION_REQUIRED"
    __test__ = False


class LedgerIntegrityError(WCError):
    error_class = "LEDGER_INTEGRITY"


class InvalidTransitionError(WCError):
    error_class = "INVALID_STATE_TRANSITION"


class CheckpointIntegrityError(WCError):
    error_class = "CHECKPOINT_INTEGRITY"


class IncompatibleResumeError(WCError):
    error_class = "INCOMPATIBLE_RESUME"


class RealModeRefused(WCError):
    error_class = "REAL_MODE_NOT_YET_IMPLEMENTATION_COMPLETE"


class HardGateStop(WCError):
    error_class = "HARD_GATE_STOP"


class PhaseBlocked(WCError):
    """Raised by a phase adapter to signal BLOCKED (an external precondition is absent)."""
    error_class = "PHASE_BLOCKED"


class PhaseFailed(WCError):
    """Raised by a phase adapter to signal FAIL (a gate evaluated negative or execution failed)."""
    error_class = "PHASE_FAILED"


class FailureInjectionNotAllowed(WCError):
    error_class = "FAILURE_INJECTION_NOT_ALLOWED"
