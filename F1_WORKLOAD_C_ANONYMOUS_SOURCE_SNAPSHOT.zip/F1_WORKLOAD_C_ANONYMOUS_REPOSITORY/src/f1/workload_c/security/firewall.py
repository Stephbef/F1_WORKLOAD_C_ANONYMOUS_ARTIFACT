"""VALIDATION / TEST firewall: machine-checkable change taxonomy and namespace access rules (PRE-S3 §22).

Change classes:
  E1  pure implementation bug (fix with issue record + failing test + fix + regression test + changelog)
  E2  portability/runtime adaptation preserving frozen semantics (documented + shown semantics-preserving)
  S1  scientific semantic change (contract, Gamma, history visibility, baseline capability, cost definition,
      region rule, scheduler science, analysis denominator) — NOT allowed after validation outcomes are inspected
      without a formal amendment and a complete restart from a clean preregistered state
  R1  change motivated by an observed comparative result — STRICTLY PROHIBITED
Namespace access: FIXTURE free; VALIDATION only with an open validation gate; TEST never readable for outcomes
before the authorized final campaign (TestExecutionGuard certificate).
"""
from __future__ import annotations

import enum
from dataclasses import dataclass

from ..errors import NamespaceViolation, WCError


class ChangeClass(str, enum.Enum):
    E1 = "E1"
    E2 = "E2"
    S1 = "S1"
    R1 = "R1"


class Stage(str, enum.Enum):
    IMPLEMENTATION = "IMPLEMENTATION"          # Sessions 3/4 on FIXTURE data
    VALIDATION_OPEN = "VALIDATION_OPEN"        # validation outcomes may be inspected (engineering only)
    POST_VALIDATION = "POST_VALIDATION"        # after validation outcomes were inspected
    CAMPAIGN = "CAMPAIGN"                      # authorized TEST campaign


class FirewallViolation(WCError):
    error_class = "FIREWALL_VIOLATION"


@dataclass(frozen=True)
class ChangeRecord:
    change_class: ChangeClass
    stage: Stage
    issue_id: str | None = None
    failing_test: str | None = None
    regression_test: str | None = None
    formal_amendment: str | None = None
    restart_from_clean_freeze: bool = False          # V1.1: S1 after validation access needs a full restart ...
    restart_evidence_id: str | None = None           # ... evidenced by the identity of the new clean freeze
    semantic_preservation_evidence: str | None = None   # V1.1: E2 needs independent semantic-preservation evidence
    motivated_by_comparative_result: bool = False


def check_change(rec: ChangeRecord) -> None:
    """Raise FirewallViolation unless the change is permitted at its stage (13_VALIDATION_TEST_FIREWALL.md)."""
    if rec.change_class == ChangeClass.R1 or rec.motivated_by_comparative_result:
        raise FirewallViolation("R1: changes motivated by observed comparative results are prohibited")
    if rec.change_class == ChangeClass.S1:
        if rec.stage == Stage.CAMPAIGN:
            raise FirewallViolation("S1 scientific change during the campaign is prohibited")
        if rec.stage in (Stage.VALIDATION_OPEN, Stage.POST_VALIDATION):
            if not rec.formal_amendment:
                raise FirewallViolation("S1 after validation access requires a formal amendment")
            if not (rec.restart_from_clean_freeze and rec.restart_evidence_id):
                raise FirewallViolation("S1 after validation access requires a complete restart from a clean "
                                        "preregistered freeze (restart_from_clean_freeze + restart_evidence_id)")
    if rec.change_class == ChangeClass.E1 and not (rec.issue_id and rec.failing_test and rec.regression_test):
        raise FirewallViolation("E1 fix requires issue record, failing test and regression test")
    if rec.change_class == ChangeClass.E2 and not (rec.issue_id and rec.semantic_preservation_evidence):
        raise FirewallViolation("E2 adaptation requires an issue record and independent semantic-preservation evidence")


def check_namespace_read(namespace: str, stage: Stage, validation_gate_open: bool = False,
                         campaign_certificate_verified: bool = False) -> None:
    """Fail closed on any read of VALIDATION/TEST outcome data outside the permitted stage."""
    if namespace == "FIXTURE":
        return
    if namespace == "VALIDATION":
        if not validation_gate_open or stage == Stage.IMPLEMENTATION:
            raise NamespaceViolation("VALIDATION data may be read only under an open validation gate")
        return
    if namespace == "TEST":
        if stage != Stage.CAMPAIGN or not campaign_certificate_verified:
            raise NamespaceViolation("TEST data is sealed until the authorized final campaign")
        return
    raise NamespaceViolation(f"unknown namespace {namespace!r}")
