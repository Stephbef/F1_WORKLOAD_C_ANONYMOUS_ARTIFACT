"""Data namespaces (FIXTURE / VALIDATION / TEST) and the TEST-execution authorization boundary.

Rules (all fail closed):
  * every persisted manifest/run/checkpoint carries exactly one namespace;
  * a consumer declares the namespace it is allowed to read; reading any other namespace raises
    NamespaceViolation (FIXTURE data can never be consumed as VALIDATION/TEST data, VALIDATION outputs can never
    enter TEST statistics);
  * a TEST-namespace *scientific* step requires a campaign authorization certificate verified by a
    `CampaignAuthorizationVerifier`. Session 1 defines the stable verifier interface and its identity checks;
    the full Session-4 certificate contents are intentionally not invented. Absence or any identity mismatch is
    a refusal. A FIXTURE-issued certificate can never authorize TEST.
"""
from __future__ import annotations

import enum
import hmac
from dataclasses import dataclass
from typing import Iterable, Protocol

from ...common.util import sha256_obj
from ..errors import NamespaceViolation, TestAuthorizationError


class Namespace(str, enum.Enum):
    FIXTURE = "FIXTURE"
    VALIDATION = "VALIDATION"
    TEST = "TEST"


def parse_namespace(v: str) -> Namespace:
    try:
        return Namespace(v)
    except ValueError as e:
        raise NamespaceViolation(f"unknown namespace {v!r}") from e


def require_namespace(record: dict, allowed: Namespace | Iterable[Namespace], what: str = "artifact") -> None:
    allowed_set = {allowed} if isinstance(allowed, Namespace) else set(allowed)
    ns = record.get("namespace")
    if ns is None:
        raise NamespaceViolation(f"{what} carries no namespace (fail closed)")
    if parse_namespace(ns) not in allowed_set:
        raise NamespaceViolation(f"{what} namespace {ns} not admissible here "
                                 f"(allowed: {sorted(a.value for a in allowed_set)})")


def assert_homogeneous(records: Iterable[dict], ns: Namespace, what: str = "inputs") -> None:
    for r in records:
        require_namespace(r, ns, what)


CERT_SCHEMA = "F1-WC-CAMPAIGN-AUTHORIZATION-1"
_CERT_FIELDS = {"schema", "namespace", "campaign_id", "run_id", "freeze_seal_sha256", "implementation_id",
                "config_digest", "issued_by", "issuer_kind", "certificate_sha256"}


@dataclass(frozen=True)
class AuthorizationContext:
    namespace: Namespace
    campaign_id: str
    run_id: str
    freeze_seal_sha256: str
    implementation_id: str
    config_digest: str


def certificate_body_digest(cert: dict) -> str:
    return sha256_obj({k: v for k, v in cert.items() if k != "certificate_sha256"})


def make_certificate(ctx: AuthorizationContext, issued_by: str, issuer_kind: str) -> dict:
    cert = {"schema": CERT_SCHEMA, "namespace": ctx.namespace.value, "campaign_id": ctx.campaign_id,
            "run_id": ctx.run_id, "freeze_seal_sha256": ctx.freeze_seal_sha256,
            "implementation_id": ctx.implementation_id, "config_digest": ctx.config_digest,
            "issued_by": issued_by, "issuer_kind": issuer_kind}
    cert["certificate_sha256"] = certificate_body_digest(cert)
    return cert


class CampaignAuthorizationVerifier(Protocol):
    def verify(self, certificate: dict | None, ctx: AuthorizationContext) -> None: ...


class IdentityCertificateVerifier:
    """Session-1 verifier: structural + identity binding. Session 4 extends it (signatures/PI authorization
    references) behind the same interface. `accepted_issuer_kinds` must not contain 'FIXTURE' for TEST."""

    def __init__(self, accepted_issuer_kinds: Iterable[str]) -> None:
        self.accepted = frozenset(accepted_issuer_kinds)

    def verify(self, certificate: dict | None, ctx: AuthorizationContext) -> None:
        if certificate is None:
            raise TestAuthorizationError("no campaign authorization certificate presented")
        if not isinstance(certificate, dict) or set(certificate) != _CERT_FIELDS:
            raise TestAuthorizationError("certificate structure invalid")
        if certificate["schema"] != CERT_SCHEMA:
            raise TestAuthorizationError("certificate schema invalid")
        if not hmac.compare_digest(certificate["certificate_sha256"], certificate_body_digest(certificate)):
            raise TestAuthorizationError("certificate digest does not match its body (tampered)")
        if certificate["issuer_kind"] not in self.accepted:
            raise TestAuthorizationError(f"issuer kind {certificate['issuer_kind']!r} not accepted")
        if ctx.namespace == Namespace.TEST and certificate["issuer_kind"] == "FIXTURE":
            raise TestAuthorizationError("a FIXTURE certificate can never authorize TEST execution")
        expect = {"namespace": ctx.namespace.value, "campaign_id": ctx.campaign_id, "run_id": ctx.run_id,
                  "freeze_seal_sha256": ctx.freeze_seal_sha256, "implementation_id": ctx.implementation_id,
                  "config_digest": ctx.config_digest}
        for k, v in expect.items():
            if certificate[k] != v:
                raise TestAuthorizationError(f"certificate identity mismatch on {k}")


class TestExecutionGuard:
    """Gate in front of every scientific campaign step (phase 13 and anything consuming TEST data)."""
    __test__ = False

    def __init__(self, verifier: CampaignAuthorizationVerifier) -> None:
        self.verifier = verifier

    def authorize(self, ctx: AuthorizationContext, certificate: dict | None) -> None:
        if ctx.namespace in (Namespace.TEST, Namespace.FIXTURE):
            self.verifier.verify(certificate, ctx)
        else:
            raise NamespaceViolation(f"campaign steps may not run in namespace {ctx.namespace.value}")
