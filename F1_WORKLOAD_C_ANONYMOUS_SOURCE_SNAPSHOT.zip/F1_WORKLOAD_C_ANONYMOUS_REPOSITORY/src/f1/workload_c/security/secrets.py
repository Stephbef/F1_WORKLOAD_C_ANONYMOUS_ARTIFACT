"""Secret management and redaction.

* `SecretProvider` is the only way code obtains a credential. `EnvSecretProvider` reads an allow-listed
  environment variable (default contract: MOBILITY_DB_TOKEN). Secrets are wrapped in `Secret`, whose repr/str
  never reveal the value; the raw value is available only through `.reveal()` at the HTTP boundary.
* Every revealed secret is registered with the process-wide `Redactor`, which scrubs the literal value and
  its common encodings (URL-encoded, base64) plus generic credential patterns from any string or JSON-like
  structure before it reaches a log, ledger, checkpoint, manifest or exception record.
* `scan_paths()` is the automated post-run secret scan over produced artifacts.
"""
from __future__ import annotations

import base64
import os
import re
import urllib.parse
from pathlib import Path
from typing import Any, Iterable

from ..errors import MissingSecretError

ALLOWED_SECRET_NAMES = frozenset({"MOBILITY_DB_TOKEN"})
REDACTED = "[REDACTED]"

_GENERIC_PATTERNS = [
    re.compile(r"(?i)(authorization\s*[:=]\s*)(bearer\s+)?[A-Za-z0-9._~+/=-]{8,}"),
    re.compile(r"(?i)(\"?(?:refresh_token|access_token|api_key|token|password)\"?\s*[:=]\s*\"?)[A-Za-z0-9._~+/=-]{8,}"),
    re.compile(r"(?i)(bearer\s+)[A-Za-z0-9._~+/=-]{16,}"),
]


class Secret:
    __slots__ = ("_name", "_value")

    def __init__(self, name: str, value: str) -> None:
        self._name = name
        self._value = value

    @property
    def name(self) -> str:
        return self._name

    def reveal(self) -> str:
        REDACTOR.register(self._value)
        return self._value

    def __repr__(self) -> str:
        return f"Secret({self._name}={REDACTED})"

    __str__ = __repr__

    def __reduce__(self):  # never picklable with its value
        raise TypeError("Secret objects cannot be serialised")


class Redactor:
    def __init__(self) -> None:
        self._needles: set[str] = set()

    def register(self, value: str) -> None:
        if not value or len(value) < 4:
            return
        forms = {value, urllib.parse.quote(value, safe=""), urllib.parse.quote_plus(value),
                 base64.b64encode(value.encode()).decode(), base64.urlsafe_b64encode(value.encode()).decode()}
        self._needles.update(f for f in forms if len(f) >= 4)

    def clear(self) -> None:
        self._needles.clear()

    @property
    def needles(self) -> frozenset[str]:
        return frozenset(self._needles)

    def redact_text(self, s: str) -> str:
        for n in sorted(self._needles, key=len, reverse=True):
            if n in s:
                s = s.replace(n, REDACTED)
        for pat in _GENERIC_PATTERNS:
            s = pat.sub(lambda m: m.group(1) + REDACTED, s)
        return s

    def redact(self, obj: Any) -> Any:
        if isinstance(obj, str):
            return self.redact_text(obj)
        if isinstance(obj, dict):
            out = {}
            for k, v in obj.items():
                ks = str(k)
                if ks.lower() in ("authorization", "token", "access_token", "refresh_token", "api_key", "password"):
                    out[ks] = REDACTED
                else:
                    out[self.redact_text(ks)] = self.redact(v)
            return out
        if isinstance(obj, (list, tuple)):
            return [self.redact(v) for v in obj]
        if isinstance(obj, BaseException):
            return self.redact_text(f"{type(obj).__name__}: {obj}")
        return obj


REDACTOR = Redactor()


class SecretProvider:
    def get(self, name: str, required: bool = True) -> Secret | None:  # pragma: no cover - interface
        raise NotImplementedError


class EnvSecretProvider(SecretProvider):
    def __init__(self, environ: dict | None = None) -> None:
        self._env = environ if environ is not None else os.environ

    def get(self, name: str, required: bool = True) -> Secret | None:
        if name not in ALLOWED_SECRET_NAMES:
            raise MissingSecretError(f"secret name {name!r} is not allow-listed")
        v = self._env.get(name)
        if not v:
            if required:
                raise MissingSecretError(f"required secret {name} is not set in the environment")
            return None
        REDACTOR.register(v)
        return Secret(name, v)


class StaticSecretProvider(SecretProvider):
    """Test/fixture provider: holds synthetic secrets (never real credentials)."""

    def __init__(self, values: dict[str, str]) -> None:
        self._values = dict(values)
        for v in self._values.values():
            REDACTOR.register(v)

    def get(self, name: str, required: bool = True) -> Secret | None:
        if name not in ALLOWED_SECRET_NAMES:
            raise MissingSecretError(f"secret name {name!r} is not allow-listed")
        if name not in self._values:
            if required:
                raise MissingSecretError(f"required secret {name} not provided")
            return None
        return Secret(name, self._values[name])


def scan_paths(roots: Iterable[str | Path], needles: Iterable[str], max_bytes: int = 64 << 20) -> list[dict]:
    """Scan every file under roots for any needle (raw bytes, also inside ZIP members). Returns findings."""
    import zipfile
    ns = [n.encode() for n in needles if n]
    findings: list[dict] = []
    if not ns:
        return findings
    for root in roots:
        root = Path(root)
        files = [root] if root.is_file() else sorted(p for p in root.rglob("*") if p.is_file())
        for p in files:
            try:
                if p.stat().st_size > max_bytes:
                    findings.append({"path": str(p), "issue": "too_large_to_scan"})
                    continue
                data = p.read_bytes()
            except OSError as e:
                findings.append({"path": str(p), "issue": f"unreadable:{e.errno}"})
                continue
            for n in ns:
                if n in data:
                    findings.append({"path": str(p), "issue": "secret_present"})
                    break
            if data[:2] == b"PK":
                try:
                    with zipfile.ZipFile(p) as z:
                        for info in z.infolist():
                            b = z.read(info)
                            if any(n in b for n in ns):
                                findings.append({"path": f"{p}!{info.filename}", "issue": "secret_present"})
                except (zipfile.BadZipFile, OSError, RuntimeError):
                    pass
    return findings
