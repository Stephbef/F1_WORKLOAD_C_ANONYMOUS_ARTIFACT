"""F1 Workload C (GTFS feeds -> gtfs-validator / OpenTripPlanner) — Session-1 foundation layer.

Session 1 implements the foundation, data plane, region pipeline, security, run-state and the 19-phase
orchestrator. Later-session components are reached only through `interfaces.protocols` and are supplied by
deterministic mock adapters (`interfaces.mocks`) in FIXTURE mode. Nothing here produces scientific results.
"""
SESSION = "S1"
PACKAGE_VERSION = "0.1.0-s1"
FIXTURE_MARKER = "ENGINEERING FIXTURE ONLY — NOT SCIENTIFIC RESULTS"
REAL_MODE_REFUSAL = "REAL_MODE_NOT_YET_IMPLEMENTATION_COMPLETE"
