"""Immutable content-addressed storage: BlobStore, ManifestStore, SnapshotStore.

Write protocol (BlobStore.put):
  1. bytes are written to `tmp/<random>` and fsync'ed;
  2. the temp file is hard-linked to its final path `sha256/<aa>/<bb>/<hex>` with os.link, which fails
     atomically if the target already exists — an existing immutable blob is therefore NEVER overwritten,
     and concurrent writers of the same content (threads or processes on one POSIX filesystem) are safe;
  3. the temp file is removed and the parent directory fsync'ed; metadata `<hex>.meta.json` is written once by
     the same link-no-overwrite protocol; provenance records are content-addressed and append-only.
A crash between (1) and (2) leaves only a temp file, which `recover()` removes; a final path therefore either
exists with complete bytes or does not exist. Every read re-hashes the bytes (corruption / hash mismatch is
detected and raised, never returned).
"""
from __future__ import annotations

import json
import os
import secrets
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator

from ...common.util import canonical_json, sha256_bytes
from ..errors import (BlobCorruptionError, BlobMissingError, HashMismatchError, ImmutableOverwriteError,
                      NamespaceViolation, StorageError)

NAMESPACES = ("FIXTURE", "VALIDATION", "TEST")


@dataclass(frozen=True)
class BlobRef:
    sha256: str
    size: int
    media_type: str

    def to_dict(self) -> dict:
        return {"sha256": self.sha256, "size": self.size, "media_type": self.media_type}


def _fsync_dir(d: Path) -> None:
    try:
        fd = os.open(str(d), os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def _is_hex64(h: str) -> bool:
    return isinstance(h, str) and len(h) == 64 and all(c in "0123456789abcdef" for c in h)


class BlobStore:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.blobs = self.root / "sha256"
        self.tmp = self.root / "tmp"
        self.prov = self.root / "provenance"
        for d in (self.blobs, self.tmp, self.prov):
            d.mkdir(parents=True, exist_ok=True)

    # --- paths ---------------------------------------------------------------------------------------------
    def path_of(self, h: str) -> Path:
        if not _is_hex64(h):
            raise StorageError(f"invalid sha256 key {h!r}")
        return self.blobs / h[:2] / h[2:4] / h

    def _meta_path(self, h: str) -> Path:
        return self.path_of(h).with_name(h + ".meta.json")

    # --- low level immutable write -------------------------------------------------------------------------
    def _write_tmp(self, data: bytes) -> Path:
        tmp = self.tmp / f".tmp-{os.getpid()}-{secrets.token_hex(8)}"
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
        except BaseException:
            try:
                tmp.unlink()
            except OSError:
                pass
            raise
        return tmp

    def _link_immutable(self, data: bytes, final: Path, expect_sha: str | None) -> bool:
        """Create `final` with `data` unless it exists. Returns True if newly created."""
        final.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._write_tmp(data)
        try:
            try:
                os.link(tmp, final)
                created = True
            except FileExistsError:
                created = False
            if created:
                try:
                    os.chmod(final, 0o444)
                except OSError:
                    pass
                _fsync_dir(final.parent)
            else:
                existing = final.read_bytes()
                if expect_sha is not None and sha256_bytes(existing) != expect_sha:
                    raise BlobCorruptionError(f"existing immutable object is corrupt: {final.name}", path=str(final))
                if expect_sha is None and existing != data:
                    raise ImmutableOverwriteError(f"refusing to overwrite immutable object {final.name}")
            return created
        finally:
            try:
                tmp.unlink()
            except OSError:
                pass

    # --- public API ----------------------------------------------------------------------------------------
    def put(self, data: bytes, media_type: str = "application/octet-stream",
            provenance: dict | None = None, expected_sha256: str | None = None) -> BlobRef:
        if not isinstance(data, (bytes, bytearray)):
            raise StorageError("blob data must be bytes")
        data = bytes(data)
        h = sha256_bytes(data)
        if expected_sha256 is not None and expected_sha256 != h:
            raise HashMismatchError(f"content hash {h} != expected {expected_sha256}", expected=expected_sha256,
                                    actual=h)
        self._link_immutable(data, self.path_of(h), expect_sha=h)
        meta: dict[str, Any] = {"sha256": h, "size": len(data), "media_type": media_type}
        mp = self._meta_path(h)
        if mp.exists():
            old = json.loads(mp.read_text(encoding="utf-8"))
            if old.get("sha256") != h or old.get("size") != len(data):
                raise BlobCorruptionError(f"metadata for {h} is corrupt")
            meta = old  # first-insert media type is immutable
        else:
            try:
                self._link_immutable(canonical_json(meta).encode(), mp, expect_sha=None)
            except ImmutableOverwriteError:
                meta = json.loads(mp.read_text(encoding="utf-8"))
        if provenance is not None:
            self.add_provenance(h, provenance)
        return BlobRef(h, meta["size"], meta["media_type"])

    def add_provenance(self, h: str, provenance: dict) -> str:
        if not self.has(h):
            raise BlobMissingError(f"cannot attach provenance to missing blob {h}")
        body = canonical_json({"blob": h, "provenance": provenance}).encode()
        ph = sha256_bytes(body)
        self._link_immutable(body, self.prov / h[:2] / h / (ph + ".json"), expect_sha=ph)
        return ph

    def provenance(self, h: str) -> list[dict]:
        d = self.prov / h[:2] / h
        out = []
        if d.is_dir():
            for p in sorted(d.glob("*.json")):
                b = p.read_bytes()
                if sha256_bytes(b) != p.stem:
                    raise BlobCorruptionError(f"provenance record corrupt: {p.name}")
                out.append(json.loads(b)["provenance"])
        return out

    def has(self, h: str) -> bool:
        return self.path_of(h).exists()

    def get(self, h: str) -> bytes:
        p = self.path_of(h)
        if not p.exists():
            raise BlobMissingError(f"blob missing: {h}", sha256=h)
        data = p.read_bytes()
        if sha256_bytes(data) != h:
            raise BlobCorruptionError(f"blob corrupt (hash mismatch): {h}", sha256=h)
        return data

    def meta(self, h: str) -> BlobRef:
        mp = self._meta_path(h)
        if not mp.exists():
            raise BlobMissingError(f"blob metadata missing: {h}")
        m = json.loads(mp.read_text(encoding="utf-8"))
        return BlobRef(m["sha256"], m["size"], m["media_type"])

    def iter_keys(self) -> Iterator[str]:
        for p in sorted(self.blobs.glob("??/??/*")):
            if _is_hex64(p.name):
                yield p.name

    def verify_all(self) -> list[str]:
        """Return the keys of every corrupt blob (empty list = store intact)."""
        bad = []
        for h in self.iter_keys():
            try:
                self.get(h)
                m = self.meta(h)
                if m.size != self.path_of(h).stat().st_size:
                    bad.append(h)
            except (BlobCorruptionError, BlobMissingError):
                bad.append(h)
        return bad

    def recover(self) -> int:
        """Remove temp files left behind by an interrupted writer. Returns the number removed."""
        n = 0
        for p in self.tmp.glob(".tmp-*"):
            try:
                p.unlink()
                n += 1
            except OSError:
                pass
        return n


class ManifestStore:
    """Canonical-JSON manifests stored as immutable blobs. Every manifest declares a schema, kind and namespace."""

    MEDIA = "application/vnd.f1.wc.manifest+json"

    def __init__(self, blobs: BlobStore) -> None:
        self.blobs = blobs

    def put(self, manifest: dict) -> BlobRef:
        for k in ("schema", "kind", "namespace"):
            if k not in manifest:
                raise StorageError(f"manifest missing required field {k!r}")
        if manifest["namespace"] not in NAMESPACES:
            raise NamespaceViolation(f"manifest namespace invalid: {manifest['namespace']!r}")
        return self.blobs.put(canonical_json(manifest).encode("utf-8"), self.MEDIA)

    def get(self, h: str, expect_namespace: str | None = None, expect_kind: str | None = None) -> dict:
        m = json.loads(self.blobs.get(h).decode("utf-8"))
        if expect_namespace is not None and m.get("namespace") != expect_namespace:
            raise NamespaceViolation(f"manifest {h[:12]} namespace {m.get('namespace')} != {expect_namespace}")
        if expect_kind is not None and m.get("kind") != expect_kind:
            raise StorageError(f"manifest {h[:12]} kind {m.get('kind')} != {expect_kind}")
        return m


class SnapshotStore:
    """Named immutable snapshots. A snapshot is a manifest of {key: blob sha256}; its name ref is written once."""

    def __init__(self, blobs: BlobStore, manifests: ManifestStore) -> None:
        self.blobs = blobs
        self.manifests = manifests
        self.refs = blobs.root / "snapshots"
        self.refs.mkdir(parents=True, exist_ok=True)

    def commit(self, name: str, entries: dict[str, str], namespace: str, meta: dict | None = None) -> str:
        if not name or "/" in name or name.startswith("."):
            raise StorageError(f"invalid snapshot name {name!r}")
        for k, h in entries.items():
            if not self.blobs.has(h):
                raise BlobMissingError(f"snapshot entry {k} refers to missing blob {h}")
        man = {"schema": "F1-WC-SNAPSHOT-1", "kind": "snapshot", "namespace": namespace, "name": name,
               "entries": dict(sorted(entries.items())), "meta": meta or {}}
        ref = self.manifests.put(man)
        rp = self.refs / f"{name}.json"
        body = canonical_json({"name": name, "manifest_sha256": ref.sha256}).encode()
        if rp.exists():
            cur = json.loads(rp.read_text(encoding="utf-8"))
            if cur.get("manifest_sha256") != ref.sha256:
                raise ImmutableOverwriteError(f"snapshot {name} already committed with different content")
            return ref.sha256
        self.blobs._link_immutable(body, rp, expect_sha=None)
        return ref.sha256

    def resolve(self, name: str) -> str:
        rp = self.refs / f"{name}.json"
        if not rp.exists():
            raise BlobMissingError(f"snapshot {name} not found")
        return json.loads(rp.read_text(encoding="utf-8"))["manifest_sha256"]

    def load(self, name: str, expect_namespace: str | None = None) -> dict[str, Any]:
        man = self.manifests.get(self.resolve(name), expect_namespace=expect_namespace, expect_kind="snapshot")
        for h in man["entries"].values():
            self.blobs.get(h)  # verify every entry
        return man
