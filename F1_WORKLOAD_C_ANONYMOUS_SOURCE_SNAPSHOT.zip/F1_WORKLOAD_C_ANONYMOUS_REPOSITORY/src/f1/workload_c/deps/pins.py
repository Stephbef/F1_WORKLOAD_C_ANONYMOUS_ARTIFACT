"""Pinned dependency manager (Session 2).

Every external artifact/executable is resolved against `configs/workload_c/pinned_dependencies.json`:
jar artifacts by exact SHA-256 (frozen values), tools by exact version probe. A mismatch is a refusal
(DigestMismatch / version mismatch), never a fallback. Two explicit execution modes:

  REAL_PINNED_BINARY   — pinned, verified binaries (required for any scientific execution);
  FIXTURE_STUB_BINARY  — deterministic stand-ins for unavailable binaries in engineering tests; every output they
                         produce is stamped with this mode and can never satisfy a REAL requirement.
"""
from __future__ import annotations

import enum
import hashlib
import json
import os
import re
import shutil
import subprocess
from dataclasses import asdict, dataclass, field
from pathlib import Path

from ...common.util import sha256_file
from .. import paths
from ..errors import WCError

MANIFEST = paths.CONFIG_DIR / "pinned_dependencies.json"


class BinaryMode(str, enum.Enum):
    REAL_PINNED_BINARY = "REAL_PINNED_BINARY"
    FIXTURE_STUB_BINARY = "FIXTURE_STUB_BINARY"


class DependencyMissing(WCError):
    error_class = "DEPENDENCY_MISSING"


class DigestMismatch(WCError):
    error_class = "DIGEST_MISMATCH"


class VersionMismatch(WCError):
    error_class = "DEPENDENCY_VERSION_MISMATCH"


@dataclass
class DependencyStatus:
    name: str
    kind: str
    version: str
    source: str
    expected_sha256: str | None
    actual_sha256: str | None
    license: str
    provenance: str
    path: str | None
    status: str            # VERIFIED | VERIFIED_BY_VERSION | MISSING | DIGEST_MISMATCH | VERSION_MISMATCH
    detail: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def load_manifest(path: Path | None = None) -> dict:
    m = json.loads(Path(path or MANIFEST).read_text(encoding="utf-8"))
    if m.get("schema") != "F1-WC-PINNED-DEPENDENCIES-1":
        raise WCError("pinned dependency manifest schema invalid")
    for a in m["artifacts"]:
        if set(a) != {"name", "kind", "version", "file", "source", "sha256", "license", "provenance",
                      "redistributable_in_package"}:
            raise WCError(f"artifact pin {a.get('name')} has wrong fields")
        if not re.fullmatch(r"[0-9a-f]{64}", a["sha256"]) or "latest" in a["source"].lower() or a["version"] in ("", "latest"):
            raise WCError(f"artifact pin {a['name']} is not an exact pin")
    for t in m["tools"]:
        if not t["version"] or t["version"] == "latest" or not t["expect_regex"]:
            raise WCError(f"tool pin {t.get('name')} is not an exact pin")
    return m


def deps_dir() -> Path:
    return Path(os.environ.get("F1_WC_DEPS_DIR") or (paths.REPO_ROOT / ".deps"))


def _resolve_tool(t: dict) -> str | None:
    if t.get("env_override") and os.environ.get(t["env_override"]):
        cand = Path(os.environ[t["env_override"]]) / "bin" / t["binary"]
        return str(cand) if cand.exists() else None
    return shutil.which(t["binary"])


def _tool_identity_sha(path: str) -> str:
    real = os.path.realpath(path)
    h = hashlib.sha256(Path(real).read_bytes())
    if os.path.basename(real) in ("java", "javac"):      # include the JDK runtime image for a stronger identity
        modules = Path(real).parent.parent / "lib" / "modules"
        if modules.exists():
            h.update(bytes.fromhex(sha256_file(modules)))
    return h.hexdigest()


def verify_all(manifest: dict | None = None, store: Path | None = None) -> list[DependencyStatus]:
    m = manifest or load_manifest()
    store = Path(store or deps_dir())
    out: list[DependencyStatus] = []
    for a in m["artifacts"]:
        p = store / a["file"]
        st = DependencyStatus(a["name"], a["kind"], a["version"], a["source"], a["sha256"], None, a["license"],
                              a["provenance"], str(p), "MISSING")
        if p.is_file():
            st.actual_sha256 = sha256_file(p)
            st.status = "VERIFIED" if st.actual_sha256 == a["sha256"] else "DIGEST_MISMATCH"
        out.append(st)
    for t in m["tools"]:
        exe = _resolve_tool(t)
        st = DependencyStatus(t["name"], "tool", t["version"], t["provision"], None, None, t["license"],
                              t["provenance"], exe, "MISSING")
        if exe:
            argv = [exe] + t["probe"][1:]
            try:
                cp = subprocess.run(argv, capture_output=True, text=True, timeout=60,
                                    env={"PATH": os.environ.get("PATH", ""), "LC_ALL": "C"})
                txt = cp.stdout + cp.stderr
            except (OSError, subprocess.TimeoutExpired) as e:
                txt = f"probe failed: {e}"
            st.detail = txt.strip().splitlines()[0] if txt.strip() else ""
            if re.search(t["expect_regex"], txt):
                st.status = "VERIFIED_BY_VERSION"
                st.actual_sha256 = _tool_identity_sha(exe)
            else:
                st.status = "VERSION_MISMATCH"
        out.append(st)
    return out


@dataclass
class ResolvedDependencies:
    mode: BinaryMode
    otp_jar: Path | None
    validator_jar: Path | None
    java: str | None
    javac: str | None
    osmium: str | None
    faketime: str | None
    statuses: list = field(default_factory=list)

    def identity(self) -> dict:
        return {"mode": self.mode.value, "deps": {s.name: {"version": s.version, "status": s.status,
                                                           "sha256": s.actual_sha256} for s in self.statuses}}


def resolve(mode: BinaryMode, required: tuple[str, ...] = ("otp", "gtfs-validator", "jdk", "javac"),
            store: Path | None = None, manifest: dict | None = None) -> ResolvedDependencies:
    """REAL mode: every required pin must verify, else DependencyMissing/DigestMismatch/VersionMismatch (no fallback).
    FIXTURE_STUB mode: never returns real paths for producers; stubs are selected by the producer factories."""
    sts = verify_all(manifest, store)
    by = {s.name: s for s in sts}
    if mode == BinaryMode.REAL_PINNED_BINARY:
        for name in required:
            s = by[name]
            if s.status == "MISSING":
                raise DependencyMissing(f"pinned dependency {name} {s.version} missing ({s.path})")
            if s.status == "DIGEST_MISMATCH":
                raise DigestMismatch(f"pinned dependency {name}: sha256 {s.actual_sha256} != {s.expected_sha256}")
            if s.status == "VERSION_MISMATCH":
                raise VersionMismatch(f"pinned tool {name}: expected {s.version}, got {s.detail!r}")

    def p(n):
        s = by.get(n)
        ok = s is not None and s.status in ("VERIFIED", "VERIFIED_BY_VERSION")
        return s.path if ok and mode == BinaryMode.REAL_PINNED_BINARY else None
    return ResolvedDependencies(mode, Path(p("otp")) if p("otp") else None,
                                Path(p("gtfs-validator")) if p("gtfs-validator") else None,
                                p("jdk"), p("javac"), p("osmium-tool"), p("faketime"), sts)


def real_binaries_available() -> bool:
    try:
        resolve(BinaryMode.REAL_PINNED_BINARY)
        return True
    except WCError:
        return False
