"""Session-3 interfaces — PRE-S3 V1.2 (FROZEN; V1.1 structure + V1.2 documentation/invariant micro-freeze).
Types and protocols only; no Session-3 algorithm is implemented here.

V1.1 repairs structural gaps of the PRE-S3 interface (see docs/pre_s3/V1_1_INTERFACE_CLOSURE_AUDIT.md):
  * the consumer request is JOINT: one `ConsumerRequest` = the whole region request R_t (all VAL slots + ROUTER slot);
  * a witness is a `JointWitness`: one `WitnessBinding` per designated slot, all at the SAME witness cut;
  * `AdmissionDecision` carries `action` (REUSE | REDERIVE | NO_ARTIFACT) and `mode` (CURRENT | HISTORICAL | None)
    plus a typed `RepairPlan` over the failing SLOT SET;
  * N5 sees only a `RequestBinding` of sanitized `BoundArtifact`s (no instance numbers, no `rederived_from`, no
    catalog/history handles); N1 sees only an `N1CurrentView` (current VAL bindings, current router inputs, its own
    `NativeOtpState`);
  * the cost estimator is explicit in t: `CostModel.estimate_rederive(slot, producer_class, tick_utc, prior)` where
    `prior` is a `PriorCostView` that by construction contains only shared producer runs completed STRICTLY BEFORE t;
  * replay / raw export / analysis exchange typed records (`RawExportRecord`, `ReplayReport`, `AnalysisReport`, ...).
The `__post_init__` checks are structural invariants of the frozen scientific objects (they make illegal records
unrepresentable); they do not decide anything. No scientific rule was changed (frozen PRE-S3 specs 06–13 apply).

V1.2 (docs/pre_s3/V1_2_DETERMINISTIC_FREEZE.md): ConsumerRequest parity vs method-specific binding clarified (the
request, current cut, D_t, slots and the binding RULE are identical across methods; each method binds R_t from the
shared scheduled-production catalog plus ITS OWN on-demand overlay); repair-execution invariants added to
AdmissionDecision (canonical slot order, serial fail-fast, NO_ARTIFACT after a failed step). No field or signature
changed.
"""
from __future__ import annotations

import enum
from dataclasses import asdict, dataclass, field
from typing import Protocol, runtime_checkable

from ...common.util import sha256_obj
from ..catalog.artifacts import ArtifactEntry
from ..contracts.model import Contract, EvaluationContext, EvaluationResult
from ..history.realized import Cut, RealizedHistory

INTERFACE_VERSION = "F1-WC-S3-INTERFACES-V1.2"
LEVELS = ("K0", "K1", "K2")                     # admission levels; K3 is reference-only and never an admission level
_ARTIFACT_OUTCOMES = ("SUCCESS", "SEMANTIC_FAIL")   # FailureClass values that yield an artifact (producers/failure.py)
METHODS = ("F1", "N5", "N1")


class InterfaceInvariantError(ValueError):
    """Raised when a record would violate a frozen structural invariant."""


class Action(str, enum.Enum):
    REUSE = "REUSE"
    REDERIVE = "REDERIVE"
    NO_ARTIFACT = "NO_ARTIFACT"


class Mode(str, enum.Enum):
    CURRENT = "CURRENT"
    HISTORICAL = "HISTORICAL"


class CostCategory(str, enum.Enum):
    A_PRODUCER = "A_PRODUCER"            # measured producer work (incl. failed/timeout attempts)
    B_CONTROL_PLANE = "B_CONTROL_PLANE"  # measured evaluation / search / lookup / optimisation work
    C_OFFLINE = "C_OFFLINE"              # replay, statistics, export, oracle checks: never online cost


def _need(cond: bool, msg: str) -> None:
    if not cond:
        raise InterfaceInvariantError(msg)


def canonical_request_slots(region_id: str, feed_ids: tuple[str, ...] | list[str]) -> tuple[str, ...]:
    """Frozen deterministic slot order: VAL slots by ascending feed id, then the ROUTER slot."""
    feeds = sorted(set(feed_ids))
    _need(len(feeds) == len(list(feed_ids)) and len(feeds) > 0, "feed ids must be non-empty and unique")
    return tuple(f"VAL:feed={f}" for f in feeds) + (f"ROUTER:region={region_id}",)


# ------------------------------------------------------------------------------------------------------- request
@dataclass(frozen=True)
class ConsumerRequest:
    """ONE joint region request R_t at consumer tick t (not one slot)."""
    region_id: str
    request_slots: tuple[str, ...]        # canonical_request_slots(region, feeds)
    tick_utc: str
    current_cut: Cut
    context: EvaluationContext            # evaluation context of the current cut + consumer horizon D_t

    def __post_init__(self) -> None:
        feeds = tuple(f for f, _ in self.current_cut.frontier)
        _need(self.current_cut.region_id == self.region_id, "current cut belongs to another region")
        _need(self.request_slots == canonical_request_slots(self.region_id, feeds),
              "request_slots must be exactly VAL(feed) for every region feed (ascending) + ROUTER(region)")
        _need(self.context.cut_id == self.current_cut.cut_id, "context must be the current cut's context")
        _need(len(self.context.horizon) > 0, "context must carry the consumer horizon D_t")

    @property
    def request_id(self) -> str:
        return "REQ:" + sha256_obj([self.region_id, list(self.request_slots), self.tick_utc,
                                    self.current_cut.cut_id, list(self.context.horizon)])[:32]


# ------------------------------------------------------------------------------------------- sanitized artifact
@dataclass(frozen=True)
class BoundArtifact:
    """Sanitized artifact bound to a designated slot at tick t. Deliberately has NO instance number, NO
    rederived_from, NO catalog handle: only what is needed to identify the artifact, evaluate its contracts at a
    cut, prove its availability/provenance and account for it."""
    slot_id: str
    artifact_id: str
    artifact_class: str
    producer_type: str
    birth_cut_id: str
    birth_frontier: tuple[tuple[str, int], ...]
    logical_inputs: tuple[tuple[str, ...], ...]
    contract_ids: tuple[str, ...]
    status: str
    born_utc: str
    catalog_entry_digest: str
    provenance_digest: str
    output_digests: tuple[tuple[str, str], ...]
    namespace: str
    binary_mode: str

    @staticmethod
    def from_entry(entry: ArtifactEntry, born_utc: str) -> "BoundArtifact":
        return BoundArtifact(entry.request_slot, entry.artifact_id, entry.artifact_class, entry.producer_type,
                             entry.birth_cut_id, tuple(tuple(x) for x in entry.birth_frontier),
                             tuple(tuple(x) for x in entry.logical_inputs), tuple(entry.contract_ids), entry.status,
                             born_utc, entry.entry_digest, entry.provenance_digest,
                             tuple(tuple(x) for x in entry.output_digests), entry.namespace, entry.binary_mode)


@dataclass(frozen=True)
class RequestBinding:
    """R_t as bound at tick t for ONE method. The same RequestBinding type and the identical binding rule are used for
    F1 and N5 (latest instance of each designated slot with ARTIFACT_BORN <= t, from the SHARED scheduled-production
    catalog plus THAT METHOD'S own on-demand overlay); the ConsumerRequest (current cut, D_t, slots) is identical.
    Bound instances may legitimately differ between methods when earlier method-specific repairs created different
    overlays — a consequence of the treatment, not a parity violation. N5 never receives F1's overlay.
    estimates = est(s, t) per slot from the shared CostModel over the shared ledger (bitwise identical for every method)."""
    request: ConsumerRequest
    bindings: tuple[tuple[str, BoundArtifact | None], ...]
    contracts: tuple[tuple[str, tuple[Contract, ...]], ...]       # artifact_id -> its frozen contracts
    estimates: tuple[tuple[str, float], ...]                      # slot_id -> est(s, t)

    def __post_init__(self) -> None:
        _need(tuple(s for s, _ in self.bindings) == self.request.request_slots, "one binding per designated slot, in order")
        for s, b in self.bindings:
            if b is not None:
                _need(b.slot_id == s, f"cross-slot binding: {b.slot_id} bound to {s}")
                _need(b.born_utc <= self.request.tick_utc, f"artifact {b.artifact_id} born after the tick")
        ids = {b.artifact_id for _, b in self.bindings if b is not None}
        _need({a for a, _ in self.contracts} == ids, "contracts must be given exactly for the bound artifacts")
        _need(tuple(s for s, _ in self.estimates) == self.request.request_slots, "one estimate per slot, in order")


CurrentCutView = RequestBinding        # N5's complete view: shared catalog + N5's own overlay only (no history, no F1 output)


# -------------------------------------------------------------------------------------------- joint witness
@dataclass(frozen=True)
class TemporalEvidence:
    tick_utc: str
    artifact_born_utc: str
    witness_versions_available_utc: tuple[tuple[str, int, str], ...]     # (feed, index, available_utc)

    def __post_init__(self) -> None:
        _need(self.artifact_born_utc <= self.tick_utc, "artifact completion after the tick")
        _need(all(a <= self.tick_utc for _, _, a in self.witness_versions_available_utc), "witness version from the future")


@dataclass(frozen=True)
class GammaEvidence:
    tick_utc: str
    horizon: tuple[str, ...]
    per_feed: tuple[tuple[str, int, int, bool, bool], ...]   # (feed, index, current index, depth_ok, service_on_D_ok)
    admissible: bool

    def __post_init__(self) -> None:
        _need(self.admissible == all(d and s for *_, d, s in self.per_feed), "admissible must equal all feed checks")


@dataclass(frozen=True)
class WitnessBinding:
    slot_id: str
    artifact: BoundArtifact
    contract_ids: tuple[str, ...]
    evaluations: tuple[EvaluationResult, ...]
    temporal: TemporalEvidence

    def __post_init__(self) -> None:
        _need(self.artifact.slot_id == self.slot_id, "cross-slot substitution in witness binding")
        _need(tuple(e.contract_id for e in self.evaluations) == self.contract_ids, "one evaluation per contract")
        _need(self.temporal.artifact_born_utc == self.artifact.born_utc, "temporal evidence must refer to this artifact")


@dataclass(frozen=True)
class JointWitness:
    """The ENTIRE R_t valid at ONE witness cut c (no per-artifact mixture of cuts)."""
    request_id: str
    request_slots: tuple[str, ...]
    method: str
    level: str
    witness_cut: Cut
    bindings: tuple[WitnessBinding, ...]
    gamma: GammaEvidence

    def __post_init__(self) -> None:
        _need(self.method == "F1", "only F1 forms historical witnesses")
        _need(self.level in LEVELS, "witness level must be K0/K1/K2 (K3 is reference-only)")
        _need(tuple(b.slot_id for b in self.bindings) == self.request_slots, "a binding for EVERY designated slot")
        _need(self.gamma.admissible, "witness cut must be Gamma-admissible")
        for b in self.bindings:
            _need(len(b.evaluations) > 0 and all(e.verdict == "VALID" for e in b.evaluations), "every contract VALID")
            _need(all(e.cut_id == self.witness_cut.cut_id for e in b.evaluations),
                  "all evaluations must be at the same witness cut")
            _need(b.temporal.tick_utc == self.gamma.tick_utc, "temporal evidence for a different tick")


# --------------------------------------------------------------------------------------------- repair / decision
@dataclass(frozen=True)
class RederivationStep:
    slot_id: str
    target_cut_id: str
    producer_class: str                    # validator | otp
    estimate_s: float                      # est(s, t)
    outcome: str | None = None             # FailureClass after execution (None = planned only)
    new_artifact_id: str | None = None
    provenance_digest: str | None = None
    measured_wall_s: float | None = None


@dataclass(frozen=True)
class RepairPlan:
    """Repair over the failing SLOT SET S(c); OPT values are sums of est(s, t) over slot sets."""
    request_id: str
    mode: Mode
    target_cut: Cut
    failing_slots: tuple[str, ...]
    steps: tuple[RederivationStep, ...]
    opt_current: float
    opt_hist: float | None
    best_hist_cut_id: str | None

    def __post_init__(self) -> None:
        _need(tuple(s.slot_id for s in self.steps) == self.failing_slots, "one step per failing slot, in order")
        _need(all(s.target_cut_id == self.target_cut.cut_id for s in self.steps), "all steps target the plan's cut")
        total = round(sum(s.estimate_s for s in self.steps), 9)
        chosen = self.opt_current if self.mode == Mode.CURRENT else self.opt_hist
        _need(chosen is not None and round(chosen, 9) == total, "OPT of the chosen mode must equal the plan's slot-set sum")
        if self.mode == Mode.HISTORICAL:
            _need(self.opt_hist is not None and self.opt_hist < self.opt_current, "historical repair only if OPT_hist < OPT_current")
            _need(self.best_hist_cut_id == self.target_cut.cut_id, "historical target must be the best historical cut")


@dataclass(frozen=True)
class CostItem:
    category: CostCategory
    component: str                         # e.g. producer:otp, evaluate, witness_search, catalog_lookup, solver
    wall_s: float
    cpu_s: float
    slot_id: str | None = None
    producer_outcome: str | None = None


@dataclass(frozen=True)
class CostRecord:
    items: tuple[CostItem, ...] = ()

    @property
    def online_wall_s(self) -> float:      # categories A + B only; C is never online cost
        return sum(i.wall_s for i in self.items if i.category != CostCategory.C_OFFLINE)


@dataclass(frozen=True)
class AdmissionDecision:
    request: ConsumerRequest
    method: str                            # F1 | N5 | N1
    level: str                             # K0 | K1 | K2 (N1: K0 identity for VAL; native for ROUTER)
    action: Action
    mode: Mode | None
    current_evaluations: tuple[EvaluationResult, ...]       # step-1 evaluations at the current cut (parity check)
    witness: JointWitness | None = None
    repair: RepairPlan | None = None
    costs: CostRecord = field(default_factory=CostRecord)
    exclusion: str | None = None           # e.g. OPERATIONAL_CAP, EVALUATION_ERROR, R_UNFORMABLE

    def __post_init__(self) -> None:
        _need(self.method in METHODS and self.level in LEVELS, "unknown method or level")
        _need(all(e.cut_id == self.request.current_cut.cut_id for e in self.current_evaluations),
              "current_evaluations must be at the current cut")
        if self.action == Action.NO_ARTIFACT:
            _need(self.mode is None and self.witness is None, "NO_ARTIFACT has mode None and no witness")
        elif self.action == Action.REUSE:
            _need(self.mode is not None and self.repair is None, "REUSE has a mode and no repair plan")
            _need((self.mode == Mode.HISTORICAL) == (self.witness is not None), "historical reuse requires a witness")
        else:
            _need(self.mode is not None and self.repair is not None and self.repair.mode == self.mode,
                  "REDERIVE requires a repair plan with the same mode")
        if self.method != "F1":
            _need(self.mode != Mode.HISTORICAL and self.witness is None, f"{self.method} may never use history")
        if self.witness is not None:
            _need(self.witness.request_id == self.request.request_id, "witness for another request")
        if self.repair is not None:
            _need(self.repair.request_id == self.request.request_id, "repair plan for another request")
            # V1.2 frozen execution semantics: failing slots in canonical request-slot order (filtered), serial
            # fail-fast: after the first non-artifact outcome every later step is unattempted (outcome None);
            # a plan with a failed step ends in NO_ARTIFACT; REDERIVE requires every step to have produced an artifact.
            order = [s for s in self.request.request_slots if s in self.repair.failing_slots]
            _need(list(self.repair.failing_slots) == order, "failing slots must follow canonical request-slot order")
            outcomes = [s.outcome for s in self.repair.steps]
            failed_at = next((i for i, o in enumerate(outcomes) if o is not None and o not in _ARTIFACT_OUTCOMES), None)
            if failed_at is not None:
                _need(all(o is None for o in outcomes[failed_at + 1:]), "fail-fast: steps after a failure are unattempted")
                _need(self.action == Action.NO_ARTIFACT, "a repair with a failed step ends in NO_ARTIFACT")
                for st in self.repair.steps[failed_at + 1:]:
                    _need(st.new_artifact_id is None and not st.measured_wall_s, "unattempted steps: no artifact, no cost")
            if self.action == Action.REDERIVE:
                _need(all(o in _ARTIFACT_OUTCOMES for o in outcomes), "REDERIVE requires every step to produce an artifact")


# --------------------------------------------------------------------------------------------- cost ledger view
@dataclass(frozen=True)
class ProducerRunObservation:
    region_id: str
    producer_class: str
    completed_utc: str
    wall_s: float
    cpu_s: float
    outcome: str                           # FailureClass value
    source: str = "SHARED_SCHEDULED"


@dataclass(frozen=True)
class PriorCostView:
    """Shared scheduled-production runs of one region completed STRICTLY BEFORE tick_utc (immutable)."""
    region_id: str
    tick_utc: str
    observations: tuple[ProducerRunObservation, ...]

    def __post_init__(self) -> None:
        _need(all(o.region_id == self.region_id and o.completed_utc < self.tick_utc and o.source == "SHARED_SCHEDULED"
                  for o in self.observations), "prior view may contain only shared runs completed strictly before t")

    @staticmethod
    def before(region_id: str, tick_utc: str, ledger: tuple[ProducerRunObservation, ...]) -> "PriorCostView":
        obs = tuple(sorted((o for o in ledger if o.region_id == region_id and o.source == "SHARED_SCHEDULED"
                            and o.completed_utc < tick_utc),
                           key=lambda o: (o.completed_utc, o.producer_class, o.wall_s, o.cpu_s, o.outcome)))
        return PriorCostView(region_id, tick_utc, obs)

    @property
    def digest(self) -> str:
        return sha256_obj([asdict(o) for o in self.observations] + [self.region_id, self.tick_utc])


# ------------------------------------------------------------------------------------------------- N1 views
@dataclass(frozen=True)
class NativeOtpState:
    """N1's OWN persistent native OTP state (allowed and required); never F1 history."""
    region_id: str
    street_graph_path: str
    street_graph_sha256: str
    cache_dir: str
    cache_manifest_sha256: str
    envelope_digest: str
    last_success_inputs: tuple[tuple[str, str, str], ...] | None     # (feed, logical version id, canonical sha)
    last_success_graph_sha256: str | None


@dataclass(frozen=True)
class N1CurrentView:
    request: ConsumerRequest
    val_bindings: tuple[tuple[str, BoundArtifact | None], ...]       # current VAL slots only
    val_contracts: tuple[tuple[str, tuple[Contract, ...]], ...]      # K0 identity contracts of those VAL artifacts
    current_router_inputs: tuple[tuple[str, str, str], ...]         # (feed, logical version id, canonical sha) at c_cur
    native_state: NativeOtpState
    estimates: tuple[tuple[str, float], ...]

    def __post_init__(self) -> None:
        val_slots = tuple(s for s in self.request.request_slots if s.startswith("VAL:"))
        _need(tuple(s for s, _ in self.val_bindings) == val_slots, "N1 view carries exactly the current VAL slots")
        _need(self.native_state.region_id == self.request.region_id, "native state of another region")
        _need(tuple(f for f, *_ in self.current_router_inputs) == tuple(f for f, _ in self.request.current_cut.frontier),
              "router inputs must be the current cut's versions")


@dataclass(frozen=True)
class N1Outcome:
    decision: AdmissionDecision
    native_state: NativeOtpState
    cache_evidence: tuple[tuple[str, str], ...]                     # instrumentation (key, value) pairs


# ----------------------------------------------------------------------------------- replay / export / analysis
@dataclass(frozen=True)
class RunIdentityRecord:
    run_id: str
    namespace: str
    implementation_id: str
    config_digest: str
    interface_version: str = INTERFACE_VERSION


@dataclass(frozen=True)
class RawExportRecord:
    """One append-only raw record per (method, level, request) — spec 12 §3."""
    run: RunIdentityRecord
    region_id: str
    request_id: str
    request_slots: tuple[str, ...]
    root_changes: tuple[tuple[str, int], ...]                     # (feed, logical index) whose influence period has t
    tick_utc: str
    tick_local: str
    method: str
    level: str
    current_cut_id: str
    current_frontier: tuple[tuple[str, int], ...]
    gamma_size: int | None
    action: Action
    mode: Mode | None
    witness_cut_id: str | None
    bound_artifacts: tuple[tuple[str, str | None], ...]           # (slot, artifact id)
    contract_verdicts: tuple[tuple[str, str, str, str], ...]      # (artifact id, contract id, cut id, verdict)
    rederivations: tuple[RederivationStep, ...]
    costs: CostRecord
    estimates: tuple[tuple[str, float], ...]
    opt_current: float | None
    opt_hist: float | None
    failures: tuple[tuple[str, str], ...]                         # (slot, FailureClass)
    scheduler_state_digest: str
    provenance_digests: tuple[str, ...]
    excluded: bool
    exclusion_reason: str | None

    @property
    def record_digest(self) -> str:
        return sha256_obj(asdict(self))


@dataclass(frozen=True)
class SealedLedger:
    history_journal_sha256: str
    catalog_journal_sha256s: tuple[tuple[str, str], ...]          # (shared | method overlay, sha)
    contracts_sha256: str
    raw_export_sha256: str
    cost_ledger_sha256: str
    paths: tuple[tuple[str, str], ...]


@dataclass(frozen=True)
class ReplayItem:
    record_digest: str
    status: str                                                   # REPRODUCED | NOT_REPRODUCED
    source_event_ids: tuple[str, ...]
    detail: str = ""


@dataclass(frozen=True)
class ReplayReport:
    ledger: SealedLedger
    items: tuple[ReplayItem, ...]


@dataclass(frozen=True)
class MutationPopulation:
    artifact_class: str
    artifact_ids: tuple[str, ...]                                 # TEST artifact ids of one template (sorted)
    seed_domain: str = "mutation"


@dataclass(frozen=True)
class MutationPlan:
    population: MutationPopulation
    selected: tuple[str, ...]                                     # ranked sample, top ceil(0.05 n)
    families: tuple[str, ...]


@dataclass(frozen=True)
class MutationResult:
    artifact_id: str
    family: str
    status: str                                                   # APPLIED | INVALID_MUTATION
    canon_changed: bool | None
    contract_admits: bool | None
    detected_missing_dependence: bool | None
    provenance_digest: str


@dataclass(frozen=True)
class HypothesisResult:
    name: str                                                     # H_witness(K0) | H_repair(K0) | H_hist(K2) | H_native(K2)
    n_regions: int
    n_root_changes: int
    sign_test_p: float | None
    holm_p: float | None
    bca_ci: tuple[float, float] | None
    wild_ci: tuple[float, float] | None
    verdict: str                                                  # SUPPORTED | NOT_SUPPORTED | INCONCLUSIVE


@dataclass(frozen=True)
class AnalysisReport:
    namespace: str
    raw_export_sha256: str
    per_region: tuple[tuple[str, tuple[tuple[str, float | None], ...]], ...]
    hypotheses: tuple[HypothesisResult, ...]


# ------------------------------------------------------------------------------------------------- services
@runtime_checkable
class ContractEvaluator(Protocol):
    def evaluate(self, c: Contract, ctx: EvaluationContext) -> EvaluationResult: ...


@runtime_checkable
class CurrentCutEvaluator(Protocol):
    """Evaluator bound to the request's current context (no cut parameter exists)."""
    def evaluate(self, c: Contract) -> EvaluationResult: ...


@runtime_checkable
class CutContextFactory(Protocol):
    def context_for(self, cut: Cut, tick_utc: str) -> EvaluationContext: ...


@runtime_checkable
class GammaAdmissibility(Protocol):
    def evidence(self, cut: Cut, tick_utc: str) -> GammaEvidence: ...


@runtime_checkable
class Rederiver(Protocol):
    def rederive(self, slot_id: str, cut: Cut, tick_utc: str, estimate_s: float) -> RederivationStep: ...


@runtime_checkable
class CurrentCutRederiver(Protocol):
    """Re-derivation bound to the request's current cut (no cut parameter exists)."""
    def rederive(self, slot_id: str, estimate_s: float) -> RederivationStep: ...


@runtime_checkable
class NativeOtpBuilder(Protocol):
    def build(self, view: N1CurrentView) -> tuple[RederivationStep, NativeOtpState, tuple[tuple[str, str], ...]]: ...


# --------------------------------------------------------------------------------------- the ten interfaces
@runtime_checkable
class WitnessSearch(Protocol):
    def search(self, binding: RequestBinding, level: str, history: RealizedHistory, contexts: CutContextFactory,
               gamma: GammaAdmissibility, evaluator: ContractEvaluator) -> JointWitness | None: ...


@runtime_checkable
class RepairEngine(Protocol):
    def plan(self, binding: RequestBinding, level: str, history: RealizedHistory, contexts: CutContextFactory,
             gamma: GammaAdmissibility, evaluator: ContractEvaluator) -> RepairPlan | None: ...
    def execute(self, plan: RepairPlan, rederiver: Rederiver, tick_utc: str) -> RepairPlan: ...


@runtime_checkable
class AdmissionEngine(Protocol):
    def admit(self, binding: RequestBinding, level: str, history: RealizedHistory, contexts: CutContextFactory,
              gamma: GammaAdmissibility, evaluator: ContractEvaluator, witness_search: WitnessSearch,
              repair: RepairEngine, rederiver: Rederiver) -> AdmissionDecision: ...


@runtime_checkable
class CostModel(Protocol):
    def estimate_rederive(self, slot_id: str, producer_class: str, tick_utc: str, prior: PriorCostView) -> float: ...
    def online_cost(self, record: CostRecord) -> float: ...


@runtime_checkable
class N5Baseline(Protocol):
    def decide(self, view: CurrentCutView, level: str, evaluator: CurrentCutEvaluator,
               rederiver: CurrentCutRederiver) -> AdmissionDecision: ...


@runtime_checkable
class N1Baseline(Protocol):
    def decide(self, view: N1CurrentView, evaluator: CurrentCutEvaluator, rederiver: CurrentCutRederiver,
               native: NativeOtpBuilder) -> N1Outcome: ...


@runtime_checkable
class ReplayEngine(Protocol):
    def replay(self, ledger: SealedLedger, records: tuple[RawExportRecord, ...]) -> ReplayReport: ...


@runtime_checkable
class MutationEngine(Protocol):
    def plan(self, population: MutationPopulation) -> MutationPlan: ...
    def apply(self, artifact_id: str, family: str) -> MutationResult: ...


@runtime_checkable
class StatisticsExporter(Protocol):
    def export(self, decision: AdmissionDecision, run: RunIdentityRecord, root_changes: tuple[tuple[str, int], ...],
               tick_local: str, gamma_size: int | None, scheduler_state_digest: str) -> RawExportRecord: ...


@runtime_checkable
class FrozenAnalysis(Protocol):
    def run(self, records: tuple[RawExportRecord, ...], namespace: str) -> AnalysisReport: ...


SESSION3_INTERFACES = ("AdmissionEngine", "WitnessSearch", "RepairEngine", "CostModel", "N1Baseline", "N5Baseline",
                       "ReplayEngine", "MutationEngine", "StatisticsExporter", "FrozenAnalysis")
SESSION3_DATA_TYPES = ("ConsumerRequest", "BoundArtifact", "RequestBinding", "CurrentCutView", "TemporalEvidence",
                       "GammaEvidence", "WitnessBinding", "JointWitness", "RederivationStep", "RepairPlan", "CostItem",
                       "CostRecord", "AdmissionDecision", "ProducerRunObservation", "PriorCostView", "NativeOtpState",
                       "N1CurrentView", "N1Outcome", "RunIdentityRecord", "RawExportRecord", "SealedLedger",
                       "ReplayItem", "ReplayReport", "MutationPopulation", "MutationPlan", "MutationResult",
                       "HypothesisResult", "AnalysisReport")
