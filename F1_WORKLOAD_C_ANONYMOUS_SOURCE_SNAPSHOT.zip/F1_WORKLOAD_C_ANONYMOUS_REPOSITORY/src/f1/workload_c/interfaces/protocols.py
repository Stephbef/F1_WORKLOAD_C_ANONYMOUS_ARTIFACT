"""Stable typed interfaces for components implemented in Sessions 2–3.

Session-1 mock adapters (interfaces/mocks.py) implement exactly these protocols; the real implementations must
keep the signatures and the result dataclasses. Orchestration glue never contains scientific behaviour: it only
calls these interfaces and records their typed results.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Protocol, runtime_checkable


@dataclass(frozen=True)
class FeedVersionRef:
    feed_id: str
    logical_version_id: str
    canonical_content_sha256: str


@dataclass(frozen=True)
class ProducerArtifact:
    artifact_id: str
    kind: str                      # VALIDATION_REPORT | ROUTER_GRAPH
    region_id: str
    namespace: str
    inputs_digest: str
    sha256: str | None             # None when status == NO_ARTIFACT
    status: str                    # OK | NO_ARTIFACT
    producer: str                  # e.g. "gtfs-validator 8.0.1" / "otp 2.10.0" / "MOCK:..."
    mock: bool
    detail: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class ConformanceResult:
    name: str
    overall: str                   # PASS | FAIL | BLOCKED
    tests: dict
    mock: bool
    detail: dict = field(default_factory=dict)


@dataclass(frozen=True)
class Contract:
    contract_id: str
    level: str                     # K0 | K1 | K2 | K3
    artifact_id: str
    terms_digest: str
    mock: bool


@dataclass(frozen=True)
class Decision:
    request_slot: str
    cut: str
    action: str                    # REUSE | REDERIVE | NO_ARTIFACT
    witness: str | None
    engine: str
    mock: bool


@dataclass(frozen=True)
class Seal:
    kind: str
    namespace: str
    files: dict
    seal_sha256: str
    mock: bool


@runtime_checkable
class ValidatorProducer(Protocol):
    def validate(self, region_id: str, feed: FeedVersionRef, consumer_date: str, country: str,
                 namespace: str) -> ProducerArtifact: ...


@runtime_checkable
class OtpProducer(Protocol):
    def build(self, region_id: str, feeds: list[FeedVersionRef], osm_pin: dict, semantic_config_digest: str,
              namespace: str) -> ProducerArtifact: ...


@runtime_checkable
class ResourceManager(Protocol):
    def prove_target(self, envelope: dict) -> ConformanceResult: ...
    def lease(self, component: str) -> dict: ...


@runtime_checkable
class OracleEvaluator(Protocol):
    def conformance(self, expected_rows: list[dict]) -> ConformanceResult: ...
    def canon_digest(self, artifact: ProducerArtifact, service_date: str) -> str: ...


@runtime_checkable
class ContractGenerator(Protocol):
    def generate(self, artifact: ProducerArtifact, level: str) -> Contract: ...


@runtime_checkable
class ContractEvaluator(Protocol):
    def evaluate(self, contract: Contract, cut: str) -> bool: ...


@runtime_checkable
class AdmissionEngine(Protocol):
    def admit(self, request_slot: str, contracts: list[Contract], cut: str) -> Decision: ...


@runtime_checkable
class RepairEngine(Protocol):
    def repair(self, request_slot: str, cut: str, candidates: list[str]) -> Decision: ...


@runtime_checkable
class Baseline(Protocol):
    name: str

    def decide(self, request_slot: str, cut: str, contracts: list[Contract]) -> Decision: ...


@runtime_checkable
class CostRecorder(Protocol):
    def record(self, event: dict) -> None: ...
    def ledger(self) -> list[dict]: ...


@runtime_checkable
class ReplayEngine(Protocol):
    def replay(self, raw_records: list[dict]) -> dict: ...


@runtime_checkable
class MutationEngine(Protocol):
    def plan(self, artifact_ids: list[str]) -> dict: ...


@runtime_checkable
class StatisticsEngine(Protocol):
    def analyze(self, units: list[dict], namespace: str) -> dict: ...


@runtime_checkable
class FreezeSealManager(Protocol):
    def seal(self, kind: str, namespace: str, files: dict[str, str]) -> Seal: ...
    def verify(self, seal: Seal, files: dict[str, str]) -> None: ...


INTERFACE_NAMES = ("ValidatorProducer", "OtpProducer", "ResourceManager", "OracleEvaluator", "ContractGenerator",
                   "ContractEvaluator", "AdmissionEngine", "RepairEngine", "Baseline", "CostRecorder", "ReplayEngine",
                   "MutationEngine", "StatisticsEngine", "FreezeSealManager")
