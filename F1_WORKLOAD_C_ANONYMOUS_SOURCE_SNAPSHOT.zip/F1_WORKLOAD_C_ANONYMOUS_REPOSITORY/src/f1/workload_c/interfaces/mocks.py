"""Deterministic MOCK adapters for later-session components (FIXTURE mode only).

Every mock: (1) implements the corresponding protocol exactly; (2) derives outputs from SHA-256 of canonical
inputs (no randomness); (3) labels every output `mock=True` and producer 'MOCK:...'; (4) supports injected
failure modes via `MockFaults` (raise FAIL / BLOCKED, or return NO_ARTIFACT for chosen keys); (5) computes no
scientific metric. They exist so the 19-phase orchestrator can execute end-to-end before Sessions 2–3.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from ...common.util import sha256_obj
from ..errors import NamespaceViolation, PhaseBlocked, PhaseFailed
from .protocols import (ConformanceResult, Contract, Decision, FeedVersionRef, ProducerArtifact, Seal)

MOCK_TAG = "MOCK-S1"


@dataclass
class MockFaults:
    fail: set = field(default_factory=set)        # keys that raise PhaseFailed
    block: set = field(default_factory=set)       # keys that raise PhaseBlocked
    no_artifact: set = field(default_factory=set)  # keys that yield NO_ARTIFACT

    def check(self, key: str) -> None:
        if key in self.fail:
            raise PhaseFailed(f"mock injected failure for {key}")
        if key in self.block:
            raise PhaseBlocked(f"mock injected block for {key}")


def _h(*parts) -> str:
    return sha256_obj([MOCK_TAG, *parts])


class MockValidatorProducer:
    def __init__(self, faults: MockFaults | None = None) -> None:
        self.faults = faults or MockFaults()
        self.calls = 0

    def validate(self, region_id: str, feed: FeedVersionRef, consumer_date: str, country: str,
                 namespace: str) -> ProducerArtifact:
        key = f"validate:{feed.logical_version_id}"
        self.faults.check(key)
        self.calls += 1
        inputs = _h("validator", feed.canonical_content_sha256, consumer_date, country, "gtfs-validator 8.0.1")
        ok = key not in self.faults.no_artifact
        return ProducerArtifact(artifact_id="VAL:" + inputs[:24], kind="VALIDATION_REPORT", region_id=region_id,
                                namespace=namespace, inputs_digest=inputs, sha256=_h("report", inputs) if ok else None,
                                status="OK" if ok else "NO_ARTIFACT", producer="MOCK:gtfs-validator-8.0.1", mock=True,
                                detail={"feed": feed.logical_version_id, "error_notices": 0})


class MockOtpProducer:
    def __init__(self, faults: MockFaults | None = None) -> None:
        self.faults = faults or MockFaults()
        self.calls = 0

    def build(self, region_id: str, feeds: list[FeedVersionRef], osm_pin: dict, semantic_config_digest: str,
              namespace: str) -> ProducerArtifact:
        key = f"build:{region_id}"
        self.faults.check(key)
        self.calls += 1
        inputs = _h("otp", sorted(f.canonical_content_sha256 for f in feeds), osm_pin.get("sha256"),
                    semantic_config_digest, "otp 2.10.0")
        ok = key not in self.faults.no_artifact
        return ProducerArtifact(artifact_id="RTR:" + inputs[:24], kind="ROUTER_GRAPH", region_id=region_id,
                                namespace=namespace, inputs_digest=inputs, sha256=_h("graph", inputs) if ok else None,
                                status="OK" if ok else "NO_ARTIFACT", producer="MOCK:otp-2.10.0", mock=True,
                                detail={"n_feeds": len(feeds)})


class MockResourceManager:
    def __init__(self, faults: MockFaults | None = None) -> None:
        self.faults = faults or MockFaults()

    def prove_target(self, envelope: dict) -> ConformanceResult:
        self.faults.check("l28")
        tests = {t: "PASS" for t in ("D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10", "DF")}
        return ConformanceResult("L28-target-resource", "PASS", tests, True,
                                 {"resource_envelope_verified": True, "envelope": envelope,
                                  "note": "MOCK: real L28 runs only on the target server (Session 2+/server)"})

    def lease(self, component: str) -> dict:
        table = {"otp": {"cpus": 8, "memory": "32G"}, "validator": {"cpus": 2, "memory": "4g"},
                 "f1": {"cpus": 2, "memory": "8g"}, "n5": {"cpus": 2, "memory": "8g"}, "n1": {"cpus": 8, "memory": "32G"}}
        if component not in table:
            raise PhaseFailed(f"unknown resource component {component}")
        return {"component": component, **table[component], "mock": True}


class MockOracleEvaluator:
    def __init__(self, faults: MockFaults | None = None) -> None:
        self.faults = faults or MockFaults()

    def conformance(self, expected_rows: list[dict]) -> ConformanceResult:
        self.faults.check("oracle")
        if not expected_rows:
            raise PhaseFailed("oracle conformance expectations missing")
        tests = {r["test"]: ("PASS" if r["expected"] in ("EQ", "NE") else "FAIL") for r in expected_rows}
        overall = "PASS" if all(v == "PASS" for v in tests.values()) else "FAIL"
        return ConformanceResult("canon-1.3-conformance", overall, tests, True,
                                 {"expected_digest": sha256_obj(expected_rows)})

    def canon_digest(self, artifact: ProducerArtifact, service_date: str) -> str:
        if artifact.status != "OK":
            raise PhaseFailed("canon digest requested for NO_ARTIFACT")
        return _h("canon", artifact.sha256, service_date)


class MockContractGenerator:
    LEVELS = ("K0", "K1", "K2", "K3")

    def generate(self, artifact: ProducerArtifact, level: str) -> Contract:
        if level not in self.LEVELS:
            raise PhaseFailed(f"unknown contract level {level}")
        terms = _h("contract", artifact.inputs_digest, level)
        return Contract(contract_id=f"{level}:{terms[:20]}", level=level, artifact_id=artifact.artifact_id,
                        terms_digest=terms, mock=True)


class MockContractEvaluator:
    """Deterministic pseudo-evaluation: a pure function of (terms, cut). NOT a scientific contract semantics."""

    def evaluate(self, contract: Contract, cut: str) -> bool:
        return int(_h("eval", contract.terms_digest, cut)[:2], 16) < 128


class MockAdmissionEngine:
    def __init__(self, evaluator: MockContractEvaluator) -> None:
        self.ev = evaluator

    def admit(self, request_slot: str, contracts: list[Contract], cut: str) -> Decision:
        for c in sorted(contracts, key=lambda c: c.contract_id):
            if self.ev.evaluate(c, cut):
                return Decision(request_slot, cut, "REUSE", c.contract_id, "MOCK:admission", True)
        return Decision(request_slot, cut, "REDERIVE", None, "MOCK:admission", True)


class MockRepairEngine:
    def repair(self, request_slot: str, cut: str, candidates: list[str]) -> Decision:
        pick = sorted(candidates)[0] if candidates else None
        return Decision(request_slot, cut, "REUSE" if pick else "REDERIVE", pick, "MOCK:repair", True)


class MockBaseline:
    def __init__(self, name: str, evaluator: MockContractEvaluator) -> None:
        if name not in ("N0", "N1", "N2", "N3", "N4", "N5", "N6"):
            raise PhaseFailed(f"unknown baseline {name}")
        self.name = name
        self.ev = evaluator

    def decide(self, request_slot: str, cut: str, contracts: list[Contract]) -> Decision:
        cur = [c for c in contracts if c.level == "K2"][:1] if self.name == "N5" else []
        hit = any(self.ev.evaluate(c, cut) for c in cur)
        return Decision(request_slot, cut, "REUSE" if hit else "REDERIVE", None, f"MOCK:{self.name}", True)


class MockCostRecorder:
    def __init__(self) -> None:
        self._ledger: list[dict] = []

    def record(self, event: dict) -> None:
        for k in ("namespace", "region_id", "kind"):
            if k not in event:
                raise PhaseFailed(f"cost event missing {k}")
        self._ledger.append(dict(event, mock=True))

    def ledger(self) -> list[dict]:
        return list(self._ledger)


class MockReplayEngine:
    def replay(self, raw_records: list[dict]) -> dict:
        ids = [r["record_id"] for r in raw_records]
        if len(ids) != len(set(ids)):
            raise PhaseFailed("replay found duplicate raw record ids")
        return {"replayed": len(ids), "digest": sha256_obj(sorted(ids)), "mismatches": 0, "mock": True}


class MockMutationEngine:
    def __init__(self, seed_bytes: bytes) -> None:
        self.seed = seed_bytes

    def plan(self, artifact_ids: list[str]) -> dict:
        import hashlib
        ids = sorted(set(artifact_ids))
        ranked = sorted(ids, key=lambda a: hashlib.sha256(self.seed + b"\x00" + a.encode()).digest())
        k = math.ceil(0.05 * len(ids)) if ids else 0
        return {"population": len(ids), "selected": ranked[:k], "mock": True,
                "note": "MOCK plan; mutation families are implemented in Session 3"}


class MockStatisticsEngine:
    def analyze(self, units: list[dict], namespace: str) -> dict:
        for u in units:
            if u.get("namespace") != namespace:
                raise NamespaceViolation(f"statistics input from namespace {u.get('namespace')} in {namespace} analysis")
        keys = [u["unit_id"] for u in units]
        if len(keys) != len(set(keys)):
            raise PhaseFailed("duplicate analysis units")
        return {"namespace": namespace, "n_units": len(units), "units_digest": sha256_obj(sorted(keys)),
                "statistics": "NOT COMPUTED — MOCK (frozen analysis implemented in Session 3)", "mock": True}


class MockFreezeSealManager:
    def __init__(self, faults: MockFaults | None = None) -> None:
        self.faults = faults or MockFaults()

    def seal(self, kind: str, namespace: str, files: dict[str, str]) -> Seal:
        self.faults.check(f"seal:{kind}")
        if not files:
            raise PhaseFailed(f"nothing to seal for {kind}")
        return Seal(kind, namespace, dict(sorted(files.items())), _h("seal", kind, namespace, sorted(files.items())),
                    True)

    def verify(self, seal: Seal, files: dict[str, str]) -> None:
        if dict(sorted(files.items())) != seal.files or \
                _h("seal", seal.kind, seal.namespace, sorted(files.items())) != seal.seal_sha256:
            raise PhaseFailed(f"seal {seal.kind} verification failed")
