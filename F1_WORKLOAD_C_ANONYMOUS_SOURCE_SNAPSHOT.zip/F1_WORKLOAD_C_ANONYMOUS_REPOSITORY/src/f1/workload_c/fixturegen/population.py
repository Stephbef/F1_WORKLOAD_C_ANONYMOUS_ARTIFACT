"""Deterministic ENGINEERING fixture population (NOT scientific data).

Builds a synthetic Mobility-Database-shaped catalog (~120 feeds) with full archive histories:
  * 30 natural regions (2–4 feeds, every pair joined by exactly 4 hub stop pairs within ~20–80 m);
  * a 10-feed component (two 5-feed clusters joined by one 3-pair bridge) -> split into two 5-feed regions;
  * a 9-feed component (8-feed cluster + pendant joined by a 3-pair edge) -> 8-feed region + excluded pendant;
  * controlled exclusions: insufficient history, >30-day gap, unclear/unknown/incompatible licence, inactive,
    authentication, malformed metadata, malformed dataset record, missing history, source-locator failure,
    malformed GTFS, bbox > 500 km, duplicate content, mirror URL, alias provider, redirect, merged bundle,
    timezone mismatch, connectivity failure (2 pairs), isolated feed;
  * history patterns A,A(repacks) / A,B / A,B,A / calendar change / future-only change, with ZIP timestamp,
    compression, member order, CRLF, BOM, folder nesting and extra-member variation.
Everything is a pure function of the code (no randomness). Feed ids are `mdb-1001`, `mdb-1002`, ... in
construction order, so dedup survivors (smallest id) are always the originals.
"""
from __future__ import annotations

import math
import zipfile
from dataclasses import dataclass, field

from ..timeutil import epoch, from_epoch
from .gtfs_gen import FeedContent, FeedLayout, FStop, ZipStyle, build_zip

BASE_URL = "https://mock.mobilitydatabase.invalid/v1"
FILE_HOST = "https://files.mock.mobilitydatabase.invalid"
TZS = ("Europe/Paris", "America/New_York", "Asia/Tokyo", "Australia/Sydney", "America/Chicago", "Europe/Berlin",
       "America/Sao_Paulo", "Africa/Johannesburg", "Asia/Kolkata", "America/Los_Angeles")
LICENSES = (("https://creativecommons.org/licenses/by/4.0/", None),        # A+C
            ("https://creativecommons.org/publicdomain/zero/1.0/", None),  # A
            (None, "research-use-only"),                                    # B
            ("https://creativecommons.org/licenses/by-nd/4.0/legalcode", None),  # B+C
            ("https://opendatacommons.org/licenses/odbl/1-0/", None))      # A+C
OBS_START = "2025-03-01T06:00:00Z"
OBS_END = "2026-07-10T06:00:00Z"
OBS_STEP_DAYS = 20


@dataclass
class FixtureFeed:
    feed_id: str
    key: str
    tz: str
    layout: FeedLayout
    agencies: tuple[tuple[str, str, str], ...]
    provider: str
    feed_name: str
    producer_url: str
    license_url: str | None
    license_id: str | None
    status: str = "active"
    auth: int = 0
    redirects: tuple[str, ...] = ()
    pattern: str = "repack"
    obs: list[str] = field(default_factory=list)
    intent: str = "REGION_MEMBER"
    content_override: str | None = None     # "mirror"/"alias" variant marker
    malformed_meta: str | None = None       # "no_source_info" | "bad_dataset_record"
    no_datasets: bool = False
    locator_fail_index: int | None = None
    malformed_gtfs_latest: bool = False
    content_twin_of: "FixtureFeed | None" = None
    duplicate_catalog_record: bool = False
    duplicate_dataset_record: bool = False


def _obs_times(start: str = OBS_START, end: str = OBS_END, step_days: int = OBS_STEP_DAYS,
               skip: tuple[str, str] | None = None) -> list[str]:
    t, e = epoch(start), epoch(end)
    out = []
    while t <= e:
        s = from_epoch(t)
        if not (skip and skip[0] <= s < skip[1]):
            out.append(s)
        t += step_days * 86400
    return out


def _hub_cluster(lat0: float, lon0: float, keys: list[str], n_hub: int = 4) -> list[FeedLayout]:
    n = len(keys)
    outs = []
    for i, key in enumerate(keys):
        L = FeedLayout(key)
        for k in range(n_hub):
            L.add(lat0, lon0, (k - (n_hub - 1) / 2) * 1000.0, i * 20.0, f"H{k}")
        theta = 2 * math.pi * i / max(n, 1) + 0.3
        for j, delta in enumerate((-0.15, 0.0, 0.15)):
            for r in (4000.0, 6000.0, 8000.0):
                L.add(lat0, lon0, r * math.cos(theta + delta), r * math.sin(theta + delta), f"L{j}{int(r)}")
        outs.append(L)
    return outs


def _link(a: FeedLayout, b: FeedLayout, lat0: float, lon0: float, dx: float, dy: float, n_pairs: int, tag: str) -> None:
    for k in range(n_pairs):
        a.add(lat0, lon0, dx + k * 1000.0, dy, f"{tag}{k}")
        b.add(lat0, lon0, dx + k * 1000.0, dy + 20.0, f"{tag}{k}")


class PopulationBuilder:
    def __init__(self) -> None:
        self.feeds: list[FixtureFeed] = []
        self._n = 1000
        self._cluster = 0

    def _next_id(self) -> str:
        self._n += 1
        return f"mdb-{self._n}"

    def _center(self) -> tuple[float, float]:
        k = self._cluster
        self._cluster += 1
        return -50.0 + 2.2 * k, float(((k * 37) % 300) - 150) + 0.123

    def _feed(self, layout: FeedLayout, tz: str, idx: int, **kw) -> FixtureFeed:
        fid = self._next_id()
        lic = LICENSES[idx % len(LICENSES)]
        f = FixtureFeed(feed_id=fid, key=layout.key, tz=tz, layout=layout,
                        agencies=((f"AG{layout.key}", f"Agency {layout.key}", tz),),
                        provider=f"Provider {layout.key}", feed_name=f"Network {layout.key}",
                        producer_url=f"https://producer.example.invalid/{layout.key}/gtfs.zip",
                        license_url=lic[0], license_id=lic[1], pattern=("repack", "AB", "ABA", "CAL", "FUT")[idx % 5],
                        obs=_obs_times())
        for k, v in kw.items():
            setattr(f, k, v)
        self.feeds.append(f)
        return f

    def build(self) -> list[FixtureFeed]:
        gi = 0
        natural: list[list[FixtureFeed]] = []
        sizes = (2, 3, 2, 4, 2, 3)
        for c in range(30):
            lat0, lon0 = self._center()
            tz = TZS[c % len(TZS)]
            keys = [f"N{c:02d}F{i}" for i in range(sizes[c % len(sizes)])]
            group = []
            for L in _hub_cluster(lat0, lon0, keys):
                group.append(self._feed(L, tz, gi))
                gi += 1
            natural.append(group)
            group[0].obs = group[0].obs  # explicit: natural feeds use the regular schedule

        # --- 10-feed component: two 5-clusters + one 3-pair bridge ---------------------------------------
        lat0, lon0 = self._center()
        tz = "Europe/Madrid"
        c1 = _hub_cluster(lat0, lon0, [f"BIG10A{i}" for i in range(5)])
        lat2, lon2 = lat0, lon0 + 30000.0 / (111195.0 * math.cos(math.radians(lat0)))
        c2 = _hub_cluster(lat2, lon2, [f"BIG10B{i}" for i in range(5)])
        _link(c1[0], c2[0], lat0, lon0, 15000.0, 12000.0, 3, "BR")
        for L in c1 + c2:
            self._feed(L, tz, gi, intent="REGION_MEMBER_SPLIT")
            gi += 1
        # --- 9-feed component: 8-cluster + pendant with a 3-pair edge ------------------------------------
        lat0, lon0 = self._center()
        tz = "America/Toronto"
        c8 = _hub_cluster(lat0, lon0, [f"BIG9C{i}" for i in range(8)])
        pend = FeedLayout("BIG9P")
        _link(c8[3], pend, lat0, lon0, 0.0, 20000.0, 3, "PD")
        for j in range(4):
            pend.add(lat0, lon0, 2000.0 * j, 23000.0, f"L{j}")
        for L in c8:
            self._feed(L, tz, gi, intent="REGION_MEMBER_SPLIT")
            gi += 1
        self._feed(pend, tz, gi, intent="EXCLUDED:SPLIT_PART_SINGLETON")
        gi += 1

        # --- controlled exclusions attached as extra members of natural regions --------------------------
        def extra(group: list[FixtureFeed], tag: str, intent: str, **kw) -> FixtureFeed:
            g0 = group[0]
            lat0, lon0 = g0.layout.stops[0].lat, g0.layout.stops[0].lon
            L = FeedLayout(f"{g0.key}X{tag}")
            for k in range(4):
                L.add(lat0, lon0, (k - 1.5) * 1000.0 + 1500.0, 140.0, f"H{k}")  # aligned with the hub line
            L.add(lat0, lon0, 0.0, -9000.0, "L0")
            return self._feed(L, g0.tz, 2, intent=intent, **kw)

        extra(natural[0], "HIST", "EXCLUDED:HISTORY_INSUFFICIENT_START", obs=_obs_times(start="2025-05-10T06:00:00Z"))
        extra(natural[1], "GAP", "EXCLUDED:HISTORY_GAP_EXCEEDED",
              obs=_obs_times(skip=("2025-09-01T00:00:00Z", "2025-10-15T00:00:00Z")))
        extra(natural[2], "LICU", "EXCLUDED:LICENSE_UNCLEAR", license_url=None, license_id=None)
        extra(natural[3], "LICK", "EXCLUDED:LICENSE_UNCLEAR", license_url="https://unknown-licence.example.invalid/terms",
              license_id=None)
        extra(natural[4], "LICX", "EXCLUDED:LICENSE_INCOMPATIBLE", license_url=None, license_id="login-only-terms")
        extra(natural[5], "INACT", "EXCLUDED:STATUS_NOT_ACTIVE", status="deprecated")
        extra(natural[6], "AUTH", "EXCLUDED:AUTHENTICATION_REQUIRED", auth=2)
        extra(natural[7], "META", "EXCLUDED:MALFORMED_METADATA", malformed_meta="no_source_info")
        extra(natural[8], "DSET", "EXCLUDED:MALFORMED_METADATA", malformed_meta="bad_dataset_record")
        extra(natural[9], "NOHIST", "EXCLUDED:NO_HISTORY", no_datasets=True)
        extra(natural[10], "LOC", "EXCLUDED:ARCHIVE_UNRETRIEVABLE", locator_fail_index=5)
        extra(natural[11], "BADZIP", "EXCLUDED:MALFORMED_GTFS", malformed_gtfs_latest=True)
        bb = extra(natural[12], "BBOX", "EXCLUDED:BBOX_DIAGONAL_EXCEEDED")
        bb.layout.add(bb.layout.stops[0].lat, bb.layout.stops[0].lon, 0.0, 600000.0, "FAR")
        o = natural[13][0]
        self._feed(FeedLayout(o.key + "DUP", list(o.layout.stops)), o.tz, 0, intent="EXCLUDED:DEDUP_IDENTICAL_CONTENT",
                   content_twin_of=o, provider="Mirror Hosting Co", feed_name="Mirror copy",
                   producer_url="https://mirror.example.invalid/copy.zip", pattern=o.pattern)
        o = natural[14][0]
        self._feed(FeedLayout(o.key + "MIR", [FStop(s.stop_id.replace(o.key, o.key + "MIR"), s.lat, s.lon)
                                             for s in o.layout.stops]), o.tz, 1,
                   intent="EXCLUDED:DEDUP_IDENTICAL_URL", content_override="mirror", provider="Another Host",
                   feed_name="Mirror", producer_url=o.producer_url.replace("https://producer.example.invalid",
                                                                           "HTTPS://Producer.Example.invalid:443") + "/")
        o = natural[15][0]
        self._feed(FeedLayout(o.key + "ALI", [FStop(s.stop_id.replace(o.key, o.key + "ALI"), s.lat, s.lon)
                                             for s in o.layout.stops]), o.tz, 1,
                   intent="EXCLUDED:DEDUP_ALIAS", content_override="alias", provider="  " + o.provider.upper() + " ",
                   feed_name=o.feed_name.lower(), producer_url="https://alias.example.invalid/feed.zip")
        o = natural[16][0]
        self._feed(FeedLayout(o.key + "RED", [FStop(s.stop_id.replace(o.key, o.key + "RED"), s.lat, s.lon)
                                             for s in o.layout.stops]), o.tz, 1,
                   intent="EXCLUDED:DEDUP_REDIRECT", redirects=(o.feed_id,), content_override="redirect",
                   producer_url="https://old.example.invalid/feed.zip")
        a, b = natural[17][0], natural[17][1]
        bl = FeedLayout(a.key + "BUN", [FStop("BUN-" + s.stop_id, s.lat, s.lon) for s in a.layout.stops + b.layout.stops])
        self._feed(bl, a.tz, 0, intent="EXCLUDED:DEDUP_MERGED_BUNDLE",
                   agencies=(a.agencies[0][:2] + (a.tz,), b.agencies[0][:2] + (a.tz,)),
                   provider="Regional Bundle Authority", feed_name="All operators",
                   producer_url="https://bundle.example.invalid/all.zip")
        natural[18][0].duplicate_catalog_record = True
        natural[19][0].duplicate_dataset_record = True

        # --- standalone exclusion clusters ---------------------------------------------------------------
        lat0, lon0 = self._center()
        tzm = _hub_cluster(lat0, lon0, ["TZM0", "TZM1"])
        self._feed(tzm[0], "Europe/London", 0, intent="EXCLUDED:REGION_SINGLETON_NO_EDGE(TIMEZONE_MISMATCH)")
        self._feed(tzm[1], "Europe/Dublin", 1, intent="EXCLUDED:REGION_SINGLETON_NO_EDGE(TIMEZONE_MISMATCH)")
        lat0, lon0 = self._center()
        cf = _hub_cluster(lat0, lon0, ["CON0", "CON1"], n_hub=2)
        self._feed(cf[0], "Asia/Seoul", 0, intent="EXCLUDED:REGION_SINGLETON_NO_EDGE(STOP_PAIRS_BELOW_THRESHOLD)")
        self._feed(cf[1], "Asia/Seoul", 1, intent="EXCLUDED:REGION_SINGLETON_NO_EDGE(STOP_PAIRS_BELOW_THRESHOLD)")
        lat0, lon0 = self._center()
        iso = _hub_cluster(lat0, lon0, ["ISO0"])
        self._feed(iso[0], "Pacific/Auckland", 3, intent="EXCLUDED:REGION_SINGLETON_NO_EDGE")
        return self.feeds


# ------------------------------------------------------------------------------------------------------------
# rendering to catalog JSON / datasets / files

def _contents(f: FixtureFeed) -> dict[str, FeedContent]:
    src = f.content_twin_of or f
    stops = tuple(src.layout.stops)
    agencies = src.agencies
    base = FeedContent(feed_key=src.key, agencies=agencies, stops=stops,
                       feed_info_version=f"v1-{f.content_override}" if f.content_override else "v1")
    import dataclasses as dc
    return {
        "A": base,
        "B": dc.replace(base, variant="B", headway_min=10),
        "C": dc.replace(base, variant="C", weekday_pattern="1111110"),
        "F": dc.replace(base, variant="F", calendar_dates=(("S1", "20270105", 2), ("S1", "20270106", 1))),
        "X": dc.replace(base, variant="X", malformed="not_zip"),
    }


def _variant_at(pattern: str, i: int) -> str:
    if pattern == "AB":
        return "A" if i < 8 else "B"
    if pattern == "ABA":
        return "B" if 6 <= i < 12 else "A"
    if pattern == "CAL":
        return "A" if i < 10 else "C"
    if pattern == "FUT":
        return "A" if i < 12 else "F"
    return "A"


def _style(i: int, t: str) -> ZipStyle:
    y, mo, d = int(t[0:4]), int(t[5:7]), int(t[8:10])
    return ZipStyle(date_time=(y, mo, d, 6, (i * 7) % 60, 0),
                    compression=zipfile.ZIP_STORED if i % 2 else zipfile.ZIP_DEFLATED,
                    order_rotation=i, crlf=(i % 3 == 1), bom=(i % 4 == 2), folder="gtfs/" if i % 5 == 3 else "",
                    extra_member=(i % 7 == 4))


@dataclass
class RenderedPopulation:
    feeds: list[dict]                      # catalog records (MDB shape), in catalog order
    datasets: dict[str, list[dict]]        # feed_id -> dataset records
    files: dict[str, bytes]                # hosted_url -> bytes
    missing_files: set[str]                # hosted_urls that 404
    intents: dict[str, str]                # feed_id -> controlled intent
    fixture_feeds: list[FixtureFeed]


def render(feeds: list[FixtureFeed]) -> RenderedPopulation:
    catalog, datasets, files, missing, intents = [], {}, {}, set(), {}
    for f in feeds:
        intents[f.feed_id] = f.intent
        contents = _contents(f)
        dsl = []
        for i, t in enumerate(f.obs):
            v = _variant_at(f.pattern, i)
            if f.malformed_gtfs_latest and i == len(f.obs) - 1:
                v = "X"
            data = build_zip(contents[v], _style(i, t))
            did = f"{f.feed_id}-{t[0:4]}{t[5:7]}{t[8:10]}{t[11:13]}{t[14:16]}"
            url = f"{FILE_HOST}/{f.feed_id}/{did}/{did}.zip"
            if f.locator_fail_index is not None and i == f.locator_fail_index:
                missing.add(url)
            else:
                files[url] = data
            rec = {"id": did, "feed_id": f.feed_id, "hosted_url": url, "downloaded_at": t,
                   "hash": __import__("hashlib").sha256(data).hexdigest(), "note": None,
                   "zipped_folder_size_mb": round(len(data) / 1e6, 6)}
            if f.malformed_meta == "bad_dataset_record" and i == 3:
                del rec["downloaded_at"]
            dsl.append(rec)
            if f.duplicate_dataset_record and i == 4:
                dsl.append(dict(rec))
        datasets[f.feed_id] = [] if f.no_datasets else dsl
        source_info = {"producer_url": f.producer_url, "authentication_type": f.auth,
                       "authentication_info_url": None, "api_key_parameter_name": None,
                       "license_url": f.license_url}
        if f.license_id is not None:
            source_info["license_id"] = f.license_id
        rec = {"id": f.feed_id, "data_type": "gtfs", "status": f.status, "provider": f.provider,
               "feed_name": f.feed_name, "source_info": source_info,
               "redirects": [{"target_id": t, "comment": "fixture redirect"} for t in f.redirects],
               "locations": [{"country_code": "XX", "subdivision_name": f.tz, "municipality": f.key}],
               "latest_dataset": ({"id": dsl[-1]["id"], "hosted_url": dsl[-1]["hosted_url"]} if dsl and not f.no_datasets
                                  else None)}
        if f.malformed_meta == "no_source_info":
            del rec["source_info"]
        catalog.append(rec)
        if f.duplicate_catalog_record:
            catalog.append(dict(rec))
    return RenderedPopulation(catalog, datasets, files, missing, intents, feeds)


def build_fixture_population() -> RenderedPopulation:
    return render(PopulationBuilder().build())
