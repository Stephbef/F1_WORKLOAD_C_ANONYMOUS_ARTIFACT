"""Deterministic synthetic GTFS archive generator (ENGINEERING FIXTURES ONLY — no study feed bytes).

A `FeedContent` describes one logical GTFS content state (agencies, stops, service calendar, variant tag).
`build_zip()` renders it into ZIP bytes under an explicit `ZipStyle` (timestamp, compression, member order,
CRLF/BOM line style, folder nesting, extra non-GTFS members). Different styles of the same content produce
different raw ZIP bytes but — by the frozen rule — the same canonical content hash.
"""
from __future__ import annotations

import io
import math
import zipfile
from dataclasses import dataclass, field

M_PER_DEG_LAT = 111195.0


def offset(lat0: float, lon0: float, dx_m: float, dy_m: float) -> tuple[float, float]:
    lat = lat0 + dy_m / M_PER_DEG_LAT
    lon = lon0 + dx_m / (M_PER_DEG_LAT * math.cos(math.radians(lat0)))
    return round(lat, 7), round(lon, 7)


@dataclass(frozen=True)
class FStop:
    stop_id: str
    lat: float
    lon: float


@dataclass(frozen=True)
class FeedContent:
    feed_key: str
    agencies: tuple[tuple[str, str, str], ...]     # (agency_id, agency_name, agency_timezone)
    stops: tuple[FStop, ...]
    service_start: str = "20250101"
    service_end: str = "20261231"
    weekday_pattern: str = "1111100"
    calendar_dates: tuple[tuple[str, str, int], ...] = ()   # (service_id, date, exception_type)
    headway_min: int = 15
    variant: str = "A"
    feed_info_version: str = "v1"
    malformed: str | None = None    # None | "no_stops" | "not_zip" | "bad_coords"


@dataclass(frozen=True)
class ZipStyle:
    date_time: tuple[int, int, int, int, int, int] = (2025, 1, 1, 0, 0, 0)
    compression: int = zipfile.ZIP_DEFLATED
    order_rotation: int = 0
    crlf: bool = False
    bom: bool = False
    folder: str = ""
    extra_member: bool = False


def _csv(rows: list[list[str]], crlf: bool, bom: bool) -> bytes:
    eol = "\r\n" if crlf else "\n"
    txt = eol.join(",".join(r) for r in rows) + eol
    b = txt.encode("utf-8")
    return (b"\xef\xbb\xbf" + b) if bom else b


def render_tables(c: FeedContent) -> dict[str, list[list[str]]]:
    t: dict[str, list[list[str]]] = {}
    t["agency.txt"] = [["agency_id", "agency_name", "agency_url", "agency_timezone"]] + \
        [[a, n, f"https://{a.lower()}.example.invalid", tz] for a, n, tz in c.agencies]
    stops = [["stop_id", "stop_name", "stop_lat", "stop_lon"]]
    for s in c.stops:
        lat = "not-a-number" if c.malformed == "bad_coords" else f"{s.lat:.7f}"
        stops.append([s.stop_id, f"Stop {s.stop_id}", lat, f"{s.lon:.7f}"])
    if c.malformed != "no_stops":
        t["stops.txt"] = stops
    a0 = c.agencies[0][0]
    t["routes.txt"] = [["route_id", "agency_id", "route_short_name", "route_type"],
                       [f"{c.feed_key}-R1", a0, "1", "3"]]
    t["calendar.txt"] = [["service_id", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
                          "start_date", "end_date"], ["S1", *list(c.weekday_pattern), c.service_start, c.service_end]]
    if c.calendar_dates:
        t["calendar_dates.txt"] = [["service_id", "date", "exception_type"]] + \
            [[s, d, str(e)] for s, d, e in c.calendar_dates]
    t["trips.txt"] = [["route_id", "service_id", "trip_id"], [f"{c.feed_key}-R1", "S1", f"{c.feed_key}-T1"],
                      [f"{c.feed_key}-R1", "S1", f"{c.feed_key}-T2"]]
    st = [["trip_id", "arrival_time", "departure_time", "stop_id", "stop_sequence"]]
    for ti, trip in enumerate((f"{c.feed_key}-T1", f"{c.feed_key}-T2")):
        base = 6 * 60 + ti * c.headway_min
        for seq, s in enumerate(c.stops[: min(6, len(c.stops))]):
            m = base + seq * 3
            hhmm = f"{m // 60:02d}:{m % 60:02d}:00"
            st.append([trip, hhmm, hhmm, s.stop_id, str(seq + 1)])
    t["stop_times.txt"] = st
    t["feed_info.txt"] = [["feed_publisher_name", "feed_publisher_url", "feed_lang", "feed_version"],
                          [f"Fixture {c.feed_key}", "https://fixture.example.invalid", "en",
                           f"{c.feed_info_version}-{c.variant}"]]
    return t


DEFAULT_STYLE = ZipStyle()


def build_zip(c: FeedContent, style: ZipStyle = DEFAULT_STYLE) -> bytes:
    if c.malformed == "not_zip":
        return b"this is not a zip archive " + c.feed_key.encode() + c.variant.encode()
    tables = render_tables(c)
    names = sorted(tables)
    k = style.order_rotation % len(names)
    names = names[k:] + names[:k]
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for n in names:
            zi = zipfile.ZipInfo(style.folder + n, date_time=style.date_time)
            zi.compress_type = style.compression
            zi.external_attr = 0o644 << 16
            z.writestr(zi, _csv(tables[n], style.crlf, style.bom))
        if style.extra_member:
            zi = zipfile.ZipInfo(style.folder + "README.fixture.md", date_time=style.date_time)
            zi.compress_type = style.compression
            z.writestr(zi, f"fixture {c.feed_key} {style.date_time}\n".encode())
    return buf.getvalue()


@dataclass
class FeedLayout:
    """Geometry builder helper: stops for one feed."""
    key: str
    stops: list[FStop] = field(default_factory=list)

    def add(self, lat0: float, lon0: float, dx: float, dy: float, tag: str) -> None:
        lat, lon = offset(lat0, lon0, dx, dy)
        self.stops.append(FStop(f"{self.key}-{tag}", lat, lon))
