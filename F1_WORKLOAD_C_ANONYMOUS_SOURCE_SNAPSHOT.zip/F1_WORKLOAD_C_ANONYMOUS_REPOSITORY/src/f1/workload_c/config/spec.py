"""Authoritative frozen-spec layer for Workload C (Session-1 rules).

`load_protocol_spec()` reads `frozen_specs/derived/workload_c_protocol_spec.json` — a machine-readable encoding of
the authoritative baseline — and validates it strictly:

* exact key sets per section (unknown or missing keys are rejected), exact types and value constraints;
* every cited source file exists under `frozen_specs/` with the recorded SHA-256 (binding to frozen evidence);
* critical values are cross-checked against the authoritative text / frozen tools (GTFS member list and seed
  label are compared with the frozen Python tools themselves, thresholds with the text of spec 17).

No other module defines frozen constants: they receive a `ProtocolSpec`. The spec digest is part of every
checkpoint identity, so a changed rule can never be silently resumed.
"""
from __future__ import annotations

import ast
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ...common.util import canonical_json, sha256_obj
from ..errors import SpecValidationError
from .. import paths

SCHEMA = "F1-WC-PROTOCOL-SPEC-1"

_SECTIONS: dict[str, dict[str, type | tuple]] = {
    "protocol_identity": {"workload": str, "protocol_label": str, "authoritative_baseline": str,
                          "authoritative_baseline_zip_sha256": str, "canon_schema": str, "otp_version": str,
                          "otp_jar_sha256": str, "gtfs_validator_version": str, "gtfs_validator_sha256": str,
                          "java_major": int, "source": str},
    "history": {"window_start": str, "window_end_inclusive": str, "max_gap_days": int, "source": str},
    "feed_eligibility": {"required_status": str, "require_no_authentication": bool, "max_bbox_diagonal_km": int,
                         "eligible_license_classes": list, "excluded_license_classes": list, "source": str},
    "license_policy": {"classes": dict, "unclear_never_pass": bool, "source": str},
    "dedup": {"rules": list, "merged_bundle_min_agency_overlap": float, "source": str},
    "connectivity": {"min_stop_pairs": int, "stop_pair_max_distance_m": int, "hull_max_distance_m": int,
                     "require_same_agency_timezone": bool, "version_in_force_date": str, "source": str},
    "region": {"min_feeds": int, "max_feeds": int, "min_edges_per_feed": int, "oversize_split": str,
               "weakest_edge_order": list, "max_total_latest_zip_mb": int, "region_id_prefix": str,
               "region_id_separator": str, "source": str},
    "seeds": {"master_label": str, "master_hex": str, "seed_bytes_rule": str, "integer_seed_rule": str,
              "domains": list, "source": str},
    "selection": {"domain": str, "count": int, "rank_rule": str, "order": str, "shortfall_message": str,
                  "source": str},
    "split": {"domain": str, "validation_count": int, "test_count": int, "source": str},
    "producers": {"validator_version": str, "validator_flags_template": str, "validator_gate_rule": str,
                  "validator_heap": str, "validator_cpus": int, "otp_jvm_flags": list, "otp_cpus": int,
                  "otp_cpu_quota_percent": int, "otp_memory_max": str, "otp_max_concurrent_builds": int,
                  "otp_locale": str, "f1_n5_cpus": int, "f1_n5_memory_gb": int, "source": str},
    "schedule": {"validator_trigger": str, "validator_workers_per_region": int, "otp_trigger_local": str,
                 "otp_builds_per_region": int, "otp_skip_if_running": bool, "consumer_local": str,
                 "nonexistent_time": str, "ambiguous_time": str, "operational_cap_hours": int, "source": str},
    "canon": {"schema": str, "source_file": str, "main_class": str, "output_marker": str, "horizon_days": int,
              "source": str},
    "logical_versions": {"gtfs_member_names": list, "member_identity": str, "normalizations": list,
                         "pair_format": str, "pair_join": str, "pair_order": str, "collapse": str,
                         "availability": str, "recurrence": str, "logical_version_id_format": str,
                         "chain_order": list, "computed_before_regions": bool, "source": str},
}
_TOP = {"schema", "sources", *list(_SECTIONS)}
_REQUIRED_SOURCES = {"SPEC17", "TOOL_LOGICAL_VERSIONS", "TOOL_HASHRANK", "PROV_V5_REGION_RULES",
                     "PROV_V4_LICENSE_POLICY", "RESOURCE14", "CANON06", "CFGPROJ", "ORACLE_EXPECTED", "CONFIG_EXPECTED",
                     "DETERMINISM_EXPECTED", "FIELD_MATRIX03", "COVERAGE09", "K2ALIGN08"}


@dataclass(frozen=True)
class ProtocolSpec:
    raw: dict
    digest: str
    root: Path

    def __getitem__(self, k: str) -> Any:
        return self.raw[k]

    # convenience typed accessors (values are validated at load time)
    @property
    def gtfs_member_names(self) -> frozenset[str]:
        return frozenset(self.raw["logical_versions"]["gtfs_member_names"])

    @property
    def master_hex(self) -> str:
        return self.raw["seeds"]["master_hex"]

    def seed_bytes(self, domain: str) -> bytes:
        if domain not in self.raw["seeds"]["domains"]:
            raise SpecValidationError(f"unknown seed domain {domain!r}")
        return hashlib.sha256((self.master_hex + "|" + domain).encode("utf-8")).digest()

    def integer_seed(self, domain: str) -> int:
        return int.from_bytes(self.seed_bytes(domain)[:8], "big")


def _fail(msg: str) -> None:
    raise SpecValidationError(msg)


def _check_types(spec: dict) -> None:
    if not isinstance(spec, dict):
        _fail("spec must be a JSON object")
    keys = set(spec)
    if keys != _TOP:
        _fail(f"top-level keys mismatch: missing={sorted(_TOP - keys)} unknown={sorted(keys - _TOP)}")
    if spec["schema"] != SCHEMA:
        _fail(f"unsupported schema {spec['schema']!r}")
    for sec, fields in _SECTIONS.items():
        val = spec[sec]
        if not isinstance(val, dict):
            _fail(f"section {sec} must be an object")
        ks = set(val)
        if ks != set(fields):
            _fail(f"section {sec}: missing={sorted(set(fields) - ks)} unknown={sorted(ks - set(fields))}")
        for k, t in fields.items():
            v = val[k]
            if t is float:
                ok = isinstance(v, (int, float)) and not isinstance(v, bool)
            elif t is int:
                ok = isinstance(v, int) and not isinstance(v, bool)
            else:
                ok = isinstance(v, t)  # type: ignore[arg-type]
            if not ok:
                _fail(f"{sec}.{k} must be {getattr(t, '__name__', t)}, got {type(v).__name__}")
    if not isinstance(spec["sources"], dict):
        _fail("sources must be an object")
    for name, s in spec["sources"].items():
        if not isinstance(s, dict) or set(s) != {"path", "sha256"}:
            _fail(f"source {name} must have exactly path and sha256")
    missing = _REQUIRED_SOURCES - set(spec["sources"])
    if missing:
        _fail(f"required sources missing: {sorted(missing)}")


def _check_values(spec: dict) -> None:
    h, fe, cn, rg = spec["history"], spec["feed_eligibility"], spec["connectivity"], spec["region"]
    sel, spl, lv, sd = spec["selection"], spec["split"], spec["logical_versions"], spec["seeds"]
    if h["max_gap_days"] <= 0:
        _fail("history.max_gap_days must be positive")
    if not (h["window_start"] < h["window_end_inclusive"]):
        _fail("history window is empty")
    if fe["max_bbox_diagonal_km"] <= 0:
        _fail("bbox threshold must be positive")
    if set(fe["eligible_license_classes"]) & set(fe["excluded_license_classes"]):
        _fail("license classes both eligible and excluded")
    classes = spec["license_policy"]["classes"]
    if set(classes) != {"A", "B", "C", "D", "E"}:
        _fail("license_policy.classes must be exactly A..E")
    for c in fe["eligible_license_classes"]:
        if not classes[c]["eligible"]:
            _fail(f"class {c} listed eligible but policy says not eligible")
    for c in fe["excluded_license_classes"]:
        if classes[c]["eligible"]:
            _fail(f"class {c} listed excluded but policy says eligible")
    if classes["D"]["enum"] != "UNCLEAR" or classes["E"]["enum"] != "INCOMPATIBLE":
        _fail("D must map to UNCLEAR and E to INCOMPATIBLE")
    if not spec["license_policy"]["unclear_never_pass"]:
        _fail("UNCLEAR must never become PASS")
    if not (0 < spec["dedup"]["merged_bundle_min_agency_overlap"] <= 1):
        _fail("merged bundle overlap must lie in (0,1]")
    if cn["min_stop_pairs"] < 1 or cn["stop_pair_max_distance_m"] <= 0 or cn["hull_max_distance_m"] < 0:
        _fail("connectivity thresholds invalid")
    if not (2 <= rg["min_feeds"] <= rg["max_feeds"]):
        _fail("region feed bounds invalid")
    if rg["oversize_split"] != "remove_weakest_edges":
        _fail("unsupported oversize split rule")
    if rg["weakest_edge_order"] != ["fewest_stop_pairs", "smallest_feed_ids"]:
        _fail("unsupported weakest-edge order")
    if sel["count"] != spl["validation_count"] + spl["test_count"]:
        _fail("selection count must equal validation + test")
    if sel["domain"] == spl["domain"]:
        _fail("selection and split domains must be independent")
    for d in (sel["domain"], spl["domain"]):
        if d not in sd["domains"]:
            _fail(f"domain {d} not declared")
    if hashlib.sha256(sd["master_label"].encode("utf-8")).hexdigest() != sd["master_hex"]:
        _fail("seeds.master_hex is not SHA-256(master_label)")
    if lv["logical_version_id_format"].format(feed_id="x", n=1) != "x#L00001":
        _fail("logical version id format invalid")
    if lv["normalizations"] != ["strip_utf8_bom", "crlf_to_lf"]:
        _fail("logical-version normalisations must be exactly BOM strip + CRLF->LF (no extra normalisation)")
    if lv["member_identity"] != "basename_lowercase" or lv["pair_format"] != "{name}:{sha256hex}" \
            or lv["pair_join"] != "\n" or lv["chain_order"] != ["feed_id", "archive_observed_utc", "archive_id"]:
        _fail("logical-version hashing rule deviates from the frozen tool")


def _literal_from_tool(path: Path, name: str) -> Any:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return ast.literal_eval(node.value) if not isinstance(node.value, ast.Call) else node.value
    raise SpecValidationError(f"{name} not found in {path}")


def _check_sources(spec: dict, root: Path) -> None:
    for name, s in sorted(spec["sources"].items()):
        p = root / s["path"]
        if not p.is_file():
            _fail(f"frozen source {name} missing at {s['path']}")
        if hashlib.sha256(p.read_bytes()).hexdigest() != s["sha256"]:
            _fail(f"frozen source {name} hash mismatch ({s['path']})")
    # Cross-check against the frozen tools themselves.
    lv_tool = root / spec["sources"]["TOOL_LOGICAL_VERSIONS"]["path"]
    gtfs = _literal_from_tool(lv_tool, "GTFS")
    if set(gtfs) != set(spec["logical_versions"]["gtfs_member_names"]):
        _fail("GTFS member list differs from frozen tools/logical_versions.py")
    rank_src = (root / spec["sources"]["TOOL_HASHRANK"]["path"]).read_text(encoding="utf-8")
    if spec["seeds"]["master_label"] not in rank_src or '"region-selection"' not in rank_src \
            or '"validation-test"' not in rank_src or "[:24]" not in rank_src or "i < 8" not in rank_src:
        _fail("selection rule differs from frozen tools/select_regions_hashrank.py")
    text = (root / spec["sources"]["SPEC17"]["path"]).read_text(encoding="utf-8")
    h, fe, cn, rg = spec["history"], spec["feed_eligibility"], spec["connectivity"], spec["region"]
    needles = [
        f"{h['window_start']}..{h['window_end_inclusive']}", f"no gap > {h['max_gap_days']} days",
        f"diagonal ≤ {fe['max_bbox_diagonal_km']} km", "licence class " + "/".join(fe["eligible_license_classes"]),
        f"≥ {cn['min_stop_pairs']} stop pairs within {cn['stop_pair_max_distance_m']} m",
        f"version in force at {cn['version_in_force_date']}",
        f"≤ {cn['hull_max_distance_m'] // 1000} km apart", "same agency_timezone",
        f"{rg['min_feeds']}–{rg['max_feeds']} feeds", f"≤ {rg['max_total_latest_zip_mb']} MB",
        f"≥ {int(spec['dedup']['merged_bundle_min_agency_overlap'] * 100)} % agency overlap",
        "`R:` + sorted feed ids joined by `+`", f"first {spec['selection']['count']} by \"{spec['selection']['domain']}\"",
        f"first {spec['split']['validation_count']} by \"{spec['split']['domain']}\"",
        spec["protocol_identity"]["otp_jar_sha256"], spec["protocol_identity"]["gtfs_validator_sha256"],
        "Consecutive equal hashes collapse", "BOM removed; CRLF converted to LF",
    ]
    pr, sc, cn2 = spec["producers"], spec["schedule"], spec["canon"]
    needles += [f"gtfs-validator | {pr['validator_version']}", pr["validator_flags_template"], pr["validator_gate_rule"],
                f"{sc['otp_trigger_local']} local", f"region FIFO with {sc['validator_workers_per_region']} worker",
                f"{sc['otp_builds_per_region']} build per region", "a trigger is skipped if a build is running",
                f"Consumer:** {sc['consumer_local']} local", f"moves to the {sc['nonexistent_time']}",
                f"takes its {sc['ambiguous_time']}", f"operational {sc['operational_cap_hours']} h cap",
                f"schema {cn2['schema']}", "[t, t + 6]"]
    for n in needles:
        if n not in text:
            _fail(f"derived spec value not found in authoritative spec 17: {n!r}")
    t14 = (root / spec["sources"]["RESOURCE14"]["path"]).read_text(encoding="utf-8")
    for n in (" ".join(pr["otp_jvm_flags"][:4]), f"MemoryMax {pr['otp_memory_max']}", f"CPUQuota {pr['otp_cpu_quota_percent']} %",
              f"{pr['otp_cpus']} dedicated cores", f"≤ {pr['otp_max_concurrent_builds']} concurrent builds",
              f"`{pr['validator_heap']}`", f"{pr['validator_cpus']} cores", "-Duser.timezone=UTC", pr["otp_locale"],
              f"{pr['f1_n5_cpus']} cores; {pr['f1_n5_memory_gb']} GB"):
        if n not in t14:
            _fail(f"derived resource value not found in authoritative 14: {n!r}")
    canon_src = (root / spec["sources"]["CANON06"]["path"]).read_text(encoding="utf-8")
    if f"public class {cn2['main_class']}" not in canon_src or cn2["output_marker"] not in canon_src \
            or cn2["schema"] not in canon_src or spec["sources"]["CANON06"]["sha256"] != \
            hashlib.sha256((root / "authoritative/conformance/tools/CanonExtractFinal.java").read_bytes()).hexdigest():
        _fail("canon section does not match the frozen Canon source")


def validate_protocol_spec(spec: dict, root: Path | None = None) -> ProtocolSpec:
    root = Path(root) if root else paths.FROZEN_SPECS
    _check_types(spec)
    _check_values(spec)
    _check_sources(spec, root)
    return ProtocolSpec(raw=json.loads(canonical_json(spec)), digest=sha256_obj(spec), root=root)


def load_protocol_spec(path: Path | None = None, root: Path | None = None) -> ProtocolSpec:
    path = Path(path) if path else paths.DERIVED_SPEC
    try:
        spec = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        raise SpecValidationError(f"cannot read protocol spec {path}: {e}") from e
    return validate_protocol_spec(spec, root=root or Path(path).resolve().parents[1])
