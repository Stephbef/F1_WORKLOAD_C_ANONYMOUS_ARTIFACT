"""Runtime configuration (separate from frozen specs) and the spec-interpretation register.

The effective configuration digest binds: protocol-spec digest + interpretation-register digest +
licence-identifier-table digest + runtime config. Any change produces a new digest, which checkpoints compare.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from ...common.util import sha256_obj
from ..errors import SpecValidationError
from .. import paths
from .spec import ProtocolSpec, load_protocol_spec

RUNTIME_SCHEMA = "F1-WC-RUNTIME-CONFIG-1"
_RUNTIME_KEYS = {"schema", "mode", "namespace", "run_id_prefix", "mobility", "clock", "failure_injection_allowed"}
_MOBILITY_KEYS = {"base_url", "auth_mode", "page_limit", "timeout_s", "retry", "token_env", "require_token"}
_RETRY_KEYS = {"max_attempts", "base_delay_s", "factor", "max_delay_s", "max_retry_after_s"}
_INTERP_PARAMS = {
    "in_force_instant_utc", "history_window_start_utc", "history_window_end_exclusive_utc", "history_gap_basis",
    "history_requires_observation_at_or_before_start", "megabyte_bytes", "earth_radius_m", "distance_comparison",
    "hull_geometry", "stop_rows_used", "feed_timezone_rule", "bbox_source", "agency_identity",
    "merged_bundle_measure", "dedup_survivor", "url_normalization", "alias_key", "source_locator_failure",
    "license_identifier_table", "otp_newer_than", "merged_bundle_equal_cardinality"}
_INTERP_ALLOWED = {
    "history_gap_basis": {"archive_observations"},                 # PRE-S3 frozen (INT-02)
    "otp_newer_than": {"last_successful_build"},                    # PRE-S3 frozen (SCH-01)
    "merged_bundle_equal_cardinality": {"keep_both"},               # PRE-S3 frozen (INT-06)
    "distance_comparison": {"inclusive"},
    "hull_geometry": {"planar_hull_local_equirectangular_about_pair_midpoint"},
    "stop_rows_used": {"boarding_points_location_type_blank_or_0"},
    "feed_timezone_rule": {"unique_agency_timezone_else_undefined"},
    "bbox_source": {"latest_logical_version_stops"},
    "agency_identity": {"exact_agency_id"},
    "merged_bundle_measure": {"overlap_coefficient_drop_strictly_larger_agency_set"},
    "dedup_survivor": {"smallest_feed_id"},
    "url_normalization": {"lowercase_scheme_host_drop_default_port_drop_trailing_slash"},
    "alias_key": {"normalized_provider_and_feed_name"},
    "source_locator_failure": {"exclude_feed_archive_unretrievable"},
}


@dataclass(frozen=True)
class Interpretations:
    raw: dict
    digest: str

    @property
    def p(self) -> dict:
        return self.raw["parameters"]

    @property
    def confirmed(self) -> bool:
        return self.raw["status"] == "PI_CONFIRMED"


@dataclass(frozen=True)
class LicenseTable:
    raw: dict
    digest: str


@dataclass(frozen=True)
class EffectiveConfig:
    spec: ProtocolSpec
    interp: Interpretations
    license_table: LicenseTable
    runtime: dict
    digest: str

    @property
    def mode(self) -> str:
        return self.runtime["mode"]

    @property
    def namespace(self) -> str:
        return self.runtime["namespace"]


def validate_runtime(cfg: Any) -> dict:
    if not isinstance(cfg, dict) or set(cfg) != _RUNTIME_KEYS:
        raise SpecValidationError(f"runtime config keys mismatch: {sorted(set(cfg or {}) ^ _RUNTIME_KEYS)}")
    if cfg["schema"] != RUNTIME_SCHEMA:
        raise SpecValidationError("unsupported runtime schema")
    if cfg["mode"] not in ("FIXTURE", "REAL"):
        raise SpecValidationError("mode must be FIXTURE or REAL")
    if cfg["namespace"] not in ("FIXTURE", "VALIDATION", "TEST"):
        raise SpecValidationError("namespace must be FIXTURE, VALIDATION or TEST")
    if cfg["mode"] == "FIXTURE" and cfg["namespace"] != "FIXTURE":
        raise SpecValidationError("FIXTURE mode must use the FIXTURE namespace")
    if cfg["mode"] == "REAL" and cfg["namespace"] == "FIXTURE":
        raise SpecValidationError("REAL mode may not use the FIXTURE namespace")
    if cfg["mode"] == "REAL" and cfg["failure_injection_allowed"]:
        raise SpecValidationError("failure injection may never be enabled in REAL mode")
    m = cfg["mobility"]
    if not isinstance(m, dict) or set(m) != _MOBILITY_KEYS:
        raise SpecValidationError("mobility section keys mismatch")
    if m["auth_mode"] not in ("refresh_token_exchange", "bearer"):
        raise SpecValidationError("mobility.auth_mode invalid")
    if not str(m["base_url"]).startswith("https://"):
        raise SpecValidationError("mobility.base_url must be https")
    if not (isinstance(m["page_limit"], int) and 1 <= m["page_limit"] <= 1000):
        raise SpecValidationError("mobility.page_limit out of range")
    if not (isinstance(m["timeout_s"], (int, float)) and 0 < m["timeout_s"] <= 600):
        raise SpecValidationError("mobility.timeout_s must be bounded (0, 600]")
    r = m["retry"]
    if not isinstance(r, dict) or set(r) != _RETRY_KEYS:
        raise SpecValidationError("mobility.retry keys mismatch")
    if not (isinstance(r["max_attempts"], int) and 1 <= r["max_attempts"] <= 10):
        raise SpecValidationError("retry.max_attempts must be bounded 1..10")
    if not (0 < r["base_delay_s"] <= r["max_delay_s"] <= 3600 and r["factor"] >= 1 and r["max_retry_after_s"] > 0):
        raise SpecValidationError("retry delays invalid")
    if not isinstance(cfg["clock"], dict) or cfg["clock"].get("kind") not in ("fixed_tick", "wall"):
        raise SpecValidationError("clock.kind invalid")
    if cfg["mode"] == "REAL" and cfg["clock"]["kind"] != "wall":
        raise SpecValidationError("REAL mode requires the wall clock")
    if not isinstance(cfg["failure_injection_allowed"], bool):
        raise SpecValidationError("failure_injection_allowed must be bool")
    return cfg


def load_interpretations(path: Path | None = None) -> Interpretations:
    raw = json.loads(Path(path or paths.INTERPRETATIONS).read_text(encoding="utf-8"))
    if raw.get("schema") != "F1-WC-SPEC-INTERPRETATIONS-1" or raw.get("status") not in ("UNCONFIRMED", "PI_CONFIRMED"):
        raise SpecValidationError("interpretation register schema/status invalid")
    params = raw.get("parameters")
    if not isinstance(params, dict) or set(params) != _INTERP_PARAMS:
        raise SpecValidationError("interpretation parameters mismatch")
    for k, allowed in _INTERP_ALLOWED.items():
        if params[k] not in allowed:
            raise SpecValidationError(f"interpretation {k}={params[k]!r} not supported")
    if params["megabyte_bytes"] != 1000000:
        raise SpecValidationError("megabyte_bytes is frozen at 10^6 (INT-03)")
    if params["in_force_instant_utc"] != "2025-04-01T00:00:00Z" or \
            params["history_window_start_utc"] != "2025-04-01T00:00:00Z" or \
            params["history_window_end_exclusive_utc"] != "2026-07-01T00:00:00Z" or \
            params["earth_radius_m"] != 6371008.8 or params["history_requires_observation_at_or_before_start"] is not True:
        raise SpecValidationError("frozen PRE-S3 interpretation values altered (INT-01/02/04)")
    if raw["status"] == "PI_CONFIRMED":
        bad = [i.get("id") for i in raw.get("items", []) if i.get("status") != "FROZEN_PRE_S3" or "alternatives" in i]
        if bad:
            raise SpecValidationError(f"PI_CONFIRMED register contains non-frozen items: {bad}")
    ids = [i.get("id") for i in raw.get("items", [])]
    if len(ids) != len(set(ids)) or not ids:
        raise SpecValidationError("interpretation items missing/duplicated")
    return Interpretations(raw=raw, digest=sha256_obj(raw))


def load_license_table(path: Path | None = None) -> LicenseTable:
    raw = json.loads(Path(path or paths.LICENSE_TABLE).read_text(encoding="utf-8"))
    if raw.get("schema") != "F1-WC-LICENSE-IDENTIFIER-TABLE-1" or raw.get("status") not in ("UNCONFIRMED", "PI_CONFIRMED"):
        raise SpecValidationError("license table schema/status invalid")
    for lid, ent in raw.get("identifiers", {}).items():
        if lid != lid.lower() or set(ent) != {"base", "attribution"} or ent["base"] not in ("A", "B", "E") \
                or not isinstance(ent["attribution"], bool):
            raise SpecValidationError(f"license identifier entry invalid: {lid}")
    for url, lid in raw.get("url_aliases", {}).items():
        if lid not in raw["identifiers"]:
            raise SpecValidationError(f"url alias {url} points at unknown identifier {lid}")
    return LicenseTable(raw=raw, digest=sha256_obj(raw))


def load_effective_config(runtime_path: Path | str | None = None, runtime_obj: dict | None = None,
                          spec: ProtocolSpec | None = None) -> EffectiveConfig:
    if runtime_obj is None:
        rp = Path(runtime_path or (paths.CONFIG_DIR / "fixture.yaml"))
        runtime_obj = yaml.safe_load(rp.read_text(encoding="utf-8"))
    runtime = validate_runtime(runtime_obj)
    spec = spec or load_protocol_spec()
    interp = load_interpretations()
    lt = load_license_table()
    digest = sha256_obj({"spec": spec.digest, "interpretations": interp.digest, "license_table": lt.digest,
                         "runtime": runtime})
    return EffectiveConfig(spec=spec, interp=interp, license_table=lt, runtime=runtime, digest=digest)
