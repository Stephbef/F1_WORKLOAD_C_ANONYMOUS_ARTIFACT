"""Durable checkpoints bound to run identity.

A checkpoint (one per COMPLETE phase, `checkpoints/<NN>_<name>.json`, written atomically and never rewritten)
binds: run id, implementation/source identity, effective-config digest (which includes the frozen-spec digest),
namespace, mode, phase, the committed output files with SHA-256, and the run-state ledger head at commit time.

`CheckpointStore.verify_resume(identity)` refuses (IncompatibleResumeError) when any identity field differs —
in particular a changed seed/config/spec can never silently recompute deterministic selection — and raises
CheckpointIntegrityError when any recorded output is missing or its hash changed.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from ...common.util import canonical_json, sha256_bytes, sha256_file
from ..errors import CheckpointIntegrityError, IncompatibleResumeError
from ..security.secrets import REDACTOR

SCHEMA = "F1-WC-CHECKPOINT-1"


@dataclass(frozen=True)
class RunIdentity:
    run_id: str
    implementation_id: str
    config_digest: str
    spec_digest: str
    namespace: str
    mode: str


class CheckpointStore:
    def __init__(self, root: str | Path, run_dir: str | Path) -> None:
        self.root = Path(root)
        self.run_dir = Path(run_dir)
        self.root.mkdir(parents=True, exist_ok=True)
        self.identity_path = self.root / "RUN_IDENTITY.json"

    # identity -------------------------------------------------------------------------------------------
    def bind_identity(self, ident: RunIdentity) -> None:
        body = canonical_json({"schema": SCHEMA, "identity": asdict(ident)}).encode()
        if self.identity_path.exists():
            self.verify_resume(ident)
            return
        tmp = self.identity_path.with_suffix(".tmp")
        tmp.write_bytes(body)
        tmp.replace(self.identity_path)

    def stored_identity(self) -> RunIdentity | None:
        if not self.identity_path.exists():
            return None
        d = json.loads(self.identity_path.read_text(encoding="utf-8"))
        return RunIdentity(**d["identity"])

    def verify_resume(self, ident: RunIdentity) -> None:
        cur = self.stored_identity()
        if cur is None:
            return
        diffs = [k for k, v in asdict(ident).items() if asdict(cur)[k] != v]
        if diffs:
            raise IncompatibleResumeError(f"resume refused: identity differs on {diffs}", fields=",".join(diffs))
        for cp in self.list():
            if any(cp["identity"][k] != v for k, v in asdict(ident).items()):
                raise IncompatibleResumeError(f"checkpoint {cp['phase']} bound to a different identity")
            self.verify_outputs(cp)

    # checkpoints ----------------------------------------------------------------------------------------
    def path_for(self, phase: str) -> Path:
        return self.root / f"{phase}.json"

    def write(self, ident: RunIdentity, phase: str, outputs: dict[str, str], ledger_head: str,
              ledger_length: int, manifest_sha256: str) -> dict:
        rec = {"schema": SCHEMA, "identity": asdict(ident), "phase": phase, "outputs": dict(sorted(outputs.items())),
               "manifest_sha256": manifest_sha256, "ledger_head": ledger_head, "ledger_length": ledger_length}
        rec = REDACTOR.redact(rec)
        rec["checkpoint_sha256"] = sha256_bytes(canonical_json(rec).encode())
        p = self.path_for(phase)
        if p.exists():
            old = json.loads(p.read_text(encoding="utf-8"))
            if {k: v for k, v in old.items() if k not in ("ledger_head", "ledger_length", "checkpoint_sha256")} != \
                    {k: v for k, v in rec.items() if k not in ("ledger_head", "ledger_length", "checkpoint_sha256")}:
                raise CheckpointIntegrityError(f"checkpoint for {phase} exists with different content")
            return old
        tmp = p.with_suffix(".tmp")
        tmp.write_text(canonical_json(rec) + "\n", encoding="utf-8")
        tmp.replace(p)
        return rec

    def load(self, phase: str) -> dict | None:
        p = self.path_for(phase)
        if not p.exists():
            return None
        rec = json.loads(p.read_text(encoding="utf-8"))
        body = {k: v for k, v in rec.items() if k != "checkpoint_sha256"}
        if sha256_bytes(canonical_json(body).encode()) != rec.get("checkpoint_sha256"):
            raise CheckpointIntegrityError(f"checkpoint {phase} corrupt (self-digest mismatch)")
        return rec

    def list(self) -> list[dict]:
        out = []
        for p in sorted(self.root.glob("*.json")):
            if p.name == "RUN_IDENTITY.json":
                continue
            cp = self.load(p.stem)
            if cp:
                out.append(cp)
        return out

    def verify_outputs(self, cp: dict) -> None:
        for rel, h in cp["outputs"].items():
            f = self.run_dir / rel
            if not f.is_file():
                raise CheckpointIntegrityError(f"checkpointed output missing: {rel}", phase=cp["phase"])
            if sha256_file(f) != h:
                raise CheckpointIntegrityError(f"checkpointed output modified: {rel}", phase=cp["phase"])
