"""Append-only realized-history model and cuts (Session 2).

Events form a DAG: every event names its causal predecessors (`preds`); per-feed logical versions form a chain;
producer queue/start/complete/artifact-birth events are linked to the versions/jobs they depend on. The journal
order is a storage order only — no total order is imposed beyond the DAG and timestamps.

A cut is a frontier vector {feed_id: logical index} (0 = no version yet). Cut(H_t) = for each feed, the latest
logical version available at or before t. Cuts(H_t) is represented finitely by `enumerate_cuts` (product of
per-feed prefixes, optionally bounded by depth back from the frontier). Cuts serialize canonically and hash.
"""
from __future__ import annotations

import enum
import itertools
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

from ...common.util import canonical_json, sha256_obj
from ..errors import WCError
from ..state.journal import AppendOnlyJournal


class EventKind(str, enum.Enum):
    LOGICAL_VERSION_AVAILABLE = "LOGICAL_VERSION_AVAILABLE"
    PRODUCER_QUEUED = "PRODUCER_QUEUED"
    PRODUCER_STARTED = "PRODUCER_STARTED"
    PRODUCER_COMPLETED = "PRODUCER_COMPLETED"
    ARTIFACT_BORN = "ARTIFACT_BORN"
    DERIVATION_EDGE = "DERIVATION_EDGE"
    OTP_TRIGGER = "OTP_TRIGGER"
    OTP_TRIGGER_SKIPPED = "OTP_TRIGGER_SKIPPED"
    CONSUMER_TICK = "CONSUMER_TICK"
    INFRA_ERROR = "INFRA_ERROR"


class HistoryError(WCError):
    error_class = "HISTORY_INVALID"


@dataclass(frozen=True)
class Event:
    kind: str
    at_utc: str
    region_id: str
    feed_id: str | None
    payload: dict
    preds: tuple[str, ...]

    @property
    def event_id(self) -> str:
        return sha256_obj(["F1-WC-EVENT-1", self.kind, self.at_utc, self.region_id, self.feed_id, self.payload,
                           sorted(self.preds)])

    def to_dict(self) -> dict:
        return {"event_id": self.event_id, "kind": self.kind, "at_utc": self.at_utc, "region_id": self.region_id,
                "feed_id": self.feed_id, "payload": self.payload, "preds": sorted(self.preds)}


class RealizedHistory:
    def __init__(self, journal_path: Path | None = None) -> None:
        self.events: dict[str, Event] = {}
        self.order: list[str] = []
        self.versions: dict[str, list[tuple[int, str, str]]] = {}   # feed -> [(index, available_utc, event_id)]
        self.journal = AppendOnlyJournal(journal_path) if journal_path else None
        if self.journal:
            for r in self.journal.records():
                self._add(Event(r["kind"], r["at_utc"], r["region_id"], r["feed_id"], r["payload"], tuple(r["preds"])),
                          persist=False)

    def add(self, ev: Event) -> str:
        return self._add(ev, persist=True)

    def _add(self, ev: Event, persist: bool) -> str:
        eid = ev.event_id
        if eid in self.events:
            return eid                                            # idempotent re-add
        for p in ev.preds:
            if p not in self.events:
                raise HistoryError(f"predecessor {p[:12]} unknown (append-only DAG requires existing causes)")
            if self.events[p].at_utc > ev.at_utc:
                raise HistoryError("an event cannot precede its cause in time")
        if ev.kind == EventKind.LOGICAL_VERSION_AVAILABLE:
            chain = self.versions.setdefault(ev.feed_id or "", [])
            idx = ev.payload["index"]
            if idx != len(chain) + 1:
                raise HistoryError(f"feed {ev.feed_id}: logical index {idx} out of order (expected {len(chain) + 1})")
            if chain and (chain[-1][2] not in ev.preds or chain[-1][1] > ev.at_utc):
                raise HistoryError("logical version must follow its predecessor version (per-feed chain)")
            chain.append((idx, ev.at_utc, eid))
        self.events[eid] = ev
        self.order.append(eid)
        if persist and self.journal:
            self.journal.append(ev.to_dict())
        return eid

    def happens_before(self, a: str, b: str) -> bool:
        seen, stack = set(), [b]
        while stack:
            x = stack.pop()
            for p in self.events[x].preds:
                if p == a:
                    return True
                if p not in seen:
                    seen.add(p)
                    stack.append(p)
        return False

    def concurrent(self, a: str, b: str) -> bool:
        return a != b and not self.happens_before(a, b) and not self.happens_before(b, a)

    def available_count(self, feed: str, t_utc: str) -> int:
        return sum(1 for _, at, _ in self.versions.get(feed, []) if at <= t_utc)


@dataclass(frozen=True)
class Cut:
    region_id: str
    frontier: tuple[tuple[str, int], ...]                 # sorted (feed_id, logical index)

    @staticmethod
    def of(region_id: str, frontier: dict) -> "Cut":
        return Cut(region_id, tuple(sorted((f, int(i)) for f, i in frontier.items())))

    def serialize(self) -> str:
        return canonical_json({"schema": "F1-WC-CUT-1", "region_id": self.region_id, "frontier": [list(x) for x in self.frontier]})

    @property
    def cut_id(self) -> str:
        return "CUT:" + sha256_obj(self.serialize())[:32]

    def index(self, feed: str) -> int:
        return dict(self.frontier)[feed]

    def leq(self, other: "Cut") -> bool:
        a, b = dict(self.frontier), dict(other.frontier)
        return a.keys() == b.keys() and all(a[k] <= b[k] for k in a)


def cut_at(h: RealizedHistory, region_id: str, feeds: list[str], t_utc: str) -> Cut:
    return Cut.of(region_id, {f: h.available_count(f, t_utc) for f in feeds})


def is_consistent(h: RealizedHistory, cut: Cut, t_utc: str) -> bool:
    """Frontier-consistent at t: every coordinate refers to a version that exists and is available at t."""
    return all(0 <= i <= h.available_count(f, t_utc) for f, i in cut.frontier)


def enumerate_cuts(h: RealizedHistory, region_id: str, feeds: list[str], t_utc: str,
                   max_back: int | None = None, include_empty: bool = False) -> Iterator[Cut]:
    """Finite representation of Cuts(H_t): product of per-feed prefixes, lexicographic, optionally depth-bounded."""
    ranges = []
    for f in sorted(feeds):
        k = h.available_count(f, t_utc)
        lo = 0 if include_empty else min(1, k)
        if max_back is not None:
            lo = max(lo, k - max_back)
        ranges.append([(f, i) for i in range(lo, k + 1)])
    for combo in itertools.product(*ranges):
        yield Cut.of(region_id, dict(combo))
