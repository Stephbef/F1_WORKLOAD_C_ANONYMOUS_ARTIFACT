"""Integrated conformance harness (Session 2): the frozen oracle (O*/ORA*/O34), config (C1–C8) and determinism
(D1–D10, DF) suites executed through the Session-2 producer code path (OtpRouterProducer.build_dir +
CanonRunner + semconfig), with the frozen fixtures and expectations from frozen_specs/authoritative/conformance.
Results are additionally compared digest-by-digest with the frozen recorded results (11/13 CSVs)."""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
import subprocess
from datetime import date
from pathlib import Path

from ..producers.semconfig import UnclassifiedConfigKey, semantic_config_digest
from .. import paths

CONF = paths.FROZEN_SPECS / "authoritative" / "conformance"
HORIZON = ["2008-06-03", "2008-06-04", "2008-06-05", "2008-06-06", "2008-06-07", "2008-06-08", "2008-06-09"]
BUILD_DATE = date(2008, 6, 1)


def verify_fixtures() -> int:
    n = 0
    for line in (CONF / "expected" / "FIXTURES.sha256").read_text().splitlines():
        if not line.strip():
            continue
        h, rel = line.split(None, 1)
        rel = rel.strip().lstrip("*")
        p = CONF / "fixtures" / rel
        if hashlib.sha256(p.read_bytes()).hexdigest() != h:
            raise RuntimeError(f"frozen fixture hash mismatch: {rel}")
        n += 1
    return n


def config_suite(out_csv: Path) -> list[dict]:
    rows = []
    for r in csv.DictReader(open(CONF / "expected" / "config_expected.csv")):
        C = CONF / "fixtures" / "config_digest"
        bd = date.fromisoformat(r["build_date"])
        if r["expected"] == "BLOCKED_EXIT3":
            try:
                semantic_config_digest(json.load(open(C / r["config_a"])), bd)
                act = "NOT_BLOCKED"
            except UnclassifiedConfigKey:
                act = "BLOCKED_EXIT3"
        else:
            a = semantic_config_digest(json.load(open(C / r["config_a"])), bd)
            b = semantic_config_digest(json.load(open(C / r["config_b"])), bd)
            act = "EQ" if a == b else "NE"
        rows.append({"test": r["test"], "config_a": r["config_a"], "config_b": r["config_b"], "expected": r["expected"],
                     "actual": act, "result": "PASS" if act == r["expected"] else "FAIL"})
    _write(out_csv, rows)
    return rows


class FixtureBuilder:
    def __init__(self, producer, canon, work: Path) -> None:
        self.p, self.canon, self.work = producer, canon, Path(work)

    def build(self, fixture: str, name: str, env_overrides=None, extra_wrappers=None, jvm_flags=None,
              work: Path | None = None) -> Path:
        job = (work or self.work) / name
        if job.exists():
            shutil.rmtree(job)
        shutil.copytree(CONF / "fixtures" / "oracle" / fixture, job / "graph")
        fc, prs = self.p.build_dir(job, env_overrides=env_overrides, extra_wrappers=extra_wrappers, jvm_flags=jvm_flags)
        (job / "build_status.json").write_text(json.dumps({"failure_class": fc.value,
                                                           "steps": [p.to_dict() for p in prs]}, indent=1))
        return job

    def canon_digest(self, job: Path) -> str | None:
        cfg = json.load(open(job / "graph" / "build-config.json"))
        sem = semantic_config_digest(cfg, BUILD_DATE)
        osm = hashlib.sha256((job / "graph" / "street.osm.pbf").read_bytes()).hexdigest()
        if not (job / "graph" / "graph.obj").exists():
            return None
        r = self.canon.run(job / "graph" / "graph.obj", HORIZON, sem, osm, self.p.binary_sha, job.name, job / "canon")
        return r.digest.sha256 if r.status == "OK" else None


def oracle_suite(builder: FixtureBuilder, out_csv: Path, only: set | None = None) -> list[dict]:
    built: dict[str, Path] = {}
    rows = []
    frozen = {r["test"]: r for r in csv.DictReader(open(paths.FROZEN_SPECS / "authoritative" / "11_ORACLE_TEST_RESULTS_FINAL.csv"))}
    for r in csv.DictReader(open(CONF / "expected" / "oracle_expected.csv")):
        if only and r["test"] not in only:
            continue
        ds = []
        for x in (r["fixture_a"], r["fixture_b"]):
            if x not in built:
                built[x] = builder.build(x.split("@")[0], x.replace("@", "_at_"))
            ds.append(builder.canon_digest(built[x]))
        act = "ERROR" if None in ds else ("EQ" if ds[0] == ds[1] else "NE")
        f = frozen.get(r["test"], {})
        rows.append({"test": r["test"], "fixture_a": r["fixture_a"], "fixture_b": r["fixture_b"], "expected": r["expected"],
                     "actual": act, "result": "PASS" if act == r["expected"] else "FAIL", "digest_a": ds[0] or "",
                     "digest_b": ds[1] or "",
                     "matches_frozen_record": str(ds[0] == f.get("digest_a") and ds[1] == f.get("digest_b"))})
    _write(out_csv, rows)
    return rows


def determinism_suite(builder: FixtureBuilder, out_csv: Path, jvm_flags_final: list[str], alt_work: Path) -> list[dict]:
    rows = []
    ref = builder.canon_digest(builder.build("base", "dbase"))

    def rec(t, v, h, exp=None):
        act = "ERROR" if h is None else ("EQ" if h == (exp or ref) else "NE")
        rows.append({"test": t, "variant": v, "expected": "EQ", "actual": act, "result": "PASS" if act == "EQ" else "FAIL",
                     "digest": h or ""})

    def blocked(t, v):
        rows.append({"test": t, "variant": v, "expected": "EQ", "actual": "BLOCKED", "result": "BLOCKED", "digest": ""})
    rec("D1", "independent rebuild", builder.canon_digest(builder.build("base", "dD1")))
    if shutil.which("faketime"):
        rec("D2", "faketime 2031-03-15 04:00:00", builder.canon_digest(
            builder.build("base", "dD2", extra_wrappers=[["faketime", "2031-03-15 04:00:00"]])))
    else:
        blocked("D2", "faketime missing")
    iso = builder.p.isolate_network
    builder.p.isolate_network = True
    try:
        rec("D3", "unshare -rn (no network)", builder.canon_digest(builder.build("base", "dD3")))
    except Exception:  # noqa: BLE001
        blocked("D3", "unshare unavailable")
    builder.p.isolate_network = iso
    rec("D4", "third rebuild", builder.canon_digest(builder.build("base", "dD4")))
    rec("D5", "cache.enabled (d5)", builder.canon_digest(builder.build("d5", "dD5")))
    a = builder.canon_digest(builder.build("d6a", "dD6a"))
    b = builder.canon_digest(builder.build("d6b", "dD6b"))
    rec("D6", "feed order d6a vs d6b", b, exp=a)
    rec("D7", "JVM restart re-extraction", builder.canon_digest(builder.work / "dbase"))
    try:
        subprocess.run(["sync"], check=False)
        Path("/proc/sys/vm/drop_caches").write_text("3")
        rec("D8", "page cache dropped + fresh dir", builder.canon_digest(builder.build("base", "dD8")))
    except OSError:
        blocked("D8", "drop_caches not permitted")
    rec("D9", "different host path", builder.canon_digest(builder.build("base", "dD9", work=alt_work)))
    rec("D10", "TZ=Asia/Tokyo LC_ALL=fr_FR.UTF-8", builder.canon_digest(
        builder.build("base", "dD10", env_overrides={"TZ": "Asia/Tokyo", "LANG": "fr_FR.UTF-8", "LC_ALL": "fr_FR.UTF-8"})))
    rec("DF", "final JVM flags " + " ".join(jvm_flags_final), builder.canon_digest(
        builder.build("base", "dDF", jvm_flags=jvm_flags_final)))
    _write(out_csv, rows)
    return rows


def _write(p: Path, rows: list[dict]) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        p.write_text("")
        return
    with open(p, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator="\n")
        w.writeheader()
        w.writerows(rows)
