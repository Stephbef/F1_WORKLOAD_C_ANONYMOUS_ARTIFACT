"""--dry-run / --preflight-only: software, dependencies, permissions, capacity, network, secret presence. Never
selects study regions, never runs VALIDATION or TEST, never writes a campaign."""
from __future__ import annotations

from pathlib import Path


def run_preflight(backend, work_root: Path, full: bool) -> dict:
    import shutil
    import tempfile

    class _C:                                     # minimal NON-campaign stand-in (no journal, no identity)
        def __init__(self, wr, rt):
            self.work_root = wr
            self.runtime = rt                     # temporary, outside the work-root, removed afterwards

        def journal_has(self, what):
            return False

        def completed(self):
            return {}
    tmp = Path(tempfile.mkdtemp(prefix="f1wc-preflight-"))
    try:
        return _run(backend, work_root, full, _C(work_root, tmp))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _run(backend, work_root: Path, full: bool, c) -> dict:
    ident = backend.server_identity(c)
    deps = backend.dependencies(c)
    rep = {"mode": "PREFLIGHT_ONLY" if full else "DRY_RUN", "server_identity": ident, "dependencies": deps,
           "work_root_writable": _writable(work_root),
           "disk_ok": ident["disk_free_bytes"] >= backend.disk_required_bytes(c)}
    if full:
        rep["l28"] = backend.l28(c)
        rep["external_access"] = backend.preflight_network() if hasattr(backend, "preflight_network") else \
            backend.external_access(c)
        rep["secret_present"] = backend.secret_present() if hasattr(backend, "secret_present") else None
    ok = deps["status"] == "PASS" and rep["work_root_writable"] and rep["disk_ok"]
    if full:
        ea = rep["external_access"]
        ok = ok and rep["l28"].get("overall") == "PASS" and (ea.get("mobility_auth") == "OK" or
                                                            ea.get("mobility_tls") == "TLS_OK")
    rep["status"] = "PASS" if ok else "FAIL"
    return rep


def _writable(p: Path) -> bool:
    try:
        p.mkdir(parents=True, exist_ok=True)
        t = p / ".preflight_write_test"
        t.write_text("x")
        t.unlink()
        return True
    except OSError:
        return False
