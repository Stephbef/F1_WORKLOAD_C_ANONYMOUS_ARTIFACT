"""FIXTURE backend: exercises the complete one-shot state machine on the synthetic Session-1 population (mock
Mobility server, in-process FIXTURE_STUB producers, simulated physical facts). Every output is labelled FIXTURE;
simulated L28 / network / cache facts can never satisfy the REAL backend (accepted_l28_states differ).
`faults` injects the preregistered failure cases of the end-to-end tests (CASE B–H)."""
from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
from pathlib import Path

from ... import workload_c
from ...common.util import sha256_obj
from ..config.runtime import load_effective_config
from ..paths import CONFIG_DIR as CONFIGS, REPO_ROOT as ROOT


class FixtureBackend:
    binary_mode = "FIXTURE_STUB_BINARY"
    namespace_validation = "FIXTURE"
    namespace_test = "FIXTURE"
    accepted_l28_states = ("FIXTURE_SIMULATED",)
    results_package_name = "F1_WORKLOAD_C_FIXTURE_CAMPAIGN_RESULTS_FINAL.zip"
    window = ("2025-04-01T00:00:00Z", "2026-03-05T00:00:00Z")
    tick_dates = ("2025-06-03", "2025-11-04", "2025-11-05", "2026-03-03")   # 11-04/11-05: N4 age paths
    native_wall_s = 1800.0

    def __init__(self, faults: dict | None = None) -> None:
        self.faults = dict(faults or {})
        self.cfg = load_effective_config(CONFIGS / "fixture.yaml")

    # ------------------------------------------------------------------------------------------ S00..S03
    def server_identity(self, c) -> dict:
        st = shutil.disk_usage(c.work_root)
        return {"mode": "FIXTURE_SIMULATED", "hostname_sha256": hashlib.sha256(platform.node().encode()).hexdigest(),
                "os": platform.platform(), "python": platform.python_version(), "cpu_count": os.cpu_count(),
                "disk_free_bytes": st.free if not self.faults.get("disk_full") else 1024}

    def dependencies(self, c) -> dict:
        import numpy
        ok = numpy.__version__ == "2.4.4" and not self.faults.get("dependency_missing")
        return {"status": "PASS" if ok else "FAIL", "numpy": numpy.__version__, "mode": "FIXTURE"}

    def disk_required_bytes(self, c) -> int:
        return 64 << 20

    def l28(self, c) -> dict:
        if self.faults.get("l28_fail"):
            return {"overall": "FAIL", "physical_l28": "NOT_EXECUTED_ON_TARGET", "reason": "fixture-injected L28 failure"}
        return {"overall": "PASS", "physical_l28": "FIXTURE_SIMULATED", "note": "simulated; never valid for REAL"}

    def external_access(self, c) -> dict:
        if self.faults.get("network_fail"):
            return {"mobility_auth": "FAIL", "osm_source": "OK"}
        return {"mobility_auth": "OK", "osm_source": "OK", "mode": "FIXTURE_MOCK_SERVER"}

    def cache_protocol(self, c) -> dict:
        from .cache_protocol import build_protocol
        return build_protocol(capabilities={"drop_caches": False, "fixture": True}, fixture=True)

    # ------------------------------------------------------------------------------------------ data plane
    def dataplane_wiring(self, c):
        from ..campaign.fixture import fixture_wiring
        w = fixture_wiring(self.cfg)
        return self.cfg, w["services"], w["adapters"], w["secrets"], w["clock"]

    def osm_pin(self, c, region: dict, osm_dir: Path) -> dict:
        """FIXTURE: deterministic synthetic OSM bytes per region (labelled); REAL uses the frozen Geofabrik rule."""
        osm_dir.mkdir(parents=True, exist_ok=True)
        data = ("FIXTURE_OSM " + region["region_id"]).encode()
        p = osm_dir / (hashlib.sha256(region["region_id"].encode()).hexdigest()[:16] + ".osm.pbf")
        p.write_bytes(data)
        d = hashlib.sha256(data).hexdigest()
        return {"region_id": region["region_id"], "source": "FIXTURE_SYNTHETIC", "region_sha256": d,
                "region_path": str(p.relative_to(c.work_root)), "raw_sha256": d}

    def producer_smoke(self, c) -> dict:
        return {"status": "PASS", "binary_mode": self.binary_mode, "mode": "FIXTURE"}

    def frozen_semantics_intact(self, c) -> bool:
        return _frozen_ok() and not self.faults.get("semantics_changed")

    def resource_config_intact(self, c) -> bool:
        return True

    def source_fingerprint(self, c) -> str:
        from ..campaign.identity import implementation_id
        fp = sha256_obj([implementation_id(), _frozen_digest()])
        if self.faults.get("source_modified_after_validation") and c.journal_has("SOURCE_LOCK"):
            return "MODIFIED-" + fp
        return fp

    def namespace_of(self, c, rid: str) -> str:
        return "FIXTURE"

    def region_constants(self, c, rid: str) -> dict:
        pins = {p["region_id"]: p for p in json.loads((c.runtime / "OSM_PINS.json").read_text())["pins"]}
        return {"osm_sha256": pins[rid]["region_sha256"], "semantic_config_digest": "semcfg:" + self.cfg.digest[:16],
                "otp_sha256": "otp:fixture-stub", "validator_sha256": "validator:fixture-stub", "country": "XX"}

    def region_session(self, c, region, cs, ctxf, out: Path) -> dict:
        from ..engines.runner import RegionCampaign
        from ..scheduler.workload_c import FixtureDurationBackend
        return {"duration_backend": FixtureDurationBackend(), "producer_factory": self.producer_factory(c, region, cs, ctxf),
                "native_builder": self.native_builder(c, region, out / "n1_native"), "campaign_cls": RegionCampaign,
                "native_factory": None, "before_arm": None}

    def mutations(self, c, region, camp, out: Path) -> list[dict]:
        from ..campaign.s3_phases import _mutations

        class _Ctx:
            namespace = "FIXTURE"
        if self.faults.get("test_integrity_fail") and c.journal_has("STAGE_COMPLETE:S14_PRETEST_AUDIT"):
            return [{"status": "APPLIED", "integrity": "FAIL", "reason": "fixture-injected TEST integrity failure"}]
        if self.faults.get("mutation_inconsistent"):
            return [{"status": "APPLIED", "integrity": "FAIL", "reason": "fixture-injected reference inconsistency"}]
        _p, res = _mutations(_Ctx(), {region.region_id: camp})       # references unavailable -> INVALID (fail closed)
        return [dict(r, integrity="OK") for r in res]

    def cold_pass_enabled(self, namespace: str) -> bool:
        return True

    def cold_pass(self, c, region, camp, arms, out: Path):
        """FIXTURE cold pass: same mechanism routing as REAL; the native mechanism is the FIXTURE-only synthetic one."""
        from ..engines.core import InProcessFixtureProducer
        from .interleave import cold_pass_mechanism

        class _Generic:
            def __init__(self, inner):
                self.inner = inner

            def execute(self, slot, cut, t):
                return self.inner.produce(slot, cut, t)

        class _FixtureNative:
            def __init__(self, inner):
                self.inner = inner

            def produce(self, slot, cut, t):
                p = self.inner.produce(slot, cut, t)
                p.wall_s, p.cpu_s = 1800.0, 1800.0
                p.entry_kw = {**p.entry_kw, "output_digests": list(p.entry_kw.get("output_digests", [])) +
                              [("mechanism", "N1_NATIVE_CONFIG")]}
                return p
        gen = _Generic(InProcessFixtureProducer(region, camp.cs, camp.contexts))
        return cold_pass_mechanism(region, camp, arms, out, gen,
                                   lambda lab: _FixtureNative(InProcessFixtureProducer(region, camp.cs, camp.contexts)),
                                   lambda: None)

    def ticks(self, c, events: list, region) -> list[str]:
        return [e["t"] for e in events if e["kind"] == "CONSUMER_TICK" and e["local_date"] in self.tick_dates]

    def producer_factory(self, c, region, cs, ctxf):
        from ..engines.core import InProcessFixtureProducer
        fault = self.faults.get("e1_validation")

        def make():
            if fault and region.namespace == "FIXTURE" and not c.journal_has("STAGE_COMPLETE:S10_VALIDATION"):
                raise RuntimeError("fixture-injected E1: producer adapter defect requiring a code change")
            return InProcessFixtureProducer(region, cs, ctxf)
        return make

    def native_builder(self, c, region, root: Path):
        from ..engines.baselines_n import FixtureNativeOtpBuilder
        return FixtureNativeOtpBuilder(root)

    def k3_reference(self, c, region, camp, arms=None):
        """FIXTURE K3: re-run the (stub) producer at the request context and compare its output digests with the
        reused artifact (validator: report digest; router: Canon digest)."""
        from ..engines.core import InProcessFixtureProducer
        prod = InProcessFixtureProducer(region, camp.cs, camp.contexts)
        uncl = self.faults.get("n4_unclassifiable")

        def ref(d, slot, aid):
            if uncl:
                return None
            e = None
            for cat in [camp.shared] + [a.mc.overlay for a in (arms or {}).values()]:
                try:
                    e = cat.get(aid)
                    break
                except Exception:   # noqa: BLE001
                    e = None
            if e is None:
                return None                                   # no provenance -> UNCLASSIFIABLE (never guessed)
            p = prod.produce(slot, d.request.current_cut if slot.startswith("ROUTER:") else
                             _sub(region, d.request.current_cut, slot), d.request.tick_utc)
            want = dict(p.entry_kw.get("output_digests", []))
            have = dict(e.output_digests)
            key = "report" if slot.startswith("VAL:") else "canon"
            return want.get(key) == have.get(key)
        return ref

    def regression(self, c) -> dict:
        if self.faults.get("regression_fail"):
            return {"status": "FAIL", "mode": "FIXTURE_INJECTED"}
        return {"status": "PASS", "mode": "FIXTURE_SIMULATED (the real backend runs scripts/run_tests.sh)"}


def _sub(region, cut, slot):
    from ..history.realized import Cut
    f = slot.split("=", 1)[1]
    return Cut.of(region.region_id, {f: cut.index(f)})


def _frozen_digest() -> str:
    d = json.loads((ROOT / "docs" / "s4a1" / "S4A1_1_SEMANTIC_FREEZE.json").read_text())
    return sha256_obj(d["files"])


def _frozen_ok() -> bool:
    d = json.loads((ROOT / "docs" / "s4a1" / "S4A1_1_SEMANTIC_FREEZE.json").read_text())
    return all(hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() == dg for rel, dg in d["files"].items())


_ = workload_c
