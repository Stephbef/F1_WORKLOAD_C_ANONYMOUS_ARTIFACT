"""Physical cache-state protocol (directive §12): operationalises the frozen "same warm state primary, cold state
secondary" rule WITHOUT touching legitimate method state (N1 persisted street graph / native cache, baseline caches).

PRIMARY (same warm state): immediately before every measured producer execution of ANY method, the runner reads every
input file of that execution once (unmeasured), so every method starts from an equivalently warm OS page cache for its
own inputs; arm order within a request is counterbalanced deterministically (rotation by request ordinal) so no
method is systematically last. COLD (secondary): page cache dropped (`sync; echo 3 > /proc/sys/vm/drop_caches`,
root required) before each re-measured producer execution in the post-campaign cold pass of the same operations.
If the host cannot drop caches the cold secondary is marked UNAVAILABLE and the campaign SAFE-STOPs (no silent
omission). The protocol is sealed before any selected-region timing and never changed afterwards.
"""
from __future__ import annotations

import os

from ...common.util import sha256_obj


def detect_capabilities() -> dict:
    p = "/proc/sys/vm/drop_caches"
    return {"drop_caches": os.path.exists(p) and os.access(p, os.W_OK), "euid": os.geteuid()}


def arm_order(arms: list, request_ordinal: int) -> list:
    """Deterministic counterbalancing: rotate the frozen arm list by the request ordinal."""
    k = request_ordinal % len(arms) if arms else 0
    return arms[k:] + arms[:k]


def warm_inputs(paths: list[str]) -> int:
    """PRIMARY warm-state normalisation: read each input once (unmeasured)."""
    n = 0
    for p in paths:
        with open(p, "rb") as f:
            while f.read(1 << 20):
                pass
        n += 1
    return n


def build_protocol(capabilities: dict | None = None, fixture: bool = False) -> dict:
    cap = capabilities or detect_capabilities()
    cold_ok = bool(cap.get("drop_caches")) or fixture
    body = {"schema": "F1-WC-PHYSICAL-CACHE-STATE-PROTOCOL-1",
            "primary": {"name": "SAME_WARM_STATE", "procedure": "unmeasured read of every producer input before each "
                        "measured execution; counterbalanced arm order (rotation by request ordinal)",
                        "method_state_preserved": ["N1 persisted street graph", "N1 native OTP cache",
                                                   "baseline method overlays / caches"]},
            "secondary": {"name": "COLD_STATE", "procedure": "drop OS page cache before each re-measured producer "
                          "execution in a post-campaign cold pass of the same operations",
                          "available": cold_ok if not fixture else "FIXTURE_SIMULATED"},
            "capabilities": cap, "fixture": fixture}
    body["status"] = "ESTABLISHED" if cold_ok else "UNAVAILABLE"
    body["protocol_sha256"] = sha256_obj({k: v for k, v in body.items() if k != "status"})
    return body
