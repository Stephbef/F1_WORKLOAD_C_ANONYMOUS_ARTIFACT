"""One-shot campaign stages S00–S17. Every decision is mechanical and preregistered: the stages execute, verify,
select τ with the frozen function, freeze, authorize on preregistered integrity conditions only, and stop fail-closed.
No stage inspects comparative performance; no stage edits source, configuration or scientific parameters."""
from __future__ import annotations

import csv
import json
import os
import stat
import time
from pathlib import Path

from ...common.util import sha256_obj
from .core import Campaign, SafeStop, Stage, copy_sealed, sha256_file, utcnow, write_json, zip_tree

TAUS = (1, 6, 24, 72, 168)
METHODS_TEST = ("F1", "N0", "N1", "N2", "N3", "N4", "N5", "N6")


# ----------------------------------------------------------------------------------------------- helpers
def _rt(c: Campaign, name: str) -> Path:
    return c.runtime / name


def _dataplane(c: Campaign):
    from .dataplane_runner import DataplaneRunner
    if "dp" not in c.state:
        cfg, services, adapters, secrets, clock = c.backend.dataplane_wiring(c)
        c.state["dp"] = DataplaneRunner(c.work_root / "dataplane", cfg, services, adapters, secrets,
                                        c.identity["campaign_id"], clock)
    return c.state["dp"]


# ----------------------------------------------------------------------------------------------- S00..S03
def s00_preflight(c: Campaign) -> dict:
    ident = c.backend.server_identity(c)
    p = _rt(c, "TARGET_SERVER_IDENTITY.json")
    write_json(p, {**ident, "campaign_id": c.identity["campaign_id"]}, immutable=True)
    deps = c.backend.dependencies(c)
    dp = _rt(c, "DEPENDENCY_VERIFICATION.json")
    write_json(dp, {**deps, "campaign_id": c.identity["campaign_id"]})
    if deps["status"] != "PASS":
        raise SafeStop("S00_PREFLIGHT", "dependency verification failed", deps)
    need, free = c.backend.disk_required_bytes(c), ident["disk_free_bytes"]
    if free < need:
        raise SafeStop("S00_PREFLIGHT", f"insufficient disk: {free} < required {need}", {"free": free, "need": need})
    c.gate("OSC-RUN-PREFLIGHT", "PASS", str(p))
    return {"server_identity": p, "dependencies": dp}


def s01_l28(c: Campaign) -> dict:
    res = c.backend.l28(c)
    p = _rt(c, "L28_RESULT.json")
    write_json(p, {**res, "campaign_id": c.identity["campaign_id"]})
    if res.get("overall") != "PASS" or res.get("physical_l28") not in c.backend.accepted_l28_states:
        raise SafeStop("S01_L28", f"physical L28 not PASS ({res.get('overall')}, {res.get('physical_l28')})", res)
    c.gate("OSC-RUN-L28", "PASS", str(p))
    return {"l28": p}


def s02_network(c: Campaign) -> dict:
    res = c.backend.external_access(c)
    p = _rt(c, "EXTERNAL_ACCESS.json")
    write_json(p, {**res, "campaign_id": c.identity["campaign_id"]})
    if not (res.get("mobility_auth") == "OK" and res.get("osm_source") == "OK"):
        raise SafeStop("S02_NETWORK", "external data access unavailable", res)
    return {"external_access": p}


def s03_cache_protocol(c: Campaign) -> dict:
    proto = c.backend.cache_protocol(c)
    if proto.get("status") != "ESTABLISHED":
        raise SafeStop("S03_CACHE_PROTOCOL", "warm/cold equivalence cannot be established", proto)
    p = _rt(c, "PHYSICAL_CACHE_STATE_PROTOCOL.json")
    write_json(p, {**proto, "campaign_id": c.identity["campaign_id"], "sealed_before_any_comparative_timing": True},
               immutable=True)
    return {"cache_protocol": p}


# ----------------------------------------------------------------------------------------------- S04..S07
def s04_population(c: Campaign) -> dict:
    dp = _dataplane(c)
    for pid in ("02_mobility_snapshot", "03_logical_versions", "04_license_gate", "05_eligible_regions"):
        dp.run_phase(pid)
    ledger = dp.filter_ledger()
    p = _rt(c, "REAL_POPULATION_FILTER_LEDGER.csv")
    with open(p, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["stage", "count", "source"], lineterminator="\n")
        w.writeheader()
        w.writerows(ledger)
    n_elig = [r for r in ledger if r["stage"] == "eligible_regions"][0]["count"]
    if int(n_elig) < 24:
        raise SafeStop("S04_POPULATION", f"eligible regions {n_elig} < 24 (filters are never weakened)")
    return {"filter_ledger": p, **{f"dataplane_{pid}": dp.root / "phases" / pid for pid in
                                   ("02_mobility_snapshot", "03_logical_versions", "04_license_gate",
                                    "05_eligible_regions")}}


def s05_selection(c: Campaign) -> dict:
    dp = _dataplane(c)
    dp.run_phase("06_select_24")
    dp.run_phase("07_split_8_16")
    sel = dp.read_csv("06_select_24", "selected_24.csv")
    val = dp.read_csv("07_split_8_16", "validation_8.csv")
    tst = dp.read_csv("07_split_8_16", "test_16.csv")
    if len(sel) != 24 or len(val) != 8 or len(tst) != 16:
        raise SafeStop("S05_SELECTION", "selection/split cardinality violated", {"n": [len(sel), len(val), len(tst)]})
    a, b = _rt(c, "SELECTED_24_REGIONS.json"), _rt(c, "VALIDATION_TEST_SPLIT.json")
    write_json(a, {"campaign_id": c.identity["campaign_id"], "regions": sel, "digest": sha256_obj(sel)}, immutable=True)
    write_json(b, {"campaign_id": c.identity["campaign_id"], "validation": [r["region_id"] for r in val],
                   "test": [r["region_id"] for r in tst], "proof": val + tst}, immutable=True)
    return {"selected_24": a, "split": b, "dataplane_06": dp.root / "phases" / "06_select_24",
            "dataplane_07": dp.root / "phases" / "07_split_8_16"}


def s06_osm(c: Campaign) -> dict:
    dp = _dataplane(c)
    regions = dp.regions_by_id()
    sel = json.loads(_rt(c, "SELECTED_24_REGIONS.json").read_text())["regions"]
    osm_dir = c.work_root / "campaign" / "osm"
    pins = []
    for r in sel:
        pins.append(c.backend.osm_pin(c, regions[r["region_id"]], osm_dir))
    p = _rt(c, "OSM_PINS.json")
    write_json(p, {"campaign_id": c.identity["campaign_id"], "pins": pins}, immutable=True)
    dp.install_osm_pins(pins)
    return {"osm_pins": p, "osm_dir": osm_dir, "dataplane_08": dp.root / "phases" / "08_osm_pinning"}


def s07_test_sealing(c: Campaign) -> dict:
    dp = _dataplane(c)
    split = json.loads(_rt(c, "VALIDATION_TEST_SPLIT.json").read_text())
    pins = {p["region_id"]: p for p in json.loads(_rt(c, "OSM_PINS.json").read_text())["pins"]}
    tout = c.work_root / "campaign" / "test_outputs"
    if tout.exists() and any(tout.rglob("*")):
        raise SafeStop("S07_TEST_SEALING", "campaign/test_outputs is not empty before VALIDATION")
    entries = []
    for rid in split["test"]:
        for v in dp.versions_of_region(rid):
            entries.append({"region_id": rid, "feed_id": v["feed_id"], "index": v["index"],
                            "raw_zip_sha256": v["raw_zip_sha256s"][0], "canonical_content_sha256": v["canonical_content_sha256"]})
        entries.append({"region_id": rid, "osm_sha256": pins[rid]["region_sha256"]})
    tin = c.work_root / "campaign" / "test_inputs"
    m = tin / "TEST_INPUT_MANIFEST.json"
    write_json(m, {"campaign_id": c.identity["campaign_id"], "entries": entries, "digest": sha256_obj(entries)},
               immutable=True)
    os.chmod(m, stat.S_IRUSR | stat.S_IRGRP)
    return {"test_input_manifest": m}


# ----------------------------------------------------------------------------------------------- S08..S12
def s08_producers(c: Campaign) -> dict:
    res = c.backend.producer_smoke(c)
    p = _rt(c, "REAL_PRODUCER_PREFLIGHT.json")
    write_json(p, {**res, "campaign_id": c.identity["campaign_id"]})
    if res.get("status") != "PASS":
        raise SafeStop("S08_PRODUCERS", "producer pre-flight failed", res)
    if c.backend.namespace_validation == "VALIDATION" and res.get("binary_mode") != "REAL_PINNED_BINARY":
        raise SafeStop("S08_PRODUCERS", "fixture producers are forbidden in the REAL namespace")
    return {"producer_preflight": p}


def s09_readiness(c: Campaign) -> dict:
    need = ["S00_PREFLIGHT", "S01_L28", "S02_NETWORK", "S03_CACHE_PROTOCOL", "S04_POPULATION", "S05_SELECTION",
            "S06_OSM", "S07_TEST_SEALING", "S08_PRODUCERS"]
    done = c.completed()
    missing = [s for s in need if s not in done]
    c.verify_sealed()
    tout = c.work_root / "campaign" / "test_outputs"
    checks = {"prior_stages_sealed": not missing, "test_outputs_absent": not (tout.exists() and any(tout.rglob("*"))),
              "frozen_semantics": c.backend.frozen_semantics_intact(c), "missing": missing}
    p = _rt(c, "VALIDATION_READINESS.json")
    write_json(p, {**checks, "campaign_id": c.identity["campaign_id"]})
    if missing or not checks["test_outputs_absent"] or not checks["frozen_semantics"]:
        raise SafeStop("S09_VALIDATION_READINESS", "readiness preconditions unmet", checks)
    return {"readiness": p}


def _run_partition(c: Campaign, stage: str, regions: list[str], out_root: Path, namespace: str, n4_taus) -> dict:
    from .campaign_runner import run_region
    summary = {}
    for i, rid in enumerate(regions, 1):
        c.progress(f"      {'VALIDATION' if stage.startswith('S10') else 'TEST'} {i}/{len(regions)} {rid}")
        res = run_region(c, rid, out_root / rid.replace(":", "_").replace("+", "_"), namespace, n4_taus)
        summary[rid] = res
        for inc in res.get("incidents", []):
            rec = c.incident(inc["category"], stage, inc["diagnosis"], inc["requires_change"], region=rid,
                             method=inc.get("method"))
            if inc["requires_change"] or inc["category"] in ("S1", "R1"):
                raise SafeStop(stage, f"incident {rec['incident_id']} ({inc['category']}) requires researcher "
                                      f"intervention — no automatic patch, campaign stops before TEST", rec)
    return summary


def s10_validation(c: Campaign) -> dict:
    split = json.loads(_rt(c, "VALIDATION_TEST_SPLIT.json").read_text())
    if len(split["validation"]) != 8:
        raise SafeStop("S10_VALIDATION", "validation partition is not exactly 8 regions")
    c.journal.append("SOURCE_LOCK", note="no source/config modification permitted after VALIDATION begins",
                     source_fingerprint=c.backend.source_fingerprint(c))
    out = c.work_root / "campaign" / "validation"
    summary = _run_partition(c, "S10_VALIDATION", split["validation"], out, c.backend.namespace_validation, TAUS)
    p = _rt(c, "VALIDATION_EXECUTION.json")
    write_json(p, {"campaign_id": c.identity["campaign_id"], "regions": summary, "n_regions": len(summary)})
    return {"validation_execution": p, "validation_outputs": out}


def s11_n4(c: Campaign) -> dict:
    from ..engines.baselines_s4 import SelectionBlocked, TauOutcome, select_tau
    ex = json.loads(_rt(c, "VALIDATION_EXECUTION.json").read_text())["regions"]
    tot: dict[int, dict[str, float]] = {t: {"unsafe": 0, "cost": 0.0, "unclassifiable": 0, "no_artifact": 0, "cap": 0}
                                        for t in TAUS}
    for _rid, r in sorted(ex.items()):
        for t in TAUS:
            n = r["n4"][str(t)]
            for k in tot[t]:
                tot[t][k] += n[k]
    outcomes = {t: TauOutcome(t, int(v["unsafe"]), round(float(v["cost"]), 6), int(v["unclassifiable"]),
                              int(v["no_artifact"]), int(v["cap"])) for t, v in tot.items()}
    p = _rt(c, "N4_VALIDATION_SELECTION_LEDGER.json")
    try:
        tau = select_tau(outcomes)
    except SelectionBlocked as e:
        write_json(p, {"campaign_id": c.identity["campaign_id"], "status": "BLOCKED", "reason": str(e),
                       "outcomes": {t: vars(o) for t, o in outcomes.items()}})
        raise SafeStop("S11_N4", str(e)) from None
    write_json(p, {"campaign_id": c.identity["campaign_id"], "status": "SELECTED", "selected_tau_h": tau,
                   "rule": "lexicographic argmin (U_tau, C_tau, tau)", "candidates": list(TAUS),
                   "outcomes": {t: vars(o) for t, o in outcomes.items()},
                   "code_digest": c.backend.source_fingerprint(c)}, immutable=True)
    return {"n4_ledger": p}


def s12_validation_closure(c: Campaign) -> dict:
    from .campaign_runner import closure_checks
    res = closure_checks(c, c.work_root / "campaign" / "validation", c.backend.namespace_validation)
    reg = c.backend.regression(c)
    res["regression"] = reg
    unresolved = [i for i in _incidents(c) if i["resolution"] == "UNRESOLVED"]
    res["unresolved_incidents"] = len(unresolved)
    p = _rt(c, "VALIDATION_CLOSURE_REPORT.json")
    write_json(p, {**res, "campaign_id": c.identity["campaign_id"]})
    md = _rt(c, "VALIDATION_CLOSURE_REPORT.md")
    md.write_text("# Validation closure\n\n" + "\n".join(f"- {k}: {v}" for k, v in res.items() if k != "detail") + "\n")
    if not res["ok"] or reg.get("status") != "PASS" or unresolved:
        raise SafeStop("S12_VALIDATION_CLOSURE", "validation closure failed", res)
    return {"closure": p, "closure_md": md}


def _incidents(c: Campaign) -> list[dict]:
    p = _rt(c, "VALIDATION_INCIDENT_LOG.jsonl")
    return [json.loads(ln) for ln in p.read_text().splitlines()] if p.exists() else []


# ----------------------------------------------------------------------------------------------- S13..S17
def s13_freeze(c: Campaign) -> dict:
    fz = c.work_root / "FINAL_CAMPAIGN_FREEZE"
    fz.mkdir(exist_ok=True)
    sealed = {f"{s}/{n}": d for s, rec in c.completed().items() for n, d in rec["digests"].items()}
    body = {"campaign_id": c.identity["campaign_id"], "source": {k: c.identity[k] for k in
                                                                ("source_head", "source_tree", "implementation_id",
                                                                 "package_sha256", "frozen_digests")},
            "sealed_stage_outputs": sealed,
            "selected_tau_h": json.loads(_rt(c, "N4_VALIDATION_SELECTION_LEDGER.json").read_text())["selected_tau_h"],
            "test_input_manifest_sha256": sha256_file(c.work_root / "campaign/test_inputs/TEST_INPUT_MANIFEST.json"),
            "validation_closure_sha256": sha256_file(_rt(c, "VALIDATION_CLOSURE_REPORT.json")),
            "source_fingerprint": c.backend.source_fingerprint(c), "created_utc": utcnow()}
    p = fz / "FINAL_CAMPAIGN_FREEZE.json"
    write_json(p, body, immutable=True)
    d = fz / "FINAL_CAMPAIGN_FREEZE.sha256"
    d.write_text(sha256_file(p) + "\n")
    return {"freeze": p, "freeze_digest": d}


def s14_pretest_audit(c: Campaign) -> dict:
    from .audit import automatic_pretest_audit
    rep = automatic_pretest_audit(c)
    p = _rt(c, "PRETEST_AUDIT.json")
    write_json(p, rep)
    auth = c.work_root / "TEST_CAMPAIGN_AUTHORIZATION.json"
    if not rep["pass"]:
        write_json(auth, {"authorized": False, "campaign_id": c.identity["campaign_id"], "failed": rep["failed"]})
        raise SafeStop("S14_PRETEST_AUDIT", f"automatic pre-TEST audit failed: {rep['failed']}", rep)
    fz = c.work_root / "FINAL_CAMPAIGN_FREEZE" / "FINAL_CAMPAIGN_FREEZE.json"
    write_json(auth, {"authorized": True, "mode": "automatic_preregistered_authorization",
                      "campaign_id": c.identity["campaign_id"], "campaign_freeze_sha256": sha256_file(fz),
                      "test_input_manifest_sha256": sha256_file(c.work_root / "campaign/test_inputs/TEST_INPUT_MANIFEST.json"),
                      "source_head": c.identity["source_head"],
                      "selected_tau_h": json.loads(fz.read_text())["selected_tau_h"], "timestamp": utcnow(),
                      "audit_sha256": sha256_file(p)}, immutable=True)
    return {"audit": p, "authorization": auth}


def require_authorization(c: Campaign) -> dict:
    """TEST execution guard: authorization must exist, be true, and bind the CURRENT freeze and test manifest."""
    auth = c.work_root / "TEST_CAMPAIGN_AUTHORIZATION.json"
    if not auth.exists():
        raise SafeStop("S15_TEST_INTEGRITY", "TEST refused: no authorization")
    a = json.loads(auth.read_text())
    fz = c.work_root / "FINAL_CAMPAIGN_FREEZE" / "FINAL_CAMPAIGN_FREEZE.json"
    if a.get("authorized") is not True or a.get("campaign_id") != c.identity["campaign_id"] or \
            a.get("campaign_freeze_sha256") != sha256_file(fz) or a.get("test_input_manifest_sha256") != \
            sha256_file(c.work_root / "campaign/test_inputs/TEST_INPUT_MANIFEST.json"):
        raise SafeStop("S15_TEST_INTEGRITY", "TEST refused: authorization absent, false or not bound to this freeze")
    return a


def s15_test(c: Campaign) -> dict:
    a = require_authorization(c)
    if c.backend.source_fingerprint(c) != json.loads(
            (c.work_root / "FINAL_CAMPAIGN_FREEZE" / "FINAL_CAMPAIGN_FREEZE.json").read_text())["source_fingerprint"]:
        raise SafeStop("S15_TEST_INTEGRITY", "source/config changed after the campaign freeze")
    split = json.loads(_rt(c, "VALIDATION_TEST_SPLIT.json").read_text())
    if len(split["test"]) != 16:
        raise SafeStop("S15_TEST_INTEGRITY", "test partition is not exactly 16 regions")
    out = c.work_root / "campaign" / "test_outputs"
    out.mkdir(parents=True, exist_ok=True)
    summary = _run_partition(c, "S15_TEST_INTEGRITY", split["test"], out, c.backend.namespace_test,
                             (a["selected_tau_h"],))
    p = out / "TEST_EXECUTION.json"
    write_json(p, {"campaign_id": c.identity["campaign_id"], "regions": summary, "selected_tau_h": a["selected_tau_h"]})
    return {"test_execution": p, "test_outputs": out}


def s16_analysis(c: Campaign) -> dict:
    from .campaign_runner import closure_checks, final_analysis
    out = c.work_root / "campaign" / "test_outputs"
    chk = closure_checks(c, out, c.backend.namespace_test)
    pc = out / "TEST_INTEGRITY_REPLAY_MUTATIONS.json"
    write_json(pc, {**chk, "campaign_id": c.identity["campaign_id"]})
    if not chk["ok"]:
        raise SafeStop("S16_ANALYSIS", "TEST integrity/replay failed — FINAL ANALYSIS BLOCKED (partial data preserved)",
                       chk)
    rep = final_analysis(c, out, c.backend.namespace_test)
    pa = out / "FINAL_ANALYSIS.json"
    write_json(pa, rep)
    return {"integrity": pc, "analysis": pa}


def s17_results(c: Campaign) -> dict:
    name = c.backend.results_package_name
    pkg = zip_tree(c.work_root, c.work_root / "output" / name,
                   include=("CAMPAIGN_ID.json", "journal", "logs", "runtime", "FINAL_CAMPAIGN_FREEZE",
                            "TEST_CAMPAIGN_AUTHORIZATION.json", "campaign", "dataplane/phases"))
    d = c.work_root / "output" / (name + ".sha256")
    d.write_text(sha256_file(pkg) + "\n")
    return {"results_package_digest": d}


STAGES = [Stage("S00_PREFLIGHT", "Server preflight", s00_preflight),
          Stage("S01_L28", "Physical L28", s01_l28),
          Stage("S02_NETWORK", "External access", s02_network),
          Stage("S03_CACHE_PROTOCOL", "Physical cache-state protocol", s03_cache_protocol),
          Stage("S04_POPULATION", "Population (frozen pipeline)", s04_population),
          Stage("S05_SELECTION", "24-region selection and 8/16 split", s05_selection),
          Stage("S06_OSM", "OSM pinning", s06_osm),
          Stage("S07_TEST_SEALING", "TEST input sealing", s07_test_sealing),
          Stage("S08_PRODUCERS", "Real producer pre-flight", s08_producers),
          Stage("S09_VALIDATION_READINESS", "Validation readiness", s09_readiness),
          Stage("S10_VALIDATION", "VALIDATION (8 regions)", s10_validation),
          Stage("S11_N4", "N4 τ selection", s11_n4),
          Stage("S12_VALIDATION_CLOSURE", "Validation closure", s12_validation_closure),
          Stage("S13_FREEZE", "Final campaign freeze", s13_freeze),
          Stage("S14_PRETEST_AUDIT", "Automatic pre-TEST audit", s14_pretest_audit),
          Stage("S15_TEST_INTEGRITY", "TEST (16 regions)", s15_test),
          Stage("S16_ANALYSIS", "Replay / mutations / frozen analysis", s16_analysis),
          Stage("S17_RESULTS_PACKAGE", "Final result package", s17_results)]

_ = (time, copy_sealed)
