"""One-shot campaign core (deployment engineering; no scientific choice is made here).

Work-root layout (all paths relative to --work-root):
  campaign.lock                      exclusive fcntl lock (no two launchers on one work-root)
  CAMPAIGN_ID.json                   immutable campaign identity (sealed at initialisation)
  journal/campaign.jsonl             append-only hash-chained journal (stage transitions, seals, incidents, gates)
  logs/master.log, logs/events.jsonl, logs/gates.jsonl   human / machine logs (secrets redacted)
  runtime/                           stage outputs (each sealed by SHA-256 in the journal when its stage completes)
  campaign/validation/  campaign/test_inputs/  campaign/test_outputs/      filesystem-level TEST firewall
  output/                            final result package or SAFE_STOP package

A stage is COMPLETE only when its outputs are sealed. Resume re-verifies every sealed digest and the source /
configuration identity bound at initialisation; any difference refuses resume. Sealed files are never overwritten.
"""
from __future__ import annotations

import fcntl
import hashlib
import json
import os
import secrets as _secrets
import shutil
import time
import traceback
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from ...common.util import canonical_json, sha256_obj
from ..security.secrets import REDACTOR

SCHEMA = "F1-WC-ONESHOT-CAMPAIGN-1"


class CampaignError(RuntimeError):
    pass


class SafeStop(CampaignError):
    """Fail-closed stop of the one-shot campaign at `stage` (a legitimate campaign outcome)."""
    def __init__(self, stage: str, reason: str, detail: dict | None = None) -> None:
        super().__init__(f"SAFE STOP at {stage}: {reason}")
        self.stage, self.reason, self.detail = stage, reason, detail or {}


class LockHeld(CampaignError):
    pass


class ResumeRefused(CampaignError):
    pass


def utcnow() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def digest_path(p: Path) -> str | None:
    """SHA-256 of a file, or of the sorted (relative path, sha256) list of a directory; None if absent."""
    p = Path(p)
    if p.is_dir():
        return sha256_obj(sorted((str(f.relative_to(p)), sha256_file(f)) for f in p.rglob("*") if f.is_file()))
    return sha256_file(p) if p.exists() else None


def atomic_write(p: Path, data: bytes, immutable: bool = False) -> None:
    """Write via temp + fsync + atomic rename; refuse to overwrite an immutable (sealed) file with other content."""
    p.parent.mkdir(parents=True, exist_ok=True)
    if immutable and p.exists():
        if p.read_bytes() != data:
            raise CampaignError(f"refusing to overwrite sealed file {p}")
        return
    tmp = p.with_name(p.name + f".tmp-{os.getpid()}")
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, p)
    dfd = os.open(p.parent, os.O_RDONLY)
    try:
        os.fsync(dfd)
    finally:
        os.close(dfd)


def write_json(p: Path, obj, immutable: bool = False) -> None:
    atomic_write(p, (json.dumps(obj, indent=1, sort_keys=True, default=str) + "\n").encode(), immutable)


class Journal:
    """Append-only, hash-chained JSONL journal with fsync per record."""
    def __init__(self, path: Path) -> None:
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self.head, self.length = "GENESIS", 0
        if path.exists():
            for rec in self.records():
                self.head, self.length = rec["digest"], self.length + 1

    def records(self) -> list[dict]:
        out: list[dict] = []
        prev = "GENESIS"
        if not self.path.exists():
            return out
        for i, ln in enumerate(self.path.read_text().splitlines()):
            rec = json.loads(ln)
            body = {k: v for k, v in rec.items() if k != "digest"}
            if rec.get("prev") != prev or sha256_obj(body) != rec.get("digest") or rec.get("seq") != i:
                raise CampaignError(f"campaign journal corrupted at record {i}")
            prev = rec["digest"]
            out.append(rec)
        return out

    def append(self, kind: str, **payload) -> dict:
        body = {"seq": self.length, "prev": self.head, "at_utc": utcnow(), "kind": kind,
                "payload": json.loads(json.dumps(REDACTOR.redact(payload), default=str))}
        rec = {**body, "digest": sha256_obj(body)}
        with open(self.path, "a") as f:
            f.write(json.dumps(rec, sort_keys=True) + "\n")
            f.flush()
            os.fsync(f.fileno())
        self.head, self.length = rec["digest"], self.length + 1
        return rec


@dataclass
class Stage:
    sid: str                         # e.g. "S04_POPULATION"
    title: str
    run: Callable                    # run(campaign) -> dict[str, Path]  (outputs to seal)


@dataclass
class Campaign:
    work_root: Path
    identity: dict
    journal: Journal
    backend: Any
    progress: Callable[[str], None] = print
    state: dict = field(default_factory=dict)

    # ------------------------------------------------------------------------------------------- paths
    @property
    def runtime(self) -> Path:
        return self.work_root / "runtime"

    def path(self, rel: str) -> Path:
        return self.work_root / rel

    def log(self, stage: str, msg: str, **kw) -> None:
        line = f"{utcnow()} [{self.identity['campaign_id'][:12]}] {stage} {REDACTOR.redact(msg)}"
        with open(self.work_root / "logs" / "master.log", "a") as f:
            f.write(line + "\n")
        ev = {"at_utc": utcnow(), "campaign_id": self.identity["campaign_id"], "stage": stage, "message": msg, **kw}
        with open(self.work_root / "logs" / "events.jsonl", "a") as f:
            f.write(json.dumps(REDACTOR.redact(ev), default=str, sort_keys=True) + "\n")

    def gate(self, gate: str, status: str, evidence: str = "") -> None:
        rec = {"at_utc": utcnow(), "campaign_id": self.identity["campaign_id"], "gate": gate, "status": status,
               "evidence": evidence}
        with open(self.work_root / "logs" / "gates.jsonl", "a") as f:
            f.write(json.dumps(rec, sort_keys=True) + "\n")
        self.journal.append("GATE", **rec)

    def incident(self, category: str, stage: str, diagnosis: str, requires_change: bool, **kw) -> dict:
        """Append-only VALIDATION/TEST incident (E1 / E2 / S1 / R1 / RUNTIME_DATA)."""
        rec = {"incident_id": f"INC-{self.journal.length:06d}", "at_utc": utcnow(), "stage": stage,
               "category": category, "diagnosis": diagnosis, "requires_source_or_config_change": requires_change,
               "software_state": self.identity["source_head"], "resolution": "UNRESOLVED" if requires_change else "N/A",
               **kw}
        with open(self.runtime / "VALIDATION_INCIDENT_LOG.jsonl", "a") as f:
            f.write(json.dumps(REDACTOR.redact(rec), default=str, sort_keys=True) + "\n")
        self.journal.append("INCIDENT", **rec)
        return rec

    # ----------------------------------------------------------------------------------------- sealing
    def seal(self, stage: str, outputs: dict) -> dict:
        digests = {name: digest_path(Path(p)) for name, p in sorted(outputs.items())}
        rels = {k: str(Path(v).resolve().relative_to(self.work_root.resolve())) for k, v in outputs.items()}
        self.journal.append("STAGE_COMPLETE", stage=stage, outputs=rels, digests=digests)
        return digests

    def journal_has(self, what: str) -> bool:
        """'KIND' or 'STAGE_COMPLETE:<stage>' present in the journal."""
        kind, _, stage = what.partition(":")
        for r in self.journal.records():
            if r["kind"] == kind and (not stage or r["payload"].get("stage") == stage):
                return True
        return False

    def completed(self) -> dict:
        return {r["payload"]["stage"]: r["payload"] for r in self.journal.records() if r["kind"] == "STAGE_COMPLETE"}

    def verify_sealed(self) -> None:
        for stage, rec in self.completed().items():
            for name, rel in rec["outputs"].items():
                if digest_path(self.work_root / rel) != rec["digests"][name]:
                    raise ResumeRefused(f"sealed output {stage}/{name} changed or missing ({rel})")

    def sealed_path(self, stage: str, name: str) -> Path:
        rec = self.completed().get(stage)
        if rec is None or name not in rec["outputs"]:
            raise CampaignError(f"{stage}/{name} not sealed")
        return self.work_root / rec["outputs"][name]


# --------------------------------------------------------------------------------------------- lifecycle
def acquire_lock(work_root: Path):
    work_root.mkdir(parents=True, exist_ok=True)
    fh = open(work_root / "campaign.lock", "a+")
    try:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        fh.close()
        raise LockHeld(f"another launcher holds {work_root / 'campaign.lock'}") from None
    fh.seek(0)
    fh.truncate()
    fh.write(json.dumps({"pid": os.getpid(), "at_utc": utcnow()}))
    fh.flush()
    return fh


def campaign_identity(source: dict, mode: str, nonce: str | None = None) -> dict:
    """campaign_id = SHA-256(schema, source head/tree, implementation id, frozen digests, mode, init nonce, init time).
    The nonce (os CSPRNG) makes each --new-campaign distinct; every output carries the id."""
    nonce = nonce or _secrets.token_hex(16)
    init = utcnow()
    body = {"schema": SCHEMA, "source_head": source["head"], "source_tree": source.get("tree"),
            "implementation_id": source["implementation_id"], "frozen_digests": source["frozen_digests"],
            "package_sha256": source.get("package_sha256"), "mode": mode, "nonce": nonce, "initialised_utc": init}
    return {**body, "campaign_id": "F1WC-" + sha256_obj(body)[:32]}


def open_campaign(work_root: Path, source: dict, mode: str, new: bool, resume: bool, backend, progress=print) -> Campaign:
    work_root = work_root.resolve()
    idp = work_root / "CAMPAIGN_ID.json"
    if new and resume:
        raise CampaignError("--new-campaign and --resume are mutually exclusive")
    if new:
        if idp.exists() or (work_root / "journal").exists():
            raise CampaignError(f"{work_root} already holds a campaign; refusing to create a new one over it")
        ident = campaign_identity(source, mode)
        for d in ("journal", "logs", "runtime", "campaign/validation", "campaign/test_inputs", "output"):
            (work_root / d).mkdir(parents=True, exist_ok=True)
        write_json(idp, ident, immutable=True)
        c = Campaign(work_root, ident, Journal(work_root / "journal" / "campaign.jsonl"), backend, progress)
        c.journal.append("CAMPAIGN_INIT", identity=ident)
        return c
    if resume:
        if not idp.exists():
            raise ResumeRefused(f"no campaign at {work_root}")
        ident = json.loads(idp.read_text())
        for k in ("source_head", "implementation_id", "frozen_digests", "mode"):
            want = source["head"] if k == "source_head" else (mode if k == "mode" else source[k])
            if ident[k] != want:
                raise ResumeRefused(f"source/config identity changed since initialisation ({k})")
        c = Campaign(work_root, ident, Journal(work_root / "journal" / "campaign.jsonl"), backend, progress)
        init = [r for r in c.journal.records() if r["kind"] == "CAMPAIGN_INIT"]
        if not init or init[0]["payload"]["identity"]["campaign_id"] != ident["campaign_id"]:
            raise ResumeRefused("journal does not belong to this campaign")
        c.verify_sealed()
        c.journal.append("CAMPAIGN_RESUME", source_head=source["head"])
        return c
    raise CampaignError("exactly one of --new-campaign / --resume is required")


def run_stages(c: Campaign, stages: list[Stage], stop_after: str | None = None) -> dict:
    """Execute stages in order (skipping sealed ones). SafeStop -> safe-stop package; returns final status."""
    done = c.completed()
    n = len(stages)
    for i, st in enumerate(stages, 1):
        if st.sid in done:
            c.progress(f"[{i:02d}/{n}] {st.title} — already sealed (resume)")
            continue
        c.progress(f"[{i:02d}/{n}] {st.title}")
        c.journal.append("STAGE_START", stage=st.sid)
        c.log(st.sid, "start")
        t0 = time.monotonic()
        try:
            outputs = st.run(c)
        except SafeStop as e:
            c.journal.append("SAFE_STOP", stage=e.stage, reason=e.reason, detail=e.detail)
            c.log(st.sid, f"SAFE STOP: {e.reason}")
            pkg = build_safe_stop(c, e)
            c.progress(f"SAFE STOP at {e.stage}: {e.reason}\n  package: {pkg}")
            return {"status": "SAFE_STOP", "stage": e.stage, "reason": e.reason, "package": str(pkg)}
        except Exception as e:   # noqa: BLE001 — any unexpected error is a fail-closed stop with diagnostics
            ss = SafeStop(st.sid, f"unexpected {type(e).__name__}: {e}", {"traceback": traceback.format_exc()})
            c.journal.append("SAFE_STOP", stage=ss.stage, reason=ss.reason, detail=ss.detail)
            pkg = build_safe_stop(c, ss)
            c.progress(f"SAFE STOP at {st.sid}: {ss.reason}\n  package: {pkg}")
            return {"status": "SAFE_STOP", "stage": st.sid, "reason": ss.reason, "package": str(pkg)}
        c.seal(st.sid, outputs)
        c.log(st.sid, f"complete in {time.monotonic() - t0:.1f}s")
        if stop_after == st.sid:
            return {"status": "STOPPED_AFTER", "stage": st.sid}
    return {"status": "COMPLETE"}


SAFE_STOP_NAMES = {"S00": "PREFLIGHT", "S01": "L28", "S02": "NETWORK", "S03": "CACHE_PROTOCOL", "S04": "POPULATION",
                   "S05": "SELECTION", "S06": "OSM", "S07": "TEST_SEALING", "S08": "PRODUCERS",
                   "S09": "VALIDATION_READINESS", "S10": "VALIDATION", "S11": "N4", "S12": "VALIDATION_CLOSURE",
                   "S13": "FREEZE", "S14": "PRETEST_AUDIT", "S15": "TEST_INTEGRITY", "S16": "ANALYSIS",
                   "S17": "RESULTS_PACKAGE"}


def build_safe_stop(c: Campaign, e: SafeStop) -> Path:
    """Diagnostic package: journal, logs, runtime (incl. partial results), identity; never secrets."""
    name = f"F1_WORKLOAD_C_CAMPAIGN_SAFE_STOP_{SAFE_STOP_NAMES.get(e.stage[:3], e.stage)}.zip"
    out = c.work_root / "output" / name
    write_json(c.runtime / "SAFE_STOP_REPORT.json", {"campaign_id": c.identity["campaign_id"], "stage": e.stage,
                                                    "reason": e.reason, "detail": e.detail, "at_utc": utcnow(),
                                                    "test_outputs_present": _test_outputs_present(c)})
    return zip_tree(c.work_root, out, include=("CAMPAIGN_ID.json", "journal", "logs", "runtime", "campaign"))


def _test_outputs_present(c: Campaign) -> bool:
    d = c.work_root / "campaign" / "test_outputs"
    return d.exists() and any(d.rglob("*"))


def zip_tree(root: Path, out: Path, include: tuple[str, ...]) -> Path:
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.name + ".tmp")
    manifest = []
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for inc in include:
            p = root / inc
            files = [p] if p.is_file() else sorted(f for f in p.rglob("*") if f.is_file()) if p.exists() else []
            for f in files:
                if "store" in f.relative_to(root).parts and f.stat().st_size > 64 << 20:
                    continue                                 # large content-addressed blobs: digests in manifests
                rel = str(f.relative_to(root))
                z.write(f, rel)
                manifest.append(f"{sha256_file(f)}  {rel}")
        z.writestr("SHA256SUMS.txt", "\n".join(manifest) + "\n")
    os.replace(tmp, out)
    return out


def copy_sealed(src: Path, dst: Path) -> Path:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return dst


_ = canonical_json
