"""OSM acquisition — the V3 rule exactly (docs/oneshot/provenance/V3_05_OSM_OSMIUM_PIN_MANIFEST.md, SHA-256
24e65766…ed19, PI-approved): smallest Geofabrik polygon containing the region hull; dated -250401 extract if available,
else the earliest dated extract on or after 2025-04-01; `osmium extract --strategy complete_ways --bbox <hull bbox + 5 km>`;
SHA-256 of the input extract and of the clipped file. No other provider or rule is ever substituted (fail closed).

Region hull: convex hull of the boarding stops (location_type blank/0, valid coordinates) of EXACTLY the frozen
`in_force_lv` logical versions recorded by Phase 05 for the region's feeds (INT-01: in_force_instant_utc =
2025-04-01T00:00:00Z) — the same versions that constructed the region (INT-04). Fail closed otherwise."""
from __future__ import annotations

import hashlib
import io
import json
import math
import re
import subprocess
import urllib.request
import zipfile
from pathlib import Path

GEOFABRIK = "https://download.geofabrik.de"
INDEX_URL = GEOFABRIK + "/index-v1.json"
SNAPSHOT = "250401"
EXPAND_KM = 5.0


class OsmRuleError(RuntimeError):
    pass


class OsmHullError(OsmRuleError):
    pass


def in_force_hull_points(region: dict, versions: list[dict], blob_get, in_force_instant_utc: str) -> list:
    """Boarding points of EXACTLY the Phase-05 `in_force_lv` of every region feed. Fail closed when in_force_lv is
    missing, has no matching logical-version record, matches inconsistent records, is not in force at the frozen
    instant, or its archive cannot be read. Never chooses another version."""
    pts: list = []
    for f in region["feeds"]:
        fid, lv = f.get("feed_id"), f.get("in_force_lv")
        if not lv:
            raise OsmHullError(f"{region['region_id']}: feed {fid} has no frozen in_force_lv")
        m = [v for v in versions if v["feed_id"] == fid and v["logical_version_id"] == lv]
        if not m:
            raise OsmHullError(f"{region['region_id']}: no logical-version record for {fid}/{lv}")
        ident = {(v["index"], v["canonical_content_sha256"], tuple(v["raw_zip_sha256s"]), v["first_observed_utc"])
                 for v in m}
        if len(ident) > 1:
            raise OsmHullError(f"{region['region_id']}: inconsistent logical-version records for {fid}/{lv}")
        v = m[0]
        if v["first_observed_utc"] > in_force_instant_utc:
            raise OsmHullError(f"{region['region_id']}: {fid}/{lv} is not in force at {in_force_instant_utc}")
        try:
            pts += boarding_points(blob_get(v["raw_zip_sha256s"][0]))
        except Exception as e:   # noqa: BLE001 — unreadable archive: fail closed
            raise OsmHullError(f"{region['region_id']}: archive of {fid}/{lv} unreadable ({type(e).__name__})") from None
    return pts


def convex_hull(points: list[tuple[float, float]]) -> list[tuple[float, float]]:
    pts = sorted(set(points))
    if len(pts) <= 2:
        return pts

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower: list = []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper: list = []
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def boarding_points(zip_bytes: bytes) -> list[tuple[float, float]]:
    import csv
    z = zipfile.ZipFile(io.BytesIO(zip_bytes))
    name = [n for n in z.namelist() if n.split("/")[-1].lower() == "stops.txt"]
    if not name:
        return []
    out = []
    for r in csv.DictReader(io.StringIO(z.read(name[0]).decode("utf-8-sig"))):
        if r.get("location_type", "").strip() not in ("", "0"):
            continue
        try:
            lat, lon = float(r["stop_lat"]), float(r["stop_lon"])
        except (KeyError, ValueError):
            continue
        if -90 <= lat <= 90 and -180 <= lon <= 180 and not (lat == 0 and lon == 0):
            out.append((lon, lat))
    return out


def _in_ring(pt, ring) -> bool:
    x, y = pt
    inside = False
    n = len(ring)
    for i in range(n):
        x1, y1 = ring[i][0], ring[i][1]
        x2, y2 = ring[(i + 1) % n][0], ring[(i + 1) % n][1]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / ((y2 - y1) or 1e-300) + x1:
            inside = not inside
    return inside


def in_multipolygon(pt, geom: dict) -> bool:
    polys = geom["coordinates"] if geom["type"] == "MultiPolygon" else [geom["coordinates"]]
    for poly in polys:
        if _in_ring(pt, poly[0]) and not any(_in_ring(pt, hole) for hole in poly[1:]):
            return True
    return False


def geodesic_area_km2(geom: dict) -> float:
    """Spherical polygon area (km²) — used only to rank containing polygons (smallest wins)."""
    R = 6371.0088
    polys = geom["coordinates"] if geom["type"] == "MultiPolygon" else [geom["coordinates"]]
    total = 0.0
    for poly in polys:
        for k, ring in enumerate(poly):
            a = 0.0
            for i in range(len(ring)):
                lon1, lat1 = map(math.radians, ring[i][:2])
                lon2, lat2 = map(math.radians, ring[(i + 1) % len(ring)][:2])
                a += (lon2 - lon1) * (2 + math.sin(lat1) + math.sin(lat2))
            total += (-1 if k else 1) * abs(a) * R * R / 2
    return total


def select_extract(index: dict, hull: list[tuple[float, float]]) -> dict:
    cands = []
    for f in index["features"]:
        geom = f.get("geometry")
        if not geom or "pbf" not in f["properties"].get("urls", {}):
            continue
        if all(in_multipolygon(p, geom) for p in hull):
            cands.append((geodesic_area_km2(geom), f["properties"]["id"], f))
    if not cands:
        raise OsmRuleError("no Geofabrik polygon contains the region hull")
    cands.sort(key=lambda c: (c[0], c[1]))
    return cands[0][2]


def expanded_bbox(hull: list[tuple[float, float]], km: float = EXPAND_KM) -> tuple[float, float, float, float]:
    lons, lats = [p[0] for p in hull], [p[1] for p in hull]
    lat_c = (min(lats) + max(lats)) / 2
    dlat = km / 111.32
    dlon = km / (111.32 * max(math.cos(math.radians(lat_c)), 1e-6))
    return (min(lons) - dlon, min(lats) - dlat, max(lons) + dlon, max(lats) + dlat)


def dated_candidates(latest_pbf_url: str, listing_html: str) -> tuple[str, list[str]]:
    """From the -latest URL and its directory listing: the region stem and its dated extracts (YYMMDD, sorted)."""
    stem = latest_pbf_url.rsplit("/", 1)[1].replace("-latest.osm.pbf", "")
    dates = sorted(set(re.findall(rf'{re.escape(stem)}-(\d{{6}})\.osm\.pbf', listing_html)))
    return stem, dates


def choose_snapshot(dates: list[str]) -> str:
    if SNAPSHOT in dates:
        return SNAPSHOT
    later = [d for d in dates if d >= SNAPSHOT]
    if not later:
        raise OsmRuleError("no dated Geofabrik extract on or after 2025-04-01")
    return later[0]


def http_get(url: str, timeout: int = 600) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "F1-WorkloadC-campaign/1"})
    with urllib.request.urlopen(req, timeout=timeout) as r:      # noqa: S310 — fixed frozen https source
        return r.read()


def pin_region(region_id: str, hull: list[tuple[float, float]], out_dir: Path, osmium: str = "osmium",
               fetch=http_get, index_cache: dict | None = None) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    index = index_cache.get("index") if index_cache is not None and "index" in index_cache else None
    if index is None:
        index = json.loads(fetch(INDEX_URL))
        if index_cache is not None:
            index_cache["index"] = index
    feat = select_extract(index, hull)
    latest = feat["properties"]["urls"]["pbf"]
    listing = fetch(latest.rsplit("/", 1)[0] + "/").decode("utf-8", "replace")
    stem, dates = dated_candidates(latest, listing)
    snap = choose_snapshot(dates)
    src_url = latest.rsplit("/", 1)[0] + f"/{stem}-{snap}.osm.pbf"
    raw_path = out_dir / f"{stem}-{snap}.osm.pbf"
    if not raw_path.exists():
        data = fetch(src_url, 3600)
        raw_path.write_bytes(data)
    raw_sha = hashlib.sha256(raw_path.read_bytes()).hexdigest()
    bb = expanded_bbox(hull)
    region_path = out_dir / (hashlib.sha256(region_id.encode()).hexdigest()[:16] + ".osm.pbf")
    cmd = [osmium, "extract", "--strategy", "complete_ways", "--bbox", ",".join(f"{v:.7f}" for v in bb),
           str(raw_path), "-o", str(region_path), "--overwrite"]
    cp = subprocess.run(cmd, capture_output=True, text=True)
    if cp.returncode != 0 or not region_path.exists():
        raise OsmRuleError(f"osmium extract failed: {cp.stderr[-500:]}")
    return {"region_id": region_id, "source": "GEOFABRIK", "geofabrik_id": feat["properties"]["id"],
            "snapshot": snap, "snapshot_is_250401": snap == SNAPSHOT, "source_url": src_url,
            "raw_path": str(raw_path), "raw_sha256": raw_sha, "bbox_expanded_5km": list(bb), "hull": hull,
            "osmium_command": cmd, "region_path": str(region_path),
            "region_sha256": hashlib.sha256(region_path.read_bytes()).hexdigest(),
            "rule_provenance_sha256": "24e65766fa99e34e5f8fabc881ea37b4af96b2365d5c632e837b11fa334fed19"}
