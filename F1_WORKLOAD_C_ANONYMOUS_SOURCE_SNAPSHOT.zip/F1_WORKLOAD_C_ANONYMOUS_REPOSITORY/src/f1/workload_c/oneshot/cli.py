"""One-shot campaign CLI (invoked by ./run_f1_workload_c_campaign.sh and ./campaign_status.sh)."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


def source_identity() -> dict:
    from ...common.util import sha256_obj
    from ..campaign.identity import implementation_id
    from ..paths import REPO_ROOT
    sid = REPO_ROOT / "SOURCE_IDENTITY.json"
    meta = json.loads(sid.read_text()) if sid.exists() else {}
    fz = json.loads((REPO_ROOT / "docs/s4a1/S4A1_1_SEMANTIC_FREEZE.json").read_text())["files"]
    return {"head": meta.get("head", "UNPACKAGED-WORKTREE"), "tree": meta.get("tree"),
            "implementation_id": implementation_id(), "frozen_digests": {"semantic_freeze": sha256_obj(fz)},
            "package_sha256": os.environ.get("F1_WC_PACKAGE_SHA256")}


def make_backend(mode: str, args):
    if mode == "fixture":
        from .fixture_backend import FixtureBackend
        return FixtureBackend(json.loads(args.fixture_faults) if args.fixture_faults else None)
    from .real_backend import RealBackend
    return RealBackend(token_file=args.mobility_token_file or os.environ.get("MOBILITY_DATABASE_TOKEN_FILE"),
                       real_campaign=bool(args.new_campaign or args.resume))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="run_f1_workload_c_campaign")
    ap.add_argument("--work-root", required=True)
    ap.add_argument("--mobility-token-file")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--new-campaign", action="store_true")
    g.add_argument("--resume", action="store_true")
    g.add_argument("--dry-run", action="store_true")
    g.add_argument("--preflight-only", action="store_true")
    ap.add_argument("--backend", choices=["real", "fixture"], default="real")
    ap.add_argument("--fixture-faults", help=argparse.SUPPRESS)
    ap.add_argument("--stop-after", help=argparse.SUPPRESS)
    a = ap.parse_args(argv)
    from .core import CampaignError, LockHeld, acquire_lock, open_campaign, run_stages
    from .stages import STAGES
    wr = Path(a.work_root).resolve()
    if a.backend == "real" and not (a.dry_run or a.preflight_only) and not (a.mobility_token_file or
                                                                          os.environ.get("MOBILITY_DATABASE_TOKEN_FILE")):
        print("a Mobility Database token file is required (--mobility-token-file)", file=sys.stderr)
        return 2
    try:
        lock = acquire_lock(wr)
    except LockHeld as e:
        print(f"REFUSED: {e}", file=sys.stderr)
        return 4
    try:
        be = make_backend(a.backend, a)
        if a.dry_run or a.preflight_only:
            from .preflight import run_preflight
            rep = run_preflight(be, wr, full=a.preflight_only)
            print(json.dumps(rep, indent=1, sort_keys=True))
            return 0 if rep["status"] == "PASS" else 5
        if not (a.new_campaign or a.resume):
            print("exactly one of --new-campaign / --resume / --dry-run / --preflight-only is required",
                  file=sys.stderr)
            return 2
        c = open_campaign(wr, source_identity(), a.backend.upper(), a.new_campaign, a.resume, be)
        print(f"campaign {c.identity['campaign_id']} at {wr}")
        res = run_stages(c, STAGES, stop_after=a.stop_after)
        print(json.dumps(res, indent=1))
        return {"COMPLETE": 0, "STOPPED_AFTER": 0}.get(res["status"], 10)
    except CampaignError as e:
        print(f"REFUSED: {e}", file=sys.stderr)
        return 3
    finally:
        lock.close()


def status_main(argv=None) -> int:
    from .status import campaign_status
    ap = argparse.ArgumentParser(prog="campaign_status")
    ap.add_argument("work_root")
    a = ap.parse_args(argv)
    print(json.dumps(campaign_status(Path(a.work_root)), indent=1, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
