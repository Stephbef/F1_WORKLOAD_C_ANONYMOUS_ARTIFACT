"""Automatic pre-TEST audit: mechanically verifies the preregistered continuation conditions A–S (directive §4).
It reads integrity / provenance facts only; it never reads a cost, HSR, decision mix or any comparative quantity."""
from __future__ import annotations

import json

from .core import digest_path, sha256_file

TAUS = [1, 6, 24, 72, 168]


def automatic_pretest_audit(c) -> dict:
    rt = c.runtime
    done = c.completed()
    j = c.journal.records()
    checks: dict[str, bool] = {}
    ex = json.loads((rt / "VALIDATION_EXECUTION.json").read_text())
    checks["A_all_8_validation_regions_completed"] = ex["n_regions"] == 8 and all(
        r.get("n_ticks", 0) > 0 and not r.get("incidents") for r in ex["regions"].values())
    l28 = json.loads((rt / "L28_RESULT.json").read_text())
    checks["B_l28_pass"] = l28.get("overall") == "PASS" and l28.get("physical_l28") in c.backend.accepted_l28_states
    n4 = json.loads((rt / "N4_VALIDATION_SELECTION_LEDGER.json").read_text())
    checks["C_n4_selected_by_frozen_rule"] = _tau_recomputes(n4)
    incidents = [r["payload"] for r in j if r["kind"] == "INCIDENT"]
    checks["D_no_S1_amendment"] = not any(i["category"] == "S1" for i in incidents)
    checks["E_no_R1"] = not any(i["category"] == "R1" for i in incidents)
    checks["F_no_unresolved_E1"] = not any(i["category"] == "E1" and i["resolution"] == "UNRESOLVED" for i in incidents)
    checks["G_no_unresolved_E2"] = not any(i["category"] == "E2" and i["resolution"] == "UNRESOLVED" for i in incidents)
    lock = [r["payload"] for r in j if r["kind"] == "SOURCE_LOCK"]
    checks["H_no_source_change_after_validation"] = bool(lock) and lock[-1]["source_fingerprint"] == \
        c.backend.source_fingerprint(c)
    clo = json.loads((rt / "VALIDATION_CLOSURE_REPORT.json").read_text())
    checks["I_regression_and_gates_pass"] = clo.get("regression", {}).get("status") == "PASS"
    checks["J_validation_integrity_pass"] = clo.get("ok") is True
    fz = c.work_root / "FINAL_CAMPAIGN_FREEZE" / "FINAL_CAMPAIGN_FREEZE.json"
    checks["K_freeze_generated"] = fz.exists() and "S13_FREEZE" in done
    tin = c.work_root / "campaign" / "test_inputs" / "TEST_INPUT_MANIFEST.json"
    checks["L_test_inputs_untouched"] = sha256_file(tin) == done["S07_TEST_SEALING"]["digests"]["test_input_manifest"]
    tout = c.work_root / "campaign" / "test_outputs"
    checks["M_test_outputs_absent"] = not (tout.exists() and any(tout.rglob("*")))
    if fz.exists():
        body = json.loads(fz.read_text())
        dig = (c.work_root / "FINAL_CAMPAIGN_FREEZE" / "FINAL_CAMPAIGN_FREEZE.sha256").read_text().split()[0]
        checks["N_freeze_hash_consistent"] = dig == sha256_file(fz) and body["campaign_id"] == c.identity["campaign_id"] \
            and body["source_fingerprint"] == c.backend.source_fingerprint(c)
    else:
        checks["N_freeze_hash_consistent"] = False
    sem = c.backend.frozen_semantics_intact(c)
    checks["O_baseline_semantics_unchanged"] = sem
    checks["P_resource_configuration_unchanged"] = sem and c.backend.resource_config_intact(c)
    sealed_split = done["S05_SELECTION"]["digests"]
    checks["Q_region_membership_unchanged"] = all(
        digest_path(c.work_root / done["S05_SELECTION"]["outputs"][k]) == sealed_split[k] for k in sealed_split)
    checks["R_statistical_configuration_unchanged"] = sem
    checks["S_n4_candidates_and_rule_unchanged"] = n4.get("candidates") == TAUS and \
        n4.get("rule") == "lexicographic argmin (U_tau, C_tau, tau)" and sem
    failed = sorted(k for k, v in checks.items() if not v)
    return {"campaign_id": c.identity["campaign_id"], "checks": checks, "failed": failed, "pass": not failed,
            "reads_performance": False}


def _tau_recomputes(n4: dict) -> bool:
    from ..engines.baselines_s4 import TauOutcome, select_tau
    if n4.get("status") != "SELECTED":
        return False
    outs = {int(t): TauOutcome(**{k: v for k, v in o.items()}) for t, o in n4["outcomes"].items()}
    try:
        return select_tau(outs) == n4["selected_tau_h"]
    except Exception:   # noqa: BLE001
        return False
