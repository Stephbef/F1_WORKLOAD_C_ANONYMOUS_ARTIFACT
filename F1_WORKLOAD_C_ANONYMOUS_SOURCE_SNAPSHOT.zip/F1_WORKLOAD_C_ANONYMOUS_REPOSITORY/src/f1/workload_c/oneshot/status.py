"""Read-only campaign status (never writes, never takes the lock)."""
from __future__ import annotations

import json
from pathlib import Path


def campaign_status(wr: Path) -> dict:
    wr = Path(wr)
    if not (wr / "CAMPAIGN_ID.json").exists():
        return {"work_root": str(wr), "campaign": None}
    ident = json.loads((wr / "CAMPAIGN_ID.json").read_text())
    recs = [json.loads(ln) for ln in (wr / "journal" / "campaign.jsonl").read_text().splitlines()] \
        if (wr / "journal" / "campaign.jsonl").exists() else []
    done = [r["payload"]["stage"] for r in recs if r["kind"] == "STAGE_COMPLETE"]
    started = [r["payload"]["stage"] for r in recs if r["kind"] == "STAGE_START"]
    stops = [r["payload"] for r in recs if r["kind"] == "SAFE_STOP"]
    gates = [r["payload"] for r in recs if r["kind"] == "GATE"]
    tau = None
    p = wr / "runtime" / "N4_VALIDATION_SELECTION_LEDGER.json"
    if p.exists():
        tau = json.loads(p.read_text()).get("selected_tau_h")
    auth = None
    a = wr / "TEST_CAMPAIGN_AUTHORIZATION.json"
    if a.exists():
        auth = json.loads(a.read_text()).get("authorized")
    tout = wr / "campaign" / "test_outputs"
    return {"campaign_id": ident["campaign_id"], "mode": ident["mode"], "stages_complete": done,
            "current_stage": (started[-1] if started and (not done or started[-1] != done[-1]) else None),
            "safe_stops": stops, "gates": gates, "validation_complete": "S10_VALIDATION" in done,
            "selected_tau_h": tau, "test_authorized": auth,
            "test_regions_done": len([d for d in tout.iterdir() if d.is_dir()]) if tout.exists() else 0,
            "final_analysis": "S16_ANALYSIS" in done, "results_package": "S17_RESULTS_PACKAGE" in done}
