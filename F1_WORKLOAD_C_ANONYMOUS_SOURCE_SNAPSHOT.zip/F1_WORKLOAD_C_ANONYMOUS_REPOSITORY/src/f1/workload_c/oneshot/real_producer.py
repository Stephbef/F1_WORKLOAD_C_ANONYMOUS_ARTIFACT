"""REAL producer paths for the one-shot campaign (target server only).

RealSlotProducer  — Session-3 producer contract (produce(slot, cut, t) -> Produced) over the pinned gtfs-validator and
                    OTP 2.10.0 + Canon_D 1.3, with the campaign's FIXED absolute service bounds on every OTP build and
                    the PHYSICAL_CACHE_STATE_PROTOCOL warm step (complete common input corpus of the request, read in
                    deterministic order, unmeasured) before every measured execution.
ScheduledExecutor — frozen-scheduler duration backend for REAL: each scheduled validator / OTP job is executed once,
                    at its scheduled invocation instant, its measured wall time and failure class feed the frozen
                    simulation, and its outcome becomes the SHARED artifact (no producer runs twice).
real_k3_reference — N4 safety reference: validator re-run at the request context / rebuild + Canon_D under the
                    current D, compared with the reused artifact; failure -> None (UNCLASSIFIABLE, never guessed).
cold pass         — implemented in interleave.cold_pass_mechanism (same mechanism as the primary step; drop_caches here).
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

from ...common.util import sha256_obj
from ..engines.core import ARTIFACT_OUTCOMES, Produced, feed_of, local_date, producer_class_of
from ..history.realized import Cut
from .cache_protocol import warm_inputs
from .semconfig_policy import BOUNDS, FixedBoundsOtp


class RealSlotProducer:
    BINARY_MODE = "REAL_PINNED_BINARY"

    def __init__(self, region, cs, ctxf, val, otp, osm_path: Path, jars: list[str], c, executor=None) -> None:
        self.r, self.cs, self.ctx = region, cs, ctxf
        self.val, self.otp = val, (otp if isinstance(otp, FixedBoundsOtp) else FixedBoundsOtp(otp))
        self.osm, self.jars, self.c = Path(osm_path), jars, c
        self.executor = executor
        self.warm_reads = 0

    # ----------------------------------------------------------------------------------- cache protocol
    def corpus(self, tick_utc: str) -> list[str]:
        """COMPLETE common immutable input corpus of the request: every GTFS archive of the region available at t,
        the region OSM file, the pinned producer jars — deterministic order, identical for every method."""
        zips = sorted({str(self.r.blobs.path_of(v.raw_zip_sha256)) for v in self.r.versions.values()
                       if v.available_utc <= tick_utc})
        return zips + [str(self.osm)] + sorted(self.jars)

    def warm(self, tick_utc: str) -> None:
        self.warm_reads += warm_inputs(self.corpus(tick_utc))       # unmeasured; not scientific producer cost

    # ----------------------------------------------------------------------------------- produce
    def produce(self, slot_id: str, cut: Cut, tick_utc: str) -> Produced:
        if self.executor is not None and self.executor.shared_phase:
            got = self.executor.take(slot_id, cut, tick_utc)
            if got is not None:
                return got
        return self.execute(slot_id, cut, tick_utc)

    def execute(self, slot_id: str, cut: Cut, invoke_utc: str) -> Produced:
        from ..producers.otp import OtpFeedInput, OtpRequest
        from ..producers.validator import ValidatorRequest
        ctx = self.ctx.context_for(cut, invoke_utc)
        pc = producer_class_of(slot_id)
        self.warm(invoke_utc)
        if pc == "validator":
            f = feed_of(slot_id) or ""
            ref = ctx.feeds[f]
            v = self.r.versions[(f, cut.index(f))]
            o = self.val.produce(ValidatorRequest(slot_id, self.r.region_id, f, ref["logical_version_id"],
                                                  ref["canonical_content_sha256"], str(self.r.blobs.path_of(v.raw_zip_sha256)),
                                                  str(ctx.consumer_date), ctx.country, cut.cut_id, self.r.namespace))
            wall, cpu = float(o.provenance.get("wall_s", 0.0)), float(o.provenance.get("cpu_s", 0.0))
            if o.failure_class not in ARTIFACT_OUTCOMES or not o.val_report:
                return Produced(o.failure_class, None, (), wall, cpu, sha256_obj(o.provenance), {})
            rd = o.val_report["report_digest"]
            aid = "VAL:" + sha256_obj([rd, cut.cut_id, str(ctx.consumer_date)])[:24]
            art = {"artifact_class": "VAL_REPORT", "feed_id": f, "report_digest": rd, "request_slot": slot_id,
                   "birth_cut_id": cut.cut_id, "artifact_id": aid}
            cons = tuple(self.cs.generate_val(art, ctx, lv) for lv in ("K0", "K1", "K2", "K3"))
            kw = dict(producer_type="gtfs-validator", artifact_class="VAL_REPORT",
                      logical_inputs=[(f, ref["logical_version_id"], ref["canonical_content_sha256"])],
                      output_digests=[("report", rd)])
        else:
            feeds = sorted(ctx.feeds)
            ins = tuple(OtpFeedInput(f, ctx.feeds[f]["logical_version_id"], ctx.feeds[f]["canonical_content_sha256"],
                                     str(self.r.blobs.path_of(self.r.versions[(f, cut.index(f))].raw_zip_sha256)))
                        for f in feeds)
            o = self.otp.produce(OtpRequest(slot_id, self.r.region_id, ins, str(self.osm), self.r.tz,
                                            str(ctx.consumer_date), tuple(ctx.horizon), cut.cut_id, self.r.namespace,
                                            BOUNDS[0], BOUNDS[1]))
            wall, cpu = float(o.provenance.get("wall_s", 0.0)), float(o.provenance.get("cpu_s", 0.0))
            if o.failure_class not in ARTIFACT_OUTCOMES or not o.router:
                return Produced(o.failure_class, None, (), wall, cpu, sha256_obj(o.provenance), {})
            if o.semantic_config_digest != self.r.semantic_config_digest:
                raise RuntimeError("OTP semantic-config digest differs from the frozen campaign digest")
            rt = o.router
            aid = "ROUTER:" + sha256_obj([slot_id, cut.cut_id, rt["canon_digest"], invoke_utc])[:24]
            art = {"artifact_id": aid, "request_slot": slot_id, "birth_cut_id": cut.cut_id,
                   "gtfs_logical_versions": {f: ctx.feeds[f]["logical_version_id"] for f in feeds},
                   "service_window": list(rt["service_window"]), "canon_digest": rt["canon_digest"],
                   "graph_sha256": rt["graph_sha256"], "horizon_D": list(ctx.horizon)}
            cons = tuple(self.cs.generate_router(art, ctx, lv) for lv in ("K0", "K1", "K2", "K3"))
            kw = dict(producer_type="otp", artifact_class="ROUTER",
                      logical_inputs=[(f, ctx.feeds[f]["logical_version_id"], ctx.feeds[f]["canonical_content_sha256"])
                                      for f in feeds],
                      output_digests=[("canon", rt["canon_digest"]), ("graph", rt["graph_sha256"])])
        return Produced(o.failure_class, aid, cons, wall, cpu, sha256_obj(o.provenance),
                        {**kw, "birth_frontier": tuple(cut.frontier), "contract_ids": [x.contract_id for x in cons],
                         "binary_mode": self.BINARY_MODE})


class ScheduledExecutor:
    """REAL duration backend for the frozen scheduler (wants_start_time protocol)."""
    mode = "REAL_MEASURED_BACKEND"
    wants_start_time = True

    def __init__(self, producer: RealSlotProducer, region) -> None:
        self.p, self.r = producer, region
        self.latest: dict[str, int] = {}
        self.results: dict = {}                      # job key -> (Produced, slot, cut, invoke_utc)
        self.pending: dict = {}                      # (slot, cut_id) -> list[Produced] (shared births, in order)
        self.shared_phase = False
        self._start: dict = {}

    def note_start(self, kind: str, key: str, t: str) -> None:
        self._start[(kind, key)] = t

    def _run(self, kind: str, key: str):
        if (kind, key) in self.results:
            return self.results[(kind, key)]
        t = self._start[(kind, key)]
        if kind == "validator":
            _, f, i = key.split("|")
            slot, cut = f"VAL:feed={f}", Cut.of(self.r.region_id, {f: int(i)})
        else:
            inputs = dict(x.split(":") for x in key.split("|", 1)[1].split(","))
            slot = f"ROUTER:region={self.r.region_id}"
            cut = Cut.of(self.r.region_id, {f: int(i) for f, i in inputs.items()})
        prod = self.p.execute(slot, cut, t)
        self.results[(kind, key)] = (prod, slot, cut, t)
        self.pending.setdefault((slot, cut.cut_id), []).append(prod)
        return self.results[(kind, key)]

    def duration(self, kind: str, key: str) -> int:
        return int(round(self._run(kind, key)[0].wall_s))

    def outcome(self, kind: str, key: str) -> str:
        return self._run(kind, key)[0].outcome

    def take(self, slot_id: str, cut: Cut, born_utc: str):
        q = self.pending.get((slot_id, cut.cut_id))
        return q.pop(0) if q else None


def real_k3_reference(c, region, camp, otp, val, arms=None):
    """K3 reference for N4 safety classification (offline, after the decisions)."""
    jars = sorted(str(p) for p in (Path(__file__).resolve().parents[4] / ".deps").glob("*.jar"))
    pins = {p["region_id"]: p for p in json.loads((c.runtime / "OSM_PINS.json").read_text())["pins"]}
    prod = RealSlotProducer(region, camp.cs, camp.contexts, val, otp, c.work_root / pins[region.region_id]["region_path"],
                            jars, c)

    def ref(d, slot, aid):
        e = None
        for cat in [camp.shared] + [a.mc.overlay for a in getattr(camp, "_arms", [])] + \
                [a.mc.overlay for a in (arms or {}).values()]:
            try:
                e = cat.get(aid)
                break
            except Exception:   # noqa: BLE001
                continue
        if e is None:
            return None                                       # provenance unavailable -> UNCLASSIFIABLE
        cut = d.request.current_cut if slot.startswith("ROUTER:") else \
            Cut.of(region.region_id, {feed_of(slot): d.request.current_cut.index(feed_of(slot) or "")})
        try:
            p = prod.execute(slot, cut, d.request.tick_utc)
        except Exception:   # noqa: BLE001
            return None
        if p.outcome not in ARTIFACT_OUTCOMES:
            return None
        key = "report" if slot.startswith("VAL:") else "canon"
        return dict(p.entry_kw["output_digests"]).get(key) == dict(e.output_digests).get(key)
    return ref


def real_mutations(c, region, camp, out: Path, producers) -> list[dict]:
    """Frozen mutation protocol on this region's shared artifacts with the REAL reference paths: CanonReference (pinned
    OTP + Canon_D under D, campaign service bounds) for ROUTER and ValidatorReference (pinned gtfs-validator) for VAL.
    Subjects / sampling exactly as the frozen campaign mutation builder (s3_phases._mutations)."""
    from ..campaign.s3_phases import _mutations
    from ..engines.mutation import CanonReference, ValidatorReference
    _spec, _deps, _blobs, otp, val, _canon = producers
    pins = {p["region_id"]: p for p in json.loads((c.runtime / "OSM_PINS.json").read_text())["pins"]}
    osm = str(c.work_root / pins[region.region_id]["region_path"])
    work = c.work_root / "work" / "mutation_ref" / out.name
    canon_ref = CanonReference(FixedBoundsOtp(otp), osm, region.tz, "2025-04-01", work)
    vref = ValidatorReference(val, work, region.country)

    class _Ctx:
        namespace = region.namespace
    _plans, results = _mutations(_Ctx(), {region.region_id: camp}, canon_ref=canon_ref, val_ref=vref)
    return [dict(r, integrity="OK") for r in results]


def drop_caches() -> None:
    subprocess.run(["sync"], check=True)
    with open("/proc/sys/vm/drop_caches", "w") as f:
        f.write("3\n")


def _cut_index(region) -> dict:
    from itertools import product
    feeds = sorted(region.feeds)
    choices = [[0] + sorted(i for (f, i) in region.versions if f == ff) for ff in feeds]
    out = {}
    for combo in product(*choices):
        cut = Cut.of(region.region_id, dict(zip(feeds, combo, strict=True)))
        out[cut.cut_id] = cut
        for f, i in zip(feeds, combo, strict=True):          # single-feed (VAL) cuts
            sc = Cut.of(region.region_id, {f: i})
            out[sc.cut_id] = sc
    return out


_ = local_date
