"""One-shot execution wiring (engineering only; no scientific rule is decided here).

* OneShotS4Runner — the frozen S4BaselineRunner (AMENDMENT-S4A-BASELINES-01/01A) decomposed per request and per arm
  (prepare / tick_context / step; the step body is the frozen run() body verbatim) so that arms of several runners can
  be interleaved. An equivalence test proves identical decisions to the frozen run().
* NativeSlotProducer — REAL ROUTER re-derivation for N2/N3/N4(τ)/N6 through the frozen N1 mechanism
  (RealNativeOtpBuilder: per-arm persisted street graph, `--loadStreet --save`, `cache.enabled`, N1 OTP envelope, fixed
  campaign service bounds); true measured wall/CPU; Canon_D extracted from the native graph as the generic producer does
  (evaluation metadata, not charged); the router artifact gets the normal frozen K0 identity and native provenance.
  Per-arm state: every arm owns its builder root (street graph + cache) — no cross-method native-state influence.
  Preprocessing (V1.2 freeze §4 A + G): the arm's one-time street-graph build is measured and charged ONCE per region to
  that arm (first decision of the arm), never divided, never free.
* WarmingNativeBuilder — RealNativeOtpBuilder that performs the approved unmeasured warm step (complete common immutable
  request corpus) immediately before every measured native execution (street build and rebuilds), N1 included.
* run_interleaved — per consumer request, every compared arm (F1, N5, N1 from the Session-3 campaign; N0, N2, N3, N4(τ),
  N6 from the Session-4 runner) executes in the frozen deterministic rotation cache_protocol.arm_order(arms, ordinal).
* cold_pass_mechanism — secondary COLD replay with the SAME mechanism as the primary step (generic producer for F1/N5/N0
  and VAL; native builder for N1/N2/N3/N4/N6 ROUTER), per-arm fresh cold native state evolving in the primary order,
  page cache dropped before each measured cold execution.
"""
from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from typing import Any

from ..engines.baselines_n import RealNativeOtpBuilder
from ..engines.baselines_s4 import (BaselineDecision, BaselineProducers, BaselineView, OwnArtifact, S4Baseline,
                                    S4BaselineRunner, _Arm)
from ..engines.core import (ARTIFACT_OUTCOMES, CurrentCutEvaluatorImpl, MethodCatalog, Produced, ProducerRederiver,
                            TimedEvaluator, feed_of, now_wall)
from ..catalog.artifacts import ArtifactCatalog
from ..history.realized import Cut
from ..interfaces import session3 as S
from .cache_protocol import arm_order

NATIVE_MECHANISM = "N1_NATIVE_CONFIG"


class SyntheticNativeDurationRefused(RuntimeError):
    pass


# ============================================================================================ native mechanism
class WarmingNativeBuilder(RealNativeOtpBuilder):
    """RealNativeOtpBuilder + the approved unmeasured warm step before every measured native execution."""
    def __init__(self, otp_producer, root: Path, envelope_digest: str, warm=None) -> None:
        super().__init__(otp_producer, root, envelope_digest)
        self.warm = warm                       # callable(tick_utc) -> None (unmeasured)
        self.current_tick: str | None = None
        self.warm_calls: list[tuple[str, str | None]] = []

    def _warm(self, what: str) -> None:
        if self.warm is not None:
            self.warm_calls.append((what, self.current_tick))
            self.warm(self.current_tick)

    def initial_state(self, region_id: str, envelope_digest: str | None = None):
        self._warm("street_build")
        return super().initial_state(region_id, envelope_digest)

    def build(self, view):
        self.current_tick = view.request.tick_utc
        self._warm("native_rebuild")
        return super().build(view)


class NativeSlotProducer:
    """Session-3 producer contract over the N1-native builder, for ROUTER slots of N2/N3/N4(τ)/N6 (REAL)."""
    BINARY_MODE = "REAL_PINNED_BINARY"

    def __init__(self, region, cs, ctxf, builder: RealNativeOtpBuilder, canon_fn, real: bool = True) -> None:
        self.r, self.cs, self.ctx, self.b, self.canon_fn, self.real = region, cs, ctxf, builder, canon_fn, real
        self.state: Any = None
        self.pending_preprocessing: dict | None = None
        self.calls = 0

    def ensure_state(self, tick_utc: str) -> None:
        if self.state is None:
            if isinstance(self.b, WarmingNativeBuilder):
                self.b.current_tick = tick_utc
            self.state = self.b.initial_state(self.r.region_id)
            self.pending_preprocessing = dict(self.b.preprocessing[self.r.region_id])

    def produce(self, slot_id: str, cut: Cut, tick_utc: str) -> Produced:
        if not slot_id.startswith("ROUTER:"):
            raise RuntimeError("native producer is ROUTER-only")
        self.ensure_state(tick_utc)
        self.calls += 1
        ctx = self.ctx.context_for(cut, tick_utc)
        feeds = sorted(ctx.feeds)
        req = S.ConsumerRequest(self.r.region_id, S.canonical_request_slots(self.r.region_id, list(self.r.feeds)),
                                tick_utc, cut, ctx)

        v = SimpleNamespace(              # exactly the attributes RealNativeOtpBuilder.build reads
            native_state=self.state, request=req, estimates=((slot_id, 0.0),),
            current_router_inputs=tuple((f, ctx.feeds[f]["logical_version_id"],
                                         ctx.feeds[f]["canonical_content_sha256"]) for f in feeds))
        step, new_state, _evidence = self.b.build(v)  # type: ignore[arg-type]
        wall = step.measured_wall_s
        cpu = self.b.last_cpu_s
        if self.real and (wall is None or cpu is None or float(wall) <= 0.0):
            raise SyntheticNativeDurationRefused("REAL N1-native rebuild without a measured process duration")
        wall, cpu = float(wall or 0.0), float(cpu or 0.0)
        if step.outcome not in ARTIFACT_OUTCOMES or step.new_artifact_id is None:
            return Produced(step.outcome or "INFRA_ERROR", None, (), wall, cpu, step.provenance_digest, {})
        self.state = new_state
        job = Path(self.b.last_evidence["job"])
        canon = self.canon_fn(job / "graph.obj", list(ctx.horizon), self.r.semantic_config_digest, ctx.osm_sha256)
        if canon is None:                                     # Canon_D failure: no artifact (as the generic producer)
            return Produced("INFRA_ERROR", None, (), wall, cpu, step.provenance_digest, {})
        from .semconfig_policy import BOUNDS
        gsha = new_state.last_success_graph_sha256 or step.new_artifact_id
        aid = "ROUTER:" + _h([slot_id, cut.cut_id, canon, tick_utc, NATIVE_MECHANISM])[:24]
        art = {"artifact_id": aid, "request_slot": slot_id, "birth_cut_id": cut.cut_id,
               "gtfs_logical_versions": {f: ctx.feeds[f]["logical_version_id"] for f in feeds},
               "service_window": list(BOUNDS), "canon_digest": canon, "graph_sha256": str(gsha), "horizon_D": list(ctx.horizon)}
        cons = tuple(self.cs.generate_router(art, ctx, lv) for lv in ("K0", "K1", "K2", "K3"))
        kw = dict(producer_type="otp", artifact_class="ROUTER",
                  logical_inputs=[(f, ctx.feeds[f]["logical_version_id"], ctx.feeds[f]["canonical_content_sha256"])
                                  for f in feeds],
                  output_digests=[("canon", canon), ("graph", str(gsha)), ("mechanism", NATIVE_MECHANISM)],
                  birth_frontier=tuple(cut.frontier), contract_ids=[c.contract_id for c in cons],
                  binary_mode=self.BINARY_MODE if self.real else "FIXTURE_STUB_BINARY")
        return Produced("SUCCESS", aid, cons, wall, cpu, step.provenance_digest, kw)


def _h(x) -> str:
    from ...common.util import sha256_obj
    return sha256_obj(x)


# ============================================================================================ S4 runner per request
class OneShotS4Runner(S4BaselineRunner):
    """Frozen S4BaselineRunner, decomposed per request/arm. `native_factory(method, tau, mc)` -> NativeSlotProducer
    (REAL); None keeps the frozen FIXTURE NativeRouterRederiver."""
    def __init__(self, campaign, producer_factory, native_factory=None, native_wall_s: float = 1800.0) -> None:
        super().__init__(campaign, producer_factory, native_wall_s)
        self.native_factory = native_factory

    def _arm(self, method: str, tau_h: int | None) -> _Arm:
        if self.native_factory is None:
            return super()._arm(method, tau_h)
        mc = MethodCatalog(self.c.shared, self.c.shared_born, ArtifactCatalog(None), {}, dict(self.c.contracts))
        vc = ProducerRederiver(self.c.r, mc, self.pf())
        nat = ProducerRederiver(self.c.r, mc, self.native_factory(method, tau_h, mc))
        nat._elapsed = vc._elapsed          # ONE serial clock per request (frozen)
        return _Arm(method, tau_h, mc, vc, nat)  # type: ignore[arg-type]

    def prepare(self, methods: list[tuple[str, int | None]]) -> list[_Arm]:
        self.arms = [self._arm(m, tau) for m, tau in methods]
        return self.arms

    def tick_context(self, t: str) -> dict:
        from ..engines.core import estimates_for, prior_view
        cut = self.c.r.current_cut(t)
        ctx = self.c.contexts.context_for(cut, t)
        req = S.ConsumerRequest(self.c.r.region_id, S.canonical_request_slots(self.c.r.region_id, list(self.c.r.feeds)),
                                t, cut, ctx)
        est = estimates_for(req, self.c.cost, prior_view(self.c.r.region_id, t, tuple(self.c.shared_runs)))
        return {"t": t, "cut": cut, "ctx": ctx, "req": req, "est": est}

    def step(self, arm: _Arm, tc: dict) -> BaselineDecision:   # noqa: C901 — frozen run() body, verbatim
        t, cut, ctx, req, est = tc["t"], tc["cut"], tc["ctx"], tc["req"], tc["est"]
        extra: list = []

        def charge(component: str, t0: float, _x: list = extra) -> None:
            dt = now_wall() - t0
            _x.append(S.CostItem(S.CostCategory.B_CONTROL_PLANE, component, dt, dt))
        m = arm.method
        if isinstance(arm.nat.p, NativeSlotProducer):          # per-arm native state initialised at the first request
            arm.nat.p.ensure_state(t)
        t0 = now_wall()
        got = {s: (None if m == "N0" or (m == "N6" and s.startswith("VAL:")) else arm.mc.bind(s, t))
               for s in req.request_slots}
        k0s = {}
        if m in ("N2", "N6"):
            for s, g in got.items():
                if g is not None:
                    self.calls["k0"] += 1
                    k0s[s] = tuple(c for c in arm.mc.contracts.get(g[0].artifact_id, ()) if c.level == "K0")
        charge("catalog_lookup", t0)
        cur_pins: tuple = ()
        n6_keys: tuple = ()
        n6_hits: tuple = ()
        pins: dict = {}
        if m == "N3":
            t0 = now_wall()
            for g in got.values():
                if g is not None:
                    self._n3_entry(arm, g[0])
            charge("n3_pin_index_update", t0)
            t0 = now_wall()
            for s, g in got.items():
                if g is not None:
                    pins[s] = arm.n3_index[g[0].artifact_id]
            cur_pins = tuple((s, self.current_pin(s, ctx)) for s in req.request_slots)
            charge("n3_pin_index_lookup", t0)
        if m == "N6":
            t0 = now_wall()
            self._n6_update(arm, t)
            charge("n6_cache_index_update", t0)
            t0 = now_wall()
            n6_keys = tuple((s, (feed_of(s), self.lv_event[(feed_of(s), cut.index(feed_of(s) or ""))],
                                 ctx.feeds[feed_of(s) or ""]["canonical_content_sha256"], ctx.country,
                                 ctx.validator_sha256)) for s in req.request_slots if s.startswith("VAL:"))
            n6_hits = tuple((s, tuple(arm.n6_index.get(k, ()))) for s, k in n6_keys)
            charge("n6_cache_index_lookup", t0)
        bound: list[tuple[str, OwnArtifact | None]] = []
        for s in req.request_slots:
            g = got[s]
            if g is None:
                bound.append((s, None))
                continue
            e, born = g
            if m == "N3":
                pin, iv = pins[s]
                bound.append((s, OwnArtifact(s, e.artifact_id, born, pin=pin, pin_interval=iv)))
            elif m in ("N2", "N6"):
                bound.append((s, OwnArtifact(s, e.artifact_id, born, k0_contracts=k0s[s])))
            else:
                bound.append((s, OwnArtifact(s, e.artifact_id, born)))
        view = BaselineView(m, req, tuple(bound), self._versions(cut), cur_pins, n6_keys, n6_hits, est, arm.tau_h)
        ev = CurrentCutEvaluatorImpl(TimedEvaluator(self.c.cs), req.context)
        j0 = sum(arm.vc.journal_s.values()) + sum(arm.nat.journal_s.values())
        d = S4Baseline().decide(view, ev, BaselineProducers(arm.vc, arm.nat, cut, t))   # type: ignore[arg-type]
        js = sum(arm.vc.journal_s.values()) + sum(arm.nat.journal_s.values()) - j0
        if js:
            extra.append(S.CostItem(S.CostCategory.B_CONTROL_PLANE, "journal_fsync", js, js))
        new_ids = [s.artifact_id for s in d.slots if s.action == "REDERIVE"]
        if m == "N3" and new_ids:
            t0 = now_wall()
            for slot in [s.slot_id for s in d.slots if s.action == "REDERIVE"]:
                for e in arm.mc.overlay.instances(slot):
                    if e.artifact_id in new_ids:
                        self._n3_entry(arm, e)
            charge("n3_pin_index_update", t0)
        if m == "N6" and new_ids:
            t0 = now_wall()
            self._n6_update(arm, t, own_only=True)
            charge("n6_cache_index_update", t0)
        if isinstance(arm.nat.p, NativeSlotProducer) and arm.nat.p.pending_preprocessing:
            pp = arm.nat.p.pending_preprocessing                 # V1.2 §4 A+G: once per region, to this arm
            extra.append(S.CostItem(S.CostCategory.A_PRODUCER, "n1_native_preprocessing", float(pp["wall_s"]),
                                    float(pp["cpu_s"]), "PREPROC:" + pp["identity"]))
            arm.nat.p.pending_preprocessing = None
        d = BaselineDecision(d.method, d.tau_h, d.request, d.slots, d.joint_action,
                             S.CostRecord(tuple(extra[:]) + tuple(d.costs.items)), d.reuse_events)
        arm.decisions.append(d)
        return d


# ============================================================================================ interleaving
def arm_label(kind: str, arm) -> str:
    return f"{arm.method}:{arm.level}" if kind == "S3" else f"{arm.method}" + (f"@{arm.tau_h}" if arm.tau_h else "")


def run_interleaved(camp, s4: OneShotS4Runner, methods: list, ticks: list[str], order_log: Path | None = None,
                    before_arm=None) -> dict:
    """Per request: every arm (Session-3 F1/N5/N1 and Session-4 N0/N2/N3/N4(τ)/N6) in the frozen deterministic rotation
    arm_order(all_arms, request_ordinal). Returns the S4 arms by (method, τ)."""
    s3_arms = camp.prepare(ticks)
    s4_arms = s4.prepare(methods)
    allarms = [("S3", a) for a in s3_arms] + [("S4", a) for a in s4_arms]
    fh = open(order_log, "w") if order_log else None
    try:
        for k, t in enumerate(sorted(ticks)):
            tc3, tc4 = camp.tick_context(t), s4.tick_context(t)
            order = arm_order(allarms, k)
            if fh:
                fh.write(json.dumps({"ordinal": k, "tick_utc": t, "order": [arm_label(x, a) for x, a in order]}) + "\n")
            for kind, a in order:
                if before_arm:
                    before_arm(kind, a, t)
                if kind == "S3":
                    camp.step(a, tc3)
                else:
                    s4.step(a, tc4)
    finally:
        if fh:
            fh.close()
    return {(a.method, a.tau_h): a for a in s4_arms}


# ============================================================================================ cold pass
def cold_pass_mechanism(region, camp, arms: dict, out: Path, generic, native_factory, drop) -> Path:
    """Re-run every recorded on-demand producer execution with the SAME mechanism as the primary step, after dropping
    the page cache. Native steps replay per arm, in primary order, on a FRESH cold native state of that arm (so the
    method-specific native-state evolution is reproduced). `generic` has execute(slot, cut, t); `native_factory(label)`
    returns a fresh NativeSlotProducer-like object with produce(slot, cut, t)."""
    from .real_producer import _cut_index
    cuts = _cut_index(region)
    plan: list[tuple[str, str, str, str, str, str]] = []           # (arm, mechanism, request_id, tick, slot, cut_id)
    for a in getattr(camp, "_arms", []):
        for d in a.decisions:
            if a.method == "N1":
                for st in d.repair.steps if d.repair else ():
                    if st.outcome is not None:
                        mech = "native" if st.slot_id.startswith("ROUTER:") else "generic"
                        plan.append((f"N1:{a.level}", mech, d.request.request_id, d.request.tick_utc, st.slot_id,
                                     st.target_cut_id))
                continue
            for st in d.repair.steps if d.repair else ():
                if st.outcome is not None:
                    plan.append((f"{a.method}:{a.level}", "generic", d.request.request_id, d.request.tick_utc,
                                 st.slot_id, st.target_cut_id))
    for (m, tau), arm in sorted(arms.items(), key=lambda kv: (kv[0][0], kv[0][1] or 0)):
        lab = m + (f"@{tau}" if tau else "")
        for d in arm.decisions:
            for sd in d.slots:
                if sd.step is not None and sd.step.outcome is not None:
                    native = sd.slot_id.startswith("ROUTER:") and m in ("N2", "N3", "N4", "N6")
                    plan.append((lab, "native" if native else "generic", d.request.request_id, d.request.tick_utc,
                                 sd.slot_id, sd.step.target_cut_id))
    natives: dict = {}
    rows = []
    for lab, mech, rid, t, slot, cut_id in plan:
        drop()
        if mech == "native":
            if lab not in natives:
                natives[lab] = native_factory(lab)
            p = natives[lab].produce(slot, cuts[cut_id], t)
        else:
            p = generic.execute(slot, cuts[cut_id], t)
        rows.append({"arm": lab, "mechanism": mech, "request_id": rid, "slot_id": slot, "cut_id": cut_id,
                     "cold_wall_s": p.wall_s, "cold_cpu_s": p.cpu_s, "outcome": p.outcome,
                     "marker": dict(p.entry_kw.get("output_digests", [])).get("mechanism", "GENERIC")})
    path = out / "COLD_SECONDARY_TIMINGS.jsonl"
    path.write_text("".join(json.dumps(x, sort_keys=True) + "\n" for x in rows))
    return path
