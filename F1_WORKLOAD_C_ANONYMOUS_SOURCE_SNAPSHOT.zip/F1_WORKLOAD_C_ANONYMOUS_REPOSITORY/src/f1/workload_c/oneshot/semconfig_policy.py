"""AMENDMENT-ONESHOT-ROUTER-SEMCONFIG-01 — FIXED_CAMPAIGN_ABSOLUTE_SERVICE_BOUNDS (pre-data PI decision).

One immutable pair of absolute OTP service bounds for the whole campaign, resolved ONCE with the frozen cfgproj period
convention: transitServiceStart = study start date − P1Y; transitServiceEnd = (study end exclusive − 1 day) + P3Y.
The study window is defined in calendar dates (2025-04-01 .. 2026-06-30 inclusive), so the local calendar dates are
the same in every agency timezone. Every OTP ROUTER build in the campaign (shared scheduled production, F1, N0, N1,
N2, N3, N4, N5, N6, K3/reference, mutation/reference, warm and cold passes) receives exactly these explicit dates; OTP
relative defaults are never resolved per build. K2's service-window condition still decides coverage of D."""
from __future__ import annotations

import dataclasses
from datetime import date, timedelta

from ..producers.semconfig import _module, semantic_config_digest

POLICY = "FIXED_CAMPAIGN_ABSOLUTE_SERVICE_BOUNDS"
STUDY_START = date(2025, 4, 1)
STUDY_END_EXCLUSIVE = date(2026, 7, 1)


class RelativeBoundsRefused(RuntimeError):
    pass


def campaign_service_bounds() -> tuple[str, str]:
    mod = _module()
    start = mod.period("-P1Y", STUDY_START)
    end = mod.period("P3Y", STUDY_END_EXCLUSIVE - timedelta(days=1))
    return start, end


BOUNDS = campaign_service_bounds()


def fixed(req):
    """Return the OtpRequest with the campaign bounds; refuse any request carrying OTHER explicit bounds."""
    for got, want in ((req.service_start, BOUNDS[0]), (req.service_end, BOUNDS[1])):
        if got is not None and got != want:
            raise RelativeBoundsRefused(f"OTP request carries non-campaign service bound {got}")
    return dataclasses.replace(req, service_start=BOUNDS[0], service_end=BOUNDS[1])


class FixedBoundsOtp:
    """Wrapper used for EVERY OTP ROUTER build of the campaign; produce() never reaches OTP with relative defaults."""
    def __init__(self, otp) -> None:
        self._otp = otp
        self.calls = 0

    def produce(self, req):
        r = fixed(req)
        if r.service_start is None or r.service_end is None:
            raise RelativeBoundsRefused("relative OTP service defaults are forbidden in the campaign")
        self.calls += 1
        return self._otp.produce(r)

    def __getattr__(self, k):
        return getattr(self._otp, k)


def region_semantic_digest(feed_ids: list[str], tz: str) -> str:
    """Semantic-config digest of the frozen F1 graph configuration with the campaign bounds (feed sources and OSM path
    are operational, not semantic). The build date argument cannot influence absolute bounds."""
    cfg = {"transitServiceStart": BOUNDS[0], "transitServiceEnd": BOUNDS[1], "transitModelTimeZone": tz,
           "transitFeeds": [{"type": "gtfs", "feedId": f, "source": f"feed{i:02d}.gtfs.zip"}
                            for i, f in enumerate(sorted(feed_ids))], "osm": [{"source": "street.osm.pbf"}]}
    return semantic_config_digest(cfg, STUDY_START)
