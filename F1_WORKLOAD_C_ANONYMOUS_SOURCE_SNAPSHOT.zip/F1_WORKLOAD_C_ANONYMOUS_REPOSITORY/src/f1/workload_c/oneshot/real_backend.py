"""REAL backend: authoritative target server. Everything here is executed only by the researcher on the target server.

- L28: the frozen authoritative L28 runner (s2.run_l28, sandbox=False); only EXECUTED_ON_TARGET + PASS continues.
- Mobility Database: the frozen S1 MobilityClient over UrllibTransport; the token is read from --mobility-token-file at
  runtime only (never logged / persisted / packaged; REDACTOR registered).
- OSM: the V3 rule (osm_v3.py; provenance docs/oneshot/provenance/V3_05_OSM_OSMIUM_PIN_MANIFEST.md).
- Producers: pinned gtfs-validator 8.0.1 and OTP 2.10.0 (+ Canon_D 1.3) under the frozen authoritative envelopes;
  N1 / N2 / N3 / N4 / N6 router re-derivations use the N1-native builder; N0 / F1 / N5 the frozen two-step producer.
- Cache state: PHYSICAL_CACHE_STATE_PROTOCOL — before every measured producer execution the COMPLETE common immutable
  input corpus of the request (all region GTFS archives available at t, the region OSM file, the pinned jars) is read
  in deterministic order (unmeasured); cold secondary requires drop_caches capability (else SAFE STOP).
- K3 references: ValidatorReference / CanonReference semantics (re-run validator at the request context; rebuild +
  Canon_D under the current D) — never a canonical hash or an expectation table.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import resource
import shutil
import subprocess
from pathlib import Path
from typing import Any

from ...common.util import sha256_obj
from ..config.runtime import load_effective_config
from ..paths import CONFIG_DIR, REPO_ROOT
from ..security.secrets import REDACTOR, Secret, SecretProvider

CAMPAIGN_CFG = CONFIG_DIR / "oneshot_campaign.json"
OSMIUM = os.environ.get("F1_WC_OSMIUM", "osmium")


def _bounds():
    from .semconfig_policy import BOUNDS
    return BOUNDS


class FileSecretProvider(SecretProvider):
    """Reads MOBILITY_DB_TOKEN from a file at runtime (0600 recommended); the value is registered for redaction."""
    def __init__(self, path: str | None) -> None:
        self.path = path

    def get(self, name: str, required: bool = True):
        if name != "MOBILITY_DB_TOKEN" or self.path is None or not Path(self.path).exists():
            if required:
                from ..errors import MissingSecretError
                raise MissingSecretError(f"secret {name} unavailable")
            return None
        v = Path(str(self.path)).read_text().strip()
        REDACTOR.register(v)
        return Secret(name, v)


def campaign_config() -> dict:
    return json.loads(CAMPAIGN_CFG.read_text())


def _run(cmd: list[str]) -> str:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=60).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return ""


class RealTransportRefused(RuntimeError):
    """The real Mobility Database transport is dormant unless every runtime condition holds."""


class RealBackend:
    binary_mode = "REAL_PINNED_BINARY"
    namespace_validation = "VALIDATION"
    namespace_test = "TEST"
    accepted_l28_states = ("EXECUTED_ON_TARGET",)
    results_package_name = "F1_WORKLOAD_C_REAL_CAMPAIGN_RESULTS_FINAL.zip"
    native_wall_s = None                      # REAL: never a synthetic native duration (measured N1-native builds)

    def __init__(self, token_file: str | None, real_campaign: bool = False) -> None:
        self.token_file = token_file
        self.real_campaign = real_campaign       # True ONLY for `--backend real` with --new-campaign / --resume (cli)
        self.cfg = load_effective_config(CONFIG_DIR / "real.yaml")
        self.ccfg = campaign_config()
        self.window = tuple(self.ccfg["analysis_window_utc"])
        self._producers = None
        self._last_session: dict[str, Any] = {}

    # ---------------------------------------------------------------------------------------------- S00
    def secret_present(self) -> bool:
        return self.token_file is not None and Path(self.token_file).is_file()

    def server_identity(self, c) -> dict:
        du = shutil.disk_usage(c.work_root)
        mem = {ln.split(":")[0]: ln.split(":")[1].strip() for ln in Path("/proc/meminfo").read_text().splitlines()} \
            if Path("/proc/meminfo").exists() else {}
        cpu = [ln.split(":", 1)[1].strip() for ln in Path("/proc/cpuinfo").read_text().splitlines()
               if ln.startswith("model name")] if Path("/proc/cpuinfo").exists() else []
        import numpy
        lim = {n: resource.getrlimit(getattr(resource, n)) for n in ("RLIMIT_NOFILE", "RLIMIT_NPROC", "RLIMIT_AS")
               if hasattr(resource, n)}
        return {"hostname": platform.node(), "os": platform.platform(), "kernel": platform.release(),
                "architecture": platform.machine(), "cpu_model": cpu[0] if cpu else None,
                "logical_cpus": os.cpu_count(), "physical_cores_hint": len(set(cpu)) if cpu else None,
                "mem_total": mem.get("MemTotal"), "mem_available": mem.get("MemAvailable"),
                "java": _run(["java", "-version"]) or _run(["bash", "-lc", "java -version 2>&1"]),
                "python": platform.python_version(), "numpy": numpy.__version__,
                "cgroup": "v2" if Path("/sys/fs/cgroup/cgroup.controllers").exists() else "v1/none",
                "systemd": _run(["systemctl", "--version"]).split("\n")[0] or None,
                "filesystem": _run(["df", "-T", str(c.work_root)]), "disk_free_bytes": du.free,
                "user": os.environ.get("USER") or str(os.geteuid()), "euid": os.geteuid(),
                "ulimits": {k: list(v) for k, v in lim.items()}, "timezone": _run(["date", "+%Z %z"]),
                "ntp": _run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"]) or None,
                "dependency_hashes": self._jar_hashes()}

    def _jar_hashes(self) -> dict:
        out = {}
        for p in sorted((REPO_ROOT / ".deps").glob("*.jar")):
            out[p.name] = hashlib.sha256(p.read_bytes()).hexdigest()
        return out

    def dependencies(self, c) -> dict:
        from ..deps.pins import BinaryMode, resolve
        import numpy
        import yaml
        problems = []
        try:
            resolve(BinaryMode.REAL_PINNED_BINARY)
        except Exception as e:   # noqa: BLE001
            problems.append(f"pinned producer binaries: {type(e).__name__}: {e}")
        if numpy.__version__ != "2.4.4":
            problems.append(f"numpy {numpy.__version__} != 2.4.4")
        if getattr(yaml, "__version__", "") != "6.0.3":
            problems.append(f"PyYAML {getattr(yaml, '__version__', '?')} != 6.0.3")
        if not _run([OSMIUM, "--version"]).startswith("osmium version 1.16.0"):
            problems.append("osmium-tool 1.16.0 not found")
        from .semconfig_policy import BOUNDS, POLICY
        if self.ccfg.get("router_semantic_config_policy") != POLICY or \
                list(self.ccfg.get("router_service_bounds", [])) != list(BOUNDS):
            problems.append("router semantic-config policy / fixed service bounds not frozen as amended")
        return {"status": "FAIL" if problems else "PASS", "problems": problems, "jars": self._jar_hashes()}

    def disk_required_bytes(self, c) -> int:
        return int(self.ccfg["conservative_disk_required_bytes"])

    # ---------------------------------------------------------------------------------------------- S01..S03
    def l28(self, c) -> dict:
        from ..campaign.s2 import run_l28
        r = run_l28(c.runtime / "l28", False, c.runtime / "l28_work")
        return {k: r["authoritative"].get(k) for k in ("overall", "physical_l28", "reason")} | {"raw": r["authoritative"]}

    def _real_transport(self, c):
        """THE ONLY construction site of a real HTTPS transport in the repository (ONESHOT-CR-01). Reachable only when
        ALL hold: explicit real-campaign mode (`--backend real` + --new-campaign/--resume), the approved token file is
        present, and the runtime preflight passed (S00_PREFLIGHT and S01_L28 sealed in THIS campaign's journal)."""
        if not self.real_campaign:
            raise RealTransportRefused("real transport refused: not an explicit real-campaign execution")
        if not self.secret_present():
            raise RealTransportRefused("real transport refused: approved token file absent")
        done = c.completed() if hasattr(c, "completed") else {}
        if "S00_PREFLIGHT" not in done or "S01_L28" not in done:
            raise RealTransportRefused("real transport refused: server/runtime preflight (S00, S01) not passed")
        from ..api.transport import UrllibTransport
        return UrllibTransport()

    def preflight_network(self) -> dict:
        """--preflight-only reachability: TCP+TLS handshake to the two frozen hosts; NO HTTP request, NO token, NO
        Mobility Database API call, NO data retrieval."""
        import socket
        import ssl
        out = {}
        from urllib.parse import urlparse
        mhost = urlparse(self.cfg.runtime["mobility"]["base_url"]).hostname or ""
        ohost = "download.geofabrik.de"
        for host in (mhost, ohost):
            try:
                with socket.create_connection((host, 443), timeout=15) as sock:
                    with ssl.create_default_context().wrap_socket(sock, server_hostname=host):
                        out[host] = "TLS_OK"
            except OSError as e:
                out[host] = f"UNREACHABLE: {type(e).__name__}"
        return {"mobility_auth": "NOT_PROBED (preflight-only: TLS reachability only)",
                "mobility_tls": out[mhost], "osm_tls": out[ohost], "osm_source": "OK" if out[ohost] == "TLS_OK" else "FAIL"}

    def external_access(self, c) -> dict:
        from ..api.mobility import MobilityClient
        from ..api.transport import RealSleeper
        from ..timeutil import Clock
        res = {}
        try:
            cl = MobilityClient(self.cfg.runtime["mobility"], FileSecretProvider(self.token_file),
                                self._real_transport(c), RealSleeper(), Clock(), None)
            cl.get_json("/gtfs_feeds", {"limit": 1, "offset": 0})
            res["mobility_auth"] = "OK"
        except RealTransportRefused:
            raise
        except Exception as e:   # noqa: BLE001
            res["mobility_auth"] = "FAIL"
            res["mobility_error"] = REDACTOR.redact(f"{type(e).__name__}: {e}")
        try:
            from .osm_v3 import INDEX_URL, http_get
            json.loads(http_get(INDEX_URL, 120))
            res["osm_source"] = "OK"
        except Exception as e:   # noqa: BLE001
            res["osm_source"] = "FAIL"
            res["osm_error"] = f"{type(e).__name__}: {e}"
        return res

    def cache_protocol(self, c) -> dict:
        from .cache_protocol import build_protocol
        return build_protocol()

    # ---------------------------------------------------------------------------------------------- data plane
    def dataplane_wiring(self, c):
        from ..api.transport import RealSleeper
        from ..timeutil import Clock
        return self.cfg, {"transport": self._real_transport(c), "sleeper": RealSleeper()}, {}, \
            FileSecretProvider(self.token_file), Clock()

    def osm_pin(self, c, region: dict, osm_dir: Path) -> dict:
        from .core import SafeStop
        from .osm_v3 import OsmHullError, convex_hull, in_force_hull_points, pin_region
        dp = c.state["dp"]
        instant = json.loads((CONFIG_DIR / "spec_interpretations.json").read_text())["parameters"]["in_force_instant_utc"]
        try:                                       # EXACTLY the Phase-05 in_force_lv versions (INT-01 / INT-04)
            pts = in_force_hull_points(region, dp.versions_of_region(region["region_id"]), dp.blobs.get, instant)
        except OsmHullError as e:
            raise SafeStop("S06_OSM", str(e)) from None
        hull = convex_hull(pts)
        if len(hull) < 3:
            raise SafeStop("S06_OSM", f"degenerate region hull for {region['region_id']}")
        cache = c.state.setdefault("osm_index_cache", {})
        pin = pin_region(region["region_id"], hull, osm_dir, OSMIUM, index_cache=cache)
        for k in ("raw_path", "region_path"):
            pin[k] = str(Path(pin[k]).resolve().relative_to(c.work_root.resolve()))
        return pin

    def _make_producers(self, c):
        if self._producers is None:
            from ..campaign.s2 import make_producers
            from ..config.spec import load_protocol_spec
            from ..deps.pins import BinaryMode
            from ..resources.manager import otp_authoritative_envelope
            env = otp_authoritative_envelope(load_protocol_spec(), self.ccfg["otp_cpuset"])
            self._producers = make_producers(BinaryMode.REAL_PINNED_BINARY, c.work_root / "work" / "producers", env,
                                             isolate_network=True)
        return self._producers

    def producer_smoke(self, c) -> dict:
        """Non-study conformance on the frozen oracle fixture: validator + OTP + Canon_D digests vs the frozen record,
        resource wrapper, scheduler, storage and replay machinery."""
        from ..campaign.s2 import run_conformance
        from ..deps.pins import BinaryMode
        s = run_conformance("oracle", c.runtime / "producer_smoke", BinaryMode.REAL_PINNED_BINARY,
                            c.work_root / "work" / "smoke")
        ok = s.get("oracle", {}).get("pass") == s.get("oracle", {}).get("n") and \
            s.get("oracle", {}).get("digests_match_frozen_record") == s.get("oracle", {}).get("n")
        return {"status": "PASS" if ok else "FAIL", "binary_mode": self.binary_mode, "oracle": s.get("oracle")}

    def frozen_semantics_intact(self, c) -> bool:
        from .fixture_backend import _frozen_ok
        return _frozen_ok()

    def resource_config_intact(self, c) -> bool:
        return sha256_obj(self.ccfg) == sha256_obj(campaign_config())

    def source_fingerprint(self, c) -> str:
        from ..campaign.identity import implementation_id
        from .fixture_backend import _frozen_digest
        return sha256_obj([implementation_id(), _frozen_digest(), sha256_obj(campaign_config())])

    def namespace_of(self, c, rid: str) -> str:
        split = json.loads((c.runtime / "VALIDATION_TEST_SPLIT.json").read_text())
        return "VALIDATION" if rid in split["validation"] else "TEST"

    def region_constants(self, c, rid: str) -> dict:
        pins = {p["region_id"]: p for p in json.loads((c.runtime / "OSM_PINS.json").read_text())["pins"]}
        spec_pins = json.loads((CONFIG_DIR / "pinned_dependencies.json").read_text())
        from .semconfig_policy import POLICY, region_semantic_digest
        if self.ccfg["router_semantic_config_policy"] != POLICY:
            raise RuntimeError("router semantic-config policy not frozen")
        reg = c.state["dp"].regions_by_id()[rid]
        return {"osm_sha256": pins[rid]["region_sha256"],
                "semantic_config_digest": region_semantic_digest([f["feed_id"] for f in reg["feeds"]],
                                                                 reg["timezone"] or "UTC"),
                "otp_sha256": spec_pins["otp"]["sha256"] if "otp" in spec_pins else "otp:2.10.0",
                "validator_sha256": spec_pins["gtfs_validator"]["sha256"] if "gtfs_validator" in spec_pins else
                "gtfs-validator:8.0.1", "country": self._country(c, rid)}

    def _country(self, c, rid: str) -> str:
        reg = c.state["dp"].regions_by_id()[rid]
        cs = sorted({f.get("country_code") or "" for f in reg["feeds"]})
        return cs[0] if len(cs) == 1 and cs[0] else "XX"

    def region_session(self, c, region, cs, ctxf, out: Path) -> dict:
        from ..engines.runner import RegionCampaign
        from .real_producer import RealSlotProducer, ScheduledExecutor
        _spec, _deps, _blobs, otp, val, _canon = self._make_producers(c)
        pins = {p["region_id"]: p for p in json.loads((c.runtime / "OSM_PINS.json").read_text())["pins"]}
        osm = c.work_root / pins[region.region_id]["region_path"]
        sched_prod = RealSlotProducer(region, cs, ctxf, val, otp, osm, self._jar_paths(), c)
        ex = ScheduledExecutor(sched_prod, region)

        def make():
            return RealSlotProducer(region, cs, ctxf, val, otp, osm, self._jar_paths(), c, executor=ex)

        class RealRegionCampaign(RegionCampaign):
            def produce_shared(self, until_utc: str) -> None:
                ex.shared_phase = True
                try:
                    super().produce_shared(until_utc)
                finally:
                    ex.shared_phase = False
        from .interleave import NativeSlotProducer
        native_inputs = {"osm": str(osm), "tz": region.tz, "build_date": "2025-04-01", "namespace": region.namespace,
                         "service_bounds": list(_bounds()),
                         "feeds": {(v.feed_id, v.logical_version_id): str(region.blobs.path_of(v.raw_zip_sha256))
                                   for v in region.versions.values()}}
        nb = self.native_builder(c, region, out / "n1_native", warm=sched_prod.warm)       # N1 (warm protocol)
        nb.inputs[region.region_id] = dict(native_inputs)

        def canon_fn(graph, horizon, sem, osm_sha):
            res = otp.canon.run(graph, horizon, sem, osm_sha, otp.binary_sha, "ROUTER:n1-native", graph.parent / "canon")
            return res.digest.sha256 if res.status == "OK" and res.digest is not None else None

        def native_factory(method, tau, mc, warm=True, root=None):
            lab = method + (f"_{tau}" if tau else "")
            b = self.native_builder(c, region, root or (out / f"native_{lab}"), warm=sched_prod.warm if warm else None)
            b.inputs[region.region_id] = dict(native_inputs)
            return NativeSlotProducer(region, cs, ctxf, b, canon_fn, real=True)

        def before_arm(kind, arm, t):
            nb.current_tick = t                                    # warm corpus of THIS request for N1 builds

        self._last_session = {"producer": RealSlotProducer(region, cs, ctxf, val, otp, osm, self._jar_paths(), c),
                              "native_factory": native_factory}
        return {"duration_backend": ex, "producer_factory": make, "native_builder": nb,
                "campaign_cls": RealRegionCampaign, "native_factory": native_factory, "before_arm": before_arm}

    def mutations(self, c, region, camp, out: Path) -> list[dict]:
        from .real_producer import real_mutations
        return [dict(m, marker="REAL") for m in real_mutations(c, region, camp, out, self._make_producers(c))]

    def cold_pass_enabled(self, namespace: str) -> bool:
        return namespace == "TEST"

    def cold_pass(self, c, region, camp, arms, out: Path):
        from .interleave import cold_pass_mechanism
        from .real_producer import drop_caches
        nf = self._last_session["native_factory"]
        return cold_pass_mechanism(region, camp, arms, out, self._last_session["producer"],
                                   lambda lab: nf(lab, None, None, warm=False, root=out / "cold_native" / lab),
                                   drop_caches)

    def ticks(self, c, events: list, region) -> list[str]:
        return [e["t"] for e in events if e["kind"] == "CONSUMER_TICK"]           # every frozen consumer tick

    def producer_factory(self, c, region, cs, ctxf):
        from .real_producer import RealSlotProducer
        _spec, _deps, _blobs, otp, val, _canon = self._make_producers(c)
        pins = {p["region_id"]: p for p in json.loads((c.runtime / "OSM_PINS.json").read_text())["pins"]}
        osm = c.work_root / pins[region.region_id]["region_path"]

        def make():
            return RealSlotProducer(region, cs, ctxf, val, otp, osm, self._jar_paths(), c)
        return make

    def _jar_paths(self) -> list[str]:
        return [str(p) for p in sorted((REPO_ROOT / ".deps").glob("*.jar"))]

    def native_builder(self, c, region, root: Path, warm=None):
        from .interleave import WarmingNativeBuilder
        _spec, _deps, _blobs, otp, _val, _canon = self._make_producers(c)
        from .semconfig_policy import FixedBoundsOtp
        from ..config.spec import load_protocol_spec
        from ..resources.manager import otp_authoritative_envelope
        env = otp_authoritative_envelope(load_protocol_spec(), self.ccfg["otp_cpuset"])
        return WarmingNativeBuilder(FixedBoundsOtp(otp), root, sha256_obj(str(env)), warm=warm)

    def k3_reference(self, c, region, camp, arms=None):
        from .real_producer import real_k3_reference
        _spec, _deps, _blobs, otp, val, _canon = self._make_producers(c)
        return real_k3_reference(c, region, camp, otp, val, arms)


    def regression(self, c) -> dict:
        out = c.runtime / "regression"
        env = dict(os.environ, F1_WC_REPORT_DIR=str(out))
        cp = subprocess.run(["bash", str(REPO_ROOT / "scripts" / "run_tests.sh")], cwd=REPO_ROOT, env=env,
                            capture_output=True, text=True)
        (c.runtime / "regression.log").write_text(REDACTOR.redact(cp.stdout[-200000:] + cp.stderr[-50000:]))
        return {"status": "PASS" if cp.returncode == 0 else "FAIL", "rc": cp.returncode, "report_dir": str(out)}
