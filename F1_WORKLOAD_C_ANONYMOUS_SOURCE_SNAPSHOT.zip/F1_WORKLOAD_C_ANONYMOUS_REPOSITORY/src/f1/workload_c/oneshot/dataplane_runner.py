"""Runs the frozen Session-1 data-plane phases (02 snapshot, 03 logical versions, 04 licence, 05 regions, 06 select-24,
07 split) unchanged, with the backend's services (FIXTURE: mock Mobility server; REAL: authenticated HTTPS transport),
inside <work-root>/dataplane. The phase functions, their filters and the frozen selection tool are not modified."""
from __future__ import annotations

import csv
import json
from pathlib import Path

from ..campaign.context import PhaseContext
from ..campaign.phases import PHASES
from ..state.journal import StructuredLog
from ..storage.blobstore import BlobStore, ManifestStore, SnapshotStore
from .core import CampaignError, sha256_file


class DataplaneRunner:
    def __init__(self, root: Path, cfg, services: dict, adapters: dict, secrets, run_id: str, clock=None) -> None:
        self.root = root
        root.mkdir(parents=True, exist_ok=True)
        self.cfg, self.services, self.adapters, self.secrets, self.run_id = cfg, services, adapters, secrets, run_id
        self.clock = clock
        self.blobs = BlobStore(root / "store")
        self.blobs.recover()
        self.manifests = ManifestStore(self.blobs)
        self.snapshots = SnapshotStore(self.blobs, self.manifests)
        self.log = StructuredLog(root / "logs" / "events.jsonl", run_id, cfg.namespace, clock)
        self.outputs: dict[str, dict] = {}
        self.summaries: dict[str, dict] = {}
        idx = root / "phase_index.json"
        if idx.exists():                              # resume: previously completed phases (digests re-verified)
            saved = json.loads(idx.read_text())
            for _pid, rec in saved["outputs"].items():
                for rel, d in rec.items():
                    if sha256_file(root / rel) != d:
                        raise CampaignError(f"data-plane output {rel} changed")
            self.outputs, self.summaries = saved["outputs"], saved["summaries"]

    def _save(self) -> None:
        (self.root / "phase_index.json").write_text(json.dumps({"outputs": self.outputs, "summaries": self.summaries},
                                                               indent=1, sort_keys=True, default=str))

    def run_phase(self, pid: str) -> dict:
        if pid in self.outputs:
            return self.summaries[pid]
        ph = [p for p in PHASES if p.phase_id == pid][0]
        ctx = PhaseContext(cfg=self.cfg, run_id=self.run_id, run_dir=self.root, phase_id=pid, blobs=self.blobs,
                           manifests=self.manifests, snapshots=self.snapshots, log=self.log, clock=self.clock,
                           secrets=self.secrets, adapters=self.adapters, services=self.services,
                           implementation_id=self.run_id, prior_outputs={k: dict(v) for k, v in self.outputs.items()})
        summary = ph.runner(ctx)
        self.outputs[pid] = {rel: sha256_file(self.root / rel) for rel in sorted(ctx.written)}
        self.summaries[pid] = summary
        self._save()
        return summary

    def path(self, pid: str, name: str) -> Path:
        return self.root / "phases" / pid / name

    def read_csv(self, pid: str, name: str) -> list[dict]:
        with open(self.path(pid, name)) as f:
            return list(csv.DictReader(f))

    def read_json(self, pid: str, name: str):
        return json.loads(self.path(pid, name).read_text())

    def read_jsonl(self, pid: str, name: str) -> list[dict]:
        return [json.loads(ln) for ln in self.path(pid, name).read_text().splitlines() if ln.strip()]

    def regions_by_id(self) -> dict:
        return {r["region_id"]: r for r in self.read_json("05_eligible_regions", "regions.json")["regions"]}

    def versions_of_region(self, rid: str) -> list[dict]:
        feeds = {f["feed_id"] for f in self.regions_by_id()[rid]["feeds"]}
        return [v for v in self.read_jsonl("03_logical_versions", "logical_versions.jsonl") if v["feed_id"] in feeds]

    def filter_ledger(self) -> list[dict]:
        s2, s3, s4, s5 = (self.summaries[p] for p in ("02_mobility_snapshot", "03_logical_versions", "04_license_gate",
                                                      "05_eligible_regions"))
        n_elig = len(self.read_csv("05_eligible_regions", "eligible_population.csv"))
        rows = [("catalog_feeds", s2.get("n_feeds"), "02"), ("archive_observations", s2.get("n_observations"), "02"),
                ("archives", s3.get("n_archives"), "03"), ("logical_versions", s3.get("n_logical_versions"), "03")]
        for k, v in sorted((s4.get("classification_counts") or {}).items()):
            rows.append((f"license_{k}", v, "04"))
        rows += [("feeds_considered", s5.get("n_feeds"), "05"), ("feeds_eligible", s5.get("n_feed_eligible"), "05"),
                 ("feeds_after_dedup", s5.get("n_after_dedup"), "05"), ("connectivity_edges", s5.get("n_edges"), "05")]
        for k, v in sorted(s5.items()):
            if k.startswith("n_") and k not in ("n_feeds", "n_feed_eligible", "n_after_dedup", "n_edges"):
                rows.append((k[2:], v, "05"))
        rows.append(("eligible_regions", n_elig, "05"))
        return [{"stage": a, "count": b, "source": f"phase {c}"} for a, b, c in rows]

    def install_osm_pins(self, pins: list[dict]) -> None:
        """Write the real OSM pins where the S3 campaign glue reads them (phases/08_osm_pinning/osm_pins.json)."""
        p = self.path("08_osm_pinning", "osm_pins.json")
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({"namespace": self.cfg.namespace, "pins": [
            {"region_id": x["region_id"], "osm_sha256": x["region_sha256"], "path": x["region_path"]} for x in pins]},
            indent=1, sort_keys=True))
        self.outputs["08_osm_pinning"] = {str(p.relative_to(self.root)): sha256_file(p)}
        self.summaries["08_osm_pinning"] = {"n_pins": len(pins)}
        self._save()
