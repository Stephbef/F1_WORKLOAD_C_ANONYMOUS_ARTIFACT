"""Per-region execution for the one-shot campaign (VALIDATION: all methods, N4 for every τ candidate; TEST: all
methods with the frozen selected τ), integrity / replay / mutation closure checks and the frozen analysis.
Engines are the frozen Session-3 / Session-4A.1.1 implementations; nothing here chooses scientific parameters."""
from __future__ import annotations

import json
from pathlib import Path

from ...common.util import sha256_obj
from ..config.spec import load_protocol_spec
from ..contracts.generators import ContractSystem
from ..engines.baselines_s4 import classify_n4_reuses, n4_cost
from ..engines.core import CutContextFactoryImpl, RegionState, VersionInfo
from ..engines.stats import FrozenAnalysisImpl, RawExportLog
from ..interfaces import session3 as S
from ..scheduler.workload_c import RegionScheduleInput, VersionAvailability, simulate
from .core import write_json


def region_state(c, rid: str) -> RegionState:
    dp = c.state["dp"]
    reg = dp.regions_by_id()[rid]
    feeds = tuple(sorted(f["feed_id"] for f in reg["feeds"]))
    versions = {(v["feed_id"], v["index"]): VersionInfo(v["feed_id"], v["index"], v["logical_version_id"],
                                                        v["canonical_content_sha256"], v["raw_zip_sha256s"][0],
                                                        v["first_observed_utc"]) for v in dp.versions_of_region(rid)}
    k = c.backend.region_constants(c, rid)
    return RegionState(rid, reg["timezone"] or "UTC", feeds, versions, k["osm_sha256"], k["semantic_config_digest"],
                       k["otp_sha256"], k["validator_sha256"], k["country"], dp.blobs, c.backend.namespace_of(c, rid))


def baseline_record(c, d, rid: str, namespace: str) -> dict:
    return {"campaign_id": c.identity["campaign_id"], "namespace": namespace, "region_id": rid,
            "request_id": d.request.request_id, "tick_utc": d.request.tick_utc, "method": d.method, "tau_h": d.tau_h,
            "joint_action": d.joint_action,
            "slots": [{"slot": s.slot_id, "action": s.action, "artifact_id": s.artifact_id, "reason": s.reason,
                       "outcome": s.step.outcome if s.step else None} for s in d.slots],
            "costs": [vars(i) | {"category": i.category.value} for i in d.costs.items],
            "reuse_events": [list(x) for x in d.reuse_events]}


def run_region(c, rid: str, out: Path, namespace: str, n4_taus) -> dict:
    """All methods for one region over the frozen consumer stream. Returns summary + incident list (never raises for
    data-level outcomes; engine invariant violations become incidents requiring researcher intervention)."""
    spec = load_protocol_spec()
    out.mkdir(parents=True, exist_ok=True)
    incidents: list[dict] = []
    try:
        r = region_state(c, rid)
        win = c.backend.window
        rin = RegionScheduleInput(rid, r.tz, r.feeds, tuple(
            VersionAvailability(v.feed_id, v.index, v.logical_version_id, v.available_utc)
            for v in sorted(r.versions.values(), key=lambda v: (v.available_utc, v.feed_id))), win[0], win[1])
        cs = ContractSystem(r.blobs, spec.gtfs_member_names)
        ctxf = CutContextFactoryImpl(r)
        sess = c.backend.region_session(c, r, cs, ctxf, out)
        sched = simulate(spec, rin, sess["duration_backend"])
        ticks = c.backend.ticks(c, sched.events, r)
        run = S.RunIdentityRecord(c.identity["campaign_id"], namespace, c.identity["implementation_id"],
                                  sha256_obj(c.identity["frozen_digests"]))
        pf = sess["producer_factory"]
        camp = sess["campaign_cls"](r, sched.events, cs, pf, run, out / "f1_n5_n1",
                                    native_builder=sess["native_builder"], analysis_window_start=win[0])
        from .interleave import OneShotS4Runner, run_interleaved
        if c.backend.binary_mode == "REAL_PINNED_BINARY" and sess.get("native_factory") is None:
            raise RuntimeError("REAL execution requires the N1-native factory for N2/N3/N4/N6 ROUTER re-derivations")
        runner = OneShotS4Runner(camp, pf, sess.get("native_factory"), native_wall_s=c.backend.native_wall_s or 1800.0)
        methods = [("N0", None), ("N2", None), ("N3", None), ("N6", None)] + [("N4", t) for t in n4_taus]
        arms = run_interleaved(camp, runner, methods, ticks, out / "EXECUTION_ORDER.jsonl",
                               sess.get("before_arm")) if ticks else {}
        recs = camp.records
        ledger = camp.seal()
        write_json(out / "sealed_ledger.json", {"campaign_id": c.identity["campaign_id"], "ledger": _led(ledger)})
        n4: dict = {}
        ref = c.backend.k3_reference(c, r, camp, arms)
        with open(out / "baseline_raw.jsonl", "w") as fh:
            for (m, tau), arm in sorted(arms.items(), key=lambda kv: (kv[0][0], kv[0][1] or 0)):
                for d in arm.decisions:
                    fh.write(json.dumps(baseline_record(c, d, rid, namespace), sort_keys=True, default=str) + "\n")
                if m == "N4":
                    unsafe, uncl = classify_n4_reuses(arm.decisions, ref)
                    n4[str(tau)] = {"unsafe": unsafe, "cost": n4_cost(arm.decisions), "unclassifiable": uncl,
                                    "no_artifact": sum(1 for d in arm.decisions if d.joint_action == "NO_ARTIFACT"),
                                    "cap": sum(1 for d in arm.decisions for s in d.slots
                                               if s.step is not None and s.step.outcome == "TIMEOUT")}
        muts = c.backend.mutations(c, r, camp, out)
        with open(out / "mutations.jsonl", "w") as fh:
            for m in muts:
                fh.write(json.dumps(m, sort_keys=True, default=str) + "\n")
        if namespace in ("TEST", "FIXTURE") and c.backend.cold_pass_enabled(namespace):
            c.backend.cold_pass(c, r, camp, arms, out)
        return {"n_ticks": len(ticks), "n_records": len(recs), "n4": n4, "incidents": incidents,
                "raw_export": str((out / "f1_n5_n1" / "raw_export.jsonl").relative_to(c.work_root)),
                "binary_mode": c.backend.binary_mode}
    except Exception as e:   # noqa: BLE001 — engine/invariant failure: incident, campaign stops before TEST
        incidents.append({"category": "E1", "diagnosis": f"{type(e).__name__}: {e}", "requires_change": True,
                          "method": None})
        return {"n_ticks": 0, "n_records": 0, "n4": {str(t): {"unsafe": 0, "cost": 0.0, "unclassifiable": 1,
                                                             "no_artifact": 0, "cap": 0} for t in n4_taus},
                "incidents": incidents}


def _led(led: S.SealedLedger) -> dict:
    return {"history_journal_sha256": led.history_journal_sha256, "catalog_journal_sha256s": [list(x) for x in
                                                                                             led.catalog_journal_sha256s],
            "contracts_sha256": led.contracts_sha256, "raw_export_sha256": led.raw_export_sha256,
            "cost_ledger_sha256": led.cost_ledger_sha256, "paths": [list(x) for x in led.paths]}


def _unled(d: dict) -> S.SealedLedger:
    return S.SealedLedger(d["history_journal_sha256"], tuple(tuple(x) for x in d["catalog_journal_sha256s"]),
                          d["contracts_sha256"], d["raw_export_sha256"], d["cost_ledger_sha256"],
                          tuple(tuple(x) for x in d["paths"]))


def closure_checks(c, root: Path, namespace: str) -> dict:
    """Integrity (hash chains, unique scientific cells, single campaign/namespace/run identity), replay of every
    sealed ledger, mutation checks through the backend's reference paths."""
    from ..engines.replay import ReplayEngineImpl
    spec = load_protocol_spec()
    problems, cells, replayed, mutations = [], set(), 0, []
    regions = sorted(p for p in root.iterdir() if p.is_dir() and (p / "sealed_ledger.json").exists())
    for rd in regions:
        recs = RawExportLog.verify(rd / "f1_n5_n1" / "raw_export.jsonl")
        for r in recs:
            key = (r["run"]["run_id"], r["run"]["namespace"], r["region_id"], r["request_id"], r["method"], r["level"])
            if key in cells:
                problems.append(f"duplicate scientific cell {key}")
            cells.add(key)
            if r["run"]["run_id"] != c.identity["campaign_id"] or r["run"]["namespace"] != namespace:
                problems.append(f"mixed run identity / namespace in {rd.name}")
        for ln in (rd / "baseline_raw.jsonl").read_text().splitlines():
            b = json.loads(ln)
            key = (b["campaign_id"], b["namespace"], b["region_id"], b["request_id"], b["method"], b["tau_h"])
            if key in cells:
                problems.append(f"duplicate baseline cell {key}")
            cells.add(key)
            if b["campaign_id"] != c.identity["campaign_id"] or b["namespace"] != namespace:
                problems.append(f"mixed baseline identity in {rd.name}")
        led = _unled(json.loads((rd / "sealed_ledger.json").read_text())["ledger"])
        rep = ReplayEngineImpl(spec.gtfs_member_names).replay(led, ())
        replayed += len(rep.items)
        bad = [i for i in rep.items if i.status != "REPRODUCED"]
        if bad or len(rep.items) != len(recs):
            problems.append(f"replay mismatch in {rd.name}: {len(bad)} not reproduced / {len(rep.items)} of {len(recs)}")
        mutations += [json.loads(ln) for ln in (rd / "mutations.jsonl").read_text().splitlines()] \
            if (rd / "mutations.jsonl").exists() else [{"status": "MISSING", "integrity": "FAIL"}]
    mut_bad = [m for m in mutations if m.get("integrity") == "FAIL"]
    if mut_bad:
        problems.append(f"{len(mut_bad)} mutation reference inconsistencies")
    return {"ok": not problems, "problems": problems[:50], "n_regions": len(regions), "n_cells": len(cells),
            "replayed": replayed, "n_mutations": len(mutations),
            "mutation_status_counts": _count(m.get("status") for m in mutations)}


def _count(xs) -> dict:
    out: dict = {}
    for x in xs:
        out[str(x)] = out.get(str(x), 0) + 1
    return out


def final_analysis(c, root: Path, namespace: str) -> dict:
    recs = []
    for rd in sorted(p for p in root.iterdir() if p.is_dir() and (p / "sealed_ledger.json").exists()):
        recs += RawExportLog.verify(rd / "f1_n5_n1" / "raw_export.jsonl")
    fa = FrozenAnalysisImpl()
    rep = fa.run(recs, namespace)
    desc = fa.descriptive(recs)
    return {"campaign_id": c.identity["campaign_id"], "namespace": namespace, "raw_export_sha256": rep.raw_export_sha256,
            "hypotheses": [vars(h) for h in rep.hypotheses], "per_region": {rid: dict(v) for rid, v in rep.per_region},
            "descriptive": desc, "binary_mode": c.backend.binary_mode,
            "note": "frozen FrozenAnalysis output; no additional confirmatory hypotheses; interpretation is out of scope"}
