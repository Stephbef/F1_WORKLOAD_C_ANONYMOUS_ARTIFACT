"""Feed-level eligibility (spec 17 §3): active, no authentication, bbox diagonal <= 500 km, licence class
A/B/C, logical history covering the window with no gap > 30 days. All failing reasons are recorded in a fixed
order; the first is the primary machine-readable reason code."""
from __future__ import annotations

from typing import Iterable

from ..config.runtime import EffectiveConfig
from ..ingestion.gtfs import ArchiveRecord
from ..timeutil import epoch
from ..versioning.logical import LogicalVersion
from .model import FeedDecision, FeedFacts, FeedRecord

REASON_ORDER = ("MALFORMED_METADATA", "NOT_GTFS_SCHEDULE", "STATUS_NOT_ACTIVE", "AUTHENTICATION_REQUIRED",
                "NO_HISTORY", "ARCHIVE_UNRETRIEVABLE", "MALFORMED_GTFS", "HISTORY_INSUFFICIENT_START",
                "HISTORY_GAP_EXCEEDED", "BBOX_DIAGONAL_EXCEEDED", "LICENSE_UNCLEAR", "LICENSE_INCOMPATIBLE",
                "LICENSE_NOT_ELIGIBLE")


def history_check(cfg: EffectiveConfig, archives: Iterable[ArchiveRecord], versions: Iterable[LogicalVersion]
                  ) -> tuple[bool, str | None, float | None]:
    """Coverage + maximum-gap rule (INT-02). Returns (ok, reason, max_gap_days)."""
    p = cfg.interp.p
    start, end = epoch(p["history_window_start_utc"]), epoch(p["history_window_end_exclusive_utc"])
    if p["history_gap_basis"] == "archive_observations":
        times = sorted(epoch(a.archive_observed_utc) for a in archives if a.status == "OK")
    else:
        times = sorted(epoch(v.first_observed_utc) for v in versions)
    if not times:
        return False, "NO_HISTORY", None
    if p["history_requires_observation_at_or_before_start"] and times[0] > start:
        gap0 = (times[0] - start) / 86400.0
        return False, "HISTORY_INSUFFICIENT_START", gap0
    prev = start
    max_gap = 0.0
    for t in times:
        if start < t < end:
            max_gap = max(max_gap, t - prev)
            prev = t
    max_gap = max(max_gap, end - prev)
    limit = cfg.spec["history"]["max_gap_days"] * 86400
    days = max_gap / 86400.0
    if max_gap > limit:
        return False, "HISTORY_GAP_EXCEEDED", days
    return True, None, days


def decide_feed(cfg: EffectiveConfig, rec: FeedRecord, facts: FeedFacts, license_decision: dict | None
                ) -> FeedDecision:
    fe = cfg.spec["feed_eligibility"]
    reasons: set[str] = set()
    if not rec.metadata_valid:
        reasons.add("MALFORMED_METADATA")
    if rec.data_type not in (None, "gtfs"):
        reasons.add("NOT_GTFS_SCHEDULE")
    if rec.status != fe["required_status"]:
        reasons.add("STATUS_NOT_ACTIVE")
    if fe["require_no_authentication"] and rec.authentication_type != 0:
        reasons.add("AUTHENTICATION_REQUIRED")
    if facts.n_archives_ok == 0 and facts.archive_failures == 0:
        reasons.add("NO_HISTORY")
    if facts.archive_failures > 0:
        reasons.add("ARCHIVE_UNRETRIEVABLE")
    if facts.malformed_reason:
        reasons.add("MALFORMED_GTFS")
    if not facts.history_ok and facts.history_reason in ("HISTORY_INSUFFICIENT_START", "HISTORY_GAP_EXCEEDED"):
        reasons.add(facts.history_reason)
    if not facts.history_ok and facts.history_reason == "NO_HISTORY":
        reasons.add("NO_HISTORY")
    if facts.bbox_diagonal_m is not None and facts.bbox_diagonal_m > fe["max_bbox_diagonal_km"] * 1000.0:
        reasons.add("BBOX_DIAGONAL_EXCEEDED")
    if license_decision is None:
        reasons.add("LICENSE_UNCLEAR")
    elif not license_decision["eligible"]:
        reasons.add({"UNCLEAR": "LICENSE_UNCLEAR", "INCOMPATIBLE": "LICENSE_INCOMPATIBLE"}.get(
            license_decision["classification"], "LICENSE_NOT_ELIGIBLE"))
    ordered = [r for r in REASON_ORDER if r in reasons]
    return FeedDecision(rec.feed_id, eligible=not ordered, reasons=ordered)
