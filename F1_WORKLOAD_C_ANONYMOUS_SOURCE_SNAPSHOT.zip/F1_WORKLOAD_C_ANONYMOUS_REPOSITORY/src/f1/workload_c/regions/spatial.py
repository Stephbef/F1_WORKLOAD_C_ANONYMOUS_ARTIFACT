"""Spatial primitives required by the frozen region rules (small, auditable, dependency-free).

Interpretations (configs/workload_c/spec_interpretations.json, INT-04/INT-05): great-circle distance by the
haversine formula on a sphere of radius R (default 6371008.8 m); thresholds inclusive; convex hulls built in a
local equirectangular plane centred on the midpoint of the two stop sets. Numerical tolerance for geometric
predicates: GEOM_EPS_M metres. All functions are deterministic for a given input order-independent set.
"""
from __future__ import annotations

import bisect
import math
from typing import Iterable, Sequence

from ..ingestion.gtfs import Stop

GEOM_EPS_M = 1e-6
Point = tuple[float, float]


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float, radius_m: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = p2 - p1
    dlmb = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return 2 * radius_m * math.asin(min(1.0, math.sqrt(a)))


def bbox(stops: Iterable[Stop]) -> tuple[float, float, float, float]:
    s = list(stops)
    if not s:
        raise ValueError("bbox of empty stop set")
    return (min(x.lat for x in s), min(x.lon for x in s), max(x.lat for x in s), max(x.lon for x in s))


def bbox_diagonal_m(stops: Iterable[Stop], radius_m: float) -> float:
    a, b, c, d = bbox(stops)
    return haversine_m(a, b, c, d, radius_m)


def stop_pairs_within(a: Sequence[Stop], b: Sequence[Stop], max_m: float, radius_m: float,
                      sample: int = 10) -> tuple[int, list[dict]]:
    """Count distinct (stop of A, stop of B) pairs with distance <= max_m (inclusive).

    Latitude-band pruning is exact: great-circle distance >= R * |Δφ|, so pairs outside the band cannot qualify.
    Returns (count, up to `sample` evidence pairs ordered by (distance, ids))."""
    a = sorted(set(a), key=lambda s: s.stop_id)
    b = sorted(set(b), key=lambda s: (s.lat, s.stop_id))
    lats = [s.lat for s in b]
    dlat = math.degrees(max_m / radius_m) * (1 + 1e-9)
    count = 0
    ev: list[tuple[float, str, str]] = []
    for sa in a:
        lo = bisect.bisect_left(lats, sa.lat - dlat)
        hi = bisect.bisect_right(lats, sa.lat + dlat)
        for sb in b[lo:hi]:
            d = haversine_m(sa.lat, sa.lon, sb.lat, sb.lon, radius_m)
            if d <= max_m:
                count += 1
                ev.append((d, sa.stop_id, sb.stop_id))
    ev.sort()
    return count, [{"stop_a": x, "stop_b": y, "distance_m": round(d, 3)} for d, x, y in ev[:sample]]


def project_local(stops: Iterable[Stop], lat0: float, lon0: float, radius_m: float) -> list[Point]:
    c = math.cos(math.radians(lat0))
    out = []
    for s in stops:
        dl = (s.lon - lon0 + 180.0) % 360.0 - 180.0
        out.append((radius_m * math.radians(dl) * c, radius_m * math.radians(s.lat - lat0)))
    return out


def _cross(o: Point, a: Point, b: Point) -> float:
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def convex_hull(points: Iterable[Point]) -> list[Point]:
    """Andrew monotone chain; returns CCW hull without repetition (1 or 2 points for degenerate input)."""
    pts = sorted(set(points))
    if len(pts) <= 2:
        return pts
    lower: list[Point] = []
    for p in pts:
        while len(lower) >= 2 and _cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper: list[Point] = []
    for p in reversed(pts):
        while len(upper) >= 2 and _cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    hull = lower[:-1] + upper[:-1]
    return hull if len(hull) >= 2 else pts[:1]


def _seg_point_dist(p: Point, a: Point, b: Point) -> float:
    ax, ay = a
    bx, by = b
    dx, dy = bx - ax, by - ay
    L = dx * dx + dy * dy
    if L == 0:
        return math.hypot(p[0] - ax, p[1] - ay)
    t = max(0.0, min(1.0, ((p[0] - ax) * dx + (p[1] - ay) * dy) / L))
    return math.hypot(p[0] - (ax + t * dx), p[1] - (ay + t * dy))


def _segments_intersect(p1: Point, p2: Point, q1: Point, q2: Point) -> bool:
    d1, d2 = _cross(q1, q2, p1), _cross(q1, q2, p2)
    d3, d4 = _cross(p1, p2, q1), _cross(p1, p2, q2)
    if ((d1 > 0 > d2) or (d1 < 0 < d2)) and ((d3 > 0 > d4) or (d3 < 0 < d4)):
        return True
    return (_seg_point_dist(p1, q1, q2) <= GEOM_EPS_M or _seg_point_dist(p2, q1, q2) <= GEOM_EPS_M
            or _seg_point_dist(q1, p1, p2) <= GEOM_EPS_M or _seg_point_dist(q2, p1, p2) <= GEOM_EPS_M)


def _point_in_hull(p: Point, hull: list[Point]) -> bool:
    if len(hull) < 3:
        return False
    for i in range(len(hull)):
        if _cross(hull[i], hull[(i + 1) % len(hull)], p) < -GEOM_EPS_M:
            return False
    return True


def _edges(h: list[Point]) -> list[tuple[Point, Point]]:
    if len(h) == 1:
        return [(h[0], h[0])]
    if len(h) == 2:
        return [(h[0], h[1])]
    return [(h[i], h[(i + 1) % len(h)]) for i in range(len(h))]


def hull_relation(h1: list[Point], h2: list[Point]) -> tuple[bool, float]:
    """Return (intersects, distance_m). Containment counts as intersection (distance 0)."""
    if not h1 or not h2:
        raise ValueError("empty hull")
    e1, e2 = _edges(h1), _edges(h2)
    for a in e1:
        for b in e2:
            if _segments_intersect(a[0], a[1], b[0], b[1]):
                return True, 0.0
    if _point_in_hull(h1[0], h2) or _point_in_hull(h2[0], h1):
        return True, 0.0
    d = min(min(_seg_point_dist(a[0], b[0], b[1]), _seg_point_dist(a[1], b[0], b[1]),
                _seg_point_dist(b[0], a[0], a[1]), _seg_point_dist(b[1], a[0], a[1]))
            for a in e1 for b in e2)
    return False, d


def hull_criterion(a: Sequence[Stop], b: Sequence[Stop], radius_m: float) -> tuple[bool, float]:
    allpts = list(a) + list(b)
    lat0 = (min(s.lat for s in allpts) + max(s.lat for s in allpts)) / 2
    lons = sorted(s.lon for s in allpts)
    lon0 = (lons[0] + lons[-1]) / 2
    ha = convex_hull(project_local(a, lat0, lon0, radius_m))
    hb = convex_hull(project_local(b, lat0, lon0, radius_m))
    return hull_relation(ha, hb)
