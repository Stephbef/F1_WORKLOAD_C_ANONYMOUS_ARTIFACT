"""Deduplication / alias / bundle engine (spec 17 §3; parameterisation INT-06/INT-07).

Applied to the feed-level-eligible set, in this fixed rule order (each rule sees the survivors of the previous):
  1. redirect             feeds whose catalog record redirects to another feed are dropped
  2. identical_url        identical normalised producer URL          -> collapse to smallest feed id
  3. identical_canonical  identical latest canonical content hash    -> collapse to smallest feed id
  4. alias                identical normalised (provider, feed_name) -> collapse to smallest feed id
  5. merged_bundle        agency_id overlap >= 0.5 (S2 correction INT-06: identity = exact agency_id string as written in
                          agency.txt, per V5 'agency_id overlap'; agency_name is never an identity; agencies without an
                          agency_id have no comparable identity). Denominator = overlap coefficient |A∩B|/min(|A|,|B|),
                          drop the feed with the strictly larger agency_id set; equal cardinality keeps both (INT-06 FROZEN_PRE_S3)
Grouping is transitive (union-find) and survivors are chosen by a total order, so the result is independent of
input order. Every dropped feed gets a reason code and the id of the feed it collapsed into.
"""
from __future__ import annotations

import re
import urllib.parse
from fractions import Fraction
from dataclasses import dataclass

from .model import FeedFacts, FeedRecord


def normalize_url(url: str | None) -> str | None:
    if not url:
        return None
    try:
        u = urllib.parse.urlsplit(url.strip())
    except ValueError:
        return None
    scheme = u.scheme.lower()
    host = (u.hostname or "").lower()
    port = u.port
    if port and not ((scheme == "https" and port == 443) or (scheme == "http" and port == 80)):
        host = f"{host}:{port}"
    path = u.path.rstrip("/")
    q = f"?{u.query}" if u.query else ""
    return f"{scheme}://{host}{path}{q}"


def normalize_name(s: str | None) -> str | None:
    if s is None:
        return None
    t = re.sub(r"\s+", " ", s).strip().casefold()
    return t or None


@dataclass(frozen=True)
class DedupDecision:
    feed_id: str
    kept: bool
    reason: str            # KEPT | DEDUP_REDIRECT | DEDUP_IDENTICAL_URL | DEDUP_IDENTICAL_CONTENT | DEDUP_ALIAS | DEDUP_MERGED_BUNDLE
    collapsed_into: str | None
    detail: str = ""


class _UF:
    def __init__(self, items):
        self.p = {i: i for i in items}

    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            lo, hi = sorted((ra, rb))
            self.p[hi] = lo


def _collapse(ids: list[str], key_of, reason: str, out: dict[str, DedupDecision]) -> list[str]:
    uf = _UF(ids)
    first: dict[object, str] = {}
    for fid in sorted(ids):
        k = key_of(fid)
        if k is None:
            continue
        if k in first:
            uf.union(first[k], fid)
        else:
            first[k] = fid
    survivors = []
    for fid in sorted(ids):
        root = uf.find(fid)
        if root == fid:
            survivors.append(fid)
        else:
            out[fid] = DedupDecision(fid, False, reason, root, f"key={key_of(fid)}")
    return survivors


def deduplicate(records: dict[str, FeedRecord], facts: dict[str, FeedFacts], eligible_ids: list[str],
                min_overlap: float) -> dict[str, DedupDecision]:
    out: dict[str, DedupDecision] = {}
    ids = sorted(set(eligible_ids))
    # 1. redirects
    survivors = []
    for fid in ids:
        if records[fid].redirects:
            tgt = sorted(records[fid].redirects)[0]
            out[fid] = DedupDecision(fid, False, "DEDUP_REDIRECT", tgt, f"redirects={sorted(records[fid].redirects)}")
        else:
            survivors.append(fid)
    survivors = _collapse(survivors, lambda f: normalize_url(records[f].producer_url), "DEDUP_IDENTICAL_URL", out)
    survivors = _collapse(survivors, lambda f: facts[f].latest_canonical_sha256, "DEDUP_IDENTICAL_CONTENT", out)
    survivors = _collapse(survivors, lambda f: (lambda p, n: (p, n) if p and n else None)(
        normalize_name(records[f].provider), normalize_name(records[f].feed_name)), "DEDUP_ALIAS", out)
    # 5. merged bundles (simultaneous over survivors)
    agencies: dict[str, frozenset[str]] = {}
    for f in survivors:
        summ = facts[f].latest_summary
        ids = summ.agency_ids if summ is not None else []
        agencies[f] = frozenset(a for a in ids if a)        # exact agency_id identity; blank ids are not identities
    dropped: dict[str, tuple[str, Fraction]] = {}
    for i, f in enumerate(survivors):
        for g in survivors[i + 1:]:
            A, B = agencies[f], agencies[g]
            if not A or not B or len(A) == len(B):
                continue
            ov = Fraction(len(A & B), min(len(A), len(B)))
            if ov >= Fraction(str(min_overlap)):
                big, small = (f, g) if len(A) > len(B) else (g, f)
                prev = dropped.get(big)
                # evidence partner: highest overlap, then smallest feed id (total order -> order independent)
                if prev is None or (-ov, small) < (-prev[1], prev[0]):
                    dropped[big] = (small, ov)
    for big, (small, ov) in sorted(dropped.items()):
        out[big] = DedupDecision(big, False, "DEDUP_MERGED_BUNDLE", small, f"overlap={ov.numerator}/{ov.denominator}")
    for f in survivors:
        if f not in out:
            out[f] = DedupDecision(f, True, "KEPT", None)
    return out
