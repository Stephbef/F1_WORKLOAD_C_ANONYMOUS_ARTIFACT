"""Feed-connectivity graph (spec 17 §3). An edge F_i–F_j exists iff ALL hold, on the logical versions in force at
2025-04-01: (a) >= 3 distinct stop pairs within 400 m; (b) convex hulls intersect or are <= 2 km apart;
(c) same agency_timezone. Every evaluated pair yields an audit record (region_connectivity_evidence.jsonl)."""
from __future__ import annotations

import math

from ..config.runtime import EffectiveConfig
from .model import Edge, FeedFacts
from .spatial import hull_criterion, stop_pairs_within


def evaluate_pair(cfg: EffectiveConfig, fa: FeedFacts, fb: FeedFacts) -> tuple[Edge | None, dict]:
    cn = cfg.spec["connectivity"]
    R = float(cfg.interp.p["earth_radius_m"])
    a, b = (fa, fb) if fa.feed_id < fb.feed_id else (fb, fa)
    sa, sb = a.in_force_summary, b.in_force_summary
    ev: dict = {"feed_a": a.feed_id, "feed_b": b.feed_id, "lv_a": a.in_force_lv, "lv_b": b.in_force_lv,
                "in_force_instant_utc": cfg.interp.p["in_force_instant_utc"]}
    reasons = []
    if sa is None or sb is None:
        ev.update({"decision": "NO_EDGE", "reasons": ["NO_VERSION_IN_FORCE"]})
        return None, ev
    tza, tzb = sa.timezone, sb.timezone
    # INT-04 (S2 correction): only boarding/alighting points (location_type blank or 0) are connectivity candidates;
    # stations, entrances, generic nodes and boarding areas never count as stop pairs nor shape the stop-set hull.
    pa, pb = sa.boarding_stops, sb.boarding_stops
    ev["n_boarding_points"] = [len(pa), len(pb)]
    if not pa or not pb:
        ev.update({"tz_a": tza, "tz_b": tzb, "tz_same": tza is not None and tza == tzb, "stop_pairs": 0,
                   "decision": "NO_EDGE", "reasons": ["NO_BOARDING_POINTS"]})
        return None, ev
    tz_same = tza is not None and tza == tzb
    ev.update({"tz_a": tza, "tz_b": tzb, "tz_same": tz_same})
    if tza is None or tzb is None:
        reasons.append("TIMEZONE_UNDEFINED")
    elif not tz_same:
        reasons.append("TIMEZONE_MISMATCH")
    # exact latitude-band lower bound: if the stop sets' latitude ranges are further apart than the threshold
    # (both pair and hull criteria), the pair counts are 0 and the hull distance exceeds the bound.
    lat_gap_deg = max(0.0, max(min(s.lat for s in pb) - max(s.lat for s in pa),
                               min(s.lat for s in pa) - max(s.lat for s in pb)))
    lat_gap_m = R * math.radians(lat_gap_deg)
    if lat_gap_m > max(cn["stop_pair_max_distance_m"], cn["hull_max_distance_m"]):
        n_pairs, hull_int, hull_d = 0, False, None
        sample: list[dict] = []
        ev["pruned_lat_gap_m"] = round(lat_gap_m, 3)
    else:
        n_pairs, sample = stop_pairs_within(pa, pb, cn["stop_pair_max_distance_m"], R)
        hull_int, hull_d = hull_criterion(pa, pb, R)
    ev.update({"stop_pairs": n_pairs, "stop_pair_sample": sample, "hull_intersects": hull_int,
               "hull_distance_m": None if hull_d is None else round(hull_d, 3)})
    if n_pairs < cn["min_stop_pairs"]:
        reasons.append("STOP_PAIRS_BELOW_THRESHOLD")
    hull_ok = hull_int or (hull_d is not None and hull_d <= cn["hull_max_distance_m"])
    ev["hull_ok"] = hull_ok
    if not hull_ok:
        reasons.append("HULL_TOO_FAR")
    if reasons:
        ev.update({"decision": "NO_EDGE", "reasons": reasons})
        return None, ev
    ev.update({"decision": "EDGE", "reasons": []})
    return Edge(a.feed_id, b.feed_id, n_pairs), ev


def build_graph(cfg: EffectiveConfig, facts: dict[str, FeedFacts], feed_ids: list[str]
                ) -> tuple[list[Edge], list[dict]]:
    ids = sorted(set(feed_ids))
    edges, evidence = [], []
    for i, f in enumerate(ids):
        for g in ids[i + 1:]:
            e, ev = evaluate_pair(cfg, facts[f], facts[g])
            evidence.append(ev)
            if e is not None:
                edges.append(e)
    return edges, evidence
