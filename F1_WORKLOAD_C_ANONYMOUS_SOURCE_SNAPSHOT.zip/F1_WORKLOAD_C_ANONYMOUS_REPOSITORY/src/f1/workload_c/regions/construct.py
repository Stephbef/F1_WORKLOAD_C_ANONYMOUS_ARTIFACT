"""Canonical region construction (spec 17 §3; weakest-edge order per V5 region rules).

Regions are connected components of the feed-connectivity graph with 2–8 feeds, every feed having >= 1 edge.
A component with > 8 feeds is split by repeatedly removing its weakest edge — fewest stop pairs, then smallest
feed ids (lexicographic (a, b)) — and recomputing components until every part has <= 8 feeds. Parts with one
feed are excluded (no edge). Regions whose total latest-ZIP size exceeds 500 MB are excluded. Region id:
'R:' + sorted feed ids joined by '+'. Output is independent of input order.
"""
from __future__ import annotations

from ..config.runtime import EffectiveConfig
from .model import Edge, Region


def region_id(spec, feed_ids: list[str]) -> str:
    rg = spec["region"]
    ids = sorted(set(feed_ids))
    if any((rg["region_id_separator"] in f) or not f for f in ids):
        raise ValueError("feed id contains the region-id separator or is empty")
    return rg["region_id_prefix"] + rg["region_id_separator"].join(ids)


def _components(nodes: set[str], edges: list[Edge]) -> list[list[str]]:
    adj: dict[str, set[str]] = {n: set() for n in nodes}
    for e in edges:
        if e.a in adj and e.b in adj:
            adj[e.a].add(e.b)
            adj[e.b].add(e.a)
    seen: set[str] = set()
    comps = []
    for n in sorted(nodes):
        if n in seen:
            continue
        stack, comp = [n], []
        seen.add(n)
        while stack:
            x = stack.pop()
            comp.append(x)
            for y in sorted(adj[x]):
                if y not in seen:
                    seen.add(y)
                    stack.append(y)
        comps.append(sorted(comp))
    return sorted(comps)


def split_oversized(component: list[str], edges: list[Edge], max_feeds: int) -> tuple[list[list[str]], list[dict]]:
    """Return final parts and the removal log for one component."""
    nodes = set(component)
    live = sorted((e for e in edges if e.a in nodes and e.b in nodes), key=Edge.key)
    work = [sorted(component)]
    final, log = [], []
    while work:
        part = work.pop(0)
        if len(part) <= max_feeds:
            final.append(part)
            continue
        pset = set(part)
        inside = [e for e in live if e.a in pset and e.b in pset]
        weakest = min(inside, key=Edge.key)
        live.remove(weakest)
        log.append({"removed_edge": [weakest.a, weakest.b], "stop_pairs": weakest.stop_pairs, "part_size": len(part)})
        work.extend(_components(pset, [e for e in live if e.a in pset and e.b in pset]))
        work.sort()
    return sorted(final), log


def construct_regions(cfg: EffectiveConfig, feed_ids: list[str], edges: list[Edge], zip_bytes: dict[str, int],
                      timezones: dict[str, str | None], license_classes: dict[str, str]
                      ) -> tuple[list[Region], list[dict]]:
    rg = cfg.spec["region"]
    limit = rg["max_total_latest_zip_mb"] * int(cfg.interp.p["megabyte_bytes"])
    nodes = set(feed_ids)
    edges = sorted({(e.a, e.b): e for e in edges if e.a in nodes and e.b in nodes}.values(), key=Edge.key)
    regions: list[Region] = []
    split_log: list[dict] = []
    for comp in _components(nodes, edges):
        parts, origin = [comp], "component"
        if len(comp) > rg["max_feeds"]:
            parts, log = split_oversized(comp, edges, rg["max_feeds"])
            origin = "split"
            split_log.append({"component": region_id(cfg.spec, comp), "n_feeds": len(comp), "removals": log,
                              "parts": [region_id(cfg.spec, p) for p in parts]})
        for part in parts:
            pset = set(part)
            pedges = [e for e in edges if e.a in pset and e.b in pset]
            rid = region_id(cfg.spec, part)
            total = sum(int(zip_bytes.get(f, 0)) for f in part)
            tzs = sorted({timezones.get(f) or "" for f in part})
            deg = {f: 0 for f in part}
            for e in pedges:
                deg[e.a] += 1
                deg[e.b] += 1
            status, reason = "ELIGIBLE", "ELIGIBLE"
            if len(part) < rg["min_feeds"]:
                status, reason = "EXCLUDED", "REGION_SINGLETON_NO_EDGE" if origin == "component" else "SPLIT_PART_SINGLETON"
            elif len(part) > rg["max_feeds"]:  # unreachable after splitting; kept as a guard
                status, reason = "EXCLUDED", "REGION_TOO_MANY_FEEDS"
            elif any(d < rg["min_edges_per_feed"] for d in deg.values()):
                status, reason = "EXCLUDED", "FEED_WITHOUT_EDGE"
            elif total > limit:
                status, reason = "EXCLUDED", "REGION_ZIP_SIZE_EXCEEDED"
            elif len(tzs) != 1 or not tzs[0]:
                status, reason = "EXCLUDED", "REGION_TIMEZONE_INCONSISTENT"
            regions.append(Region(region_id=rid, feed_ids=sorted(part), timezone=tzs[0] if len(tzs) == 1 else None,
                                  edges=pedges, total_latest_zip_bytes=total, status=status, reason=reason,
                                  origin=origin, license_classes=[license_classes.get(f, "") for f in sorted(part)]))
    regions.sort(key=lambda r: r.region_id)
    return regions, split_log
