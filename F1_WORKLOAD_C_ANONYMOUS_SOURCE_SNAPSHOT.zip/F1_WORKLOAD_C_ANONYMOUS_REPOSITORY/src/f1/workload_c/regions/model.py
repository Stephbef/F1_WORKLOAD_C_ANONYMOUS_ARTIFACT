"""Typed feed/region records shared by the eligibility, dedup, connectivity and region engines."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

from ..ingestion.gtfs import GtfsSummary


@dataclass(frozen=True)
class FeedRecord:
    """Catalog metadata of one feed (from the Mobility snapshot)."""
    feed_id: str
    metadata_valid: bool
    metadata_errors: tuple[str, ...]
    status: str | None
    authentication_type: int | None
    producer_url: str | None
    provider: str | None
    feed_name: str | None
    redirects: tuple[str, ...]
    license_url: str | None
    license_id: str | None
    data_type: str | None = "gtfs"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["metadata_errors"] = list(self.metadata_errors)
        d["redirects"] = list(self.redirects)
        return d


@dataclass
class FeedFacts:
    """Content-derived facts of one feed used by the region rules."""
    feed_id: str
    latest_lv: str | None = None
    latest_canonical_sha256: str | None = None
    latest_zip_bytes: int | None = None
    in_force_lv: str | None = None
    in_force_canonical_sha256: str | None = None
    latest_summary: GtfsSummary | None = None
    in_force_summary: GtfsSummary | None = None
    bbox_diagonal_m: float | None = None
    history_ok: bool = False
    history_reason: str | None = None
    max_gap_days: float | None = None
    malformed_reason: str | None = None
    archive_failures: int = 0
    n_archives_ok: int = 0
    n_logical_versions: int = 0

    def audit(self) -> dict:
        return {"feed_id": self.feed_id, "latest_lv": self.latest_lv, "latest_canonical_sha256":
                self.latest_canonical_sha256, "latest_zip_bytes": self.latest_zip_bytes, "in_force_lv": self.in_force_lv,
                "bbox_diagonal_m": None if self.bbox_diagonal_m is None else round(self.bbox_diagonal_m, 3),
                "history_ok": self.history_ok, "history_reason": self.history_reason,
                "max_gap_days": None if self.max_gap_days is None else round(self.max_gap_days, 6),
                "malformed_reason": self.malformed_reason, "archive_failures": self.archive_failures,
                "n_archives_ok": self.n_archives_ok, "n_logical_versions": self.n_logical_versions,
                "in_force_timezone": self.in_force_summary.timezone if self.in_force_summary else None}


@dataclass
class FeedDecision:
    feed_id: str
    eligible: bool
    reasons: list[str] = field(default_factory=list)

    @property
    def primary_reason(self) -> str:
        return self.reasons[0] if self.reasons else "ELIGIBLE"


@dataclass(frozen=True)
class Edge:
    a: str
    b: str
    stop_pairs: int

    def key(self) -> tuple[int, str, str]:
        return (self.stop_pairs, self.a, self.b)


@dataclass
class Region:
    region_id: str
    feed_ids: list[str]
    timezone: str | None
    edges: list[Edge]
    total_latest_zip_bytes: int
    status: str                 # ELIGIBLE | EXCLUDED
    reason: str
    origin: str                 # "component" | "split"
    license_classes: list[str] = field(default_factory=list)

    def to_row(self) -> dict:
        return {"region_id": self.region_id, "n_feeds": len(self.feed_ids), "feed_ids": ";".join(self.feed_ids),
                "timezone": self.timezone or "", "total_latest_zip_bytes": self.total_latest_zip_bytes,
                "n_edges": len(self.edges), "min_edge_stop_pairs": min((e.stop_pairs for e in self.edges), default=0),
                "license_classes": ";".join(self.license_classes), "origin": self.origin, "status": self.status,
                "reason": self.reason}
