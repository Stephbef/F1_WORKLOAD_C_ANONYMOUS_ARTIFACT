"""Resumable, idempotent snapshot support: a caching Transport wrapper.

Successful (2xx) GET responses are stored immutably in the BlobStore and indexed by SHA-256 of the request key
("GET <url>"; credentials are headers and never part of the key). After an interruption, a resumed snapshot is
served from the cache for every request that already completed, so completed work is never re-fetched and the
final snapshot content is identical to an uninterrupted run.
"""
from __future__ import annotations

import json
from pathlib import Path

from ...common.util import canonical_json, sha256_bytes
from ..storage.blobstore import BlobStore
from .transport import HttpResponse, Transport


class CachingTransport:
    def __init__(self, inner: Transport, blobs: BlobStore, index_dir: str | Path, clock,
                 crash_after_fetches: int | None = None) -> None:
        self.inner = inner
        self.blobs = blobs
        self.index = Path(index_dir)
        self.index.mkdir(parents=True, exist_ok=True)
        self.clock = clock
        self.hits = 0
        self.misses = 0
        self._crash_after = crash_after_fetches

    def _key_path(self, method: str, url: str) -> Path:
        return self.index / (sha256_bytes(f"{method} {url}".encode()) + ".json")

    def request(self, method: str, url: str, headers: dict, body: bytes | None, timeout_s: float) -> HttpResponse:
        kp = self._key_path(method, url)
        if method == "GET" and kp.exists():
            ent = json.loads(kp.read_text(encoding="utf-8"))
            self.hits += 1
            data = self.blobs.get(ent["blob_sha256"])
            return HttpResponse(ent["status"], {**ent["headers"], "x-f1-cache": "hit",
                                                "x-f1-retrieved-utc": ent["retrieved_utc"]}, data)
        if self._crash_after is not None and self.misses >= self._crash_after:
            raise SimulatedInterruption(f"simulated interruption after {self.misses} fetches")
        resp = self.inner.request(method, url, headers, body, timeout_s)
        if method == "GET" and 200 <= resp.status < 300:
            self.misses += 1
            ref = self.blobs.put(resp.body, "application/octet-stream",
                                 provenance={"request": f"{method} {url}", "status": resp.status})
            keep = {k: v for k, v in resp.headers.items() if k.lower() in ("content-type", "etag", "last-modified")}
            ent = {"request": f"{method} {url}", "status": resp.status, "headers": keep, "blob_sha256": ref.sha256,
                   "retrieved_utc": self.clock.now()}
            body_b = canonical_json(ent).encode()
            if not kp.exists():
                tmp = kp.with_suffix(".tmp")
                tmp.write_bytes(body_b)
                tmp.replace(kp)
            return HttpResponse(resp.status, {**resp.headers, "x-f1-cache": "miss",
                                              "x-f1-retrieved-utc": ent["retrieved_utc"]}, resp.body)
        return resp


class SimulatedInterruption(RuntimeError):
    """Raised (FIXTURE/tests only) to simulate a process interruption mid-snapshot."""
