"""HTTP transport abstraction. The Mobility client only talks to a `Transport`; real mode uses
`UrllibTransport` (stdlib, bounded timeout), FIXTURE mode uses `api.mock.MockMobilityServer` through the very
same client code path."""
from __future__ import annotations

import socket
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Protocol


@dataclass(frozen=True)
class HttpResponse:
    status: int
    headers: dict = field(default_factory=dict)
    body: bytes = b""


class TransportFailure(Exception):
    """Connection failure or timeout (no HTTP status)."""


class Transport(Protocol):
    def request(self, method: str, url: str, headers: dict, body: bytes | None, timeout_s: float) -> HttpResponse: ...


class UrllibTransport:
    """Real network transport. Never used by Session-1 tests (real mode refuses before constructing it)."""

    def request(self, method: str, url: str, headers: dict, body: bytes | None, timeout_s: float) -> HttpResponse:
        req = urllib.request.Request(url, data=body, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout_s) as r:  # noqa: S310 - https enforced by config
                return HttpResponse(r.status, {k.lower(): v for k, v in r.headers.items()}, r.read())
        except urllib.error.HTTPError as e:
            return HttpResponse(e.code, {k.lower(): v for k, v in (e.headers or {}).items()}, e.read() or b"")
        except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError) as e:
            raise TransportFailure(type(e).__name__) from None


class Sleeper(Protocol):
    def sleep(self, seconds: float) -> None: ...


class RealSleeper:
    def sleep(self, seconds: float) -> None:
        import time
        time.sleep(seconds)


class RecordingSleeper:
    """Deterministic sleeper for FIXTURE/tests: records requested delays without waiting."""

    def __init__(self) -> None:
        self.calls: list[float] = []

    def sleep(self, seconds: float) -> None:
        self.calls.append(float(seconds))
