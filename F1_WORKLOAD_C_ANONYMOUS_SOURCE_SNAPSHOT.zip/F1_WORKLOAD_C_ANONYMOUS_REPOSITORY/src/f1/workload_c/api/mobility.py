"""Mobility Database client (API v1 shape) — real interface, exercised in Session 1 only through mocks.

Credential: MOBILITY_DB_TOKEN via a SecretProvider (refresh token exchanged at POST {base}/tokens for an access
token, or used directly as a bearer token). The Authorization header is attached ONLY to requests whose host
equals the API base host — never to archive file hosts. Tokens are never logged or persisted.

Error classification: 401 -> MobilityUnauthenticated (one token refresh is attempted in exchange mode),
403 -> MobilityForbidden, 404 -> MobilityNotFound, 429 -> bounded retry honouring integer Retry-After up to
max_retry_after_s (else MobilityRateLimited), 5xx / transport failures -> bounded deterministic exponential
backoff (base * factor^(n-1), capped), malformed JSON / shape -> MobilityMalformedResponse, other 4xx ->
MobilityClientError. Pagination is offset/limit with duplicate detection (identical duplicates are recorded as
anomalies; conflicting duplicates or a repeated page raise MobilityPaginationError). Every final response body
can be preserved verbatim in the BlobStore with its SHA-256 (raw response preservation).
"""
from __future__ import annotations

import json
import urllib.parse
from dataclasses import dataclass, field
from typing import Callable

from ...common.util import canonical_json, sha256_bytes
from ..errors import (MobilityClientError, MobilityForbidden, MobilityMalformedResponse, MobilityNotFound,
                      MobilityPaginationError, MobilityRateLimited, MobilityServerError, MobilityTransportError,
                      MobilityUnauthenticated, SourceLocatorError)
from ..security.secrets import REDACTOR, SecretProvider
from .transport import HttpResponse, Sleeper, Transport, TransportFailure

MAX_PAGES = 100000


@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int
    base_delay_s: float
    factor: float
    max_delay_s: float
    max_retry_after_s: float

    def backoff(self, attempt: int) -> float:
        return min(self.max_delay_s, self.base_delay_s * (self.factor ** (attempt - 1)))


@dataclass
class ResponseRecord:
    method: str
    url: str                 # redacted, no credentials
    status: int
    body: bytes
    sha256: str
    attempts: int
    retrieved_utc: str
    blob_sha256: str | None = None


@dataclass
class ClientStats:
    requests: int = 0
    retries: int = 0
    sleeps: list = field(default_factory=list)
    anomalies: list = field(default_factory=list)


class MobilityClient:
    def __init__(self, mobility_cfg: dict, secrets: SecretProvider, transport: Transport, sleeper: Sleeper,
                 clock, recorder: Callable[[ResponseRecord], str | None] | None = None) -> None:
        self.base = mobility_cfg["base_url"].rstrip("/")
        self.base_host = urllib.parse.urlsplit(self.base).hostname
        self.auth_mode = mobility_cfg["auth_mode"]
        self.page_limit = int(mobility_cfg["page_limit"])
        self.timeout = float(mobility_cfg["timeout_s"])
        r = mobility_cfg["retry"]
        self.retry = RetryPolicy(int(r["max_attempts"]), float(r["base_delay_s"]), float(r["factor"]),
                                 float(r["max_delay_s"]), float(r["max_retry_after_s"]))
        self.token_env = mobility_cfg["token_env"]
        self.require_token = bool(mobility_cfg["require_token"])
        self.secrets = secrets
        self.transport = transport
        self.sleeper = sleeper
        self.clock = clock
        self.recorder = recorder
        self._access: str | None = None
        self.stats = ClientStats()

    # --- auth --------------------------------------------------------------------------------------------
    def _token(self, force_refresh: bool = False) -> str | None:
        if self._access is not None and not force_refresh:
            return self._access
        sec = self.secrets.get(self.token_env, required=self.require_token)
        if sec is None:
            return None
        if self.auth_mode == "bearer":
            self._access = sec.reveal()
            return self._access
        resp = self._send("POST", f"{self.base}/tokens", {"Content-Type": "application/json"},
                          json.dumps({"refresh_token": sec.reveal()}).encode(), auth=False, record=False)
        try:
            tok = json.loads(resp.body)["access_token"]
            if not isinstance(tok, str) or not tok:
                raise KeyError
        except (ValueError, KeyError, TypeError):
            raise MobilityMalformedResponse("token endpoint returned no access_token") from None
        REDACTOR.register(tok)
        self._access = tok
        return tok

    # --- core request with retries -----------------------------------------------------------------------
    def _send(self, method: str, url: str, headers: dict | None = None, body: bytes | None = None,
              auth: bool = True, record: bool = True, refreshed: bool = False) -> ResponseRecord:
        safe_url = REDACTOR.redact_text(url)
        host = urllib.parse.urlsplit(url).hostname
        attempt = 0
        last_exc: Exception | None = None
        while attempt < self.retry.max_attempts:
            attempt += 1
            h = {"Accept": "application/json", "User-Agent": "f1-workload-c/0.1"}
            h.update(headers or {})
            if auth and host == self.base_host:
                tok = self._token()
                if tok:
                    h["Authorization"] = f"Bearer {tok}"
            self.stats.requests += 1
            try:
                resp: HttpResponse = self.transport.request(method, url, h, body, self.timeout)
            except TransportFailure as e:
                last_exc = MobilityTransportError(f"transport failure on {method} {safe_url}: {e}", url=safe_url)
                if attempt < self.retry.max_attempts:
                    self._sleep(self.retry.backoff(attempt))
                    continue
                raise last_exc from None
            st = resp.status
            if 200 <= st < 300:
                rec = ResponseRecord(method, safe_url, st, resp.body, sha256_bytes(resp.body), attempt, self.clock.now())
                if record and self.recorder is not None:
                    rec.blob_sha256 = self.recorder(rec)
                return rec
            if st == 401:
                if auth and self.auth_mode == "refresh_token_exchange" and not refreshed and host == self.base_host \
                        and self._access is not None:
                    self._token(force_refresh=True)
                    return self._send(method, url, headers, body, auth, record, refreshed=True)
                raise MobilityUnauthenticated(f"401 Unauthorized on {method} {safe_url}", url=safe_url)
            if st == 403:
                raise MobilityForbidden(f"403 Forbidden on {method} {safe_url}", url=safe_url)
            if st == 404:
                raise MobilityNotFound(f"404 Not Found on {method} {safe_url}", url=safe_url)
            if st == 429:
                ra = _retry_after(resp.headers)
                if ra is not None and ra > self.retry.max_retry_after_s:
                    raise MobilityRateLimited(f"429 with Retry-After {ra}s beyond cap on {safe_url}", url=safe_url,
                                              retry_after=ra)
                last_exc = MobilityRateLimited(f"429 Too Many Requests on {method} {safe_url}", url=safe_url)
                if attempt < self.retry.max_attempts:
                    self._sleep(ra if ra is not None else self.retry.backoff(attempt))
                    continue
                raise last_exc
            if 500 <= st < 600:
                last_exc = MobilityServerError(f"{st} server error on {method} {safe_url}", url=safe_url, status=st)
                if attempt < self.retry.max_attempts:
                    self._sleep(self.retry.backoff(attempt))
                    continue
                raise last_exc
            raise MobilityClientError(f"{st} client error on {method} {safe_url}", url=safe_url, status=st)
        raise last_exc or MobilityTransportError("retry budget exhausted")  # pragma: no cover

    def _sleep(self, s: float) -> None:
        self.stats.retries += 1
        self.stats.sleeps.append(s)
        self.sleeper.sleep(s)

    # --- JSON helpers ------------------------------------------------------------------------------------
    def get_json(self, path: str, params: dict | None = None) -> tuple[object, ResponseRecord]:
        q = ("?" + urllib.parse.urlencode(sorted(params.items()))) if params else ""
        rec = self._send("GET", f"{self.base}{path}{q}")
        try:
            return json.loads(rec.body.decode("utf-8")), rec
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            raise MobilityMalformedResponse(f"malformed JSON from {rec.url}: {type(e).__name__}", url=rec.url) from None

    def paginate(self, path: str, id_key: str = "id") -> tuple[list[dict], list[ResponseRecord]]:
        items: list[dict] = []
        by_id: dict[str, str] = {}
        records: list[ResponseRecord] = []
        offset, prev_page = 0, None
        for _ in range(MAX_PAGES):
            page, rec = self.get_json(path, {"limit": self.page_limit, "offset": offset})
            records.append(rec)
            if isinstance(page, dict) and isinstance(page.get("results"), list):
                page = page["results"]
            if not isinstance(page, list) or not all(isinstance(x, dict) for x in page):
                raise MobilityMalformedResponse(f"page at offset {offset} of {path} is not a list of objects")
            if page and prev_page is not None and canonical_json(page) == prev_page:
                raise MobilityPaginationError(f"repeated page at offset {offset} of {path}")
            for x in page:
                xid = x.get(id_key)
                if not isinstance(xid, str) or not xid:
                    self.stats.anomalies.append({"path": path, "offset": offset, "anomaly": "RECORD_WITHOUT_ID"})
                    continue
                body = canonical_json(x)
                if xid in by_id:
                    if by_id[xid] != body:
                        raise MobilityPaginationError(f"conflicting duplicate record {xid} in {path}")
                    self.stats.anomalies.append({"path": path, "id": xid, "anomaly": "DUPLICATE_IDENTICAL_RECORD"})
                    continue
                by_id[xid] = body
                items.append(x)
            if len(page) < self.page_limit:
                return items, records
            prev_page = canonical_json(page)
            offset += self.page_limit
        raise MobilityPaginationError(f"pagination did not terminate for {path}")

    # --- API surface ---------------------------------------------------------------------------------------
    def list_gtfs_feeds(self) -> tuple[list[dict], list[ResponseRecord]]:
        return self.paginate("/gtfs_feeds")

    def list_datasets(self, feed_id: str) -> tuple[list[dict], list[ResponseRecord]]:
        return self.paginate(f"/gtfs_feeds/{urllib.parse.quote(feed_id, safe='')}/datasets")

    def download(self, hosted_url: str) -> ResponseRecord:
        if not isinstance(hosted_url, str) or not hosted_url.startswith("https://"):
            raise SourceLocatorError("dataset has no valid https hosted_url")
        try:
            return self._send("GET", hosted_url, {"Accept": "application/zip"}, record=False)
        except (MobilityNotFound, MobilityForbidden, MobilityClientError, MobilityServerError,
                MobilityTransportError, MobilityRateLimited) as e:
            raise SourceLocatorError(f"archive retrieval failed ({e.error_class})", url=REDACTOR.redact_text(hosted_url),
                                     cause=e.error_class) from None


def _retry_after(headers: dict) -> float | None:
    v = {str(k).lower(): v for k, v in (headers or {}).items()}.get("retry-after")
    if v is None:
        return None
    try:
        f = float(str(v).strip())
        return f if f >= 0 else None
    except ValueError:
        return None   # HTTP-date form: fall back to deterministic backoff
