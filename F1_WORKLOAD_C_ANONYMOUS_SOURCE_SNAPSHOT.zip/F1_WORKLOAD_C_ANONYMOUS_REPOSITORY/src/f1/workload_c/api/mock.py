"""Deterministic Mobility Database mock server, reached through the normal `Transport` interface.

It implements POST /tokens (refresh -> access token), GET /gtfs_feeds, GET /gtfs_feeds/{id}/datasets
(offset/limit pagination over a stable order), and archive file hosting. Fault scripts inject per-route status
sequences (401, 403, 404, 429 with Retry-After, 5xx, malformed JSON, transport failure) deterministically.
The server validates Authorization on API routes and records a call log WITHOUT credentials.
"""
from __future__ import annotations

import json
import urllib.parse
from dataclasses import dataclass, field

from .transport import HttpResponse, TransportFailure


@dataclass
class Fault:
    status: int | None = None          # None + transport=True -> TransportFailure
    headers: dict = field(default_factory=dict)
    body: bytes = b""
    transport: bool = False


class MockMobilityServer:
    def __init__(self, base_url: str, catalog: list[dict], datasets: dict[str, list[dict]], files: dict[str, bytes],
                 missing_files: set[str] | None = None, refresh_token: str | None = None,
                 forbidden_tokens: set[str] | None = None) -> None:
        self.base = base_url.rstrip("/")
        u = urllib.parse.urlsplit(self.base)
        self.api_host, self.api_path = u.hostname, u.path
        self.catalog = list(catalog)
        self.datasets = {k: list(v) for k, v in datasets.items()}
        self.files = dict(files)
        self.missing = set(missing_files or ())
        self.refresh_token = refresh_token
        self.forbidden_tokens = set(forbidden_tokens or ())
        self.faults: dict[str, list[Fault]] = {}
        self.calls: list[dict] = []
        self._issued: set[str] = set()
        self._n_issued = 0
        self.saw_auth_on_file_host = False

    # fault scripting ----------------------------------------------------------------------------------------
    def script(self, route_prefix: str, faults: list[Fault]) -> None:
        self.faults.setdefault(route_prefix, []).extend(faults)

    def _take_fault(self, route: str) -> Fault | None:
        for prefix in sorted(self.faults, key=len, reverse=True):
            if route.startswith(prefix) and self.faults[prefix]:
                return self.faults[prefix].pop(0)
        return None

    # transport interface --------------------------------------------------------------------------------------
    def request(self, method: str, url: str, headers: dict, body: bytes | None, timeout_s: float) -> HttpResponse:
        assert timeout_s > 0
        u = urllib.parse.urlsplit(url)
        route = f"{method} {u.path}"
        resp = self._handle(method, u, route, headers, body)
        self.calls.append({"method": method, "host": u.hostname, "path": u.path, "query": u.query,
                           "status": None if resp is None else resp.status})
        if resp is None:
            raise TransportFailure("mock transport failure")
        return resp

    def _json(self, status: int, obj: object) -> HttpResponse:
        return HttpResponse(status, {"content-type": "application/json"}, json.dumps(obj, sort_keys=True).encode())

    def _handle(self, method: str, u, route: str, headers: dict, body: bytes | None) -> HttpResponse | None:
        f = self._take_fault(route)
        if f is not None:
            if f.transport:
                return None
            return HttpResponse(int(f.status or 500), dict(f.headers), f.body)
        if u.hostname != self.api_host:
            if any(k.lower() == "authorization" for k in headers):
                self.saw_auth_on_file_host = True
            url = urllib.parse.urlunsplit(u)
            if url in self.missing or url not in self.files:
                return HttpResponse(404, {}, b"not found")
            return HttpResponse(200, {"content-type": "application/zip"}, self.files[url])
        path = u.path[len(self.api_path):]
        if method == "POST" and path == "/tokens":
            try:
                rt = json.loads(body or b"{}").get("refresh_token")
            except ValueError:
                return self._json(400, {"error": "bad request"})
            if self.refresh_token is None or rt != self.refresh_token:
                return self._json(401, {"error": "invalid refresh token"})
            self._n_issued += 1
            tok = f"mock-access-{self._n_issued:04d}-" + "x" * 16
            self._issued.add(tok)
            return self._json(200, {"access_token": tok, "token_type": "Bearer", "expires_in": 3600})
        if self.refresh_token is not None:
            auth = {k.lower(): v for k, v in headers.items()}.get("authorization", "")
            tok = auth[7:] if auth.startswith("Bearer ") else ""
            if tok in self.forbidden_tokens:
                return self._json(403, {"error": "forbidden"})
            if tok not in self._issued:
                return self._json(401, {"error": "unauthorized"})
        if method != "GET":
            return self._json(405, {"error": "method"})
        q = dict(urllib.parse.parse_qsl(u.query))
        try:
            limit, offset = int(q.get("limit", "100")), int(q.get("offset", "0"))
        except ValueError:
            return self._json(400, {"error": "bad pagination"})
        if path == "/gtfs_feeds":
            return self._json(200, self.catalog[offset: offset + limit])
        parts = path.strip("/").split("/")
        if len(parts) == 3 and parts[0] == "gtfs_feeds" and parts[2] == "datasets":
            fid = urllib.parse.unquote(parts[1])
            if fid not in self.datasets:
                return self._json(404, {"error": "feed not found"})
            ds = sorted(self.datasets[fid], key=lambda d: (str(d.get("downloaded_at", "")), str(d.get("id", ""))))
            return self._json(200, ds[offset: offset + limit])
        return self._json(404, {"error": "no route"})

    def revoke_all(self) -> None:
        """Simulate access-token expiry (next API call returns 401 -> client refreshes)."""
        self._issued.clear()
