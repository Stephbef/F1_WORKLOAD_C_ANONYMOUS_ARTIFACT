"""ReplayEngine (docs/pre_s3/12 §1). Recomputes every decision from the SEALED inputs with the same engines:
- every sealed file is verified against the SealedLedger digests first and only ever read (never written);
- region state, shared catalog, contracts, cost ledger and schedule are reconstructed in memory;
- each arm is replayed in tick order on a fresh in-memory overlay; re-derivations are NOT re-executed: a recorded-
  outcome rederiver returns the recorded step and inserts the recorded overlay instance (with its recorded birth time);
- binding only sees instances born <= t and est(s,t) only shared runs completed < t (no future events);
- logical fields (action, mode, witness cut, bindings, verdicts, rederivation outcomes, OPT values, failures,
  exclusions, root changes, estimates) must be identical → REPRODUCED, else NOT_REPRODUCED.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from ..catalog.artifacts import ArtifactCatalog, ArtifactEntry
from ..contracts.generators import ContractSystem
from ..contracts.model import Contract
from ..history.realized import RealizedHistory
from ..interfaces import session3 as S
from ..storage.blobstore import BlobStore
from .baselines_n import N1BaselineImpl, N5BaselineImpl
from .core import (ARTIFACT_OUTCOMES, CostModelImpl, CurrentCutEvaluatorImpl, CurrentCutRederiverImpl,
                   CutContextFactoryImpl, EngineError, GammaAdmissibilityImpl, MethodCatalog, RegionState, TimedEvaluator,
                   VersionInfo, bind_request, estimates_for, local_date, prior_view)
from .f1 import AdmissionEngineImpl, RepairEngineImpl, WitnessSearchImpl
from .runner import root_changes_at
from .stats import RawExportLog, StatisticsExporterImpl, record_to_json

LOGICAL = ("provenance_binding", "action", "mode", "witness_cut_id", "bound_artifacts", "contract_verdicts", "opt_current", "opt_hist",
           "failures", "excluded", "exclusion_reason", "root_changes", "estimates", "current_cut_id", "request_slots")


def logical_view(rec: dict) -> dict:
    rec = {**rec, "provenance_binding": [p for p in rec["provenance_digests"] if p.startswith("binding:")]}
    out = {k: rec[k] for k in LOGICAL}
    out["rederivations"] = [[s["slot_id"], s["target_cut_id"], s["outcome"], s["new_artifact_id"]]
                            for s in rec["rederivations"]]
    out["producer_costs"] = sorted([i["component"], i["slot_id"], i["producer_outcome"], i["wall_s"], i["cpu_s"]]
                                   for i in rec["costs"]["items"] if i["category"] == "A_PRODUCER")
    return out


def _load_catalog(path: Path) -> ArtifactCatalog:
    cat = ArtifactCatalog(None)
    if path.exists():
        from ..state.journal import AppendOnlyJournal
        for r in AppendOnlyJournal(path).records():
            f = {k: (tuple(tuple(x) if isinstance(x, list) else x for x in v) if isinstance(v, list) else v)
                 for k, v in r["entry"].items()}
            cat._insert(ArtifactEntry(**f), persist=False)  # type: ignore[arg-type]
    return cat


class _RecordedRederiver:
    """Returns recorded steps; inserts the recorded overlay instance (never re-executes a producer)."""
    def __init__(self, mc: MethodCatalog, sealed_overlay: ArtifactCatalog, sealed_born: dict, contracts: dict) -> None:
        self.mc, self.sealed, self.born, self.contracts = mc, sealed_overlay, sealed_born, contracts
        self.recorded: dict = {}

    def load(self, rec: dict) -> None:
        self.recorded = {(s["slot_id"], s["target_cut_id"]): s for s in rec["rederivations"] if s["outcome"] is not None}
        self.recorded_cpu = {(i["slot_id"], i["producer_outcome"]): i["cpu_s"] for i in rec["costs"]["items"]
                             if i["category"] == "A_PRODUCER" and i["component"].startswith("producer:")}

    def cpu_of(self, step, tick_utc=None) -> float:
        return float(self.recorded_cpu.get((step.slot_id, step.outcome), step.measured_wall_s or 0.0))

    def rederive(self, slot_id, cut, tick_utc, estimate_s) -> S.RederivationStep:
        s = self.recorded.get((slot_id, cut.cut_id))
        if s is None:
            raise EngineError(f"replay diverged: step {slot_id}@{cut.cut_id} was not recorded")
        if s["outcome"] in ARTIFACT_OUTCOMES and s["new_artifact_id"]:
            e = self.sealed.get(s["new_artifact_id"])
            self.mc.overlay._insert(e, persist=False)
            self.mc.overlay_born[e.artifact_id] = self.born[e.artifact_id]
            self.mc.contracts[e.artifact_id] = self.contracts.get(e.artifact_id, ())
        return S.RederivationStep(slot_id, cut.cut_id, s["producer_class"], estimate_s, s["outcome"],
                                  s["new_artifact_id"], s["provenance_digest"], s["measured_wall_s"])


class _RecordedNative:
    def __init__(self, holder: dict) -> None:
        self.holder = holder
        self.preprocessing: dict = {}
        self.last_cpu_s: float | None = None

    def build(self, view):
        rec = self.holder["r"]
        s = [x for x in rec["rederivations"] if x["slot_id"].startswith("ROUTER:") and x["outcome"] is not None][0]
        self.last_cpu_s = next((float(i["cpu_s"]) for i in rec["costs"]["items"]
                                if i["component"] == "producer:otp-native"), None)
        step = S.RederivationStep(s["slot_id"], s["target_cut_id"], "otp", s["estimate_s"], s["outcome"],
                                  s["new_artifact_id"], s["provenance_digest"], s["measured_wall_s"])
        st = view.native_state
        new = S.NativeOtpState(st.region_id, st.street_graph_path, st.street_graph_sha256, st.cache_dir,
                               st.cache_manifest_sha256, st.envelope_digest,
                               tuple(view.current_router_inputs) if s["outcome"] in ARTIFACT_OUTCOMES else
                               st.last_success_inputs,
                               "replayed" if s["outcome"] in ARTIFACT_OUTCOMES else st.last_success_graph_sha256)
        return step, new, (("mode", "REPLAY"),)


class ReplayEngineImpl:
    def __init__(self, gtfs_names: frozenset[str]) -> None:
        self.names = gtfs_names
        self.files_read: list[str] = []

    def _verify(self, ledger: S.SealedLedger) -> dict:
        paths = {k: v for k, v in ledger.paths if not k.startswith("sha256:")}
        digests = {k[len("sha256:"):]: v for k, v in ledger.paths if k.startswith("sha256:")}
        for name, p in paths.items():
            if hashlib.sha256(Path(p).read_bytes()).hexdigest() != digests[name]:
                raise EngineError(f"sealed input {name} changed after sealing")
        def fsha(name: str) -> str:
            return hashlib.sha256(Path(paths[name]).read_bytes()).hexdigest()
        # every top-level SEMANTIC digest of the SealedLedger is checked against its file (fail closed before replay)
        checks = {"history_journal_sha256": ("history.jsonl", ledger.history_journal_sha256),
                  "contracts_sha256": ("contracts.jsonl", ledger.contracts_sha256),
                  "raw_export_sha256": ("raw_export.jsonl", ledger.raw_export_sha256),
                  "cost_ledger_sha256": ("cost_ledger.jsonl", ledger.cost_ledger_sha256)}
        for field, (name, want) in checks.items():
            if name not in paths or fsha(name) != want:
                raise EngineError(f"SealedLedger.{field} does not match the sealed {name}")
        for cat_name, want in ledger.catalog_journal_sha256s:
            fn = "catalog_shared.jsonl" if cat_name == "shared" else f"overlay_{cat_name}.jsonl"
            if fn not in paths or fsha(fn) != want:
                raise EngineError(f"SealedLedger.catalog_journal_sha256s[{cat_name}] does not match {fn}")
        return paths

    @staticmethod
    def _source_events(rec, region, cut, shared, shared_born, hist, lv_event, born_event, tick_event) -> tuple:
        """Sealed RealizedHistory EVENT ids establishing the decision: consumer tick, availability of every version of
        the current (and witness) cut, ARTIFACT_BORN (+ its producer completion / derivation predecessors) of every
        bound SHARED artifact. On-demand overlay instances have no schedule event (their provenance is in the raw
        record)."""
        ids = set()
        if rec["tick_utc"] in tick_event:
            ids.add(tick_event[rec["tick_utc"]])
        frontiers = [dict(cut.frontier)]
        for fr in frontiers:
            for f, i in fr.items():
                if (f, i) in lv_event:
                    ids.add(lv_event[(f, i)])
        if rec["witness_cut_id"]:
            from ..history.realized import Cut
            from itertools import product
            feeds = sorted(region.feeds)
            choices = [[i for (ff, i) in region.versions if ff == f] for f in feeds]
            for combo in product(*choices):
                c = Cut.of(region.region_id, dict(zip(feeds, combo, strict=True)))
                if c.cut_id == rec["witness_cut_id"]:
                    ids |= {lv_event[(f, i)] for f, i in c.frontier if (f, i) in lv_event}
        for _slot, aid in rec["bound_artifacts"]:
            if aid and aid in shared_born:
                e = shared.get(aid)
                be = born_event.get((e.request_slot, shared_born[aid]))
                if be:
                    ids.add(be)
                    ids |= set(hist.events[be].preds)
        missing = [i for i in ids if i not in hist.events]
        if missing:
            raise EngineError("source event not in the sealed history")
        return tuple(sorted(ids))

    def replay(self, ledger: S.SealedLedger, records: tuple[S.RawExportRecord, ...]) -> S.ReplayReport:
        paths = self._verify(ledger)
        base = Path(paths["region.json"]).parent
        rj = json.loads(Path(paths["region.json"]).read_text())
        blobs = BlobStore(rj["blob_root"])
        versions = {(v["feed_id"], v["index"]): VersionInfo(**v) for v in rj["versions"]}
        region = RegionState(rj["region_id"], rj["tz"], tuple(rj["feeds"]), versions, rj["osm_sha256"],
                             rj["semantic_config_digest"], rj["otp_sha256"], rj["validator_sha256"], rj["country"], blobs,
                             rj["namespace"])
        shared = _load_catalog(Path(paths["catalog_shared.jsonl"]))
        shared_born = json.loads(Path(paths["shared_born.json"]).read_text())
        contracts: dict = {}
        for ln in Path(paths["contracts.jsonl"]).read_text().splitlines():
            r = json.loads(ln)
            body = json.loads(r["contract"])
            c = Contract.build(body["level"], body["artifact_class"], body["artifact_id"], body["request_slot"],
                               body["birth_cut_id"], body["footprint"], body["generator_digest"], body["evaluator_digest"])
            if c.canonical_bytes.decode() != r["contract"]:
                raise EngineError("sealed contract bytes do not round-trip")
            contracts.setdefault(r["artifact_id"], []).append(c)
        contracts = {k: tuple(v) for k, v in contracts.items()}
        runs = tuple(S.ProducerRunObservation(**json.loads(ln))
                     for ln in Path(paths["cost_ledger.jsonl"]).read_text().splitlines())
        raw = RawExportLog.verify(Path(paths["raw_export.jsonl"]))
        want = {record_to_json(r)["request_id"] + "|" + r.method + "|" + r.level for r in records} if records else None
        cs = ContractSystem(blobs, self.names)
        ctxf, gamma, cost = CutContextFactoryImpl(region), GammaAdmissibilityImpl(region), CostModelImpl()
        hist = RealizedHistory(None)
        from ..state.journal import AppendOnlyJournal
        from ..history.realized import Event
        for r in AppendOnlyJournal(Path(paths["history.jsonl"])).records():      # read-only reconstruction
            hist._add(Event(r["kind"], r["at_utc"], r["region_id"], r["feed_id"], r["payload"], tuple(r["preds"])),
                      persist=False)
        lv_event = {(ev.feed_id, ev.payload["index"]): eid for eid, ev in hist.events.items()
                    if ev.kind == "LOGICAL_VERSION_AVAILABLE"}
        born_event = {(ev.payload.get("slot") or f"ROUTER:region={ev.region_id}", ev.at_utc): eid
                      for eid, ev in hist.events.items() if ev.kind == "ARTIFACT_BORN"}
        tick_event = {ev.at_utc: eid for eid, ev in hist.events.items() if ev.kind == "CONSUMER_TICK"}
        items = []
        by_arm: dict = {}
        for rec in raw:
            by_arm.setdefault((rec["method"], rec["level"]), []).append(rec)
        for (method, level), recs in sorted(by_arm.items()):
            sealed_ov = _load_catalog(base / f"overlay_{method}_{level}.jsonl")
            ob_path = base / f"overlay_born_{method}_{level}.json"
            sealed_born = json.loads(ob_path.read_text()) if ob_path.exists() else {}
            mc = MethodCatalog(shared, shared_born, ArtifactCatalog(None), {}, dict(contracts))
            red = _RecordedRederiver(mc, sealed_ov, sealed_born, contracts)
            cur_rec: dict = {}
            native = _RecordedNative(cur_rec)
            nstate = None
            exp = StatisticsExporterImpl()
            for rec in sorted(recs, key=lambda r: r["tick_utc"]):
                t = rec["tick_utc"]
                cut = region.current_cut(t)
                req = S.ConsumerRequest(region.region_id, tuple(rec["request_slots"]), t, cut, ctxf.context_for(cut, t))
                est = estimates_for(req, cost, prior_view(region.region_id, t, runs))
                red.load(rec)
                cur_rec["r"] = rec
                ev = TimedEvaluator(cs)
                view: S.RequestBinding | S.N1CurrentView
                if method == "N1":
                    if nstate is None:
                        nstate = S.NativeOtpState(region.region_id, "replay", "replay", str(base / "replay-n1-cache"),
                                                  "replay", "replay", None, None)
                    vb = []
                    for s in req.request_slots:
                        if s.startswith("VAL:"):
                            got = mc.bind(s, t)
                            vb.append((s, S.BoundArtifact.from_entry(*got) if got else None))
                    vc = tuple((b.artifact_id, tuple(mc.contracts.get(b.artifact_id, ()))) for _, b in vb if b)
                    inputs = tuple((f, region.ref(f, i)["logical_version_id"], region.ref(f, i)["canonical_content_sha256"])
                                   for f, i in cut.frontier)
                    view = S.N1CurrentView(req, tuple(vb), vc, inputs, nstate, est)
                    out = N1BaselineImpl().decide(view,
                                                  CurrentCutEvaluatorImpl(ev, req.context),
                                                  CurrentCutRederiverImpl(_Bound(red), cut, t), native)
                    nstate, d = out.native_state, out.decision
                else:
                    binding = bind_request(req, mc, est)
                    if method == "N5":
                        d = N5BaselineImpl().decide(binding, level, CurrentCutEvaluatorImpl(ev, req.context),
                                                    CurrentCutRederiverImpl(_Bound(red), cut, t))
                    else:
                        d = AdmissionEngineImpl().admit(binding, level, hist, ctxf, gamma, ev, WitnessSearchImpl(),
                                                        RepairEngineImpl(), red)
                    view = binding
                pre = tuple(S.CostItem(S.CostCategory(i["category"]), i["component"], i["wall_s"], i["cpu_s"], i["slot_id"],
                                       i["producer_outcome"]) for i in rec["costs"]["items"]
                            if i["component"] == "n1_preprocessing")
                exp.register(d.method, d.level, view, pre)
                again = record_to_json(exp.export(d, S.RunIdentityRecord(**rec["run"]),
                                                  root_changes_at(region, t, rj["analysis_window_start"]),
                                                  local_date(t, region.tz).isoformat(), rec["gamma_size"],
                                                  rec["scheduler_state_digest"]))
                key = rec["request_id"] + "|" + method + "|" + level
                if want is not None and key not in want:
                    continue
                same = logical_view(again) == logical_view(rec)
                src = self._source_events(rec, region, cut, shared, shared_born, hist, lv_event, born_event, tick_event)
                items.append(S.ReplayItem(json.dumps(rec, sort_keys=True) and _digest(rec),
                                          "REPRODUCED" if same else "NOT_REPRODUCED", src,
                                          "" if same else json.dumps({"want": logical_view(rec),
                                                                      "got": logical_view(again)}, default=str)[:2000]))
        return S.ReplayReport(ledger, tuple(items))


class _Bound:
    """Adapts the recorded rederiver to the ProducerRederiver signature used by CurrentCutRederiverImpl."""
    def __init__(self, red: _RecordedRederiver) -> None:
        self.red = red

    def rederive(self, slot_id, cut, tick_utc, estimate_s):
        return self.red.rederive(slot_id, cut, tick_utc, estimate_s)

    def cpu_of(self, step, tick_utc=None):
        return self.red.cpu_of(step, tick_utc)


def _digest(rec: dict) -> str:
    from ...common.util import sha256_obj
    return sha256_obj(rec)
