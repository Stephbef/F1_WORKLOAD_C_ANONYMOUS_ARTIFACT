"""F1 engines behind the frozen V1.2 interfaces (docs/pre_s3/06 §2-§3, 10, V1.2 §2).

WitnessSearch: the joint R_t must be valid at ONE cut c ∈ Γ_t \\ {c_cur}; candidates in the frozen order (lag ascending,
then higher indices first by feed id); first valid candidate wins. Fixed-R: only the bound instances of the designated
slots are evaluated; there is no catalog access at all.
RepairEngine: S(c) = unbound ∪ failing slots; OPT(c) = Σ est(s,t); historical only if strictly cheaper (tie → current);
execution serial / canonical / fail-fast through `core.execute_plan`.
AdmissionEngine: current reuse → historical witness → repair → no artifact.
"""
from __future__ import annotations

from ..history.realized import Cut, RealizedHistory
from ..interfaces import session3 as S
from .core import ARTIFACT_OUTCOMES, EngineError, all_valid, execute_plan, level_contracts, producer_class_of


def _bound(binding: S.RequestBinding) -> dict:
    return dict(binding.bindings)


def _estimates(binding: S.RequestBinding) -> dict:
    return dict(binding.estimates)


def _evaluate_all(binding: S.RequestBinding, level: str, ctx, evaluator) -> tuple[dict, bool]:
    """Evaluate every bound artifact's level-K contracts in ctx. Returns ({slot: results}, R valid at ctx)."""
    res, ok = {}, True
    for slot, b in binding.bindings:
        if b is None:
            ok = False
            continue
        cs = level_contracts(binding, b.artifact_id, level)
        rs = tuple(evaluator.evaluate(c, ctx) for c in cs)
        res[slot] = rs
        ok = ok and all_valid(rs)
    return res, ok


def current_step(binding: S.RequestBinding, level: str, contexts, evaluator):
    req = binding.request
    ctx = contexts.context_for(req.current_cut, req.tick_utc)
    res, ok = _evaluate_all(binding, level, ctx, evaluator)
    flat = tuple(r for s in req.request_slots for r in res.get(s, ()))
    return flat, ok, res


class WitnessSearchImpl:
    def __init__(self) -> None:
        self.last_candidates_examined = 0

    def search(self, binding: S.RequestBinding, level: str, history: RealizedHistory, contexts, gamma, evaluator
               ) -> S.JointWitness | None:
        if level not in S.LEVELS:
            raise EngineError("K3 is never an admission level")
        req = binding.request
        if any(b is None for _, b in binding.bindings):
            return None                                       # R_t not formed: no joint witness possible
        self.last_candidates_examined = 0
        for cut in gamma.candidates(req.tick_utc):
            self.last_candidates_examined += 1
            ev = gamma.evidence(cut, req.tick_utc)
            if not ev.admissible:
                continue
            _check_realized(history, cut, req.tick_utc, gamma)
            ctx = contexts.context_for(cut, req.tick_utc)
            res, ok = _evaluate_all(binding, level, ctx, evaluator)
            if not ok:
                continue
            avail = tuple((f, i, gamma.r.versions[(f, i)].available_utc) for f, i in cut.frontier)
            wbs = []
            for slot, b in binding.bindings:
                assert b is not None
                wbs.append(S.WitnessBinding(slot, b, tuple(c.contract_id for c in level_contracts(binding, b.artifact_id,
                                                                                                    level)),
                                            res[slot], S.TemporalEvidence(req.tick_utc, b.born_utc, avail)))
            return S.JointWitness(req.request_id, req.request_slots, "F1", level, cut, tuple(wbs), ev)
        return None


def _check_realized(history: RealizedHistory | None, cut: Cut, tick_utc: str, gamma) -> None:
    """Every candidate cut must be consistent with the REALIZED HISTORY at t: each coordinate is a logical version whose
    LOGICAL_VERSION_AVAILABLE event exists in the sealed history DAG with availability <= t (no synthetic / future
    state), and agrees with the region's version table."""
    if history is None:
        raise EngineError("F1 requires the realized history to validate candidate cuts")
    from ..history.realized import is_consistent
    if not is_consistent(history, cut, tick_utc):
        raise EngineError(f"cut {cut.cut_id} not consistent with the realized history at {tick_utc}")
    for f, i in cut.frontier:
        chain = history.versions.get(f, [])
        if i < 1 or i > len(chain) or chain[i - 1][1] > tick_utc:
            raise EngineError(f"candidate cut uses an unrealized or future version {f}#{i}")
        v = gamma.r.versions.get((f, i))
        if v is None or v.available_utc != chain[i - 1][1]:
            raise EngineError(f"version table disagrees with the realized history for {f}#{i}")


class RepairEngineImpl:
    def plan(self, binding: S.RequestBinding, level: str, history: RealizedHistory, contexts, gamma, evaluator
             ) -> S.RepairPlan | None:
        req = binding.request
        est = _estimates(binding)
        bound = _bound(binding)

        def failing(cut: Cut) -> tuple[str, ...]:
            ctx = contexts.context_for(cut, req.tick_utc)
            out = []
            for s in req.request_slots:                       # canonical order
                b = bound[s]
                if b is None:
                    out.append(s)
                    continue
                rs = [evaluator.evaluate(c, ctx) for c in level_contracts(binding, b.artifact_id, level)]
                if not all_valid(rs):
                    out.append(s)
            return tuple(out)
        s_cur = failing(req.current_cut)
        if not s_cur:
            return None                                       # current already valid: no repair
        opt_cur = round(sum(est[s] for s in s_cur), 9)
        best = None
        for cut in gamma.candidates(req.tick_utc):            # frozen order breaks OPT ties among historical cuts
            if not gamma.evidence(cut, req.tick_utc).admissible:
                continue
            _check_realized(history, cut, req.tick_utc, gamma)
            sc = failing(cut)
            o = round(sum(est[s] for s in sc), 9)
            if best is None or o < best[0]:
                best = (o, cut, sc)
        opt_hist = best[0] if best else None
        if best is not None and best[0] < opt_cur:            # strictly cheaper; tie -> current
            o, cut, sc = best
            steps = tuple(S.RederivationStep(s, cut.cut_id, producer_class_of(s), est[s]) for s in sc)
            return S.RepairPlan(req.request_id, S.Mode.HISTORICAL, cut, sc, steps, opt_cur, opt_hist, cut.cut_id)
        steps = tuple(S.RederivationStep(s, req.current_cut.cut_id, producer_class_of(s), est[s]) for s in s_cur)
        return S.RepairPlan(req.request_id, S.Mode.CURRENT, req.current_cut, s_cur, steps, opt_cur, opt_hist,
                            best[1].cut_id if best else None)

    def execute(self, plan: S.RepairPlan, rederiver, tick_utc: str) -> S.RepairPlan:
        return execute_plan(plan, lambda st: rederiver.rederive(st.slot_id, plan.target_cut, tick_utc, st.estimate_s))


class AdmissionEngineImpl:
    """F1(K): REUSE/CURRENT → REUSE/HISTORICAL (JointWitness) → REDERIVE (RepairPlan) → NO_ARTIFACT.
    Control-plane time is charged with non-overlapping intervals (core.ControlTimer): 'admission' (current-cut step),
    'witness_search' (includes Γ construction for the witness search), 'repair_solver' (includes Γ construction for
    the repair optimisation); evaluator time inside any interval is charged once as 'evaluate'. Producer execution is
    excluded from B (charged as A)."""
    def admit(self, binding: S.RequestBinding, level: str, history: RealizedHistory, contexts, gamma, evaluator,
              witness_search, repair, rederiver) -> S.AdmissionDecision:
        from .core import ControlTimer, producer_cost_items
        req = binding.request
        tm = ControlTimer(evaluator)
        cur, ok, _ = current_step(binding, level, contexts, evaluator)
        tm.mark("admission")
        if ok:
            return S.AdmissionDecision(req, "F1", level, S.Action.REUSE, S.Mode.CURRENT, cur,
                                       costs=S.CostRecord(tuple(tm.items)))
        w = witness_search.search(binding, level, history, contexts, gamma, evaluator)
        tm.mark("witness_search")
        if w is not None:
            return S.AdmissionDecision(req, "F1", level, S.Action.REUSE, S.Mode.HISTORICAL, cur, witness=w,
                                       costs=S.CostRecord(tuple(tm.items)))
        plan = repair.plan(binding, level, history, contexts, gamma, evaluator)
        tm.mark("repair_solver")
        if plan is None:                                      # cannot happen when current is invalid; fail closed
            raise EngineError("current invalid but no repair plan")
        done = repair.execute(plan, rederiver, req.tick_utc)
        tm.skip()                                             # producer time is category A, never B
        items = list(tm.items) + producer_cost_items(done, rederiver, req.tick_utc)
        okall = all(s.outcome in ARTIFACT_OUTCOMES for s in done.steps)
        if okall:
            return S.AdmissionDecision(req, "F1", level, S.Action.REDERIVE, done.mode, cur, repair=done,
                                       costs=S.CostRecord(tuple(items)))
        return S.AdmissionDecision(req, "F1", level, S.Action.NO_ARTIFACT, None, cur, repair=done,
                                   costs=S.CostRecord(tuple(items)))
