"""StatisticsExporter (raw, append-only, provenance-linked) and FrozenAnalysis (docs/pre_s3/12 §3-§4, V1.2 §5).

Aggregates are computed ONLY from RawExportRecords. Inference: region = cluster; exact one-sided sign test (zeros
dropped); BCa B = 9,999 (seed domain "bootstrap", leave-one-region-out jackknife acceleration, two-sided 95 %);
wild-cluster Rademacher B = 9,999 (seed domain "wild-bootstrap"); numpy 2.4.4 Generator(PCG64(int_seed)); regions sorted
by id; Holm over exactly {H_witness(K0), H_repair(K0), H_hist(K2), H_native(K2)} at α = 0.05; INCONCLUSIVE when fewer
than 3 regions contribute (regions whose region-level statistic is DEFINED after the frozen denominator/exclusion
rules — counted BEFORE zero differences are dropped by the sign test) or the BCa CI includes 0. BCa is the PRIMARY
interval for the INCONCLUSIVE rule; the wild-cluster interval is reported as a robustness check only (provenance V2:
"wild-cluster bootstrap = robustness check"); a verdict never changes on the wild CI alone.
"""
from __future__ import annotations

import json
import math
from dataclasses import asdict
from fractions import Fraction
from pathlib import Path
from statistics import NormalDist

from ...common.util import sha256_obj
from ..config.spec import load_protocol_spec
from ..errors import NamespaceViolation
from ..interfaces import session3 as S
from .core import EngineError

B = 9999
ALPHA = 0.05
HYPOTHESES = ("H_witness(K0)", "H_repair(K0)", "H_hist(K2)", "H_native(K2)")
DIRECTION = {"H_witness(K0)": "greater", "H_repair(K0)": "greater", "H_hist(K2)": "greater", "H_native(K2)": "less"}


def _jsonable(o) -> object:
    v = getattr(o, "value", None)
    if v is not None and not isinstance(o, (str, int, float)):
        return v
    raise TypeError(type(o))


def record_to_json(r: S.RawExportRecord) -> dict:
    return json.loads(json.dumps(asdict(r), default=_jsonable))


class RawExportLog:
    """Append-only JSONL; each line carries the previous line's digest (hash chain) and the record digest."""
    def __init__(self, path: Path) -> None:
        self.path = path
        self.prev = "GENESIS"
        if path.exists():
            for ln in path.read_text().splitlines():
                self.prev = json.loads(ln)["line_digest"]

    def append(self, r: S.RawExportRecord) -> str:
        body: dict = {"prev": self.prev, "record_digest": r.record_digest, "record": record_to_json(r)}
        line = sha256_obj(body)
        body["line_digest"] = line
        with self.path.open("a") as fh:
            fh.write(json.dumps(body, sort_keys=True) + "\n")
        self.prev = line
        return line

    @staticmethod
    def verify(path: Path) -> list[dict]:
        prev, out = "GENESIS", []
        for ln in path.read_text().splitlines():
            b = json.loads(ln)
            d = b.pop("line_digest")
            if b["prev"] != prev or sha256_obj(b) != d:
                raise EngineError("raw export hash chain broken")
            prev = d
            out.append(b["record"])
        return out


class StatisticsExporterImpl:
    """Builds RawExportRecords. The binding a method decided on is registered first (implementation-private hook) so
    that bound artifacts and est(s,t) can be exported without changing the frozen protocol signature."""
    def __init__(self) -> None:
        self._bindings: dict = {}
        self._extra: dict = {}

    @staticmethod
    def binding_digest(view) -> str:
        """Immutable digest of exactly what the method decided on (RequestBinding / CurrentCutView / N1CurrentView)."""
        if isinstance(view, S.RequestBinding):
            rows = [(s, b.artifact_id if b else None, list(b.contract_ids) if b else []) for s, b in view.bindings]
            return sha256_obj(["RequestBinding", view.request.request_id, rows, [list(e) for e in view.estimates]])
        if isinstance(view, S.N1CurrentView):
            rows = [(s, b.artifact_id if b else None, list(b.contract_ids) if b else []) for s, b in view.val_bindings]
            return sha256_obj(["N1CurrentView", view.request.request_id, rows, [list(x) for x in view.current_router_inputs],
                               [list(e) for e in view.estimates]])
        raise EngineError("only RequestBinding / N1CurrentView can be registered")

    def register(self, method: str, level: str, view, extra_costs: tuple = ()) -> str:
        """Implementation-private bridge around the frozen export() signature: register, ONCE per (method, level,
        request), the exact view the method decided on. The view is stored by value (immutable dataclasses) with its
        digest; a second registration for the same key is refused (no cross-method / cross-request reuse)."""
        if method in ("N5", "F1") and not isinstance(view, S.RequestBinding):
            raise EngineError(f"{method} decides on a RequestBinding (N5: CurrentCutView) only")
        if method == "N1" and not isinstance(view, S.N1CurrentView):
            raise EngineError("N1 decides on an N1CurrentView only")
        req = view.request
        key = (method, level, req.request_id)
        if key in self._bindings:
            raise EngineError(f"binding already registered for {key}")
        if isinstance(view, S.RequestBinding):
            bound = tuple((s, b.artifact_id if b else None, b.contract_ids if b else ()) for s, b in view.bindings)
        else:
            bound = tuple((s, b.artifact_id if b else None, b.contract_ids if b else ()) for s, b in view.val_bindings)
        dg = self.binding_digest(view)
        self._bindings[key] = (bound, view.estimates, dg, req)
        self._extra[key] = extra_costs
        return dg

    def export(self, decision: S.AdmissionDecision, run: S.RunIdentityRecord, root_changes: tuple[tuple[str, int], ...],
               tick_local: str, gamma_size: int | None, scheduler_state_digest: str) -> S.RawExportRecord:
        req = decision.request
        key = (decision.method, decision.level, req.request_id)
        if key not in self._bindings:
            raise EngineError("binding not registered for export")
        bound, est, bdig, breq = self._bindings.pop(key)               # consumed exactly once
        if breq != req:
            raise EngineError("decision request differs from the registered binding's request")
        verdicts = [(c.contract_id.split(":")[0], c.contract_id, c.cut_id, c.verdict) for c in decision.current_evaluations]
        artifact_of = {}
        for _slot, aid, cids in bound:
            for cid in cids:
                artifact_of[cid] = aid
        verdicts = [(artifact_of.get(cid, "?"), cid, cut, v) for _, cid, cut, v in verdicts]
        if decision.witness is not None:
            for wb in decision.witness.bindings:
                verdicts += [(wb.artifact.artifact_id, e.contract_id, e.cut_id, e.verdict) for e in wb.evaluations]
        steps = decision.repair.steps if decision.repair else ()
        failures = tuple((s.slot_id, s.outcome) for s in steps if s.outcome is not None and
                         s.outcome not in ("SUCCESS", "SEMANTIC_FAIL"))
        reason = decision.exclusion
        if reason is None and any(v == "ERROR" for *_, v in verdicts):
            reason = "EVALUATION_ERROR"
        if reason is None and any(o == "TIMEOUT" for _, o in failures):
            reason = "OPERATIONAL_CAP"
        if reason is None and any(o == "INFEASIBLE" for _, o in failures):
            reason = "R_UNFORMABLE"
        costs = S.CostRecord(tuple(decision.costs.items) + tuple(self._extra.get(key, ())))
        prov = ("binding:" + bdig,) + tuple(sorted({s.provenance_digest for s in steps if s.provenance_digest}))
        return S.RawExportRecord(
            run, req.region_id, req.request_id, req.request_slots, tuple(root_changes), req.tick_utc, tick_local,
            decision.method, decision.level, req.current_cut.cut_id, req.current_cut.frontier, gamma_size, decision.action,
            decision.mode, decision.witness.witness_cut.cut_id if decision.witness else None,
            tuple((s, a) for s, a, _ in bound), tuple(verdicts), tuple(steps), costs, tuple(est),
            decision.repair.opt_current if decision.repair else None,
            decision.repair.opt_hist if decision.repair else None, failures, scheduler_state_digest, prov,
            reason is not None, reason)


# ------------------------------------------------------------------------------------------------ inference
def int_seed(domain: str) -> int:
    """Integer seed = first 8 bytes (big-endian) of seed_bytes(domain) (authoritative §11)."""
    return load_protocol_spec().integer_seed(domain)


def sign_test_p(values: list[float], direction: str) -> Fraction:
    nz = [v for v in values if v != 0]
    n = len(nz)
    if n == 0:
        return Fraction(1)
    k = sum(1 for v in nz if (v > 0 if direction == "greater" else v < 0))
    return Fraction(sum(math.comb(n, j) for j in range(k, n + 1)), 2 ** n)


def bca(region_values: dict, domain: str = "bootstrap", b: int = B, level: float = 0.95):
    import numpy as np
    ids = sorted(region_values)
    x = np.array([float(region_values[i]) for i in ids])
    n = len(x)
    theta = float(x.mean())
    rng = np.random.Generator(np.random.PCG64(int_seed(domain)))
    idx = rng.integers(0, n, size=(b, n))
    boots = np.sort(x[idx].mean(axis=1))
    p0 = (np.sum(boots < theta) + 0.5 * np.sum(boots == theta)) / b
    p0 = min(max(p0, 1 / (2 * b)), 1 - 1 / (2 * b))
    nd = NormalDist()
    z0 = nd.inv_cdf(p0)
    jack = np.array([np.delete(x, i).mean() for i in range(n)])
    d = jack.mean() - jack
    den = 6.0 * float(np.sum(d ** 2)) ** 1.5
    a = float(np.sum(d ** 3)) / den if den > 0 else 0.0
    out = []
    for q in ((1 - level) / 2, 1 - (1 - level) / 2):
        z = nd.inv_cdf(q)
        alpha = nd.cdf(z0 + (z0 + z) / (1 - a * (z0 + z)))
        k = min(max(math.ceil(alpha * b), 1), b)
        out.append(float(boots[k - 1]))
    return theta, (out[0], out[1]), z0, a


def wild(region_values: dict, domain: str = "wild-bootstrap", b: int = B, level: float = 0.95):
    import numpy as np
    ids = sorted(region_values)
    x = np.array([float(region_values[i]) for i in ids])
    m = float(x.mean())
    rng = np.random.Generator(np.random.PCG64(int_seed(domain)))
    w = rng.integers(0, 2, size=(b, len(x))) * 2 - 1
    reps = np.sort(m + (w * (x - m)).mean(axis=1))
    lo = reps[min(max(math.ceil((1 - level) / 2 * b), 1), b) - 1]
    hi = reps[min(max(math.ceil((1 - (1 - level) / 2) * b), 1), b) - 1]
    return m, (float(lo), float(hi))


def holm(pvals: dict) -> dict:
    items = sorted(pvals.items(), key=lambda kv: (kv[1], kv[0]))
    m = len(items)
    out, running = {}, 0.0
    for j, (k, p) in enumerate(items):
        running = max(running, min(1.0, (m - j) * float(p)))
        out[k] = running
    return out


def _online(rec: dict) -> float:
    """Per-request online cost (A + B), EXCLUDING the one-time regional N1 preprocessing (accounted per region)."""
    return float(sum(i["wall_s"] for i in rec["costs"]["items"]
                     if i["category"] != "C_OFFLINE" and i["component"] != "n1_preprocessing"))


def _clopper_pearson(k: int, n: int, level: float = 0.95) -> tuple[float, float] | None:
    """Exact (Clopper–Pearson) binomial interval by bisection on the exact binomial CDF (deterministic)."""
    if n == 0:
        return None
    a = (1 - level) / 2

    def cdf(x: int, p: float) -> float:
        return sum(math.comb(n, j) * p ** j * (1 - p) ** (n - j) for j in range(0, x + 1))

    def solve(f) -> float:
        lo, hi = 0.0, 1.0
        for _ in range(200):
            mid = (lo + hi) / 2
            if f(mid):
                lo = mid
            else:
                hi = mid
        return (lo + hi) / 2
    lower = 0.0 if k == 0 else solve(lambda p: 1 - cdf(k - 1, p) < a)
    upper = 1.0 if k == n else solve(lambda p: cdf(k, p) >= a)
    return lower, upper


class FrozenAnalysisImpl:
    @staticmethod
    def cap_excluded(records: list[dict]) -> set:
        """PAIRED operational-cap exclusion set: every (region, request) at which ANY method record carries
        OPERATIONAL_CAP is excluded for ALL methods from ALL primary metrics."""
        return {(r["region_id"], r["request_id"]) for r in records if r.get("exclusion_reason") == "OPERATIONAL_CAP"}

    @staticmethod
    def n1_preprocessing(records: list[dict]) -> dict:
        """One-time N1 regional preprocessing, de-duplicated by its deterministic provenance identity; charged once per
        participating region regardless of which (possibly excluded) record carries it. Missing evidence for a region
        that participated in the N1 arm, or two different identities, fail closed."""
        out: dict = {}
        participating = {r["region_id"] for r in records if r["method"] == "N1"}
        for r in records:
            for i in r["costs"]["items"]:
                if i["component"] != "n1_preprocessing":
                    continue
                ident = i.get("slot_id")
                if not ident or not str(ident).startswith("PREPROC:"):
                    raise EngineError("N1 preprocessing item without a provenance identity")
                prev = out.get(r["region_id"])
                if prev is not None and prev[0] != ident:
                    raise EngineError(f"two different N1 preprocessing identities for {r['region_id']}")
                out[r["region_id"]] = (ident, float(i["wall_s"]))
        missing = sorted(participating - set(out))
        if missing:
            raise EngineError(f"N1 regional preprocessing evidence missing for {missing}")
        return {k: v[1] for k, v in out.items()}

    def per_region(self, records: list[dict]) -> dict:
        regions = sorted({r["region_id"] for r in records})
        out: dict[str, dict] = {r: {} for r in regions}
        cap = self.cap_excluded(records)
        pre = self.n1_preprocessing(records)

        def eligible(r):
            return (r["region_id"], r["request_id"]) not in cap

        def sel(method, level):
            return [r for r in records if r["method"] == method and r["level"] == level and eligible(r)]
        for K in S.LEVELS:
            f1 = [r for r in sel("F1", K) if not r["excluded"]]
            for rid in regions:
                units_den, units_num, rep_den, rep_num = set(), set(), set(), set()
                dcost = 0.0
                unit_delta: dict = {}
                for r in f1:
                    if r["region_id"] != rid:
                        continue
                    units = {tuple(u) for u in r["root_changes"]}
                    cur_valid = r["action"] == "REUSE" and r["mode"] == "CURRENT"
                    if not cur_valid:
                        units_den |= units
                        if r["action"] == "REUSE" and r["mode"] == "HISTORICAL":
                            units_num |= units
                    w_empty = r["action"] in ("REDERIVE", "NO_ARTIFACT") and r["opt_current"] is not None
                    if w_empty and r["opt_current"] > 0:
                        rep_den |= units
                        if r["opt_hist"] is not None and r["opt_hist"] < r["opt_current"]:
                            rep_num |= units
                    if w_empty:
                        oh = r["opt_hist"] if r["opt_hist"] is not None else math.inf
                        delta = r["opt_current"] - min(r["opt_current"], oh)
                        dcost += delta
                        for u in units:                        # per-UNIT view: each attributed unit accumulates
                            unit_delta[u] = unit_delta.get(u, 0.0) + delta
                out[rid][f"HSR_witness({K})"] = (len(units_num & units_den) / len(units_den)) if units_den else None
                out[rid][f"HSR_repair({K})"] = (len(rep_num & rep_den) / len(rep_den)) if rep_den else None
                out[rid][f"units_witness_den({K})"] = len(units_den)
                out[rid][f"units_witness_num({K})"] = len(units_num & units_den)
                out[rid][f"units_repair_den({K})"] = len(rep_den)
                out[rid][f"units_repair_num({K})"] = len(rep_num & rep_den)
                out[rid][f"DeltaCost_history({K})"] = dcost
                out[rid][f"DeltaCost_history_per_unit_mean({K})"] = \
                    (sum(unit_delta.values()) / len(unit_delta)) if unit_delta else None

        def total(rid, method, level):
            return {r["request_id"]: _online(r) for r in records if r["region_id"] == rid and r["method"] == method
                    and r["level"] == level and eligible(r)}
        for rid in regions:
            f1, n5, n1 = total(rid, "F1", "K2"), total(rid, "N5", "K2"), total(rid, "N1", "K0")
            pair = sorted(set(f1) & set(n5))
            out[rid]["n_pairs_F1_N5(K2)"] = len(pair)
            if pair:                                            # defined only with >= 1 eligible paired request
                out[rid]["Cost_F1(K2)"] = sum(f1[k] for k in pair)
                out[rid]["Cost_N5(K2)"] = sum(n5[k] for k in pair)
                out[rid]["DeltaE2E_history(K2)"] = out[rid]["Cost_N5(K2)"] - out[rid]["Cost_F1(K2)"]
            else:
                out[rid]["Cost_F1(K2)"] = out[rid]["Cost_N5(K2)"] = out[rid]["DeltaE2E_history(K2)"] = None
            pn = sorted(set(f1) & set(n1))
            out[rid]["n_pairs_F1_N1"] = len(pn)
            if pn:
                out[rid]["Cost_N1"] = sum(n1[k] for k in pn) + pre.get(rid, 0.0)   # + one-time regional preprocessing
                out[rid]["N1_preprocessing"] = pre.get(rid, 0.0)
                out[rid]["Cost_F1(K2)_vs_N1"] = sum(f1[k] for k in pn)
                out[rid]["Native_contrast(K2)"] = out[rid]["Cost_F1(K2)_vs_N1"] - out[rid]["Cost_N1"]
            else:
                out[rid]["Cost_N1"] = out[rid]["Cost_F1(K2)_vs_N1"] = out[rid]["Native_contrast(K2)"] = None
                out[rid]["N1_preprocessing"] = pre.get(rid)
            out[rid]["n_root_changes"] = len({tuple(u) for r in records if r["region_id"] == rid and eligible(r)
                                              for u in r["root_changes"]})
        return out

    def descriptive(self, records: list[dict]) -> dict:
        """Supplemental deterministic descriptive record (NOT a Holm hypothesis): exact binomial prevalence over regions
        of '>= 1 event in a region' for witness and repair (per K), and DeltaCost per-unit means."""
        recs = [record_to_json(r) if isinstance(r, S.RawExportRecord) else r for r in records]
        pr = self.per_region(recs)
        out: dict = {"schema": "F1-WC-DESCRIPTIVE-1", "prevalence": {}, "deltacost_per_unit_mean": {}}
        for K in S.LEVELS:
            for kind in ("witness", "repair"):
                contrib = [rid for rid, v in pr.items() if v[f"units_{kind}_den({K})"] > 0]
                k = sum(1 for rid in contrib if pr[rid][f"units_{kind}_num({K})"] >= 1)
                ci = _clopper_pearson(k, len(contrib))
                out["prevalence"][f"{kind}({K})"] = {"regions_contributing": len(contrib), "regions_with_event": k,
                                                     "exact_binomial_ci95": list(ci) if ci else None}
            out["deltacost_per_unit_mean"][K] = {rid: v[f"DeltaCost_history_per_unit_mean({K})"] for rid, v in pr.items()}
        return out

    def run(self, records: tuple[S.RawExportRecord, ...] | list, namespace: str) -> S.AnalysisReport:
        recs = [record_to_json(r) if isinstance(r, S.RawExportRecord) else r for r in records]
        if any(r["run"]["namespace"] != namespace for r in recs):
            raise NamespaceViolation("records from another namespace in the analysis input")
        raw_sha = sha256_obj(recs)
        pr = self.per_region(recs)
        values = {
            "H_witness(K0)": {k: v["HSR_witness(K0)"] for k, v in pr.items() if v["HSR_witness(K0)"] is not None},
            "H_repair(K0)": {k: v["HSR_repair(K0)"] for k, v in pr.items() if v["HSR_repair(K0)"] is not None},
            "H_hist(K2)": {k: v["DeltaE2E_history(K2)"] for k, v in pr.items() if v["DeltaE2E_history(K2)"] is not None},
            "H_native(K2)": {k: v["Native_contrast(K2)"] for k, v in pr.items() if v["Native_contrast(K2)"] is not None},
        }
        pvals = {h: sign_test_p(list(values[h].values()), DIRECTION[h]) for h in HYPOTHESES}
        adj = holm({h: float(p) for h, p in pvals.items()})
        hyps = []
        for h in HYPOTHESES:
            vals = values[h]                     # contributing regions: the frozen statistic is DEFINED (denominator /
            n_contrib = len(vals)                # exclusion rules applied) — independent of the observed effect size
            ci = wci = None
            if n_contrib >= 2:
                ci = bca(vals)[1]
                wci = wild(vals)[1]
            inconclusive = n_contrib < 3 or ci is None or (ci[0] <= 0 <= ci[1])
            verdict = "INCONCLUSIVE" if inconclusive else ("SUPPORTED" if adj[h] < ALPHA else "NOT_SUPPORTED")
            n_units = sum(pr[r]["n_root_changes"] for r in vals)
            hyps.append(S.HypothesisResult(h, len(vals), n_units, float(pvals[h]), adj[h], ci, wci, verdict))
        per = tuple((rid, tuple(sorted((k, (float(v) if v is not None else None)) for k, v in pr[rid].items())))
                    for rid in sorted(pr))
        return S.AnalysisReport(namespace, raw_sha, per, tuple(hyps))
