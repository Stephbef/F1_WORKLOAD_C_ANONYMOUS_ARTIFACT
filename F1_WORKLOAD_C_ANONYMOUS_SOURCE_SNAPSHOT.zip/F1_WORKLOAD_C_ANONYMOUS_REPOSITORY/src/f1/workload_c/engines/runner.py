"""Region campaign runner (orchestration glue). For one region:

1. SHARED scheduled production (frozen schedule; SCH-01 = last_successful_build) → shared catalog + ARTIFACT_BORN times
   + contracts + the shared producer-run ledger (ProducerRunObservation, source SHARED_SCHEDULED).
2. At every selected consumer tick, ONE ConsumerRequest (identical for all arms) and, per arm (F1(K), N5(K), N1), a
   RequestBinding from the shared catalog plus THAT ARM'S OWN overlay; est(s,t) from the shared CostModel.
3. Decisions: F1 via AdmissionEngine (history services), N5 via CurrentCutView only, N1 via N1CurrentView only.
   Arms are evaluated in the fixed order N5, N1, F1 on fresh objects (N5 never sees anything produced for F1).
4. Raw export (append-only hash-chained) of every decision.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from ...common.util import sha256_obj
from ..catalog.artifacts import ArtifactCatalog
from ..history.realized import RealizedHistory
from ..interfaces import session3 as S
from ..scheduler.ledger import to_history
from .baselines_n import N1BaselineImpl, N5BaselineImpl
from .core import now_wall
from .core import (ARTIFACT_OUTCOMES, CostModelImpl, CurrentCutEvaluatorImpl, CurrentCutRederiverImpl,
                   CutContextFactoryImpl, GammaAdmissibilityImpl, MethodCatalog, ProducerRederiver, RegionState,
                   TimedEvaluator, bind_request, estimates_for, local_date, parse_utc, prior_view)
from .f1 import AdmissionEngineImpl, RepairEngineImpl, WitnessSearchImpl
from .stats import RawExportLog, StatisticsExporterImpl


@dataclass
class Arm:
    method: str
    level: str
    mc: MethodCatalog
    rederiver: ProducerRederiver
    native_state: S.NativeOtpState | None = None
    last_lookup_s: float = 0.0
    last_n1_view: S.N1CurrentView | None = None
    preprocessing_charged: bool = False
    decisions: list = field(default_factory=list)


def root_change_units(region: RegionState, window_start_utc: str) -> set:
    """Root-change units (frozen unit: region × distinct root logical-content change): a logical version v that became
    available inside the analysis window whose canonical root content differs from the IMMEDIATELY PRECEDING realized
    logical version of the same feed. The version in force at the window start is baseline state; repeated
    observations with unchanged content never create a unit (A→B and B→A are two units)."""
    units = set()
    for f in region.feeds:
        vs = sorted((v for (ff, _), v in region.versions.items() if ff == f), key=lambda v: (v.available_utc, v.index))
        for prev, v in zip(vs, vs[1:], strict=False):
            if v.available_utc >= window_start_utc and v.canonical_content_sha256 != prev.canonical_content_sha256:
                units.add((f, v.index))
    return units


def root_changes_at(region: RegionState, t_utc: str, window_start_utc: str) -> tuple[tuple[str, int], ...]:
    """Units whose influence period [available(v), available(next)) ∩ window contains t: per feed, the version current
    at t, if it is a root-change unit."""
    units = root_change_units(region, window_start_utc)
    out = []
    for f in sorted(region.feeds):
        cur = region.available_count(f, t_utc)
        if (f, cur) in units and t_utc >= window_start_utc:
            out.append((f, cur))
    return tuple(out)


@dataclass
class _Sched:
    region_id: str
    events: list


class RegionCampaign:
    def __init__(self, region: RegionState, schedule_events: list, cs, producer_factory, run: S.RunIdentityRecord,
                 out_dir: Path, levels=S.LEVELS, native_builder=None, history_path: Path | None = None,
                 analysis_window_start: str | None = None) -> None:
        self.r = region
        self.events = schedule_events
        self.window_start = analysis_window_start or (schedule_events[0]["t"] if schedule_events else "")
        self.cs = cs
        self.run_identity = run
        self.out = out_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        self.contexts = CutContextFactoryImpl(region)
        self.gamma = GammaAdmissibilityImpl(region)
        self.cost = CostModelImpl()
        # REALIZED HISTORY: the frozen schedule's events written as the append-only DAG (S2 scheduler.ledger.to_history)
        self.history_path = history_path or (out_dir / "history.jsonl")
        if self.history_path.exists():
            self.history_path.unlink()
        self.history = RealizedHistory(self.history_path)
        self.event_ids = to_history(_Sched(region.region_id, schedule_events), self.history)  # type: ignore[arg-type]
        self.producer_factory = producer_factory           # () -> producer (fresh per arm / shared)
        self.native_builder = native_builder
        self.levels = tuple(levels)
        self.shared = ArtifactCatalog(out_dir / "catalog_shared.jsonl")
        self.shared_born: dict = {}
        self.contracts: dict = {}
        self.shared_runs: list[S.ProducerRunObservation] = []
        self.export = StatisticsExporterImpl()
        self.raw = RawExportLog(out_dir / "raw_export.jsonl")
        self.records: list[S.RawExportRecord] = []
        self._arms: list[Arm] = []

    # ------------------------------------------------------------------------------------- shared production
    def produce_shared(self, until_utc: str) -> None:
        started: dict = {}
        prod = self.producer_factory()
        from ..history.realized import Cut
        for e in self.events:
            if e["t"] > until_utc:
                break
            if e["kind"] == "PRODUCER_STARTED":
                started[e["job"]] = e
            if e["kind"] == "PRODUCER_COMPLETED":
                s = started[e["job"]]
                wall = (parse_utc(e["t"]) - parse_utc(s["t"])).total_seconds()
                self.shared_runs.append(S.ProducerRunObservation(self.r.region_id, e["producer"], e["t"], wall, wall,
                                                                 e["outcome"]))
            if e["kind"] == "ARTIFACT_BORN":
                fr = e["birth_frontier"]
                slot = e["slot"] if "slot" in e else f"ROUTER:region={self.r.region_id}"
                cut = Cut.of(self.r.region_id, fr)
                p = prod.produce(slot, cut, e["t"])
                if p.outcome not in ARTIFACT_OUTCOMES:
                    continue
                kw = dict(p.entry_kw)
                ent = self.shared.add(request_slot=slot, birth_cut_id=cut.cut_id, status=p.outcome,
                                      provenance_digest=p.provenance_digest, cost={"wall_s": p.wall_s, "cpu_s": p.cpu_s},
                                      namespace=self.r.namespace, **kw)
                self.shared_born[ent.artifact_id] = e["t"]
                self.contracts[ent.artifact_id] = p.contracts

    def _arm(self, method: str, level: str) -> Arm:
        mc = MethodCatalog(self.shared, self.shared_born,
                           ArtifactCatalog(self.out / f"overlay_{method}_{level}.jsonl"), {}, dict(self.contracts))
        return Arm(method, level, mc, ProducerRederiver(self.r, mc, self.producer_factory()))

    # ------------------------------------------------------------------------------------------- decisions
    def run(self, ticks: list[str]) -> list[S.RawExportRecord]:
        arms = self.prepare(ticks)
        for t in sorted(ticks):
            tc = self.tick_context(t)
            for arm in arms:
                self.step(arm, tc)
        return self.records

    # Per-request / per-arm decomposition (used unchanged by run(); the one-shot campaign interleaves arms of several
    # runners per request with a deterministic counterbalanced order — arms hold isolated state, so decisions are
    # order-invariant).
    def prepare(self, ticks: list[str]) -> list:
        self.produce_shared(max(ticks))
        arms = [self._arm("N5", k) for k in self.levels] + [self._arm("N1", "K0")] + \
            [self._arm("F1", k) for k in self.levels]
        self._arms = arms
        self._engines = (WitnessSearchImpl(), RepairEngineImpl(), AdmissionEngineImpl(), N5BaselineImpl())
        return arms

    def tick_context(self, t: str) -> dict:
        cut = self.r.current_cut(t)
        req = S.ConsumerRequest(self.r.region_id, S.canonical_request_slots(self.r.region_id, list(self.r.feeds)), t,
                                cut, self.contexts.context_for(cut, t))
        prior = prior_view(self.r.region_id, t, tuple(self.shared_runs))
        return {"t": t, "req": req, "est": estimates_for(req, self.cost, prior),
                "rc": root_changes_at(self.r, t, self.window_start), "tl": local_date(t, self.r.tz).isoformat(),
                "sched_digest": sha256_obj([e for e in self.events if e["t"] <= t]),
                "gsize": len(self.gamma.candidates(t)) + 1}

    def step(self, arm, tc: dict) -> S.RawExportRecord:
        ws, rp, ad, n5 = self._engines
        t, req, est = tc["t"], tc["req"], tc["est"]
        arm.mc.contracts.update({a: c for a, c in self.contracts.items() if a not in arm.mc.contracts})
        ev = TimedEvaluator(self.cs)
        extra: list = []
        view: S.RequestBinding | S.N1CurrentView | None
        j_before = sum(arm.rederiver.journal_s.values())
        if arm.method == "N1":
            d = self._n1(arm, req, est, ev)
            extra.append(S.CostItem(S.CostCategory.B_CONTROL_PLANE, "catalog_lookup", arm.last_lookup_s,
                                    arm.last_lookup_s))
            if not arm.preprocessing_charged and self.native_builder is not None:
                pp = self.native_builder.preprocessing.get(self.r.region_id)
                if pp:
                    # one-time regional preprocessing; slot_id carries its deterministic provenance identity
                    extra.append(S.CostItem(S.CostCategory.A_PRODUCER, "n1_preprocessing", float(pp["wall_s"]),
                                            float(pp.get("cpu_s", pp["wall_s"])), "PREPROC:" + pp["identity"]))
                    arm.preprocessing_charged = True
            view = arm.last_n1_view
        else:
            l0 = now_wall()
            binding = bind_request(req, arm.mc, est)
            lk = now_wall() - l0
            extra.append(S.CostItem(S.CostCategory.B_CONTROL_PLANE, "catalog_lookup", lk, lk))
            if arm.method == "N5":
                d = n5.decide(binding, arm.level, CurrentCutEvaluatorImpl(ev, req.context),
                              CurrentCutRederiverImpl(arm.rederiver, req.current_cut, t))
            else:
                d = ad.admit(binding, arm.level, self.history, self.contexts, self.gamma, ev, ws, rp, arm.rederiver)
            view = binding
        js = sum(arm.rederiver.journal_s.values()) - j_before
        if js:
            extra.append(S.CostItem(S.CostCategory.B_CONTROL_PLANE, "journal_fsync", js, js))
        arm.decisions.append(d)
        self.export.register(d.method, d.level, view, tuple(extra))
        rec = self.export.export(d, self.run_identity, tc["rc"], tc["tl"], tc["gsize"] if arm.method == "F1" else None,
                                 tc["sched_digest"])
        self.raw.append(rec)
        self.records.append(rec)
        return rec

    # ------------------------------------------------------------------------------------------- sealing
    def seal(self, arms_overlays: dict | None = None) -> S.SealedLedger:
        """Persist every input replay needs (read-only afterwards) and return the SealedLedger with file digests."""
        import hashlib
        import json
        o = self.out
        r = self.r
        (o / "region.json").write_text(json.dumps({
            "region_id": r.region_id, "tz": r.tz, "feeds": list(r.feeds), "osm_sha256": r.osm_sha256,
            "semantic_config_digest": r.semantic_config_digest, "otp_sha256": r.otp_sha256,
            "validator_sha256": r.validator_sha256, "country": r.country, "namespace": r.namespace,
            "blob_root": str(r.blobs.root), "analysis_window_start": self.window_start,
            "versions": [vars(v) for v in sorted(r.versions.values(), key=lambda v: (v.feed_id, v.index))]},
            indent=1, sort_keys=True))
        (o / "schedule.json").write_text(json.dumps(self.events, sort_keys=True))
        (o / "shared_born.json").write_text(json.dumps(self.shared_born, sort_keys=True))
        allc = dict(self.contracts)
        for arm in self._arms:
            (o / f"overlay_born_{arm.method}_{arm.level}.json").write_text(json.dumps(arm.mc.overlay_born, sort_keys=True))
            allc.update(arm.mc.contracts)
            (o / f"native_{arm.method}_{arm.level}.json").write_text(json.dumps(
                {"preprocessing": (self.native_builder.preprocessing.get(r.region_id) if self.native_builder else None)},
                sort_keys=True, default=str))
        with (o / "contracts.jsonl").open("w") as fh:
            for aid in sorted(allc):
                for c in allc[aid]:
                    fh.write(json.dumps({"artifact_id": aid, "contract": c.canonical_bytes.decode()}, sort_keys=True) + "\n")
        with (o / "cost_ledger.jsonl").open("w") as fh:
            for ob in self.shared_runs:
                fh.write(json.dumps(vars(ob), sort_keys=True) + "\n")

        def h(name):
            return hashlib.sha256((o / name).read_bytes()).hexdigest()
        cats = tuple([("shared", h("catalog_shared.jsonl"))] + [
            (f"{a.method}_{a.level}", h(f"overlay_{a.method}_{a.level}.jsonl")) for a in self._arms
            if (o / f"overlay_{a.method}_{a.level}.jsonl").exists()])
        names = ["region.json", "schedule.json", "history.jsonl", "shared_born.json", "contracts.jsonl",
                 "cost_ledger.jsonl", "raw_export.jsonl", "catalog_shared.jsonl"] + \
            [p.name for p in sorted(o.glob("overlay_*.jsonl"))] + [p.name for p in sorted(o.glob("overlay_born_*.json"))]
        if self.history_path.resolve() != (o / "history.jsonl").resolve():
            raise RuntimeError("history journal must live in the sealed directory")
        return S.SealedLedger(h("history.jsonl"), cats, h("contracts.jsonl"), h("raw_export.jsonl"), h("cost_ledger.jsonl"),
                              tuple((n, str(o / n)) for n in names) + tuple(("sha256:" + n, h(n)) for n in names))

    def _n1_val_bound(self, arm: Arm, req: S.ConsumerRequest):
        out = []
        for s in req.request_slots:
            if s.startswith("VAL:"):
                got = arm.mc.bind(s, req.tick_utc)
                out.append((s, S.BoundArtifact.from_entry(*got) if got else None))
        return out

    def _n1(self, arm: Arm, req: S.ConsumerRequest, est, ev) -> S.AdmissionDecision:
        if arm.native_state is None:
            arm.native_state = self.native_builder.initial_state(self.r.region_id, "envelope:" + self.r.region_id)
        l0 = now_wall()
        vb = tuple(self._n1_val_bound(arm, req))
        arm.last_lookup_s = now_wall() - l0
        vc = tuple((b.artifact_id, tuple(arm.mc.contracts.get(b.artifact_id, ()))) for _, b in vb if b is not None)
        inputs = tuple((f, self.r.ref(f, i)["logical_version_id"], self.r.ref(f, i)["canonical_content_sha256"])
                       for f, i in req.current_cut.frontier)
        view = S.N1CurrentView(req, vb, vc, inputs, arm.native_state, est)
        arm.last_n1_view = view
        out = N1BaselineImpl().decide(view, CurrentCutEvaluatorImpl(ev, req.context),
                                      CurrentCutRederiverImpl(arm.rederiver, req.current_cut, req.tick_utc),
                                      self.native_builder)
        arm.native_state = out.native_state
        return out.decision


def schedule_history(sched, path: Path | None = None) -> RealizedHistory:
    h = RealizedHistory(path)
    to_history(sched, h)
    return h
