"""N5 and N1 baselines behind the frozen V1.2 interfaces (docs/pre_s3/06 §4, §6, 08, 09, V1.2 §2, §4).

N5: same contracts / evaluator / est / re-derivation as F1, CURRENT cut only. It receives a CurrentCutView
(= RequestBinding built from the shared catalog + N5's OWN overlay) and current-bound evaluator / rederiver; no
history, catalog, cut enumeration, witness index or F1 output is reachable from its inputs.
N1: VAL slots via the N5(K0) current-cut path; ROUTER slot = reuse the last successful N1 graph iff its exact input
vector equals c_cur's, else a native `--loadStreet` + `cache.enabled` rebuild at c_cur charged with N1's OWN measured
cost. No contracts beyond K0 identity; no history.
"""
from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

from ...common.util import sha256_obj
from ..interfaces import session3 as S
from .core import ARTIFACT_OUTCOMES, EngineError, all_valid, execute_plan, producer_class_of, producer_cost_items


def _decide_current(req: S.ConsumerRequest, bindings, contracts_, estimates, level: str, evaluator, rederiver,
                    method: str, slots=None) -> S.AdmissionDecision:
    from .core import ControlTimer
    tm = ControlTimer(evaluator)
    slots = slots or req.request_slots
    bound = dict(bindings)
    contracts = dict(contracts_)
    est = dict(estimates)
    cur, failing = [], []
    for s in req.request_slots:
        if s not in slots:
            continue
        b = bound.get(s)
        if b is None:
            failing.append(s)
            continue
        cs = [c for c in contracts.get(b.artifact_id, ()) if c.level == level]
        if level not in S.LEVELS:
            raise EngineError("K3 is never an admission level")
        rs = [evaluator.evaluate(c) for c in cs]
        cur.extend(rs)
        if not all_valid(rs):
            failing.append(s)
    tm.mark("admission")
    items = list(tm.items)
    if not failing:
        return S.AdmissionDecision(req, method, level, S.Action.REUSE, S.Mode.CURRENT, tuple(cur),
                                   costs=S.CostRecord(tuple(items)))
    opt = round(sum(est[s] for s in failing), 9)
    plan = S.RepairPlan(req.request_id, S.Mode.CURRENT, req.current_cut, tuple(failing),
                        tuple(S.RederivationStep(s, req.current_cut.cut_id, producer_class_of(s), est[s]) for s in failing),
                        opt, None, None)
    done = execute_plan(plan, lambda st: rederiver.rederive(st.slot_id, st.estimate_s))
    items.extend(producer_cost_items(done, rederiver, req.tick_utc))
    if all(s.outcome in ARTIFACT_OUTCOMES for s in done.steps):
        return S.AdmissionDecision(req, method, level, S.Action.REDERIVE, S.Mode.CURRENT, tuple(cur), repair=done,
                                   costs=S.CostRecord(tuple(items)))
    return S.AdmissionDecision(req, method, level, S.Action.NO_ARTIFACT, None, tuple(cur), repair=done,
                               costs=S.CostRecord(tuple(items)))


class N5BaselineImpl:
    def decide(self, view: S.CurrentCutView, level: str, evaluator, rederiver) -> S.AdmissionDecision:
        if not isinstance(view, S.RequestBinding):
            raise EngineError("N5 accepts only a CurrentCutView")
        return _decide_current(view.request, view.bindings, view.contracts, view.estimates, level, evaluator, rederiver,
                               "N5")


class N1BaselineImpl:
    """Router via native OTP persistence; VAL via the N5(K0) current-cut path. Fail-fast in canonical order."""
    def decide(self, view: S.N1CurrentView, evaluator, rederiver, native) -> S.N1Outcome:
        req = view.request
        val_slots = tuple(s for s, _ in view.val_bindings)
        vd = _decide_current(req, view.val_bindings, view.val_contracts, view.estimates, "K0", evaluator, rederiver, "N1",
                             slots=val_slots)
        items = list(vd.costs.items)
        steps = list(vd.repair.steps) if vd.repair else []
        failing = list(vd.repair.failing_slots) if vd.repair else []
        state = view.native_state
        evidence: tuple = ()
        router = [s for s in req.request_slots if s.startswith("ROUTER:")][0]
        est = dict(view.estimates)
        failed_val = vd.action == S.Action.NO_ARTIFACT
        same_inputs = state.last_success_inputs is not None and tuple(state.last_success_inputs) == \
            tuple(view.current_router_inputs) and state.last_success_graph_sha256 is not None
        if not same_inputs:
            failing.append(router)
            if failed_val:                                                  # fail-fast: router step unattempted
                steps.append(S.RederivationStep(router, req.current_cut.cut_id, "otp", est[router]))
            else:
                st, state, evidence = native.build(view)
                steps.append(st)
                if st.outcome is not None:
                    lc = getattr(native, "last_cpu_s", None)
                    cpu = float(lc) if lc is not None else float(st.measured_wall_s or 0.0)
                    items.append(S.CostItem(S.CostCategory.A_PRODUCER, "producer:otp-native", float(st.measured_wall_s or 0),
                                            cpu, router, st.outcome))
        if not failing:
            d = S.AdmissionDecision(req, "N1", "K0", S.Action.REUSE, S.Mode.CURRENT, vd.current_evaluations,
                                    costs=S.CostRecord(tuple(items)))
            return S.N1Outcome(d, state, evidence)
        plan = S.RepairPlan(req.request_id, S.Mode.CURRENT, req.current_cut, tuple(failing), tuple(steps),
                            round(sum(s.estimate_s for s in steps), 9), None, None)
        ok = all(s.outcome in ARTIFACT_OUTCOMES for s in steps)
        d = S.AdmissionDecision(req, "N1", "K0", S.Action.REDERIVE if ok else S.Action.NO_ARTIFACT,
                                S.Mode.CURRENT if ok else None, vd.current_evaluations, repair=plan,
                                costs=S.CostRecord(tuple(items)))
        return S.N1Outcome(d, state, evidence)


class N1BlockedError(EngineError):
    """Native cache activity could not be evidenced: the N1 run is BLOCKED (never silently a weaker N1)."""


def _dir_manifest(d: Path) -> str:
    if not d.exists():
        return sha256_obj([])
    return sha256_obj(sorted((str(p.relative_to(d)), hashlib.sha256(p.read_bytes()).hexdigest())
                             for p in d.rglob("*") if p.is_file()))


class FixtureNativeOtpBuilder:
    """FIXTURE_STUB native builder: emulates the persisted street graph + cache with labelled marker files; measured
    cost = the fixture duration for a native rebuild (otp_native_s) — N1's OWN observation, not the F1/N5 ledger."""
    def __init__(self, root: Path, otp_native_s: float = 1800.0, street_s: float = 3600.0, evidence_cache: bool = True,
                 otp_native_cpu_s: float | None = None):
        self.root = root
        self.otp_native_s = otp_native_s
        self.otp_native_cpu_s = otp_native_s if otp_native_cpu_s is None else otp_native_cpu_s   # synthetic CPU
        self.last_cpu_s: float | None = None
        self.street_s = street_s
        self.evidence_cache = evidence_cache
        self.preprocessing: dict = {}

    def initial_state(self, region_id: str, envelope_digest: str) -> S.NativeOtpState:
        d = self.root / sha256_obj(region_id)[:16]
        (d / "street").mkdir(parents=True, exist_ok=True)
        (d / "cache").mkdir(parents=True, exist_ok=True)
        g = d / "street" / "streetGraph.obj"
        g.write_text("FIXTURE_STUB_BINARY street graph " + region_id)
        self.preprocessing[region_id] = {"component": "n1_street_graph_build", "wall_s": self.street_s,
                                         "cpu_s": self.street_s, "charged_once": True,
                                         "identity": sha256_obj(["n1_preprocessing", region_id, str(g)]),
                                         "binary_mode": "FIXTURE_STUB_BINARY"}
        return S.NativeOtpState(region_id, str(g), hashlib.sha256(g.read_bytes()).hexdigest(), str(d / "cache"),
                                _dir_manifest(d / "cache"), envelope_digest, None, None)

    def build(self, view: S.N1CurrentView):
        st = view.native_state
        cache = Path(st.cache_dir)
        before = _dir_manifest(cache)
        if self.evidence_cache:
            key = sha256_obj(list(view.current_router_inputs))
            (cache / f"{key[:16]}.cache").write_text("FIXTURE_STUB_BINARY native cache entry")
        after = _dir_manifest(cache)
        if after == before or not any(cache.iterdir()):
            raise N1BlockedError("native cache activity not evidenced")
        g = sha256_obj(["FIXTURE-STUB-N1-GRAPH", list(view.current_router_inputs)])
        router = [s for s in view.request.request_slots if s.startswith("ROUTER:")][0]
        step = S.RederivationStep(router, view.request.current_cut.cut_id, "otp", dict(view.estimates)[router], "SUCCESS",
                                  "N1:" + g[:24], sha256_obj(["FIXTURE-STUB-N1", g]), self.otp_native_s)
        self.last_cpu_s = self.otp_native_cpu_s
        new = S.NativeOtpState(st.region_id, st.street_graph_path, st.street_graph_sha256, st.cache_dir, after,
                               st.envelope_digest, tuple(view.current_router_inputs), g)
        ev = (("mode", "FIXTURE_STUB_BINARY"), ("load_street", st.street_graph_path), ("cache_before", before),
              ("cache_after", after), ("cache_enabled", "true"))
        return step, new, ev


CACHE_NO_TASK = "CACHE_ENABLED_NO_CACHEABLE_TASK_UNDER_FROZEN_CONFIG"
CACHE_ACTIVE = "CACHE_ACTIVITY_EVIDENCED"
# Applicability of each OTP 2.10.0 graph-build cache task under a build configuration (AMENDMENT-S3-N1-01):
#   ELEVATION  — requires an elevation input (build-config "dem"/elevation keys or a DEM file in the base directory)
#   VISIBILITY — requires area visibility (build-config "areaVisibility": true; OTP default false)
KNOWN_CACHE_TASKS = ("ELEVATION", "VISIBILITY")


def otp_cache_tasks(otp_jar: Path) -> tuple[str, ...]:
    """Enum constants of org.opentripplanner.graph_builder.module.cache.CacheTask read from the pinned jar's class file
    (fields with ACC_ENUM). Proves the set of cacheable build tasks of THIS OTP binary."""
    import struct
    import zipfile as zf
    data = zf.ZipFile(otp_jar).read("org/opentripplanner/graph_builder/module/cache/CacheTask.class")
    if data[:4] != b"\xca\xfe\xba\xbe":
        raise N1BlockedError("CacheTask.class is not a class file")
    n = struct.unpack(">H", data[8:10])[0]
    i, k, utf8 = 10, 1, {}
    sizes = {3: 4, 4: 4, 5: 8, 6: 8, 7: 2, 8: 2, 9: 4, 10: 4, 11: 4, 12: 4, 15: 3, 16: 2, 17: 4, 18: 4, 19: 2, 20: 2}
    while k < n:
        tag = data[i]
        if tag == 1:
            ln = struct.unpack(">H", data[i + 1:i + 3])[0]
            utf8[k] = data[i + 3:i + 3 + ln].decode("utf-8", "replace")
            i += 3 + ln
        else:
            i += 1 + sizes[tag]
        k += 2 if tag in (5, 6) else 1
    i += 6                                                   # access, this, super
    ni = struct.unpack(">H", data[i:i + 2])[0]
    i += 2 + 2 * ni
    nf = struct.unpack(">H", data[i:i + 2])[0]
    i += 2
    out = []
    for _ in range(nf):
        acc, name, _desc, na = struct.unpack(">HHHH", data[i:i + 8])
        i += 8
        for _ in range(na):
            ln = struct.unpack(">I", data[i + 2:i + 6])[0]
            i += 6 + ln
        if acc & 0x4000:
            out.append(utf8[name])
    return tuple(out)


def applicable_cache_tasks(tasks: tuple[str, ...], build_config: dict, base_dir: Path, otp_log: str) -> dict:
    """Which cacheable tasks apply under the exact build configuration; unknown tasks are never assumed inapplicable."""
    res = {}
    for t in tasks:
        if t == "ELEVATION":
            keys = [k for k in build_config if "dem" in k.lower() or "elevation" in k.lower()]
            files = [p.name for p in base_dir.iterdir() if p.suffix.lower() in (".tif", ".tiff")]
            res[t] = {"applicable": bool(keys or files), "evidence": {"config_keys": keys, "dem_files": files}}
        elif t == "VISIBILITY":
            on = build_config.get("areaVisibility") is True
            skipped = "Skipping visibility graph construction" in otp_log
            res[t] = {"applicable": on or not skipped,
                      "evidence": {"areaVisibility_config": build_config.get("areaVisibility", "default(false)"),
                                   "otp_log_skipped_visibility": skipped}}
        else:
            res[t] = {"applicable": True, "evidence": {"reason": "unknown task: inapplicability cannot be demonstrated"}}
    return res


def router_slot(view) -> str:
    return [s for s in view.request.request_slots if s.startswith("ROUTER:")][0]


class RealNativeOtpBuilder:
    """REAL pinned OTP 2.10.0 native rebuild (frozen N1 mechanism): a per-region street graph built ONCE with
    `--buildStreet` (charged once as preprocessing) and persisted; every rebuild runs `--loadStreet --save` on a job
    directory holding the persisted streetGraph.obj, the current GTFS inputs and build-config with
    `cache: {enabled: true}`; OTP cache files (`<task>-cache-<version>.obj`, base directory) are persisted between
    builds in the region's cache directory. Same java/JVM flags/wrappers (resource envelope) as F1 router production.
    Evidence: OTP log line reading streetGraph.obj + cache files present/changed. If cache activity cannot be
    evidenced the run raises N1BlockedError (BLOCKED, never a silently weaker N1)."""
    def __init__(self, otp_producer, root: Path, envelope_digest: str):
        self.otp = otp_producer
        self.root = root
        self.envelope_digest = envelope_digest
        self.preprocessing: dict = {}
        self.inputs: dict = {}          # region -> {"osm": path, "feeds": {(feed, lvid): zip}, "tz", "build_date"}
        self.last_evidence: dict = {}
        self.last_cpu_s: float | None = None
        self.street_logs: dict = {}

    def _run(self, args: list[str], job: Path, name: str):
        from ..producers.process import base_env, run_process
        java = str(self.otp.deps.java)
        argv = [java] + self.otp.jvm_flags(job) + ["-jar", str(self.otp.deps.otp_jar)] + args
        wrappers = (self.otp.wrappers_factory("otp") if self.otp.wrappers_factory else []) + self.otp.extra_wrappers
        (job / "tmp").mkdir(exist_ok=True)
        return run_process(argv, job, env=base_env(job), timeout_s=self.otp.timeout_s, wrappers=wrappers,
                           isolate_network=self.otp.isolate_network, clock=self.otp.clock,
                           stdout_name=f"{name}_stdout.log", stderr_name=f"{name}_stderr.log")

    def initial_state(self, region_id: str, envelope_digest: str | None = None) -> S.NativeOtpState:
        reg = self.inputs[region_id]
        d = self.root / sha256_obj(region_id)[:16]
        street = d / "street"
        if d.exists():
            shutil.rmtree(d)
        street.mkdir(parents=True)
        shutil.copy(reg["osm"], street / "street.osm.pbf")
        (street / "build-config.json").write_text(json.dumps({"osm": [{"source": "street.osm.pbf"}],
                                                              "cache": {"enabled": True}}))
        pr = self._run(["--buildStreet", str(street)], street, "street")
        g = street / "streetGraph.obj"
        if pr.failure_class != "SUCCESS" or not g.exists():
            raise N1BlockedError(f"N1 street graph build failed ({pr.failure_class})")
        self.street_logs[region_id] = Path(pr.stdout_path).read_text(errors="ignore") + \
            Path(pr.stderr_path).read_text(errors="ignore")
        self.preprocessing[region_id] = {"component": "n1_street_graph_build", "wall_s": pr.wall_s,
                                         "cpu_s": pr.cpu_user_s + pr.cpu_sys_s, "charged_once": True,
                                         "identity": sha256_obj(["n1_preprocessing", region_id,
                                                                 hashlib.sha256(g.read_bytes()).hexdigest()]),
                                         "binary_mode": "REAL_PINNED_BINARY"}
        (d / "cache").mkdir()
        for c in street.glob("*-cache-*.obj"):
            shutil.copy(c, d / "cache" / c.name)
        return S.NativeOtpState(region_id, str(g), hashlib.sha256(g.read_bytes()).hexdigest(), str(d / "cache"),
                                _dir_manifest(d / "cache"), envelope_digest or self.envelope_digest, None, None)

    def build(self, view: S.N1CurrentView):
        st = view.native_state
        reg = self.inputs[st.region_id]
        cache = Path(st.cache_dir)
        job = cache.parent / ("build-" + sha256_obj(list(view.current_router_inputs))[:12])
        if job.exists():
            shutil.rmtree(job)
        job.mkdir(parents=True)
        shutil.copy(st.street_graph_path, job / "streetGraph.obj")
        shutil.copy(reg["osm"], job / "street.osm.pbf")
        for c in cache.glob("*-cache-*.obj"):
            shutil.copy(c, job / c.name)
        from ..producers.otp import OtpFeedInput, OtpRequest, build_config_for
        oreq = OtpRequest(router_slot(view), st.region_id,
                          tuple(OtpFeedInput(f, lvid, sha, reg["feeds"][(f, lvid)])
                                for f, lvid, sha in view.current_router_inputs),
                          reg["osm"], reg["tz"], reg["build_date"], tuple(view.request.context.horizon),
                          view.request.current_cut.cut_id, reg.get("namespace", "FIXTURE"))
        if reg.get("service_bounds"):                             # one-shot campaign: fixed absolute bounds
            import dataclasses
            oreq = dataclasses.replace(oreq, service_start=reg["service_bounds"][0],
                                       service_end=reg["service_bounds"][1])
        frozen_cfg, files = build_config_for(oreq)               # EXACT frozen F1 graph configuration
        for local, src in files.items():
            if local != "street.osm.pbf":
                shutil.copy(src, job / local)
        reg["frozen_build_config"] = frozen_cfg
        cfg = {**frozen_cfg, "cache": {"enabled": True}}         # + native cache (only difference)
        (job / "build-config.json").write_text(json.dumps(cfg, sort_keys=True))
        before = _dir_manifest(cache)
        pr = self._run(["--loadStreet", "--save", str(job)], job, "native")
        self.last_cpu_s = pr.cpu_user_s + pr.cpu_sys_s
        log = Path(pr.stdout_path).read_text(errors="ignore") + Path(pr.stderr_path).read_text(errors="ignore")
        for c in job.glob("*-cache-*.obj"):
            shutil.copy(c, cache / c.name)
        after = _dir_manifest(cache)
        router = [s for s in view.request.request_slots if s.startswith("ROUTER:")][0]
        est = dict(view.estimates)[router]
        graph = job / "graph.obj"
        street_loaded = "streetGraph.obj" in log and "Reading graph from" in log
        cache_files = sorted(p.name for p in cache.glob("*-cache-*.obj"))
        self.last_evidence = {"street_graph_loaded": street_loaded, "cache_enabled_in_config": True,
                              "cache_files": cache_files, "cache_manifest_before": before, "cache_manifest_after": after,
                              "rc": pr.rc, "wall_s": pr.wall_s, "failure_class": pr.failure_class,
                              "graph_built": graph.exists(), "job": str(job)}
        if pr.failure_class != "SUCCESS" or not graph.exists():
            step = S.RederivationStep(router, view.request.current_cut.cut_id, "otp", est, pr.failure_class, None, None,
                                      pr.wall_s)
            return step, st, (("failure_class", pr.failure_class),)
        tasks = otp_cache_tasks(Path(self.otp.deps.otp_jar))
        appl = applicable_cache_tasks(tasks, cfg, job, self.street_logs.get(st.region_id, "") + log)
        applicable = sorted(t for t, v in appl.items() if v["applicable"])
        frozen_cfg = {k: v for k, v in cfg.items() if k != "cache"}
        cfg_ok = frozen_cfg == reg.get("frozen_build_config", frozen_cfg)
        status = CACHE_ACTIVE if cache_files else (CACHE_NO_TASK if not applicable else "BLOCKED")
        self.last_evidence.update(otp_jar_sha256=hashlib.sha256(Path(self.otp.deps.otp_jar).read_bytes()).hexdigest(),
                                  cache_tasks=list(tasks), cache_task_applicability=appl,
                                  frozen_config_identical=cfg_ok, cache_status=status,
                                  otp_log=str(Path(pr.stdout_path)))
        if not street_loaded:
            raise N1BlockedError("persisted streetGraph.obj loading not evidenced in the OTP log")
        if not cfg_ok:
            raise N1BlockedError("N1 build configuration differs from the frozen graph configuration")
        if status == "BLOCKED":
            raise N1BlockedError(f"cacheable task(s) {applicable} apply under the frozen configuration but no cache "
                                 "activity was evidenced")
        gsha = hashlib.sha256(graph.read_bytes()).hexdigest()
        step = S.RederivationStep(router, view.request.current_cut.cut_id, "otp", est, "SUCCESS", "N1:" + gsha[:24],
                                  sha256_obj(["N1", gsha]), pr.wall_s)
        new = S.NativeOtpState(st.region_id, st.street_graph_path, st.street_graph_sha256, st.cache_dir, after,
                               st.envelope_digest, tuple(view.current_router_inputs), gsha)
        return step, new, (("mode", "REAL_PINNED_BINARY"), ("street_loaded", str(street_loaded)),
                           ("cache_before", before), ("cache_after", after), ("cache_enabled", "true"),
                           ("cache_status", status), ("cache_tasks", ",".join(tasks)),
                           ("applicable_cache_tasks", ",".join(applicable)))
