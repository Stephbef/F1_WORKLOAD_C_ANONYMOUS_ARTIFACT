"""Session-4 baselines N0, N2, N3, N4, N6 — AMENDMENT-S4A-BASELINES-01 (docs/s4a1/AMENDMENT_S4A_BASELINES_01.md).

Typed Session-4 internal interfaces (the frozen V1.2 Session-3 interface is untouched): a baseline sees ONLY a
`BaselineView` (the identical ConsumerRequest, per slot the latest admissible artifact from the SHARED scheduled catalog
plus ITS OWN overlay — none for N0 —, the current versions' realized event identities and intervals, est(s,t), τ for N4)
and acts only through a `BaselineProducers` facade bound to the current cut (VAL validator; ROUTER either the N0 full cold
build or the N1-native configuration). No RealizedHistory, Γ, catalog handle, witness index, F1/N5 output or K3
reference is reachable from a baseline decision.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import timedelta

from ..catalog.artifacts import ArtifactCatalog
from ..contracts.model import Contract
from ..history.realized import Cut
from ..interfaces import session3 as S
from .core import (ARTIFACT_OUTCOMES, ControlTimer, CurrentCutEvaluatorImpl, EngineError, MethodCatalog,
                   ProducerRederiver, TimedEvaluator, feed_of, now_wall, parse_utc, producer_class_of)

BASELINES_S4 = ("N0", "N2", "N3", "N4", "N6")
TAU_CANDIDATES_H = (1, 6, 24, 72, 168)
N1_NATIVE = "N1_NATIVE_CONFIG"
N0_FULL_COLD = "FULL_COLD_STREET_PLUS_TRANSIT"


class SelectionBlocked(EngineError):
    """N4 τ selection cannot proceed (unclassifiable reuse decisions)."""


# ------------------------------------------------------------------------------------------------- data types
@dataclass(frozen=True)
class OwnArtifact:
    """METHOD-SPECIFIC projection of an admissible artifact (S4A.1.1): only the fields the method uses are present.
    N0: never. N2 / N6-ROUTER: k0_contracts. N3: pin + pin_interval (from N3's own pin index). N4: born only.
    N6-VAL: n6_key (from N6's own exact-key cache index)."""
    slot_id: str
    artifact_id: str
    born_utc: str
    k0_contracts: tuple[Contract, ...] = ()
    pin: tuple | None = None
    pin_interval: tuple[str, str | None] | None = None
    n6_key: tuple | None = None


@dataclass(frozen=True)
class VersionEvent:
    feed_id: str
    index: int
    event_id: str
    canonical_sha256: str
    available_utc: str
    next_available_utc: str | None


_USES = {"N0": set(), "N2": {"k0"}, "N3": {"pin"}, "N4": set(), "N6": {"k0", "n6"}}


@dataclass(frozen=True)
class BaselineView:
    method: str
    request: S.ConsumerRequest
    bound: tuple[tuple[str, OwnArtifact | None], ...]              # per designated slot (N0: all None; N6-VAL: None)
    current_versions: tuple[VersionEvent, ...]                      # realized identities of the CURRENT cut only
    current_pins: tuple[tuple[str, tuple], ...]                     # N3 only: slot -> pin the current context requires
    current_n6_keys: tuple[tuple[str, tuple], ...]                  # N6 only: VAL slot -> current N6 key
    n6_hits: tuple[tuple[str, tuple[OwnArtifact, ...]], ...]        # N6 only: EXACT-key cache candidates per VAL slot
    estimates: tuple[tuple[str, float], ...]
    tau_h: int | None = None

    def __post_init__(self) -> None:
        if self.method not in BASELINES_S4:
            raise EngineError(f"unknown Session-4 baseline {self.method}")
        if tuple(s for s, _ in self.bound) != self.request.request_slots:
            raise EngineError("one binding per designated slot, in canonical order")
        if self.method == "N0" and any(b is not None for _, b in self.bound):
            raise EngineError("N0 receives no reusable artifact")
        if self.method == "N4" and self.tau_h not in TAU_CANDIDATES_H:
            raise EngineError(f"N4 τ must be one of {TAU_CANDIDATES_H}")
        if self.method != "N4" and self.tau_h is not None:
            raise EngineError("τ is N4-only")
        cur = {(v.feed_id, v.index) for v in self.current_versions}
        if cur != {(f, i) for f, i in self.request.current_cut.frontier if i > 0}:
            raise EngineError("current_versions must describe exactly the current cut")
        uses = _USES[self.method]
        arts = [b for _, b in self.bound if b is not None] + [a for _, hs in self.n6_hits for a in hs]
        for a in arts:                                   # method-specific projection: no foreign metadata present
            if a.pin is not None and "pin" not in uses or a.n6_key is not None and "n6" not in uses or \
                    a.k0_contracts and "k0" not in uses:
                raise EngineError(f"{self.method} view carries metadata it does not use")
        if (self.current_pins and "pin" not in uses) or ((self.current_n6_keys or self.n6_hits) and "n6" not in uses):
            raise EngineError(f"{self.method} view carries foreign index data")
        keys = dict(self.current_n6_keys)
        for slot, hs in self.n6_hits:                    # N6 sees EXACT-key matches only
            if any(a.n6_key != keys.get(slot) or a.slot_id != slot for a in hs):
                raise EngineError("N6 candidates must match the current key exactly")


@dataclass(frozen=True)
class SlotDecision:
    slot_id: str
    action: str                                      # REUSE | REDERIVE | NO_ARTIFACT
    artifact_id: str | None
    step: S.RederivationStep | None
    reason: str


@dataclass(frozen=True)
class BaselineDecision:
    method: str
    tau_h: int | None
    request: S.ConsumerRequest
    slots: tuple[SlotDecision, ...]
    joint_action: str                                # REUSE | REDERIVE | NO_ARTIFACT
    costs: S.CostRecord
    reuse_events: tuple[tuple[str, str, str], ...]   # (slot, artifact id, born_utc) — for offline N4 safety

    def __post_init__(self) -> None:
        if tuple(s.slot_id for s in self.slots) != self.request.request_slots:
            raise EngineError("one slot decision per designated slot")
        acts = [s.action for s in self.slots]
        want = "NO_ARTIFACT" if "NO_ARTIFACT" in acts else ("REUSE" if all(a == "REUSE" for a in acts) else "REDERIVE")
        if self.joint_action != want:
            raise EngineError("joint action inconsistent with slot decisions")
        if self.method == "N0" and any(a == "REUSE" for a in acts):
            raise EngineError("N0 never reuses")


class BaselineProducers:
    """Current-cut-bound producer facade: VAL validator; ROUTER = N0 full cold build or N1-native rebuild."""
    def __init__(self, val_and_cold: ProducerRederiver, native: "NativeRouterRederiver", cut: Cut, tick_utc: str):
        self._vc, self._nat, self._cut, self._t = val_and_cold, native, cut, tick_utc

    def validator(self, slot_id: str, estimate_s: float) -> S.RederivationStep:
        return self._vc.rederive(slot_id, self._cut, self._t, estimate_s)

    def router_full_cold(self, slot_id: str, estimate_s: float) -> S.RederivationStep:
        return self._vc.rederive(slot_id, self._cut, self._t, estimate_s)            # frozen two-step full build

    def router_n1_native(self, slot_id: str, estimate_s: float) -> S.RederivationStep:
        return self._nat.rederive(slot_id, self._cut, self._t, estimate_s)

    def cpu_of(self, step: S.RederivationStep) -> float:
        for r in (self._vc, self._nat):
            c = r.cpu.get((step.slot_id, step.target_cut_id, self._t))
            if c is not None:
                return float(c)
        return float(step.measured_wall_s or 0.0)


class NativeRouterRederiver(ProducerRederiver):
    """ROUTER re-derivation in the N1-native configuration for N2/N3/N4/N6 (persisted street, --loadStreet --save,
    cache.enabled, N1 OTP envelope). FIXTURE: the in-process producer builds the artifact (K0 identity as frozen) and the
    measured duration is the fixture native-rebuild duration; REAL: RealNativeOtpBuilder (Session 4 wiring)."""
    def __init__(self, region, mc: MethodCatalog, producer, native_wall_s: float = 1800.0,
                 native_cpu_s: float | None = None) -> None:
        super().__init__(region, mc, producer)
        self.native_wall_s = native_wall_s
        self.native_cpu_s = native_wall_s if native_cpu_s is None else native_cpu_s

    def rederive(self, slot_id, cut, tick_utc, estimate_s):
        if not slot_id.startswith("ROUTER:"):
            raise EngineError("native rederiver is ROUTER-only")
        orig = self.p.produce

        def produce(s, c, t):
            p = orig(s, c, t)
            p.wall_s, p.cpu_s = self.native_wall_s, self.native_cpu_s
            p.entry_kw = {**p.entry_kw, "output_digests": list(p.entry_kw.get("output_digests", [])) +
                          [("mechanism", N1_NATIVE)]}
            return p
        self.p.produce = produce
        try:
            return super().rederive(slot_id, cut, tick_utc, estimate_s)
        finally:
            self.p.produce = orig


# ------------------------------------------------------------------------------------------------- policies
def _k0_valid(art: OwnArtifact, evaluator) -> bool:
    rs = [evaluator.evaluate(c) for c in art.k0_contracts]
    return bool(rs) and all(r.verdict == "VALID" for r in rs)


def _in_interval(t: str, iv: tuple[str, str | None]) -> bool:
    return iv[0] <= t and (iv[1] is None or t < iv[1])


def _age_s(t: str, born: str) -> float:
    return (parse_utc(t) - parse_utc(born)).total_seconds()


class S4Baseline:
    """Executes one Session-4 baseline policy for one request. Per-slot independent decisions in canonical order;
    every needed re-derivation is attempted (no fail-fast, no stale fallback); artifacts appear at completion.
    Control-plane intervals are disjoint (core.ControlTimer): 'n3_pin_index_lookup' (N3 join) and 'admission'."""
    def decide(self, view: BaselineView, evaluator: S.CurrentCutEvaluator, producers: BaselineProducers
               ) -> BaselineDecision:
        tm = ControlTimer(evaluator)
        req = view.request
        est = dict(view.estimates)
        joins: dict[str, bool] = {}
        if view.method == "N3":                          # explicit, non-overlapping N3 pin/interval join interval
            pins = dict(view.current_pins)
            for slot, art in view.bound:
                joins[slot] = art is not None and art.pin is not None and art.pin_interval is not None and \
                    art.pin == pins[slot] and _in_interval(req.tick_utc, art.pin_interval) and art.born_utc <= req.tick_utc
            tm.mark("n3_pin_index_lookup")
        hits = dict(view.n6_hits)
        plan: list[tuple[str, OwnArtifact | None, str]] = []
        for slot, art in view.bound:
            reuse, why = None, "rederive"
            m = view.method
            if m == "N0":
                why = "N0 full rebuild"
            elif m == "N2" or (m == "N6" and slot.startswith("ROUTER:")):
                if art is not None and _k0_valid(art, evaluator):
                    reuse, why = art, "K0 valid at current cut"
            elif m == "N3":
                if joins[slot]:
                    reuse, why = art, "exact pin joins current interval"
            elif m == "N4":
                tau_s = float(view.tau_h or 0) * 3600.0
                if art is not None and art.born_utc <= req.tick_utc and _age_s(req.tick_utc, art.born_utc) < tau_s:
                    reuse, why = art, f"age < τ={view.tau_h}h"
            elif m == "N6":
                hs = [a for a in hits.get(slot, ()) if a.born_utc <= req.tick_utc]
                if hs:
                    reuse, why = max(hs, key=lambda a: (a.born_utc, a.artifact_id)), "N6 exact-key cache hit"
            plan.append((slot, reuse, why))
        tm.mark("admission")
        items = list(tm.items)
        slots, reused = [], []
        for slot, reuse, why in plan:
            if reuse is not None:
                slots.append(SlotDecision(slot, "REUSE", reuse.artifact_id, None, why))
                reused.append((slot, reuse.artifact_id, reuse.born_utc))
                continue
            pc = producer_class_of(slot)
            if pc == "validator":
                st = producers.validator(slot, est[slot])
            elif view.method == "N0":
                st = producers.router_full_cold(slot, est[slot])
            else:
                st = producers.router_n1_native(slot, est[slot])
            ok = st.outcome in ARTIFACT_OUTCOMES and st.new_artifact_id is not None
            slots.append(SlotDecision(slot, "REDERIVE" if ok else "NO_ARTIFACT", st.new_artifact_id if ok else None, st,
                                      why if ok else f"{why}; producer {st.outcome}; no stale fallback"))
            comp = f"producer:{pc}" + ("" if pc == "validator" else (":full_cold" if view.method == "N0" else ":n1_native"))
            items.append(S.CostItem(S.CostCategory.A_PRODUCER, comp, float(st.measured_wall_s or 0.0),
                                    producers.cpu_of(st), slot, st.outcome))
        acts = [s.action for s in slots]
        joint = "NO_ARTIFACT" if "NO_ARTIFACT" in acts else ("REUSE" if all(a == "REUSE" for a in acts) else "REDERIVE")
        return BaselineDecision(view.method, view.tau_h, req, tuple(slots), joint, S.CostRecord(tuple(items)),
                                tuple(reused))


# --------------------------------------------------------------------------------------------- N4 selection
@dataclass(frozen=True)
class TauOutcome:
    tau_h: int
    unsafe: int                    # U_τ
    cost_wall_s: float             # C_τ
    unclassifiable: int = 0
    no_artifact_requests: int = 0
    operational_cap_events: int = 0


def select_tau(outcomes: dict[int, TauOutcome]) -> int:
    """Frozen rule: τ* = lexicographic argmin (U_τ, C_τ, τ); blocked on any unclassifiable reuse. Takes ONLY TauOutcome
    (no F1 field exists in the input type)."""
    if set(outcomes) != set(TAU_CANDIDATES_H):
        raise SelectionBlocked(f"outcomes must cover exactly {TAU_CANDIDATES_H}")
    if any(o.unclassifiable for o in outcomes.values()):
        raise SelectionBlocked("N4 TAU SELECTION BLOCKED: unclassifiable reuse decisions")
    for t, o in outcomes.items():
        if o.tau_h != t:
            raise SelectionBlocked("τ key mismatch")
    return min(outcomes.values(), key=lambda o: (o.unsafe, o.cost_wall_s, o.tau_h)).tau_h


def classify_n4_reuses(decisions: list[BaselineDecision], reference) -> tuple[int, int]:
    """Offline (after the decisions): UNSAFE_ADMISSION iff the frozen K3 reference says the reused artifact is invalid for
    the request context. `reference(decision, slot, artifact_id)` returns True (valid) / False (invalid) / None
    (no scientifically valid verdict → UNCLASSIFIABLE). Returns (unsafe, unclassifiable)."""
    unsafe = unclassifiable = 0
    for d in decisions:
        if d.method != "N4":
            raise EngineError("only N4 decisions are classified")
        for slot, aid, _born in d.reuse_events:
            v = reference(d, slot, aid)
            if v is None:
                unclassifiable += 1
            elif v is False:
                unsafe += 1
    return unsafe, unclassifiable


def n4_cost(decisions: list[BaselineDecision]) -> float:
    """C_τ: total measured N4 online wall seconds (A + B), including failed attempts and work up to the cap."""
    return float(sum(i.wall_s for d in decisions for i in d.costs.items if i.category != S.CostCategory.C_OFFLINE))


# --------------------------------------------------------------------------------------------- runner glue
class N3PinError(EngineError):
    """An artifact lacks trustworthy birth-context provenance for an N3 pin (fail closed: never pinnable/reusable)."""


def n3_pin_from_contract(slot: str, k0: tuple[Contract, ...], lv_event: dict, frontier, region_id: str) -> tuple:
    """N3 pin from the artifact's ACTUAL birth-time K0 contract footprint (validator date / country / validator digest;
    router feeds / OSM / semantic config / OTP) plus the exact logical-version EVENT ids of its inputs. Never derived
    from ARTIFACT_BORN, file times or the current request."""
    if len(k0) != 1:
        raise N3PinError(f"{slot}: exactly one K0 contract required for N3 pinning")
    fp = json.loads(k0[0].canonical_bytes)["footprint"]
    fr = dict(frontier)
    try:
        if slot.startswith("VAL:"):
            f = feed_of(slot) or ""
            return ("VAL", f, lv_event[(f, fr[f])], fp["canonical_content_sha256"], fp["date"], fp["country"],
                    fp["validator_sha256"])
        return ("ROUTER", region_id, tuple((f, lv_event[(f, i)], fp["feeds"][f]) for f, i in sorted(fr.items()) if i > 0),
                fp["osm_sha256"], fp["semantic_config_digest"], fp["otp_sha256"])
    except KeyError as e:
        raise N3PinError(f"{slot}: birth context incomplete ({e})") from e


@dataclass
class _Arm:
    method: str
    tau_h: int | None
    mc: MethodCatalog
    vc: ProducerRederiver
    nat: NativeRouterRederiver
    decisions: list = field(default_factory=list)
    n3_index: dict = field(default_factory=dict)       # artifact_id -> (pin | None, interval)   (N3 method state)
    n6_index: dict = field(default_factory=dict)       # n6_key -> list[OwnArtifact]           (N6 method state)
    n6_seen: set = field(default_factory=set)


class S4BaselineRunner:
    """Runs Session-4 baseline arms for one region over the SAME consumer stream as a Session-3 RegionCampaign whose
    shared scheduled production and realized history are reused (identical inputs for every method). Method state:
    N3 keeps an explicit pin index, N6 an explicit exact-key cache index; each method pays only for its own metadata."""
    def __init__(self, campaign, producer_factory, native_wall_s: float = 1800.0) -> None:
        self.c = campaign
        self.pf = producer_factory
        self.native_wall_s = native_wall_s
        h = campaign.history
        self.lv = {(f, idx): (eid, at) for f, chain in h.versions.items() for idx, at, eid in chain}
        self.lv_event = {k: v[0] for k, v in self.lv.items()}
        self.calls: dict[str, int] = {"n3_pin": 0, "n6_key": 0, "k0": 0}       # call spy (accounting isolation tests)

    def _arm(self, method: str, tau_h: int | None) -> _Arm:
        mc = MethodCatalog(self.c.shared, self.c.shared_born, ArtifactCatalog(None), {}, dict(self.c.contracts))
        vc = ProducerRederiver(self.c.r, mc, self.pf())
        nat = NativeRouterRederiver(self.c.r, mc, self.pf(), self.native_wall_s)
        nat._elapsed = vc._elapsed          # ONE serial clock per request: births at t + cumulative executed durations
        return _Arm(method, tau_h, mc, vc, nat)

    def _versions(self, cut: Cut) -> tuple[VersionEvent, ...]:
        out = []
        for f, i in cut.frontier:
            if i < 1:
                continue
            eid, at = self.lv[(f, i)]
            nxt = self.lv.get((f, i + 1))
            out.append(VersionEvent(f, i, eid, self.c.r.versions[(f, i)].canonical_content_sha256, at,
                                    nxt[1] if nxt else None))
        return tuple(out)

    def _interval(self, frontier) -> tuple[str, str | None]:
        lo, hi = "", None
        for f, i in frontier:
            if i < 1:
                continue
            at = self.lv[(f, i)][1]
            nxt = self.lv.get((f, i + 1))
            lo = max(lo, at)
            if nxt and (hi is None or nxt[1] < hi):
                hi = nxt[1]
        return lo, hi

    def current_pin(self, slot: str, ctx) -> tuple:
        """Pin the CURRENT request context requires (same field order as n3_pin_from_contract)."""
        r = self.c.r
        fr = dict(ctx_frontier(ctx, r))
        if slot.startswith("VAL:"):
            f = feed_of(slot) or ""
            return ("VAL", f, self.lv_event[(f, fr[f])], ctx.feeds[f]["canonical_content_sha256"], ctx.consumer_date,
                    ctx.country, ctx.validator_sha256)
        return ("ROUTER", r.region_id, tuple((f, self.lv_event[(f, i)], ctx.feeds[f]["canonical_content_sha256"])
                                             for f, i in sorted(fr.items()) if i > 0),
                ctx.osm_sha256, ctx.semantic_config_digest, ctx.otp_sha256)

    def n6_key(self, slot: str, entry) -> tuple:
        self.calls["n6_key"] += 1
        f = feed_of(slot) or ""
        i = dict(entry.birth_frontier)[f]
        return (f, self.lv_event[(f, i)], self.c.r.versions[(f, i)].canonical_content_sha256, self.c.r.country,
                self.c.r.validator_sha256)

    def _n3_entry(self, arm: _Arm, entry) -> tuple:
        """N3 pin-index UPDATE for one artifact (creation on first sight; immutable afterwards)."""
        if entry.artifact_id not in arm.n3_index:
            self.calls["n3_pin"] += 1
            k0 = tuple(c for c in arm.mc.contracts.get(entry.artifact_id, ()) if c.level == "K0")
            try:
                pin = n3_pin_from_contract(entry.request_slot, k0, self.lv_event, entry.birth_frontier, self.c.r.region_id)
            except N3PinError:
                pin = None                                # fail closed: never reusable by N3
            arm.n3_index[entry.artifact_id] = (pin, self._interval(entry.birth_frontier))
        return arm.n3_index[entry.artifact_id]

    def _n6_update(self, arm: _Arm, t: str, own_only: bool = False) -> None:
        """N6 cache-index UPDATE: index every newly available (born <= t) artifact-bearing VAL instance (shared + own)
        by its key; after a decision, N6's OWN new artifacts are inserted (they become hits only once born <= t')."""
        cats = [(arm.mc.overlay, arm.mc.overlay_born)] if own_only else \
            [(arm.mc.shared, arm.mc.shared_born), (arm.mc.overlay, arm.mc.overlay_born)]
        for cat, born in cats:
            for s in cat.slots():
                if not s.startswith("VAL:"):
                    continue
                for e in cat.instances(s):
                    b = born.get(e.artifact_id)
                    if e.artifact_id in arm.n6_seen or b is None or (b > t and not own_only) or \
                            e.status not in ARTIFACT_OUTCOMES:
                        continue
                    arm.n6_seen.add(e.artifact_id)
                    key = self.n6_key(s, e)
                    arm.n6_index.setdefault(key, []).append(OwnArtifact(s, e.artifact_id, b, n6_key=key))

    def run(self, methods: list[tuple[str, int | None]], ticks: list[str]) -> dict:
        from .core import estimates_for, local_date, prior_view  # noqa: F401
        arms = [self._arm(m, tau) for m, tau in methods]
        for t in sorted(ticks):
            cut = self.c.r.current_cut(t)
            ctx = self.c.contexts.context_for(cut, t)
            req = S.ConsumerRequest(self.c.r.region_id, S.canonical_request_slots(self.c.r.region_id, list(self.c.r.feeds)),
                                    t, cut, ctx)
            est = estimates_for(req, self.c.cost, prior_view(self.c.r.region_id, t, tuple(self.c.shared_runs)))
            for arm in arms:
                extra: list = []

                def charge(component: str, t0: float, _x: list = extra) -> None:
                    dt = now_wall() - t0
                    _x.append(S.CostItem(S.CostCategory.B_CONTROL_PLANE, component, dt, dt))
                m = arm.method
                # ---- universal binding (common to every reusing method) -> catalog_lookup
                t0 = now_wall()
                got = {s: (None if m == "N0" or (m == "N6" and s.startswith("VAL:")) else arm.mc.bind(s, t))
                       for s in req.request_slots}
                k0s = {}
                if m in ("N2", "N6"):                    # K0 contracts only for methods that evaluate K0
                    for s, g in got.items():
                        if g is not None:
                            self.calls["k0"] += 1
                            k0s[s] = tuple(c for c in arm.mc.contracts.get(g[0].artifact_id, ()) if c.level == "K0")
                charge("catalog_lookup", t0)
                cur_pins: tuple = ()
                n6_keys: tuple = ()
                n6_hits: tuple = ()
                pins: dict = {}
                if m == "N3":                             # ---- N3 pin index update + lookup (method state)
                    t0 = now_wall()
                    for g in got.values():
                        if g is not None:
                            self._n3_entry(arm, g[0])
                    charge("n3_pin_index_update", t0)
                    t0 = now_wall()
                    for s, g in got.items():
                        if g is not None:
                            pins[s] = arm.n3_index[g[0].artifact_id]
                    cur_pins = tuple((s, self.current_pin(s, ctx)) for s in req.request_slots)
                    charge("n3_pin_index_lookup", t0)
                if m == "N6":                             # ---- N6 exact-key cache index update + lookup
                    t0 = now_wall()
                    self._n6_update(arm, t)
                    charge("n6_cache_index_update", t0)
                    t0 = now_wall()
                    n6_keys = tuple((s, (feed_of(s), self.lv_event[(feed_of(s), cut.index(feed_of(s) or ""))],
                                         ctx.feeds[feed_of(s) or ""]["canonical_content_sha256"], ctx.country,
                                         ctx.validator_sha256)) for s in req.request_slots if s.startswith("VAL:"))
                    n6_hits = tuple((s, tuple(arm.n6_index.get(k, ()))) for s, k in n6_keys)
                    charge("n6_cache_index_lookup", t0)
                bound: list[tuple[str, OwnArtifact | None]] = []
                for s in req.request_slots:
                    g = got[s]
                    if g is None:
                        bound.append((s, None))
                        continue
                    e, born = g
                    if m == "N3":
                        pin, iv = pins[s]
                        bound.append((s, OwnArtifact(s, e.artifact_id, born, pin=pin, pin_interval=iv)))
                    elif m in ("N2", "N6"):
                        bound.append((s, OwnArtifact(s, e.artifact_id, born, k0_contracts=k0s[s])))
                    else:
                        bound.append((s, OwnArtifact(s, e.artifact_id, born)))
                view = BaselineView(m, req, tuple(bound), self._versions(cut), cur_pins, n6_keys, n6_hits, est, arm.tau_h)
                ev = CurrentCutEvaluatorImpl(TimedEvaluator(self.c.cs), req.context)
                j0 = sum(arm.vc.journal_s.values()) + sum(arm.nat.journal_s.values())
                d = S4Baseline().decide(view, ev, BaselineProducers(arm.vc, arm.nat, cut, t))
                js = sum(arm.vc.journal_s.values()) + sum(arm.nat.journal_s.values()) - j0
                if js:
                    extra.append(S.CostItem(S.CostCategory.B_CONTROL_PLANE, "journal_fsync", js, js))
                new_ids = [s.artifact_id for s in d.slots if s.action == "REDERIVE"]
                if m == "N3" and new_ids:                 # N3 pin-index UPDATE for its own new artifacts
                    t0 = now_wall()
                    for slot in [s.slot_id for s in d.slots if s.action == "REDERIVE"]:
                        for e in arm.mc.overlay.instances(slot):
                            if e.artifact_id in new_ids:
                                self._n3_entry(arm, e)
                    charge("n3_pin_index_update", t0)
                if m == "N6" and new_ids:                 # N6 cache-index UPDATE (artifact-producing VAL results only)
                    t0 = now_wall()
                    self._n6_update(arm, t, own_only=True)
                    charge("n6_cache_index_update", t0)
                d = BaselineDecision(d.method, d.tau_h, d.request, d.slots, d.joint_action,
                                     S.CostRecord(tuple(extra[:]) + tuple(d.costs.items)), d.reuse_events)
                arm.decisions.append(d)
        return {(a.method, a.tau_h): a for a in arms}


def ctx_frontier(ctx, region) -> tuple:
    """Frontier of an EvaluationContext's cut (from the region's version table by logical version id)."""
    out = []
    for f, ref in sorted(ctx.feeds.items()):
        idx = [i for (ff, i), v in region.versions.items() if ff == f and v.logical_version_id == ref["logical_version_id"]]
        out.append((f, idx[0]))
    return tuple(out)


def born_after(t: str, seconds: float) -> str:
    from .core import iso_utc
    return iso_utc(parse_utc(t) + timedelta(seconds=seconds))

