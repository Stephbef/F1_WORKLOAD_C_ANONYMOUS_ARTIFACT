"""Session-3 engine core (behind the frozen V1.2 interfaces): region state, the frozen R_t binding rule, cut contexts,
Γ_t admissibility, the frozen CostModel, slot producers and the (current-bound) evaluators / rederivers.

Normative sources: docs/pre_s3/06 (R_t, Γ_t), 07/08 (parity, non-interference), 10 (repair), 11 (costs) and
V1_2_DETERMINISTIC_FREEZE.md (est median, serial fail-fast execution, overlay binding rule).
"""
from __future__ import annotations

import io
import time
import zipfile
from dataclasses import dataclass, field
from typing import Any
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from ...common.util import sha256_obj
from ..catalog.artifacts import ArtifactCatalog, ArtifactEntry
from ..contracts.generators import ContractSystem
from ..contracts.model import Contract, EvaluationContext, EvaluationResult
from ..history.realized import Cut
from ..ingestion.gtfs import read_table
from ..interfaces import session3 as S

ARTIFACT_OUTCOMES = ("SUCCESS", "SEMANTIC_FAIL")
INFEASIBLE = "INFEASIBLE"                      # required input not realized at t (never an artifact)
PRIORS = {"validator": 600.0, "otp": 5400.0}   # V1.2 §1
HORIZON_DAYS = 7                               # spec17 §5 primary
DEPTH = 2                                      # spec17 §5 primary


class EngineError(RuntimeError):
    pass


def producer_class_of(slot_id: str) -> str:
    return "otp" if slot_id.startswith("ROUTER:") else "validator"


def feed_of(slot_id: str) -> str | None:
    return slot_id.split("=", 1)[1] if slot_id.startswith("VAL:feed=") else None


def iso_utc(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_utc(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def local_date(t_utc: str, tz: str) -> date:
    return parse_utc(t_utc).astimezone(ZoneInfo(tz)).date()


def horizon_dates(d0: date, days: int = HORIZON_DAYS) -> tuple[str, ...]:
    return tuple((d0 + timedelta(days=k)).isoformat() for k in range(days))


# ------------------------------------------------------------------------------------------- service on a date
_SERVICE_CACHE: dict[str, frozenset[str]] = {}


def service_dates(zip_bytes: bytes, key: str) -> frozenset[str]:
    """Dates (ISO) on which >= 1 trip of the feed version runs (calendar ∪ calendar_dates; exception 2 removes)."""
    if key in _SERVICE_CACHE:
        return _SERVICE_CACHE[key]
    names = set(zipfile.ZipFile(io.BytesIO(zip_bytes)).namelist())

    def rows(n):
        return read_table(zip_bytes, n) if n in names else []
    used = {r.get("service_id", "") for r in rows("trips.txt")}
    days: dict[str, set[str]] = {}
    wk = ("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday")
    for r in rows("calendar.txt"):
        sid = r.get("service_id", "")
        try:
            a = datetime.strptime(r["start_date"], "%Y%m%d").date()
            b = datetime.strptime(r["end_date"], "%Y%m%d").date()
        except (KeyError, ValueError):
            continue
        cur_d = a
        while cur_d <= b:
            if r.get(wk[cur_d.weekday()], "0").strip() == "1":
                days.setdefault(sid, set()).add(cur_d.isoformat())
            cur_d += timedelta(days=1)
    for r in rows("calendar_dates.txt"):
        sid = r.get("service_id", "")
        try:
            ds = datetime.strptime(r["date"], "%Y%m%d").date().isoformat()
        except (KeyError, ValueError):
            continue
        if r.get("exception_type", "").strip() == "1":
            days.setdefault(sid, set()).add(ds)
        elif r.get("exception_type", "").strip() == "2":
            days.setdefault(sid, set()).discard(ds)
    out = frozenset(x for sid, ds in days.items() if sid in used for x in ds)
    _SERVICE_CACHE[key] = out
    return out


# ------------------------------------------------------------------------------------------------ region state
@dataclass(frozen=True)
class VersionInfo:
    feed_id: str
    index: int
    logical_version_id: str
    canonical_content_sha256: str
    raw_zip_sha256: str
    available_utc: str


@dataclass
class RegionState:
    """Immutable-by-convention realized inputs of one region (logical versions + constants of the contexts)."""
    region_id: str
    tz: str
    feeds: tuple[str, ...]
    versions: dict                       # (feed, index) -> VersionInfo
    osm_sha256: str
    semantic_config_digest: str
    otp_sha256: str
    validator_sha256: str
    country: str
    blobs: Any                           # BlobStore
    namespace: str = "FIXTURE"

    def ref(self, feed: str, index: int) -> dict:
        v = self.versions[(feed, index)]
        return {"logical_version_id": v.logical_version_id, "canonical_content_sha256": v.canonical_content_sha256,
                "raw_zip_sha256": v.raw_zip_sha256}

    def available_count(self, feed: str, t_utc: str) -> int:
        return max([i for (f, i), v in self.versions.items() if f == feed and v.available_utc <= t_utc], default=0)

    def current_cut(self, t_utc: str) -> Cut:
        return Cut.of(self.region_id, {f: self.available_count(f, t_utc) for f in self.feeds})


class CutContextFactoryImpl:
    """EvaluationContext of a cut at tick t: the cut's logical versions + region constants + consumer date and D_t."""
    def __init__(self, region: RegionState, horizon_days: int = HORIZON_DAYS) -> None:
        self.r = region
        self.horizon_days = horizon_days

    def context_for(self, cut: Cut, tick_utc: str) -> EvaluationContext:
        d0 = local_date(tick_utc, self.r.tz)
        feeds = {f: self.r.ref(f, i) for f, i in cut.frontier if i > 0}
        return EvaluationContext(cut.cut_id, feeds, self.r.osm_sha256, self.r.semantic_config_digest, self.r.otp_sha256,
                                 self.r.validator_sha256, d0.isoformat(), self.r.country,
                                 horizon_dates(d0, self.horizon_days))


class GammaAdmissibilityImpl:
    """Γ_t (spec17 §5): per feed, versions available <= t, with service on every date of D_t, <= depth superseding."""
    def __init__(self, region: RegionState, horizon_days: int = HORIZON_DAYS, depth: int = DEPTH) -> None:
        self.r = region
        self.horizon_days = horizon_days
        self.depth = depth

    def _feed_ok(self, feed: str, index: int, cur: int, D: tuple[str, ...], tick_utc: str) -> tuple[bool, bool]:
        if index < 1 or (feed, index) not in self.r.versions or self.r.versions[(feed, index)].available_utc > tick_utc:
            return False, False
        depth_ok = 0 <= cur - index <= self.depth
        v = self.r.versions[(feed, index)]
        sd = service_dates(self.r.blobs.get(v.raw_zip_sha256), v.raw_zip_sha256)
        return depth_ok, all(d in sd for d in D)

    def evidence(self, cut: Cut, tick_utc: str) -> S.GammaEvidence:
        D = horizon_dates(local_date(tick_utc, self.r.tz), self.horizon_days)
        per = []
        for f, i in cut.frontier:
            cur = self.r.available_count(f, tick_utc)
            dok, sok = self._feed_ok(f, i, cur, D, tick_utc)
            per.append((f, i, cur, dok, sok))
        return S.GammaEvidence(tick_utc, D, tuple(per), all(d and s for *_, d, s in per))

    def candidates(self, tick_utc: str) -> list[Cut]:
        """All Γ_t cuts other than c_cur in the FROZEN witness order (06 §2): lag ascending, then frontier with higher
        indices first in ascending feed-id order."""
        D = horizon_dates(local_date(tick_utc, self.r.tz), self.horizon_days)
        cur = {f: self.r.available_count(f, tick_utc) for f in self.r.feeds}
        per_feed = []
        for f in sorted(self.r.feeds):
            ok = [i for i in range(max(1, cur[f] - self.depth), cur[f] + 1)
                  if all(self._feed_ok(f, i, cur[f], D, tick_utc))]
            per_feed.append((f, ok))
        cuts: list[dict] = [{}]
        for f, ok in per_feed:
            cuts = [{**c, f: i} for c in cuts for i in ok]
        out = [c for c in cuts if c != cur]
        out.sort(key=lambda c: (sum(cur[f] - c[f] for f in c), [-c[f] for f in sorted(c)]))
        return [Cut.of(self.r.region_id, c) for c in out]


# ------------------------------------------------------------------------------------------------ catalog views
@dataclass
class MethodCatalog:
    """The SHARED scheduled-production catalog plus ONE method's own on-demand overlay. N5 / N1 views are built only
    from this object for their own overlay — never from another method's overlay."""
    shared: ArtifactCatalog
    shared_born: dict                    # artifact_id -> ARTIFACT_BORN utc
    overlay: ArtifactCatalog
    overlay_born: dict = field(default_factory=dict)
    contracts: dict = field(default_factory=dict)   # artifact_id -> tuple[Contract, ...]  (shared + overlay)

    def bind(self, slot_id: str, tick_utc: str) -> tuple[ArtifactEntry, str] | None:  # noqa: D401
        """Frozen rule: latest artifact-bearing instance with ARTIFACT_BORN <= t; tie: overlay before shared, then the
        higher instance number (V1.2 §3)."""
        cands = []
        for rank, cat, born in ((0, self.shared, self.shared_born), (1, self.overlay, self.overlay_born)):
            for e in cat.instances(slot_id):
                b = born.get(e.artifact_id)
                if b is not None and b <= tick_utc and e.status in ARTIFACT_OUTCOMES:
                    cands.append((b, rank, e.instance, e))
        if not cands:
            return None
        b, _, _, e = max(cands, key=lambda c: c[:3])
        return e, b


def prior_view(region_id: str, tick_utc: str, shared_runs: tuple[S.ProducerRunObservation, ...]) -> S.PriorCostView:
    return S.PriorCostView.before(region_id, tick_utc, shared_runs)


class CostModelImpl:
    """Frozen CostModel: est(s,t) = ordinary arithmetic median of SUCCESS wall seconds of the producer class in the
    prior view (shared runs strictly before t); no runs -> priors. online_cost = A + B (C never online)."""
    def estimate_rederive(self, slot_id: str, producer_class: str, tick_utc: str, prior: S.PriorCostView) -> float:
        if prior.tick_utc != tick_utc:
            raise EngineError("prior view built for another tick")
        if producer_class != producer_class_of(slot_id):
            raise EngineError("producer class does not match slot")
        xs = sorted(o.wall_s for o in prior.observations if o.producer_class == producer_class and o.outcome == "SUCCESS")
        n = len(xs)
        if n == 0:
            return PRIORS[producer_class]
        if n % 2 == 1:
            return float(xs[n // 2])
        return (xs[n // 2 - 1] + xs[n // 2]) / 2.0

    def online_cost(self, record: S.CostRecord) -> float:
        return float(sum(i.wall_s for i in record.items if i.category != S.CostCategory.C_OFFLINE))


def bind_request(req: S.ConsumerRequest, mc: MethodCatalog, estimates: tuple[tuple[str, float], ...]) -> S.RequestBinding:
    bindings: list[tuple[str, S.BoundArtifact | None]] = []
    contracts = []
    for s in req.request_slots:
        got = mc.bind(s, req.tick_utc)
        if got is None:
            bindings.append((s, None))
            continue
        e, born = got
        b = S.BoundArtifact.from_entry(e, born)
        bindings.append((s, b))
        contracts.append((b.artifact_id, tuple(mc.contracts.get(b.artifact_id, ()))))
    return S.RequestBinding(req, tuple(bindings), tuple(contracts), estimates)


def estimates_for(req: S.ConsumerRequest, cost: CostModelImpl, prior: S.PriorCostView) -> tuple[tuple[str, float], ...]:
    return tuple((s, cost.estimate_rederive(s, producer_class_of(s), req.tick_utc, prior)) for s in req.request_slots)


def level_contracts(binding: S.RequestBinding, artifact_id: str, level: str) -> tuple[Contract, ...]:
    if level not in S.LEVELS:
        raise EngineError(f"{level} is not an admission level (K3 is reference-only)")
    cs = dict(binding.contracts).get(artifact_id, ())
    return tuple(c for c in cs if c.level == level)


# --------------------------------------------------------------------------------------------- bound evaluators
class TimedEvaluator:
    """ContractEvaluator that also measures control-plane wall time (category B) for the method using it."""
    def __init__(self, cs: ContractSystem) -> None:
        self.cs = cs
        self.wall_s = 0.0
        self.calls = 0

    def evaluate(self, c: Contract, ctx: EvaluationContext) -> EvaluationResult:
        t0 = now_wall()
        try:
            if c.level not in S.LEVELS:
                return EvaluationResult(c.contract_id, ctx.cut_id, "ERROR", "K3 is not an admission contract",
                                        self.cs.eval_digest)
            return self.cs.evaluate(c, ctx)
        finally:
            self.wall_s += now_wall() - t0
            self.calls += 1


class CurrentCutEvaluatorImpl:
    """Evaluator bound to the request's current context — there is no way to pass another cut."""
    def __init__(self, inner: TimedEvaluator, ctx: EvaluationContext) -> None:
        self._inner = inner
        self._ctx = ctx

    def evaluate(self, c: Contract) -> EvaluationResult:
        return self._inner.evaluate(c, self._ctx)


# ------------------------------------------------------------------------------------------------ slot producers
@dataclass
class Produced:
    outcome: str
    artifact_id: str | None
    contracts: tuple[Contract, ...]
    wall_s: float
    cpu_s: float
    provenance_digest: str | None
    entry_kw: dict


class InProcessFixtureProducer:
    """Deterministic in-process FIXTURE_STUB producer (no binaries; every output labelled FIXTURE_STUB_BINARY).
    Durations follow the FIXTURE_DURATION_BACKEND values (validator 600 s, otp 5400 s) unless overridden; outcomes may
    be injected per (slot, cut_id) for failure tests."""
    BINARY_MODE = "FIXTURE_STUB_BINARY"

    def __init__(self, region: RegionState, cs: ContractSystem, contexts: CutContextFactoryImpl,
                 durations: dict | None = None, outcomes: dict | None = None) -> None:
        self.r, self.cs, self.ctx = region, cs, contexts
        self.durations = {"validator": 600.0, "otp": 5400.0, **(durations or {})}
        self.outcomes = dict(outcomes or {})
        self.calls: list[tuple[str, str, str]] = []

    def produce(self, slot_id: str, cut: Cut, tick_utc: str) -> Produced:
        from ..producers.semconfig import resolve_service_bounds
        pc = producer_class_of(slot_id)
        self.calls.append((slot_id, cut.cut_id, tick_utc))
        outcome = str(self.outcomes.get((slot_id, cut.cut_id), self.outcomes.get(slot_id, "SUCCESS")))
        wall = float(self.durations[pc])
        ctx = self.ctx.context_for(cut, tick_utc)
        kw: dict
        if outcome not in ARTIFACT_OUTCOMES:
            return Produced(outcome, None, (), wall, wall, sha256_obj(["FIXTURE-STUB", slot_id, cut.cut_id, outcome]), {})
        if pc == "validator":
            f = feed_of(slot_id) or ""
            ref = ctx.feeds[f]
            rd = sha256_obj(["FIXTURE-STUB-VAL", ref["canonical_content_sha256"], ctx.consumer_date, ctx.country,
                             outcome])
            aid = "VAL:" + rd[:24]
            vart = {"artifact_class": "VAL_REPORT", "feed_id": f, "report_digest": rd, "request_slot": slot_id,
                   "birth_cut_id": cut.cut_id, "artifact_id": aid}
            cons = tuple(self.cs.generate_val(vart, ctx, lv) for lv in ("K0", "K1", "K2", "K3"))
            kw = dict(producer_type="gtfs-validator", artifact_class="VAL_REPORT",
                      logical_inputs=[(f, ref["logical_version_id"], ref["canonical_content_sha256"])],
                      output_digests=[("report", rd)])
        else:
            feeds = sorted(ctx.feeds)
            ws = resolve_service_bounds(date.fromisoformat(str(ctx.consumer_date)))
            canon = sha256_obj(["FIXTURE-STUB-CANON", [ctx.feeds[f]["canonical_content_sha256"] for f in feeds],
                                list(ctx.horizon), ctx.osm_sha256])
            aid = "ROUTER:" + sha256_obj([slot_id, cut.cut_id, canon, tick_utc])[:24]
            art: dict = {"artifact_id": aid, "request_slot": slot_id, "birth_cut_id": cut.cut_id,
                   "gtfs_logical_versions": {f: ctx.feeds[f]["logical_version_id"] for f in feeds},
                   "service_window": list(ws), "canon_digest": canon, "graph_sha256": sha256_obj(["graph", aid]),
                   "horizon_D": list(ctx.horizon)}
            cons = tuple(self.cs.generate_router(art, ctx, lv) for lv in ("K0", "K1", "K2", "K3"))
            kw = dict(producer_type="otp", artifact_class="ROUTER",
                      logical_inputs=[(f, ctx.feeds[f]["logical_version_id"], ctx.feeds[f]["canonical_content_sha256"])
                                      for f in feeds],
                      output_digests=[("canon", canon), ("graph", art["graph_sha256"])])
        return Produced(outcome, aid, cons, wall, wall, sha256_obj(["FIXTURE-STUB", slot_id, cut.cut_id, aid]),
                        {**kw, "birth_frontier": tuple(cut.frontier), "contract_ids": [c.contract_id for c in cons],
                         "binary_mode": self.BINARY_MODE})


class ProducerRederiver:
    """rederive(r, c): a NEW instance of the SAME slot r born at cut c, appended to THIS method's overlay only.
    Enforces the t information boundary: every version of c must be available <= t (else INFEASIBLE, no work)."""
    def __init__(self, region: RegionState, mc: MethodCatalog, producer, clock_start: dict | None = None) -> None:
        self.r, self.mc, self.p = region, mc, producer
        self._elapsed: dict[str, float] = dict(clock_start or {})     # tick -> serial elapsed seconds since t
        self.cpu: dict = {}                    # (slot, cut_id, tick) -> measured producer CPU seconds (sidecar)
        self.journal_s: dict = {}              # tick -> measured online catalog-insertion (journal/fsync) seconds

    def rederive(self, slot_id: str, cut: Cut, tick_utc: str, estimate_s: float) -> S.RederivationStep:
        if cut.region_id != self.r.region_id or slot_id.split("=", 1)[0] not in ("VAL:feed", "ROUTER:region"):
            raise EngineError("rederive outside the region's designated slots")
        fs = feed_of(slot_id)
        if any(i < 1 or (f, i) not in self.r.versions or self.r.versions[(f, i)].available_utc > tick_utc
               for f, i in cut.frontier if fs in (None, f)):
            return S.RederivationStep(slot_id, cut.cut_id, producer_class_of(slot_id), estimate_s, INFEASIBLE)
        sub = Cut.of(self.r.region_id, {fs: cut.index(fs)}) if fs else cut
        p = self.p.produce(slot_id, sub, tick_utc)
        elapsed = self._elapsed.get(tick_utc, 0.0) + p.wall_s
        self._elapsed[tick_utc] = elapsed
        self.cpu[(slot_id, cut.cut_id, tick_utc)] = float(p.cpu_s)
        new_id = None
        if p.outcome in ARTIFACT_OUTCOMES and p.artifact_id:
            kw = dict(p.entry_kw)
            kw.update(status=p.outcome, provenance_digest=p.provenance_digest, cost={"wall_s": p.wall_s, "cpu_s": p.cpu_s},
                      namespace=self.r.namespace, birth_cut_id=sub.cut_id)
            j0 = now_wall()
            if self.mc.overlay.instances(slot_id):
                e = self.mc.overlay.rederive(slot_id, **kw)
            else:
                e = self.mc.overlay.add(request_slot=slot_id, **kw)
            self.journal_s[tick_utc] = self.journal_s.get(tick_utc, 0.0) + (now_wall() - j0)
            born = iso_utc(parse_utc(tick_utc) + timedelta(seconds=elapsed))
            self.mc.overlay_born[e.artifact_id] = born
            self.mc.contracts[e.artifact_id] = p.contracts
            new_id = e.artifact_id
        return S.RederivationStep(slot_id, cut.cut_id, producer_class_of(slot_id), estimate_s, p.outcome, new_id,
                                  p.provenance_digest, p.wall_s)

    def cpu_of(self, step: S.RederivationStep, tick_utc: str) -> float:
        return self.cpu.get((step.slot_id, step.target_cut_id, tick_utc), float(step.measured_wall_s or 0.0))


class CurrentCutRederiverImpl:
    """Re-derivation bound to the request's current cut (no cut parameter exists)."""
    def __init__(self, inner: Any, cut: Cut, tick_utc: str) -> None:
        self._inner, self._cut, self._t = inner, cut, tick_utc

    def rederive(self, slot_id: str, estimate_s: float) -> S.RederivationStep:
        return self._inner.rederive(slot_id, self._cut, self._t, estimate_s)

    def cpu_of(self, step: S.RederivationStep, tick_utc: str | None = None) -> float:
        f = getattr(self._inner, "cpu_of", None)
        return f(step, self._t) if f else float(step.measured_wall_s or 0.0)


def execute_plan(plan: S.RepairPlan, rederive_one) -> S.RepairPlan:
    """Frozen V1.2 execution: serial, canonical slot order (the plan's order), exact target cut, fail-fast; unattempted
    steps keep outcome None (no artifact, zero cost)."""
    steps, stopped = [], False
    for st in plan.steps:
        if stopped:
            steps.append(st)
            continue
        done = rederive_one(st)
        steps.append(done)
        if done.outcome not in ARTIFACT_OUTCOMES:
            stopped = True
    return S.RepairPlan(plan.request_id, plan.mode, plan.target_cut, plan.failing_slots, tuple(steps), plan.opt_current,
                        plan.opt_hist, plan.best_hist_cut_id)


def producer_cost_items(plan: S.RepairPlan | None, rederiver=None, tick_utc: str | None = None) -> list[S.CostItem]:
    """A items for every ATTEMPTED step: wall = measured wall seconds (primary); cpu = the producer's measured CPU
    seconds from the rederiver sidecar (never the wall time, unless the step carries no CPU measurement)."""
    if plan is None:
        return []
    cpu_of = getattr(rederiver, "cpu_of", None)
    out = []
    for s in plan.steps:
        if s.outcome is None:
            continue
        w = float(s.measured_wall_s or 0.0)
        c = float(cpu_of(s, tick_utc)) if cpu_of else w
        out.append(S.CostItem(S.CostCategory.A_PRODUCER, f"producer:{s.producer_class}", w, c, s.slot_id, s.outcome))
    return out


class ControlTimer:
    """Non-overlapping control-plane intervals: mark(component) closes the interval opened by the previous mark and
    charges it to `component`, minus the evaluator time spent inside it (charged once as 'evaluate')."""
    def __init__(self, evaluator) -> None:
        self.ev = evaluator
        self.t = now_wall()
        self.e = self._ev_s()
        self.items: list[S.CostItem] = []

    def _ev_s(self) -> float:
        inner = getattr(self.ev, "_inner", self.ev)
        return float(getattr(inner, "wall_s", 0.0))

    def mark(self, component: str) -> None:
        t, e = now_wall(), self._ev_s()
        ev = e - self.e
        other = max(0.0, (t - self.t) - ev)
        if ev:
            self.items.append(S.CostItem(S.CostCategory.B_CONTROL_PLANE, "evaluate", ev, ev))
        self.items.append(S.CostItem(S.CostCategory.B_CONTROL_PLANE, component, other, other))
        self.t, self.e = now_wall(), self._ev_s()     # next interval starts AFTER this bookkeeping

    def skip(self) -> None:
        """Exclude the time since the last mark (e.g. producer execution charged as A) from B."""
        self.t, self.e = now_wall(), self._ev_s()


def all_valid(results) -> bool:
    return bool(results) and all(r.verdict == "VALID" for r in results)


_CLOCK = time.perf_counter


def now_wall() -> float:
    """Control-plane clock (injectable for tests via set_clock)."""
    return _CLOCK()


def set_clock(fn) -> None:
    global _CLOCK
    _CLOCK = fn
