"""MutationEngine (spec17 §10; docs/pre_s3/12 §2). Robustness evaluation of contracts — never a scientific outcome.

Sample: per artifact class, ids sorted, ranked by SHA-256(seed_bytes("mutation") || 0x00 || UTF8(id)) ascending, top
ceil(0.05·n). Families are exactly the frozen list. A family that does not apply to the subject (artifact class, or
the feed lacks the required element) fails closed with status INVALID_MUTATION (never silently skipped).

Subjects are provided by an injected `MutationSubjectStore` (sealed inputs of the engine):
- ROUTER subjects: per-feed GTFS zip bytes at birth, consumer horizon D, and comparison inputs with a reference Canon_D
  verdict ("EQ"/"NE"; from the frozen oracle record or from the Canon reference path).
- VAL subjects: the feed zip bytes, consumer date and comparison inputs (other date / other bytes) with the reference
  verdict of a validator re-run.
Contract-dependency families build a MUTANT K2/K-projection omitting one dependency: detection = a comparison where the
reference differs (NE) but the mutant admits (equal footprint). Input-mutation families edit GTFS and check the
(unmutated) K2 contract against the frozen expected Canon behaviour.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from ...common.util import sha256_obj
from ..config.spec import load_protocol_spec
from ..contracts.k2 import k2_projection
from ..interfaces import session3 as S

DEPENDENCY_FAMILIES = ("stop_times", "frequencies", "calendar_dates", "transfers", "block_id", "coordinates",
                       "pathways", "wheelchair", "route_type", "timezones", "namespace", "horizon")
NEGATIVE_CONTROL = ("shapes",)
VALIDATOR_FAMILIES = ("validator_date", "validator_file")
INPUT_FAMILIES = {                      # family -> (canon expected to change, K2 expected to change)
    "M-FUTURE-1": (False, False), "M-FUTURE-2": (True, True), "M-CT": (True, True),
    "M-FREQ-IN": (True, True), "M-FREQ-OUT": (False, False),
    "M-STOP-ACTIVE": (True, True), "M-STOP-INACTIVE": (False, False),
    "M-AGENCY-ACTIVE": (True, True), "M-AGENCY-FUTURE": (False, False)}
FAMILIES = DEPENDENCY_FAMILIES + NEGATIVE_CONTROL + VALIDATOR_FAMILIES + tuple(INPUT_FAMILIES)


class InvalidMutation(ValueError):
    pass


class CanonReference:
    """Authoritative Canon_D reference: build each input set with the pinned OTP producer and compare the frozen
    CanonExtractFinal (F1-OTP-CANON-1.3) digests over D. Never a ZIP / canonical-GTFS / K2 hash. Cached per input."""
    def __init__(self, otp_producer, osm_path: str, tz: str, build_date: str, work: Path) -> None:
        self.otp, self.osm, self.tz, self.build_date, self.work = otp_producer, osm_path, tz, build_date, work
        self.cache: dict = {}
        self.calls = 0

    def canon(self, feeds: dict, D: list) -> str | None:
        from ..producers.otp import OtpFeedInput, OtpRequest
        key = sha256_obj([sorted((f, hashlib.sha256(b).hexdigest()) for f, b in feeds.items()), list(D)])
        if key in self.cache:
            return self.cache[key]
        d = self.work / key[:16]
        d.mkdir(parents=True, exist_ok=True)
        ins = []
        for f, b in sorted(feeds.items()):
            p = d / f"{f}.gtfs.zip"
            p.write_bytes(b)
            ins.append(OtpFeedInput(f, f"{f}#{hashlib.sha256(b).hexdigest()[:12]}", hashlib.sha256(b).hexdigest(), str(p)))
        self.calls += 1
        o = self.otp.produce(OtpRequest("ROUTER:region=R:mutation-ref", "R:mutation-ref", tuple(ins), self.osm, self.tz,
                                        self.build_date, tuple(D), "CUT:mutation-ref:" + key[:16], "FIXTURE"))
        dg = (o.router or {}).get("canon_digest") if o.failure_class == "SUCCESS" else None
        self.cache[key] = dg
        return dg

    def verdict(self, feeds_a: dict, feeds_b: dict, D: list) -> str | None:
        a, b = self.canon(feeds_a, D), self.canon(feeds_b, D)
        if a is None or b is None:
            return None                                   # evaluation failure -> never substituted
        return "EQ" if a == b else "NE"


class ValidatorReference:
    """Validator reference path: re-run the pinned gtfs-validator and compare semantic report digests."""
    def __init__(self, validator_producer, work: Path, country: str = "US") -> None:
        self.val, self.work, self.country = validator_producer, work, country
        self.cache: dict = {}

    def report(self, zip_bytes: bytes, date: str) -> str | None:
        from ..producers.validator import ValidatorRequest
        key = sha256_obj([hashlib.sha256(zip_bytes).hexdigest(), date])
        if key in self.cache:
            return self.cache[key]
        p = self.work / (key[:16] + ".zip")
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(zip_bytes)
        o = self.val.produce(ValidatorRequest("VAL:feed=ref", "R:mutation-ref", "ref", "ref#1",
                                              hashlib.sha256(zip_bytes).hexdigest(), str(p), date, self.country,
                                              "CUT:ref", "FIXTURE"))
        dg = (o.val_report or {}).get("report_digest")
        self.cache[key] = dg
        return dg

    def verdict(self, zip_a: bytes, date_a: str, zip_b: bytes, date_b: str) -> str | None:
        a, b = self.report(zip_a, date_a), self.report(zip_b, date_b)
        if a is None or b is None:
            return None
        return "EQ" if a == b else "NE"


def replace_member(zip_bytes: bytes, member: str, transform) -> bytes:
    src = zipfile.ZipFile(io.BytesIO(zip_bytes))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for n in src.namelist():
            data = src.read(n)
            z.writestr(n, transform(data) if n.split("/")[-1] == member else data)
    return buf.getvalue()


@dataclass
class RouterSubject:
    feeds: dict                                   # feed_id -> zip bytes at birth
    D: list
    comparisons: list = field(default_factory=list)   # [(feeds_b: dict, D_b: list, reference "EQ"/"NE", label)]


@dataclass
class ValSubject:
    zip_bytes: bytes
    consumer_date: str
    comparisons: list = field(default_factory=list)   # [(zip_b, date_b, reference "EQ"/"NE"/None, label)]
    # label "date" -> validator_date subject (same bytes, other date);
    # label "file:<member>" -> validator_file subject (same date, <member> content differs; mutant omits <member>)


class MutationSubjectStore:
    def __init__(self, artifact_classes: dict, subjects: dict) -> None:
        self.cls = artifact_classes                # artifact_id -> "ROUTER" | "VAL_REPORT"
        self.subjects = subjects                   # artifact_id -> RouterSubject | ValSubject


def _rank(spec, artifact_id: str) -> bytes:
    return hashlib.sha256(spec.seed_bytes("mutation") + b"\x00" + artifact_id.encode()).digest()


# ------------------------------------------------------------------------------------- mutant projections
def _mutant_lines(lines: list[str], family: str) -> list[str]:
    def blank(rec: str, prefix: str, idxs: tuple[int, ...]) -> str:
        if not rec.startswith(prefix):
            return rec
        parts = rec.split("|")
        for i in idxs:
            if i < len(parts):
                parts[i] = "*"
        return "|".join(parts)
    out = []
    for r in lines:
        if family == "stop_times" and r.startswith("stoptimes|"):
            continue
        if family == "frequencies" and r.startswith("frequency|"):
            continue
        if family == "transfers" and r.startswith("transfer|"):
            continue
        if family == "block_id":
            r = blank(r, "trip|", (4,))
        if family == "coordinates":
            r = blank(r, "stop|", (3, 4))
        if family == "pathways":
            r = blank(r, "pathway|", (7, 8, 9))
        if family == "wheelchair":
            r = blank(blank(r, "trip|", (6,)), "stop|", (5,))
        if family == "route_type":
            r = blank(r, "route|", (3,))
        if family == "timezones":
            r = blank(blank(r, "agency|", (2,)), "stop|", (7,))
        out.append(r)
    return sorted(out)


def _without_member(zip_bytes: bytes, member: str) -> bytes:
    src = zipfile.ZipFile(io.BytesIO(zip_bytes))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for n in src.namelist():
            if n.split("/")[-1] != member:
                z.writestr(n, src.read(n))
    return buf.getvalue()


def mutant_router_digest(feeds: dict, D: list, family: str) -> str:
    if family == "horizon":
        D = list(D)[:3]
    per = []
    for f in sorted(feeds):
        data = feeds[f]
        if family == "calendar_dates":
            data = _without_member(data, "calendar_dates.txt")
        lines = k2_projection(data, list(D))
        if family not in ("horizon", "calendar_dates", "namespace"):
            lines = _mutant_lines(lines, family)
        per.append((f, sha256_obj(lines)))
    if family == "namespace":
        return sha256_obj(sorted(d for _, d in per))         # feedId binding dropped
    return sha256_obj([list(D), per])


def router_digest(feeds: dict, D: list) -> str:
    return sha256_obj([list(D), [(f, sha256_obj(k2_projection(feeds[f], list(D)))) for f in sorted(feeds)]])


# ------------------------------------------------------------------------------------------- input edits
def _tables(zip_bytes: bytes) -> dict[str, list[dict]]:
    z = zipfile.ZipFile(io.BytesIO(zip_bytes))
    out = {}
    for n in z.namelist():
        if n.endswith(".txt"):
            txt = z.read(n).decode("utf-8-sig")
            out[n.split("/")[-1]] = list(csv.DictReader(io.StringIO(txt)))
    return out


def _zip(tables: dict[str, list[dict]]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for n in sorted(tables):
            rows = tables[n]
            cols: list[str] = []
            for r in rows:
                for k in r:
                    if k not in cols:
                        cols.append(k)
            s = io.StringIO()
            w = csv.DictWriter(s, fieldnames=cols, lineterminator="\n")
            w.writeheader()
            w.writerows(rows)
            z.writestr(n, s.getvalue())
    return buf.getvalue()


def _active(T: dict, D: list) -> tuple[set, set, set]:
    from ..contracts.k2 import active_services
    svc = active_services(T.get("calendar.txt", []), T.get("calendar_dates.txt", []), list(D))
    trips = {t["trip_id"] for t in T.get("trips.txt", []) if t.get("service_id") in svc}
    stops = {r["stop_id"] for r in T.get("stop_times.txt", []) if r.get("trip_id") in trips}
    routes = {t["route_id"] for t in T.get("trips.txt", []) if t["trip_id"] in trips}
    return trips, stops, routes


def apply_input_mutation(zip_bytes: bytes, D: list, family: str) -> bytes:
    T = _tables(zip_bytes)
    trips, stops, routes = _active(T, D)
    from datetime import date, timedelta
    d_end = date.fromisoformat(max(D))
    if family in ("M-FUTURE-1", "M-FUTURE-2"):
        if not trips:
            raise InvalidMutation("no active trip to copy")
        tid = sorted(trips)[0]
        t0 = next(t for t in T["trips.txt"] if t["trip_id"] == tid)
        day = (d_end + timedelta(days=30)) if family == "M-FUTURE-1" else date.fromisoformat(min(D))
        T["trips.txt"].append({**t0, "trip_id": tid + "_mut", "service_id": "MUT_SVC"})
        T.setdefault("calendar_dates.txt", []).append({"service_id": "MUT_SVC", "date": day.strftime("%Y%m%d"),
                                                       "exception_type": "1"})
        T["stop_times.txt"] += [{**r, "trip_id": tid + "_mut"} for r in T["stop_times.txt"] if r["trip_id"] == tid]
    elif family == "M-CT":
        act = sorted(stops)
        if len(act) < 2:
            raise InvalidMutation("fewer than two active stops")
        rows = [r for r in T.get("transfers.txt", []) if r.get("from_stop_id") in stops and r.get("to_stop_id") in stops]
        if rows:
            rows[0]["min_transfer_time"] = str(int(rows[0].get("min_transfer_time") or 0) + 60)
        else:
            T.setdefault("transfers.txt", []).append({"from_stop_id": act[0], "to_stop_id": act[1],
                                                      "transfer_type": "2", "min_transfer_time": "120"})
    elif family in ("M-FREQ-IN", "M-FREQ-OUT"):
        fr = T.get("frequencies.txt", [])
        rows = [r for r in fr if (r.get("trip_id") in trips) == (family == "M-FREQ-IN")]
        if not rows:
            raise InvalidMutation("no applicable frequencies row")
        rows[0]["headway_secs"] = str(int(rows[0].get("headway_secs") or 600) + 60)
    elif family in ("M-STOP-ACTIVE", "M-STOP-INACTIVE"):
        cand = [s for s in T.get("stops.txt", []) if (s["stop_id"] in stops) == (family == "M-STOP-ACTIVE")
                and s.get("stop_lat") and s.get("location_type", "") in ("", "0")]
        if not cand:
            raise InvalidMutation("no applicable stop")
        s0 = sorted(cand, key=lambda s: s["stop_id"])[0]
        s0["stop_lat"] = f"{float(s0['stop_lat']) + 0.001:.6f}"
    elif family in ("M-AGENCY-ACTIVE", "M-AGENCY-FUTURE"):
        ags = T.get("agency.txt", [])
        single = ags[0].get("agency_id", "") if len(ags) == 1 else None
        active_ag = {r.get("agency_id", "") or single for r in T.get("routes.txt", []) if r["route_id"] in routes}
        cand = [a for a in ags if (a.get("agency_id", "") in active_ag) == (family == "M-AGENCY-ACTIVE")]
        if not cand:
            raise InvalidMutation("no applicable agency")
        tz = cand[0].get("agency_timezone", "")
        cand[0]["agency_timezone"] = "America/Chicago" if tz != "America/Chicago" else "America/Denver"
    elif family == "shapes":
        sh = T.get("shapes.txt", [])
        if not sh:
            raise InvalidMutation("feed has no shapes")
        seqs = [r.get("shape_pt_sequence") for r in sh]
        for r, q in zip(sh, reversed(seqs), strict=True):
            r["shape_pt_sequence"] = q
    else:
        raise InvalidMutation(f"unknown input family {family}")
    return _zip(T)


# ------------------------------------------------------------------------------------------------ engine
class MutationEngineImpl:
    def __init__(self, store: MutationSubjectStore, canon_reference: "CanonReference | None" = None) -> None:
        self.store = store
        self.spec = load_protocol_spec()
        self.canon_reference = canon_reference
        self.expectation_report: list[dict] = []          # measured vs frozen expectation (input families)

    def plan(self, population: S.MutationPopulation) -> S.MutationPlan:
        if population.seed_domain != "mutation":
            raise InvalidMutation("mutation sample uses the frozen 'mutation' seed domain only")
        ids = sorted(population.artifact_ids)
        if list(population.artifact_ids) != ids or len(set(ids)) != len(ids):
            raise InvalidMutation("population ids must be sorted and unique")
        k = math.ceil(0.05 * len(ids))
        ranked = sorted(ids, key=lambda i: (_rank(self.spec, i), i))
        return S.MutationPlan(population, tuple(ranked[:k]), FAMILIES)

    def apply(self, artifact_id: str, family: str) -> S.MutationResult:
        def res(status, canon=None, admits=None, detected=None, detail=""):
            return S.MutationResult(artifact_id, family, status, canon, admits, detected,
                                    sha256_obj(["mutation", artifact_id, family, status, canon, admits, detected, detail]))
        if family not in FAMILIES:
            return res("INVALID_MUTATION", detail="unknown family")
        cls = self.store.cls.get(artifact_id)
        subj = self.store.subjects.get(artifact_id)
        if cls is None or subj is None:
            return res("INVALID_MUTATION", detail="unknown subject")
        if cls == "ROUTER":
            if family in VALIDATOR_FAMILIES or not isinstance(subj, RouterSubject):
                return res("INVALID_MUTATION", detail="family not applicable to ROUTER")
            if family in DEPENDENCY_FAMILIES:
                usable = [c for c in subj.comparisons if c[2] in ("EQ", "NE")]
                if not usable:
                    return res("INVALID_MUTATION", detail="no comparison with a Canon_D reference verdict")
                detected, any_ne = False, False
                for feeds_b, D_b, ref, _ in usable:
                    if ref == "NE":
                        any_ne = True
                        if mutant_router_digest(subj.feeds, subj.D, family) == mutant_router_digest(feeds_b, D_b, family):
                            detected = True
                admits = None if not any_ne else True if detected else False
                return res("APPLIED", any_ne, admits, detected)
            feed = sorted(subj.feeds)[0]
            try:
                mutated = apply_input_mutation(subj.feeds[feed], subj.D, family)
            except InvalidMutation as e:
                return res("INVALID_MUTATION", detail=str(e))
            mf = {**subj.feeds, feed: mutated}
            if self.canon_reference is None:
                return res("INVALID_MUTATION", detail="Canon_D reference unavailable; the frozen expectation is never "
                                                      "substituted for a measurement")
            ref = self.canon_reference.verdict(subj.feeds, mf, subj.D)          # MEASURED Canon_D
            if ref is None:
                return res("INVALID_MUTATION", detail="Canon_D evaluation failed")
            canon_change = ref == "NE"
            k2_same = router_digest(subj.feeds, subj.D) == router_digest(mf, subj.D)      # unmutated K2 holds?
            expected = NEGATIVE_CONTROL_EXPECT if family == "shapes" else INPUT_FAMILIES[family][0]
            self.expectation_report.append({"artifact_id": artifact_id, "family": family,
                                            "expected_canon_change": expected, "measured_canon_change": canon_change,
                                            "match": expected == canon_change, "k2_holds": k2_same})
            return res("APPLIED", canon_change, k2_same, bool(canon_change and k2_same))
        if cls == "VAL_REPORT":
            if family not in VALIDATOR_FAMILIES or not isinstance(subj, ValSubject):
                return res("INVALID_MUTATION", detail="family not applicable to VAL")
            want = "date" if family == "validator_date" else "file:"
            usable = [c for c in subj.comparisons if c[3].startswith(want) and c[2] in ("EQ", "NE")]
            if not usable:
                return res("INVALID_MUTATION", detail=f"no {family} comparison with a validator reference verdict")
            detected, any_ne = False, False
            for zb, db, ref, label in usable:
                if ref != "NE":
                    continue
                any_ne = True
                fa, fb = _file_hashes(subj.zip_bytes), _file_hashes(zb)
                if family == "validator_date":                       # mutant VAL K1 footprint omits the date
                    a, b = sha256_obj(fa), sha256_obj(fb)
                else:                                                # mutant omits ONE file binding (the member)
                    drop = label.split(":", 1)[1]
                    if drop not in fa:
                        return res("INVALID_MUTATION", detail=f"member {drop} absent")
                    a = sha256_obj([subj.consumer_date, {k: v for k, v in fa.items() if k != drop}])
                    b = sha256_obj([db, {k: v for k, v in fb.items() if k != drop}])
                if a == b:
                    detected = True
            return res("APPLIED", any_ne, detected if any_ne else None, detected)
        return res("INVALID_MUTATION", detail="unknown artifact class")


NEGATIVE_CONTROL_EXPECT = False


def _file_hashes(zip_bytes: bytes) -> dict:
    z = zipfile.ZipFile(io.BytesIO(zip_bytes))
    return {n.split("/")[-1]: hashlib.sha256(z.read(n)).hexdigest() for n in sorted(z.namelist()) if n.endswith(".txt")}


def oracle_router_subjects() -> MutationSubjectStore:
    """Router subjects from the frozen oracle corpus: subject = fixture_a of each pair, comparison = fixture_b with
    the frozen Canon_D expectation (no OTP run required)."""
    from .. import paths
    conf = paths.FROZEN_SPECS / "authoritative" / "conformance"
    from ..contracts.alignment import HORIZON

    def feeds(fx: str) -> dict:
        d = conf / "fixtures" / "oracle" / fx.split("@")[0]
        cfg = json.load(open(d / "build-config.json"))
        return {f["feedId"]: (d / f["source"]).read_bytes() for f in cfg["transitFeeds"]}
    cls, subj = {}, {}
    for r in csv.DictReader(open(conf / "expected" / "oracle_expected.csv")):
        aid = f"ORACLE:{r['test']}"
        cls[aid] = "ROUTER"
        subj[aid] = RouterSubject(feeds(r["fixture_a"]), list(HORIZON),
                                  [(feeds(r["fixture_b"]), list(HORIZON), r["expected"], r["test"])])
    return MutationSubjectStore(cls, subj)
