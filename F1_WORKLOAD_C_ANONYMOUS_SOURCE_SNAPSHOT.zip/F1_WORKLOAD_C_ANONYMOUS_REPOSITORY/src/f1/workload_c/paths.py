"""Repository-relative path resolution (no absolute host paths are ever hard-coded)."""
from __future__ import annotations

import os
from pathlib import Path

REPO_ROOT = Path(os.environ.get("F1_WC_REPO_ROOT") or Path(__file__).resolve().parents[3])
FROZEN_SPECS = REPO_ROOT / "frozen_specs"
DERIVED_SPEC = FROZEN_SPECS / "derived" / "workload_c_protocol_spec.json"
CONFIG_DIR = REPO_ROOT / "configs" / "workload_c"
INTERPRETATIONS = CONFIG_DIR / "spec_interpretations.json"
LICENSE_TABLE = CONFIG_DIR / "license_identifier_table.json"
