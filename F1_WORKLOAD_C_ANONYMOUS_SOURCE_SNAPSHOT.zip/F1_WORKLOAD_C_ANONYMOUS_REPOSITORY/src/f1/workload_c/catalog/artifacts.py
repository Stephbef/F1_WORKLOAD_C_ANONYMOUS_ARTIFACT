"""Immutable artifact catalog with fixed-R request slots (spec 16_FIXED_R_REDERIVE_CONFIRMATION.md).

* RequestSlot = the designated artifact request identity (e.g. "VAL:feed=mdb-1001", "ROUTER:region=R:a+b");
* ArtifactEntry = one derivation instance (birth cut, inputs, contracts, status, provenance, outputs, cost);
* rederive(r, c) creates a NEW instance for the SAME slot, born at c (request identity != birth-context identity);
* the catalog is append-only; entries are frozen; there is deliberately NO cross-slot content lookup
  (no free primary historical substitution — catalog substitution is a secondary diagnostic only).
"""
from __future__ import annotations

import enum
from dataclasses import asdict, dataclass
from pathlib import Path

from ...common.util import sha256_obj
from ..errors import WCError
from ..state.journal import AppendOnlyJournal


class SlotKind(str, enum.Enum):
    VAL = "VAL"
    ROUTER = "ROUTER"


class CatalogError(WCError):
    error_class = "CATALOG_INVALID"


@dataclass(frozen=True)
class RequestSlot:
    kind: str
    subject: str            # feed id for VAL, region id for ROUTER

    @property
    def slot_id(self) -> str:
        return f"{self.kind}:{'feed' if self.kind == SlotKind.VAL else 'region'}={self.subject}"


def designated_slots(region_id: str, feed_ids: list[str]) -> list[RequestSlot]:
    """Fixed R for a region: one validation-certificate slot per feed + one router slot."""
    return [RequestSlot(SlotKind.VAL.value, f) for f in sorted(feed_ids)] + [RequestSlot(SlotKind.ROUTER.value, region_id)]


@dataclass(frozen=True)
class ArtifactEntry:
    artifact_id: str
    request_slot: str
    instance: int                   # derivation instance number within the slot (1, 2, ...)
    producer_type: str              # gtfs-validator | otp
    artifact_class: str             # VAL_REPORT | VAL_GATE | ROUTER
    birth_cut_id: str
    birth_frontier: tuple
    logical_inputs: tuple           # ((feed_id, logical_version_id, canonical sha256), ...)
    contract_ids: tuple
    status: str                     # FailureClass value
    provenance_digest: str
    output_digests: tuple           # ((name, sha256), ...)
    cost: tuple                     # ((key, value), ...) placeholder interface for Session 3 cost model
    namespace: str
    binary_mode: str
    rederived_from: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def entry_digest(self) -> str:
        return sha256_obj(self.to_dict())


class ArtifactCatalog:
    def __init__(self, journal_path: Path | None = None) -> None:
        self._by_id: dict[str, ArtifactEntry] = {}
        self._by_slot: dict[str, list[str]] = {}
        self.journal = AppendOnlyJournal(journal_path) if journal_path else None
        if self.journal:
            for r in self.journal.records():
                fields: dict = {k: (tuple(tuple(x) if isinstance(x, list) else x for x in v) if isinstance(v, list) else v)
                                for k, v in r["entry"].items()}
                self._insert(ArtifactEntry(**fields), persist=False)

    def _insert(self, e: ArtifactEntry, persist: bool) -> ArtifactEntry:
        old = self._by_id.get(e.artifact_id)
        if old is not None:
            if old != e:
                raise CatalogError(f"artifact {e.artifact_id} already catalogued with different content (immutable)")
            return old
        slot = self._by_slot.setdefault(e.request_slot, [])
        if e.instance != len(slot) + 1:
            raise CatalogError(f"slot {e.request_slot}: instance {e.instance} out of order")
        self._by_id[e.artifact_id] = e
        slot.append(e.artifact_id)
        if persist and self.journal:
            self.journal.append({"entry": e.to_dict(), "entry_digest": e.entry_digest})
        return e

    def add(self, *, request_slot: str, producer_type: str, artifact_class: str, birth_cut_id: str, birth_frontier,
            logical_inputs, contract_ids, status: str, provenance_digest: str, output_digests, cost: dict,
            namespace: str, binary_mode: str, rederived_from: str | None = None) -> ArtifactEntry:
        inst = len(self._by_slot.get(request_slot, [])) + 1
        # identity = slot + instance + birth cut + inputs + outputs (never timestamps/provenance, which vary per run)
        aid = f"A:{artifact_class}:" + sha256_obj([request_slot, inst, birth_cut_id, [list(x) for x in logical_inputs],
                                                   sorted(list(x) for x in output_digests), status])[:32]
        e = ArtifactEntry(aid, request_slot, inst, producer_type, artifact_class, birth_cut_id, tuple(birth_frontier),
                          tuple(tuple(x) for x in logical_inputs), tuple(contract_ids), status, provenance_digest,
                          tuple(tuple(x) for x in sorted(output_digests)), tuple(sorted(cost.items())), namespace,
                          binary_mode, rederived_from)
        return self._insert(e, persist=True)

    def rederive(self, slot: str, birth_cut_id: str, **kw) -> ArtifactEntry:
        """rederive(r, c): a NEW derivation instance born at c for the SAME request slot r."""
        if slot not in self._by_slot:
            raise CatalogError(f"rederive on unknown slot {slot}")
        prev = self._by_slot[slot][-1]
        return self.add(request_slot=slot, birth_cut_id=birth_cut_id, rederived_from=prev, **kw)

    def get(self, artifact_id: str) -> ArtifactEntry:
        return self._by_id[artifact_id]

    def instances(self, slot: str) -> list[ArtifactEntry]:
        return [self._by_id[a] for a in self._by_slot.get(slot, [])]

    def slots(self) -> list[str]:
        return sorted(self._by_slot)

    def __len__(self) -> int:
        return len(self._by_id)
