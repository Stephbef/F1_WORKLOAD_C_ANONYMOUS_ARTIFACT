"""Logical-version engine (frozen semantics, spec 17 §2 / tools/logical_versions.py).

Archive observations of each feed are ordered by (feed_id, archive_observed_utc, archive_id). Consecutive equal
canonical hashes collapse into one logical version whose availability is the FIRST observation; a recurrence
after a different hash is a new logical state event (A,B,A -> three versions). Logical version ids are
`{feed_id}#L{n:05d}`. Only archive observations with status OK participate (failed retrievals have no content).
Logical versions are computed before any region step. The engine is a pure function of its inputs:
re-running on the same (or a permuted) record set yields identical output (reconciliation/idempotence).
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Iterable

from ...common.util import sha256_obj
from ..ingestion.gtfs import ArchiveRecord, sort_archives


@dataclass(frozen=True)
class LogicalVersion:
    namespace: str
    feed_id: str
    index: int
    logical_version_id: str
    canonical_content_sha256: str
    first_observed_utc: str
    archive_ids: tuple[str, ...]
    raw_zip_sha256s: tuple[str, ...]
    provenance: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["archive_ids"] = list(self.archive_ids)
        d["raw_zip_sha256s"] = list(self.raw_zip_sha256s)
        return d


def build_logical_versions(records: Iterable[ArchiveRecord], id_format: str = "{feed_id}#L{n:05d}"
                           ) -> list[LogicalVersion]:
    out: list[dict[str, Any]] = []
    cur: dict[str, dict[str, Any]] = {}
    count: dict[str, int] = {}
    ordered = [r for r in sort_archives(records) if r.status == "OK"]
    seen_ids: set[tuple[str, str]] = set()
    for r in ordered:
        if (r.feed_id, r.archive_id) in seen_ids:
            raise ValueError(f"duplicate archive id {r.archive_id} for feed {r.feed_id}")
        seen_ids.add((r.feed_id, r.archive_id))
        last = cur.get(r.feed_id)
        if last is not None and last["h"] == r.canonical_content_sha256:
            last["archives"].append(r.archive_id)
            last["raws"].append(r.raw_zip_sha256)
            continue
        n = count.get(r.feed_id, 0) + 1
        count[r.feed_id] = n
        rec: dict[str, Any] = {"ns": r.namespace, "feed": r.feed_id, "n": n, "h": r.canonical_content_sha256,
               "t": r.archive_observed_utc, "archives": [r.archive_id], "raws": [r.raw_zip_sha256]}
        cur[r.feed_id] = rec
        out.append(rec)
    result = []
    for rec in out:
        result.append(LogicalVersion(
            namespace=rec["ns"], feed_id=rec["feed"], index=rec["n"],
            logical_version_id=id_format.format(feed_id=rec["feed"], n=rec["n"]),
            canonical_content_sha256=rec["h"], first_observed_utc=rec["t"], archive_ids=tuple(rec["archives"]),
            raw_zip_sha256s=tuple(rec["raws"]),
            provenance={"rule": "F1-WC logical versions (spec17 §2)", "n_archives": len(rec["archives"])}))
    return result


def versions_by_feed(versions: Iterable[LogicalVersion]) -> dict[str, list[LogicalVersion]]:
    out: dict[str, list[LogicalVersion]] = {}
    for v in versions:
        out.setdefault(v.feed_id, []).append(v)
    for k in out:
        out[k].sort(key=lambda v: v.index)
    return out


def version_in_force(versions: list[LogicalVersion], instant_utc: str) -> LogicalVersion | None:
    """Latest logical version whose availability is <= instant (canonical UTC strings compare chronologically)."""
    best = None
    for v in versions:
        if v.first_observed_utc <= instant_utc:
            best = v
    return best


def ledger_digest(versions: Iterable[LogicalVersion]) -> str:
    return sha256_obj([v.to_dict() for v in versions])
