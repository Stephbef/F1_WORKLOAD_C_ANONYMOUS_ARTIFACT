"""Write a ScheduleResult into the append-only RealizedHistory as a DAG (causal predecessors per event)."""
from __future__ import annotations

from ..history.realized import Event, EventKind, RealizedHistory
from .workload_c import ScheduleResult

_MAP = {"LOGICAL_VERSION_AVAILABLE": EventKind.LOGICAL_VERSION_AVAILABLE, "PRODUCER_QUEUED": EventKind.PRODUCER_QUEUED,
        "PRODUCER_STARTED": EventKind.PRODUCER_STARTED, "PRODUCER_COMPLETED": EventKind.PRODUCER_COMPLETED,
        "ARTIFACT_BORN": EventKind.ARTIFACT_BORN, "OTP_TRIGGER": EventKind.OTP_TRIGGER,
        "OTP_TRIGGER_SKIPPED": EventKind.OTP_TRIGGER_SKIPPED, "CONSUMER_TICK": EventKind.CONSUMER_TICK}


def to_history(res: ScheduleResult, h: RealizedHistory) -> list[str]:
    last_version: dict[str, str] = {}
    by_job: dict[str, str] = {}
    ids = []
    for e in res.events:
        kind = _MAP[e["kind"]]
        payload = {k: v for k, v in e.items() if k not in ("t", "kind", "feed_id")}
        preds: list[str] = []
        f = e.get("feed_id")
        if kind == EventKind.LOGICAL_VERSION_AVAILABLE:
            if f in last_version:
                preds.append(last_version[f])
        elif kind in (EventKind.PRODUCER_QUEUED, EventKind.PRODUCER_STARTED, EventKind.PRODUCER_COMPLETED,
                      EventKind.ARTIFACT_BORN):
            job = e["job"]
            if job in by_job:
                preds.append(by_job[job])
            elif kind == EventKind.PRODUCER_QUEUED and f in last_version:
                preds.append(last_version[f])
            elif kind == EventKind.PRODUCER_STARTED and e.get("producer") == "otp":
                preds += [last_version[x] for x in sorted(e["inputs"]) if x in last_version]
        eid = h.add(Event(kind.value, e["t"], res.region_id, f, payload, tuple(preds)))
        if kind == EventKind.LOGICAL_VERSION_AVAILABLE:
            last_version[f] = eid
        if "job" in e:
            by_job[e["job"]] = eid
        ids.append(eid)
    return ids
