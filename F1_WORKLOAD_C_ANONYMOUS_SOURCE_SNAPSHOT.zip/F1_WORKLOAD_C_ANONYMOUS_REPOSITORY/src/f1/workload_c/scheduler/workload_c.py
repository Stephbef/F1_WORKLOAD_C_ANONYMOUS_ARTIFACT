"""Exact Workload-C producer/consumer scheduler (spec17 §4), as a deterministic discrete-event simulation over a
realized history. Values come from the frozen spec `schedule` section:

  Validator : job queued at logical-version availability; region FIFO ordered by (availability, feed id, index);
              1 worker per region; the artifact exists at real completion.
  OTP       : trigger at 02:00 local each day; build only if newer inputs exist; inputs = latest available version
              of each feed at the trigger (availability <= trigger is included); 1 build per region; a trigger is
              skipped if a build is running; the artifact exists at completion.
  Consumer  : tick at 06:00 local; an artifact completed at or before the tick is visible (completion == tick
              counts as existing).
Local times use the region's IANA agency timezone with the frozen DST rules (scheduler/timeutil_local.py).
Tie order at equal instants: availability < completion < OTP trigger < validator start < consumer tick.
SCH-01 (frozen PRE-S3): "newer inputs" are compared with the inputs of the last SUCCESSFUL build
(`otp_newer_than = last_successful_build`, also recorded in configs/workload_c/spec_interpretations.json). The
alternative `last_completed_build` is retained ONLY for provenance/unit tests and is refused by `scientific_policy()`.
Durations come from an explicit backend: FIXTURE_DURATION_BACKEND or REAL_MEASURED_BACKEND (never mixed).
"""
from __future__ import annotations

import heapq
from dataclasses import dataclass, field
from datetime import timedelta
from typing import Callable

from ...common.util import sha256_obj
from ..config.spec import ProtocolSpec
from ..errors import WCError
from .timeutil_local import iso, local_dates, local_to_utc, parse

PRIO = {"AVAILABLE": 0, "VAL_COMPLETE": 1, "OTP_COMPLETE": 1, "OTP_TRIGGER": 2, "VAL_START": 3, "CONSUMER_TICK": 4}


class SchedulerError(WCError):
    error_class = "SCHEDULER_INVALID"


@dataclass(frozen=True)
class VersionAvailability:
    feed_id: str
    index: int
    logical_version_id: str
    available_utc: str


@dataclass(frozen=True)
class RegionScheduleInput:
    region_id: str
    timezone: str
    feeds: tuple[str, ...]
    versions: tuple[VersionAvailability, ...]
    start_utc: str
    end_utc: str


class FixtureDurationBackend:
    mode = "FIXTURE_DURATION_BACKEND"

    def __init__(self, validator_s: int = 600, otp_s: int = 5400, overrides: dict | None = None,
                 outcomes: dict | None = None) -> None:
        self.validator_s, self.otp_s = validator_s, otp_s
        self.overrides = overrides or {}            # job_key -> seconds
        self.outcomes = outcomes or {}              # job_key -> FailureClass value (default SUCCESS)

    def duration(self, kind: str, key: str) -> int:
        return int(self.overrides.get(key, self.validator_s if kind == "validator" else self.otp_s))

    def outcome(self, kind: str, key: str) -> str:
        return self.outcomes.get(key, "SUCCESS")


class RealMeasuredBackend:
    """Durations/outcomes measured from real producer executions (provenance wall_s / failure_class)."""
    mode = "REAL_MEASURED_BACKEND"

    def __init__(self, measure: Callable[[str, str], tuple[float, str]]) -> None:
        self._measure = measure
        self._cache: dict = {}

    def _get(self, kind, key):
        if (kind, key) not in self._cache:
            self._cache[(kind, key)] = self._measure(kind, key)
        return self._cache[(kind, key)]

    def duration(self, kind: str, key: str) -> int:
        return int(round(self._get(kind, key)[0]))

    def outcome(self, kind: str, key: str) -> str:
        return self._get(kind, key)[1]


@dataclass
class ScheduleResult:
    region_id: str
    events: list = field(default_factory=list)
    backend_mode: str = ""

    @property
    def digest(self) -> str:
        return sha256_obj(self.events)


FROZEN_OTP_NEWER_THAN = "last_successful_build"


def scientific_policy(register_value: str) -> str:
    """The scientific path accepts exactly the frozen SCH-01 policy."""
    if register_value != FROZEN_OTP_NEWER_THAN:
        raise SchedulerError(f"SCH-01 is frozen to {FROZEN_OTP_NEWER_THAN}; got {register_value}")
    return register_value


def simulate(spec: ProtocolSpec, rin: RegionScheduleInput, backend, otp_newer_than: str = FROZEN_OTP_NEWER_THAN
             ) -> ScheduleResult:
    sc = spec["schedule"]
    if sc["validator_workers_per_region"] != 1 or sc["otp_builds_per_region"] != 1 or not sc["otp_skip_if_running"]:
        raise SchedulerError("scheduler implements the frozen 1-worker / 1-build / skip-if-running rules only")
    if otp_newer_than not in ("last_completed_build", "last_successful_build"):
        raise SchedulerError("unknown otp_newer_than policy")
    feeds = tuple(sorted(rin.feeds))
    vers = sorted(rin.versions, key=lambda v: (v.available_utc, v.feed_id, v.index))
    for f in feeds:
        idx = [v.index for v in vers if v.feed_id == f]
        if idx != list(range(1, len(idx) + 1)):
            raise SchedulerError(f"feed {f}: logical indices must be 1..n in availability order")
    q: list = []
    seq = 0

    def push(t: str, kind: str, data: dict) -> None:
        nonlocal seq
        heapq.heappush(q, (t, PRIO[kind], data.get("feed_id") or "", seq, kind, data))
        seq += 1
    for v in vers:
        if rin.start_utc <= v.available_utc < rin.end_utc or v.available_utc < rin.start_utc:
            push(max(v.available_utc, "0"), "AVAILABLE", {"feed_id": v.feed_id, "index": v.index,
                                                          "lv": v.logical_version_id})
    for d in local_dates(rin.start_utc, rin.end_utc, rin.timezone):
        for kind, hhmm in (("OTP_TRIGGER", sc["otp_trigger_local"]), ("CONSUMER_TICK", sc["consumer_local"])):
            u, rule = local_to_utc(d, hhmm, rin.timezone)
            t = iso(u)
            if rin.start_utc <= t < rin.end_utc:
                push(t, kind, {"local_date": d.isoformat(), "local_time": hhmm, "dst_rule": rule})
    latest: dict[str, tuple[int, str]] = {}
    val_queue: list[tuple[str, str, int, str]] = []
    val_busy_until: str | None = None
    otp_running: dict | None = None
    last_built_inputs: dict | None = None
    last_success_inputs: dict | None = None
    val_done: dict[str, dict] = {}
    router_done: dict | None = None
    out: list[dict] = []

    def emit(t: str, kind: str, **kw) -> None:
        out.append({"t": t, "kind": kind, **kw})
    while q:
        t, _, _, _, kind, data = heapq.heappop(q)
        if kind == "AVAILABLE":
            latest[data["feed_id"]] = (data["index"], data["lv"])
            emit(t, "LOGICAL_VERSION_AVAILABLE", feed_id=data["feed_id"], index=data["index"], lv=data["lv"])
            key = f"validator|{data['feed_id']}|{data['index']}"
            val_queue.append((t, data["feed_id"], data["index"], data["lv"]))
            val_queue.sort()
            emit(t, "PRODUCER_QUEUED", producer="validator", job=key, feed_id=data["feed_id"], index=data["index"])
            if val_busy_until is None:
                push(t, "VAL_START", {})
        elif kind == "VAL_START":
            if val_busy_until is not None or not val_queue:
                continue
            qt, f, i, lv = val_queue.pop(0)
            key = f"validator|{f}|{i}"
            if getattr(backend, "wants_start_time", False):     # real executor: invocation instant (provenance)
                backend.note_start("validator", key, t)
            dur = backend.duration("validator", key)
            end = iso(parse(t) + timedelta(seconds=dur))
            val_busy_until = end
            emit(t, "PRODUCER_STARTED", producer="validator", job=key, feed_id=f, index=i, queued_at=qt)
            push(end, "VAL_COMPLETE", {"feed_id": f, "index": i, "lv": lv, "job": key, "started": t})
        elif kind == "VAL_COMPLETE":
            oc = backend.outcome("validator", data["job"])
            emit(t, "PRODUCER_COMPLETED", producer="validator", job=data["job"], feed_id=data["feed_id"],
                 index=data["index"], outcome=oc, backend=backend.mode)
            if oc in ("SUCCESS", "SEMANTIC_FAIL"):
                val_done[data["feed_id"]] = {"index": data["index"], "lv": data["lv"], "born": t, "outcome": oc}
                emit(t, "ARTIFACT_BORN", producer="validator", job=data["job"], feed_id=data["feed_id"],
                     slot=f"VAL:feed={data['feed_id']}", birth_frontier={data["feed_id"]: data["index"]})
            val_busy_until = None
            if val_queue:
                push(t, "VAL_START", {})
        elif kind == "OTP_TRIGGER":
            if otp_running is not None:
                emit(t, "OTP_TRIGGER_SKIPPED", reason="build running", local_date=data["local_date"],
                     dst_rule=data["dst_rule"])
                continue
            if any(f not in latest for f in feeds):
                emit(t, "OTP_TRIGGER_SKIPPED", reason="not every feed has a version", local_date=data["local_date"],
                     dst_rule=data["dst_rule"])
                continue
            inputs = {f: latest[f][0] for f in feeds}
            ref = last_built_inputs if otp_newer_than == "last_completed_build" else last_success_inputs
            if ref is not None and inputs == ref:
                emit(t, "OTP_TRIGGER_SKIPPED", reason="no newer inputs", local_date=data["local_date"],
                     dst_rule=data["dst_rule"])
                continue
            key = "otp|" + ",".join(f"{f}:{inputs[f]}" for f in feeds)
            if getattr(backend, "wants_start_time", False):
                backend.note_start("otp", key, t)
            dur = backend.duration("otp", key)
            end = iso(parse(t) + timedelta(seconds=dur))
            otp_running = {"inputs": inputs, "job": key, "started": t}
            emit(t, "OTP_TRIGGER", local_date=data["local_date"], dst_rule=data["dst_rule"])
            emit(t, "PRODUCER_STARTED", producer="otp", job=key, inputs=inputs)
            push(end, "OTP_COMPLETE", {"job": key, "inputs": inputs})
        elif kind == "OTP_COMPLETE":
            oc = backend.outcome("otp", data["job"])
            emit(t, "PRODUCER_COMPLETED", producer="otp", job=data["job"], outcome=oc, backend=backend.mode)
            last_built_inputs = data["inputs"]
            if oc == "SUCCESS":
                last_success_inputs = data["inputs"]
                router_done = {"inputs": data["inputs"], "born": t, "job": data["job"]}
                emit(t, "ARTIFACT_BORN", producer="otp", job=data["job"], slot=f"ROUTER:region={rin.region_id}",
                     birth_frontier=data["inputs"])
            otp_running = None
        elif kind == "CONSUMER_TICK":
            emit(t, "CONSUMER_TICK", local_date=data["local_date"], dst_rule=data["dst_rule"],
                 cut={f: latest.get(f, (0, ""))[0] for f in feeds},
                 visible_val={f: v["index"] for f, v in sorted(val_done.items())},
                 visible_router=(router_done["inputs"] if router_done else None))
    return ScheduleResult(rin.region_id, out, backend.mode)
