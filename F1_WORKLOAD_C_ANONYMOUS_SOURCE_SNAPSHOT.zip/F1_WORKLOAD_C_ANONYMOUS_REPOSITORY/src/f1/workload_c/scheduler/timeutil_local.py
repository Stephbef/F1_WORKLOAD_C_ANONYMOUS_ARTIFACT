"""Local-time trigger resolution with frozen DST rules (spec17 §4): agency timezone (IANA); a non-existent local
time moves to the next valid minute; an ambiguous local time takes its first occurrence."""
from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo


def _exists(naive: datetime, tz: ZoneInfo) -> bool:
    aware = naive.replace(tzinfo=tz, fold=0)
    return aware.astimezone(timezone.utc).astimezone(tz).replace(tzinfo=None) == naive


def local_to_utc(d: date, hhmm: str, tz_name: str) -> tuple[datetime, str]:
    """Return (UTC instant, rule applied: 'ordinary' | 'nonexistent->next-valid-minute' | 'ambiguous->first')."""
    tz = ZoneInfo(tz_name)
    h, m = (int(x) for x in hhmm.split(":"))
    naive = datetime.combine(d, time(h, m))
    rule = "ordinary"
    steps = 0
    while not _exists(naive, tz):
        naive += timedelta(minutes=1)
        steps += 1
        rule = "nonexistent->next-valid-minute"
        if steps > 24 * 60:
            raise ValueError("no valid local minute found")
    a0, a1 = naive.replace(tzinfo=tz, fold=0), naive.replace(tzinfo=tz, fold=1)
    if a0.utcoffset() != a1.utcoffset() and rule == "ordinary":
        rule = "ambiguous->first"
    return a0.astimezone(timezone.utc), rule


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def local_dates(start_utc: str, end_utc: str, tz_name: str) -> list[date]:
    tz = ZoneInfo(tz_name)
    a = parse(start_utc).astimezone(tz).date() - timedelta(days=1)
    b = parse(end_utc).astimezone(tz).date() + timedelta(days=1)
    return [a + timedelta(days=i) for i in range((b - a).days + 1)]
