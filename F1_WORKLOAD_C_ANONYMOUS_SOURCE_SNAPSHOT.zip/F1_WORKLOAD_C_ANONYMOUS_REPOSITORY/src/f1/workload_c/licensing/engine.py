"""Deterministic licence engine (frozen class policy; identifier mapping in configs/workload_c).

Frozen classes (V4 policy, consistent with spec 17 'licence class A/B/C'):
  A raw redistribution permitted        -> PASS
  B research processing, redistribution constrained -> RESTRICTED_BUT_USABLE
  C attribution required (modifier on A or B)
  D unclear                              -> UNCLEAR       (excluded before selection)
  E incompatible                         -> INCOMPATIBLE  (excluded before selection)
UNCLEAR never becomes PASS: missing evidence, unknown identifiers and conflicting evidence are all D.
"""
from __future__ import annotations

import enum
import urllib.parse
from dataclasses import asdict, dataclass

from ..config.runtime import LicenseTable
from ..config.spec import ProtocolSpec


class LicenseClassification(str, enum.Enum):
    PASS = "PASS"
    RESTRICTED_BUT_USABLE = "RESTRICTED_BUT_USABLE"
    UNCLEAR = "UNCLEAR"
    INCOMPATIBLE = "INCOMPATIBLE"


@dataclass(frozen=True)
class LicenseEvidence:
    feed_id: str
    license_url: str | None
    license_id: str | None
    source: str                      # where the evidence came from (e.g. catalog field path / evidence doc)
    evidence_sha256: str | None = None


@dataclass(frozen=True)
class LicenseDecision:
    feed_id: str
    classification: str
    license_class: str               # e.g. "A", "A+C", "B+C", "D", "E"
    attribution_required: bool
    normalized_identity: str | None
    reason_code: str
    redistribution_constraints: str
    processing_constraints: str
    eligible: bool
    evidence: dict
    provenance: dict

    def to_dict(self) -> dict:
        return asdict(self)


_REDIST = {"A": "raw ZIPs may be redistributed in the artifact",
           "B": "publish Mobility Database IDs, URLs, hashes, derived metadata and Canon digests only; never raw ZIPs",
           "D": "excluded before selection", "E": "excluded before selection"}
_PROC = {"A": "research processing permitted", "B": "research processing permitted",
         "D": "not established", "E": "research or derivative use prohibited / login-only"}


def normalize_license_url(url: str) -> str:
    u = urllib.parse.urlsplit(url.strip())
    host = (u.hostname or "").lower()
    if host.startswith("www.") and host != "www.nationalarchives.gov.uk":
        host = host[4:]
    path = u.path.rstrip("/")
    for suffix in ("/legalcode", "/deed.en", "/deed"):
        if path.endswith(suffix):
            path = path[: -len(suffix)]
    return f"https://{host}{path}"


class LicenseEngine:
    def __init__(self, spec: ProtocolSpec, table: LicenseTable) -> None:
        self.spec = spec
        self.table = table
        self._ids = table.raw["identifiers"]
        self._aliases = {normalize_license_url(k): v for k, v in table.raw["url_aliases"].items()}
        self._eligible = set(spec["feed_eligibility"]["eligible_license_classes"])

    def _decision(self, ev: LicenseEvidence, base: str, attribution: bool, identity: str | None,
                  reason: str) -> LicenseDecision:
        classes = self.spec["license_policy"]["classes"]
        enum_v = classes[base]["enum"]
        letters = base + ("+C" if attribution and base in ("A", "B") else "")
        eligible = base in self._eligible and (not attribution or "C" in self._eligible)
        if enum_v == "UNCLEAR":
            assert not eligible  # UNCLEAR can never pass (frozen invariant)
        return LicenseDecision(
            feed_id=ev.feed_id, classification=LicenseClassification(enum_v).value, license_class=letters,
            attribution_required=bool(attribution and base in ("A", "B")), normalized_identity=identity,
            reason_code=reason, redistribution_constraints=_REDIST[base]
            + ("; attribution file required" if attribution and base in ("A", "B") else ""),
            processing_constraints=_PROC[base], eligible=eligible, evidence=asdict(ev),
            provenance={"policy": "frozen classes A–E (V4 03 / spec17 §3)", "table_digest": self.table.digest,
                        "table_status": self.table.raw["status"]})

    def classify(self, ev: LicenseEvidence) -> LicenseDecision:
        from_url = None
        if ev.license_url:
            try:
                from_url = self._aliases.get(normalize_license_url(ev.license_url), None)
            except ValueError:
                return self._decision(ev, "D", False, None, "LICENSE_URL_UNPARSEABLE")
        from_id = ev.license_id.strip().lower() if ev.license_id else None
        if not ev.license_url and not from_id:
            return self._decision(ev, "D", False, None, "NO_LICENSE_EVIDENCE")
        if from_id is not None and from_id not in self._ids:
            return self._decision(ev, "D", False, from_id, "UNKNOWN_LICENSE_IDENTIFIER")
        if ev.license_url and from_url is None and from_id is None:
            return self._decision(ev, "D", False, None, "UNKNOWN_LICENSE_URL")
        if from_url is not None and from_id is not None and from_url != from_id:
            return self._decision(ev, "D", False, f"{from_url}|{from_id}", "CONFLICTING_LICENSE_EVIDENCE")
        ident = from_id or from_url
        ent = self._ids[ident]
        base = ent["base"]
        reason = {"A": "LICENSE_REDISTRIBUTION_PERMITTED", "B": "LICENSE_RESEARCH_ONLY",
                  "E": "LICENSE_INCOMPATIBLE"}[base]
        return self._decision(ev, base, ent["attribution"], ident, reason)
