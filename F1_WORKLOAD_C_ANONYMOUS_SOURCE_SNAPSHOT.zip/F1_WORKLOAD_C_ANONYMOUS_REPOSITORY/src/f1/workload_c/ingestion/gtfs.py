"""GTFS archive ingestion and the frozen canonical logical-content hash.

`canonical_content_hash()` reproduces frozen `tools/logical_versions.py::canonical_hash` exactly:
  * members whose lower-cased basename is in the frozen GTFS name set (directories skipped);
  * per member: strip a leading UTF-8 BOM, replace CRLF by LF, SHA-256;
  * sort the (name, hex) tuples; hash "\n".join(f"{name}:{hex}") encoded UTF-8.
No other normalisation is applied (ZIP timestamps, compression and member order are irrelevant by
construction because only member names and decompressed bytes enter the hash). A conformance test compares
this implementation with the frozen tool itself on every fixture archive.
"""
from __future__ import annotations

import csv
import hashlib
import io
import zipfile
from dataclasses import asdict, dataclass, field
from typing import Iterable

from ..errors import GtfsFormatError


def canonical_member_pairs(zip_bytes: bytes, gtfs_names: frozenset[str]) -> list[tuple[str, str]]:
    try:
        z = zipfile.ZipFile(io.BytesIO(zip_bytes))
    except zipfile.BadZipFile as e:
        raise GtfsFormatError(f"not a ZIP archive: {e}") from e
    parts: list[tuple[str, str]] = []
    with z:
        for info in z.infolist():
            name = info.filename.split("/")[-1].lower()
            if name not in gtfs_names or info.is_dir():
                continue
            try:
                b = z.read(info)
            except (zipfile.BadZipFile, RuntimeError, NotImplementedError, OSError) as e:
                raise GtfsFormatError(f"unreadable member {info.filename}: {e}") from e
            if b.startswith(b"\xef\xbb\xbf"):
                b = b[3:]
            b = b.replace(b"\r\n", b"\n")
            parts.append((name, hashlib.sha256(b).hexdigest()))
    parts.sort()
    return parts


def canonical_content_hash(zip_bytes: bytes, gtfs_names: frozenset[str]) -> str:
    parts = canonical_member_pairs(zip_bytes, gtfs_names)
    return hashlib.sha256("\n".join(f"{n}:{h}" for n, h in parts).encode()).hexdigest()


def read_table(zip_bytes: bytes, member: str) -> list[dict[str, str]]:
    """Read one GTFS table (basename match, case-insensitive). Missing member -> []."""
    try:
        z = zipfile.ZipFile(io.BytesIO(zip_bytes))
    except zipfile.BadZipFile as e:
        raise GtfsFormatError(f"not a ZIP archive: {e}") from e
    with z:
        cands = sorted((i for i in z.infolist() if i.filename.split("/")[-1].lower() == member and not i.is_dir()),
                       key=lambda i: (i.filename.count("/"), i.filename))
        if not cands:
            return []
        raw = z.read(cands[0])
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as e:
        raise GtfsFormatError(f"{member} is not UTF-8: {e}") from e
    rows = list(csv.DictReader(io.StringIO(text.replace("\r\n", "\n"))))
    return [{(k or "").strip(): (v or "").strip() for k, v in r.items()} for r in rows]


@dataclass(frozen=True)
class Stop:
    stop_id: str
    lat: float
    lon: float
    location_type: str = ""

    @property
    def is_boarding_point(self) -> bool:
        """INT-04 (S2 correction): a boarding/alighting stop or platform = location_type blank/missing or 0."""
        return self.location_type in ("", "0")


@dataclass
class GtfsSummary:
    stops: list[Stop]
    agency_timezones: list[str]
    agency_names: list[str]
    invalid_stop_rows: int = 0
    agency_ids: list[str] = field(default_factory=list)

    @property
    def boarding_stops(self) -> list[Stop]:
        return [s for s in self.stops if s.is_boarding_point]

    @property
    def timezone(self) -> str | None:
        tzs = sorted(set(self.agency_timezones))
        return tzs[0] if len(tzs) == 1 else None


def summarize(zip_bytes: bytes) -> GtfsSummary:
    stops_rows = read_table(zip_bytes, "stops.txt")
    agency_rows = read_table(zip_bytes, "agency.txt")
    if not agency_rows:
        raise GtfsFormatError("agency.txt missing or empty")
    if not stops_rows:
        raise GtfsFormatError("stops.txt missing or empty")
    stops: dict[str, Stop] = {}
    bad = 0
    for r in stops_rows:
        sid = r.get("stop_id", "")
        try:
            lat, lon = float(r.get("stop_lat", "")), float(r.get("stop_lon", ""))
        except ValueError:
            bad += 1
            continue
        if not sid or not (-90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0):
            bad += 1
            continue
        if sid not in stops:  # first row wins for a duplicated stop_id (distinct stops are by stop_id)
            stops[sid] = Stop(sid, lat, lon, r.get("location_type", "").strip())
    if not stops:
        raise GtfsFormatError("stops.txt contains no row with valid coordinates")
    return GtfsSummary(stops=[stops[k] for k in sorted(stops)],
                       agency_timezones=[r.get("agency_timezone", "") for r in agency_rows],
                       agency_names=[r.get("agency_name", "") for r in agency_rows], invalid_stop_rows=bad,
                       agency_ids=[r.get("agency_id", "") for r in agency_rows])


@dataclass(frozen=True)
class ArchiveRecord:
    """One archived dataset observation of one feed (provenance-complete)."""
    namespace: str
    feed_id: str
    archive_id: str
    source_locator: dict
    archive_observed_utc: str
    retrieved_utc: str
    raw_zip_sha256: str
    canonical_content_sha256: str
    byte_size: int
    license: dict
    provenance: dict = field(default_factory=dict)
    status: str = "OK"            # OK | SOURCE_LOCATOR_FAILURE | MALFORMED_ARCHIVE
    error_class: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def sort_archives(records: Iterable[ArchiveRecord]) -> list[ArchiveRecord]:
    return sorted(records, key=lambda r: (r.feed_id, r.archive_observed_utc, r.archive_id))
