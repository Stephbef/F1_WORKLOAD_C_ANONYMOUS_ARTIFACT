"""Deterministic SHA-256 selection of 24 and the independent 8/16 split (frozen tools/select_regions_hashrank.py).

seed_bytes(domain) = SHA-256(UTF8(MASTER_HEX + '|' + domain));
rank(domain, id)   = SHA-256(seed_bytes(domain) || 0x00 || UTF8(region_id)), compared as 32-byte big-endian;
selection: sorted unique eligible ids, ascending rank("region-selection"), first 24 (B1 FAIL if fewer than 24);
split: the 24 ascending by rank("validation-test"); first 8 VALIDATION, remaining 16 TEST.
No PRNG, no shuffle, no human choice.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass

from ..config.spec import ProtocolSpec
from ..errors import PopulationShortfall


def rank(spec: ProtocolSpec, domain: str, rid: str) -> bytes:
    return hashlib.sha256(spec.seed_bytes(domain) + b"\x00" + rid.encode("utf-8")).digest()


@dataclass(frozen=True)
class SelectionResult:
    eligible_sorted: tuple[str, ...]
    selection_order: tuple[str, ...]      # every eligible id in ascending selection rank
    selected: tuple[str, ...]             # first 24, in selection-rank order
    split_order: tuple[str, ...]          # the 24 in ascending split rank
    validation: tuple[str, ...]
    test: tuple[str, ...]


def select_and_split(spec: ProtocolSpec, eligible_region_ids) -> SelectionResult:
    sel, spl = spec["selection"], spec["split"]
    ids = tuple(sorted(set(eligible_region_ids)))
    if len(ids) < sel["count"]:
        raise PopulationShortfall(f"{sel['shortfall_message']}: {len(ids)} eligible regions", eligible=len(ids))
    order = tuple(sorted(ids, key=lambda r: rank(spec, sel["domain"], r)))
    chosen = order[: sel["count"]]
    split_order = tuple(sorted(chosen, key=lambda r: rank(spec, spl["domain"], r)))
    v = split_order[: spl["validation_count"]]
    t = split_order[spl["validation_count"]:]
    assert len(t) == spl["test_count"]
    return SelectionResult(ids, order, chosen, split_order, v, t)


def selection_proof_rows(spec: ProtocolSpec, res: SelectionResult) -> list[dict]:
    chosen = set(res.selected)
    return [{"selection_position": i + 1, "region_id": r, "selection_rank_hex": rank(spec, spec["selection"]["domain"], r).hex(),
             "selected": "1" if r in chosen else "0"} for i, r in enumerate(res.selection_order)]


def split_proof_rows(spec: ProtocolSpec, res: SelectionResult) -> list[dict]:
    nv = spec["split"]["validation_count"]
    return [{"split_position": i + 1, "region_id": r, "split": "VALIDATION" if i < nv else "TEST",
             "selection_rank_hex": rank(spec, spec["selection"]["domain"], r).hex(),
             "split_rank_hex": rank(spec, spec["split"]["domain"], r).hex()} for i, r in enumerate(res.split_order)]
