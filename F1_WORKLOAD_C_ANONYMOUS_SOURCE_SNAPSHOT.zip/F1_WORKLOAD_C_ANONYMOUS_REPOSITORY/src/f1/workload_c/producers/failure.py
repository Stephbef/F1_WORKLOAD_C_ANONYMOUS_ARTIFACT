"""Deterministic producer failure classification (Session 2).

Frozen rules (spec 17 §4): no scientific timeouts; an operational 24 h cap applies (affected instants excluded from
primary metrics); a build failure means "no artifact" — it is NOT cost ∞. Infrastructure failure is never turned
into semantic artifact invalidity: only SEMANTIC_FAIL (e.g. validator ERROR notices -> VAL_GATE FAIL) is a
statement about the input; every other non-SUCCESS class is an operational/no-artifact event.
"""
from __future__ import annotations

import enum


class FailureClass(str, enum.Enum):
    SUCCESS = "SUCCESS"
    SEMANTIC_FAIL = "SEMANTIC_FAIL"          # producer ran correctly and its semantic verdict is negative
    INVALID_INPUT = "INVALID_INPUT"          # input unreadable/malformed before the producer could judge it
    INFRA_ERROR = "INFRA_ERROR"              # nonzero exit / crash / corrupt or missing report
    TIMEOUT = "TIMEOUT"                      # operational cap exceeded (24 h) -> no artifact, excluded instant
    RESOURCE_FAILURE = "RESOURCE_FAILURE"    # OOM-kill / envelope overflow -> infrastructure "no artifact"
    DEPENDENCY_MISSING = "DEPENDENCY_MISSING"
    DIGEST_MISMATCH = "DIGEST_MISMATCH"


ARTIFACT_EXISTS = frozenset({FailureClass.SUCCESS, FailureClass.SEMANTIC_FAIL})
EXCLUDED_FROM_PRIMARY = frozenset({FailureClass.TIMEOUT})
INFRASTRUCTURE = frozenset({FailureClass.INFRA_ERROR, FailureClass.TIMEOUT, FailureClass.RESOURCE_FAILURE,
                            FailureClass.DEPENDENCY_MISSING, FailureClass.DIGEST_MISMATCH})


def has_artifact(fc: FailureClass) -> bool:
    """A semantic FAIL still yields an artifact (e.g. a VAL_REPORT with VAL_GATE=FAIL); infra classes do not."""
    return fc in ARTIFACT_EXISTS


def classify_process(rc: int | None, timed_out: bool, signal_killed: int | None, oom_suspected: bool) -> FailureClass:
    if timed_out:
        return FailureClass.TIMEOUT
    if oom_suspected or signal_killed == 9 and rc in (None, -9, 137):
        return FailureClass.RESOURCE_FAILURE
    if rc == 0:
        return FailureClass.SUCCESS
    return FailureClass.INFRA_ERROR
