"""Semantic routing-configuration digest: integration of the frozen whitelist projection (cfgproj.py,
frozen_specs/authoritative/conformance/tools/cfgproj.py) — executed as the authoritative implementation, not
re-designed. Operational locators (cache, storage, source paths, report dirs, ...) are excluded; relative service
bounds are resolved against an explicit BUILD_DATE; any unclassified key is BLOCKED (fail closed)."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from datetime import date
from functools import lru_cache

from .. import paths
from ..errors import WCError

CFGPROJ = paths.FROZEN_SPECS / "authoritative" / "conformance" / "tools" / "cfgproj.py"


class UnclassifiedConfigKey(WCError):
    error_class = "CONFIG_UNCLASSIFIED_KEY_BLOCKED"


@lru_cache(maxsize=1)
def _module():
    spec = importlib.util.spec_from_file_location("frozen_cfgproj", CFGPROJ)
    mod = importlib.util.module_from_spec(spec)  # type: ignore[arg-type]
    old = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(mod)  # type: ignore[union-attr]
    finally:
        sys.dont_write_bytecode = old
    return mod


def project(build_config: dict, build_date: date) -> dict:
    mod = _module()
    try:
        return mod.project(build_config, build_date)
    except SystemExit as e:
        raise UnclassifiedConfigKey(f"build-config contains an unclassified key (frozen cfgproj exit {e.code})") from None


def semantic_config_digest(build_config: dict, build_date: date) -> str:
    p = project(build_config, build_date)
    return hashlib.sha256(json.dumps(p, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def resolve_service_bounds(build_date: date, start: str | None = None, end: str | None = None) -> tuple[str, str]:
    """Resolve OTP service bounds to ABSOLUTE ISO dates before invocation. None -> OTP defaults (-P1Y / P3Y) relative
    to the explicit build date (never the ambient wall clock); relative ISO periods are resolved the same way."""
    mod = _module()
    s = start or "-P1Y"
    e = end or "P3Y"
    rs = mod.period(s, build_date) or date.fromisoformat(s).isoformat()
    re_ = mod.period(e, build_date) or date.fromisoformat(e).isoformat()
    if rs > re_:
        raise WCError(f"service window empty: {rs} > {re_}")
    return rs, re_
