"""gtfs-validator producer (frozen: MobilityData gtfs-validator 8.0.1, `-d <consumer date> -c <country> -svu -t 1`,
validator envelope 2 cores / -Xmx4g / 1 worker per region; VAL_GATE = PASS iff zero ERROR notices).

Artifacts per invocation:
  VAL_REPORT — the validator report; raw report bytes stored immutably, plus a SEMANTIC report projection
               (notices + validatorVersion + dateForValidation + countryCode; volatile fields such as validatedAt,
               outputDirectory, timings and memory records are excluded) whose digest is the report identity;
  VAL_GATE   — derived value PASS/FAIL (zero ERROR notices) under the exact validator/date/options.
Infrastructure outcomes (timeout, crash, corrupt report, OOM, missing/mismatched binary) are never a semantic FAIL.
"""
from __future__ import annotations

import json
import shutil
import sys
import zipfile
from dataclasses import asdict, dataclass, field
from pathlib import Path

from ...common.util import canonical_json, sha256_bytes, sha256_file, sha256_obj
from .. import paths
from ..config.spec import ProtocolSpec
from ..deps.pins import BinaryMode, ResolvedDependencies
from ..storage.blobstore import BlobStore
from .failure import FailureClass, has_artifact
from .process import OPERATIONAL_CAP_S, base_env, run_process
from .provenance import ProducerProvenance, host_identity

STUB = paths.REPO_ROOT / "fixtures" / "stub_binaries" / "stub_gtfs_validator.py"
VOLATILE_SUMMARY = {"validatedAt", "outputDirectory", "validationTimeSeconds", "memoryUsageRecords", "gtfsInput",
                    "threads", "systemErrorsReportName", "validationReportName", "htmlReportName"}


@dataclass(frozen=True)
class ValidatorRequest:
    request_slot: str                 # fixed-R slot, e.g. "VAL:feed=mdb-1001"
    region_id: str
    feed_id: str
    logical_version_id: str
    canonical_content_sha256: str
    zip_path: str
    consumer_date: str                # ISO date of the historical consumer/birth cut (passed as -d)
    country: str                      # ISO-3166 alpha-2 (passed as -c)
    birth_cut_id: str
    namespace: str


@dataclass
class ValidatorOutcome:
    failure_class: str
    val_report: dict | None
    val_gate: dict | None
    provenance: dict
    argv: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def semantic_report(report: dict) -> dict:
    s = {k: v for k, v in report.get("summary", {}).items() if k in ("validatorVersion", "dateForValidation", "countryCode")}
    notices = sorted(({"code": n["code"], "severity": n["severity"], "totalNotices": int(n.get("totalNotices", 0))}
                      for n in report["notices"]), key=lambda n: (n["code"], n["severity"]))
    return {"summary": s, "notices": notices}


class GtfsValidatorProducer:
    """Concrete ValidatorProducer. `produce()` is the Session-2 API; `validate()` keeps the Session-1 protocol."""

    def __init__(self, spec: ProtocolSpec, deps: ResolvedDependencies, blobs: BlobStore, work_root: Path, clock,
                 timeout_s: float = OPERATIONAL_CAP_S, wrappers_factory=None, isolate_network: bool = True,
                 stub_behavior: str = "ok") -> None:
        self.spec, self.deps, self.blobs, self.clock = spec, deps, blobs, clock
        self.work_root = Path(work_root)
        self.timeout_s = timeout_s
        self.wrappers_factory = wrappers_factory
        self.isolate_network = isolate_network
        self.stub_behavior = stub_behavior
        self.mode = deps.mode
        if self.mode == BinaryMode.REAL_PINNED_BINARY:
            if not (deps.validator_jar and deps.java):
                raise ValueError("REAL_PINNED_BINARY validator requires verified jar and JDK")
            self.binary_sha = sha256_file(deps.validator_jar)
            self.producer_name = "gtfs-validator 8.0.1"
        else:
            self.binary_sha = sha256_file(STUB)
            self.producer_name = "FIXTURE-STUB:gtfs-validator"

    def command(self, req: ValidatorRequest, out_dir: str) -> list[str]:
        """Exact frozen flags: -d <consumer date> -c <country> -svu -t 1 (+ envelope heap -Xmx4g)."""
        args = ["-i", req.zip_path, "-o", out_dir, "-d", req.consumer_date, "-c", req.country, "-svu", "-t", "1"]
        if self.mode == BinaryMode.REAL_PINNED_BINARY:
            return [str(self.deps.java), "-Xmx4g", "-Duser.timezone=UTC", "-Djava.io.tmpdir=" + str(Path(out_dir).parent),
                    "-jar", str(self.deps.validator_jar)] + args
        return [sys.executable, str(STUB)] + args + ["--stub-behavior", self.stub_behavior]

    def config_digest(self, req: ValidatorRequest) -> str:
        return sha256_obj({"producer": self.producer_name, "flags": ["-d", req.consumer_date, "-c", req.country, "-svu",
                                                                     "-t", "1"], "heap": "-Xmx4g", "mode": self.mode.value})

    def produce(self, req: ValidatorRequest) -> ValidatorOutcome:
        job = self.work_root / f"val-{sha256_obj(asdict(req))[:20]}"
        if job.exists():
            shutil.rmtree(job)
        job.mkdir(parents=True)
        inputs = {"gtfs_zip_sha256": sha256_file(req.zip_path), "canonical_content_sha256": req.canonical_content_sha256}
        argv = self.command(req, str(job / "out"))
        # input pre-check: an unreadable container is INVALID_INPUT; the producer is not invoked
        try:
            with zipfile.ZipFile(req.zip_path) as z:
                z.testzip()
        except (zipfile.BadZipFile, OSError):
            return self._outcome(req, FailureClass.INVALID_INPUT, None, inputs, argv, None, job)
        wrappers = self.wrappers_factory("validator") if self.wrappers_factory else []
        pr = run_process(argv, job, env=base_env(job), timeout_s=self.timeout_s, wrappers=wrappers,
                         isolate_network=self.isolate_network, clock=self.clock)
        fc = FailureClass(pr.failure_class)
        report = None
        if fc == FailureClass.SUCCESS:
            rp = job / "out" / "report.json"
            try:
                raw = rp.read_bytes()
                report = json.loads(raw)
                if not isinstance(report.get("notices"), list) or "summary" not in report:
                    raise ValueError("report shape")
                for n in report["notices"]:
                    if n.get("severity") not in ("ERROR", "WARNING", "INFO") or "code" not in n:
                        raise ValueError("notice shape")
            except (OSError, ValueError, json.JSONDecodeError):
                fc, report = FailureClass.INFRA_ERROR, None          # corrupt/missing report is infrastructure
        return self._outcome(req, fc, report, inputs, argv, pr, job)

    def _outcome(self, req, fc, report, inputs, argv, pr, job) -> ValidatorOutcome:
        val_report = val_gate = None
        result_digest = None
        if report is not None:
            raw_ref = self.blobs.put((job / "out" / "report.json").read_bytes(), "application/json",
                                     provenance={"kind": "VAL_REPORT_RAW", "slot": req.request_slot})
            sem = semantic_report(report)
            sem_ref = self.blobs.put(canonical_json(sem).encode(), "application/json",
                                     provenance={"kind": "VAL_REPORT", "slot": req.request_slot})
            n_err = sum(n["totalNotices"] for n in sem["notices"] if n["severity"] == "ERROR")
            gate = "PASS" if not any(n["severity"] == "ERROR" for n in sem["notices"]) else "FAIL"
            if gate == "FAIL":
                fc = FailureClass.SEMANTIC_FAIL
            common = {"request_slot": req.request_slot, "region_id": req.region_id, "feed_id": req.feed_id,
                      "logical_version_id": req.logical_version_id, "birth_cut_id": req.birth_cut_id,
                      "consumer_date": req.consumer_date, "country": req.country, "validator_sha256": self.binary_sha,
                      "binary_mode": self.mode.value, "namespace": req.namespace}
            val_report = {**common, "artifact_class": "VAL_REPORT", "report_digest": sem_ref.sha256,
                          "raw_report_sha256": raw_ref.sha256, "n_error_notices": n_err}
            val_gate = {**common, "artifact_class": "VAL_GATE", "report_digest": sem_ref.sha256, "gate": gate,
                        "rule": "PASS iff zero ERROR notices (spec17 §1)"}
            result_digest = sem_ref.sha256
        assert (val_report is not None) == has_artifact(fc)
        prov = ProducerProvenance(
            producer=self.producer_name, binary_mode=self.mode.value, binary_sha256=self.binary_sha,
            runtime_identity=self._runtime(), config_digest=self.config_digest(req), input_digests=inputs,
            resource_envelope={"component": "validator", "cpus": 2, "heap": "-Xmx4g", "threads": 1},
            started_utc=pr.started_utc if pr else self.clock.now(), ended_utc=pr.ended_utc if pr else self.clock.now(),
            wall_s=pr.wall_s if pr else 0.0, cpu_s=round((pr.cpu_user_s + pr.cpu_sys_s), 3) if pr else 0.0,
            host=host_identity(), stdout_sha256=pr.stdout_sha256 if pr else sha256_bytes(b""),
            stderr_sha256=pr.stderr_sha256 if pr else sha256_bytes(b""), result_digest=result_digest,
            argv_digest=sha256_obj(argv), failure_class=fc.value,
            extra={"network_isolated": bool(pr and pr.network_isolated), "wrappers": pr.wrappers if pr else [],
                   "rc": pr.rc if pr else None, "timed_out": bool(pr and pr.timed_out)})
        return ValidatorOutcome(fc.value, val_report, val_gate, prov.to_dict(), argv)

    def _runtime(self) -> dict:
        st = {s.name: s for s in self.deps.statuses}
        if self.mode == BinaryMode.REAL_PINNED_BINARY and "jdk" in st:
            return {"jdk": st["jdk"].detail, "jdk_identity_sha256": st["jdk"].actual_sha256}
        return {"stub_interpreter": sys.version.split()[0]}
