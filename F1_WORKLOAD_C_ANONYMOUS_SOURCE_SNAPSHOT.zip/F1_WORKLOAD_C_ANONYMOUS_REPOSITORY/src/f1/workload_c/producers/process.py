"""Hardened external-process execution for producers.

* argv arrays only (never a shell string) and an explicit, minimal environment (PATH, LANG/LC_ALL=C.UTF-8, TZ=UTC,
  HOME=<job dir>) — no ambient variables, so credentials such as MOBILITY_DB_TOKEN can never reach a producer;
* per-job isolated working directory; stdout/stderr captured to files and hashed;
* bounded operational timeout (frozen 24 h cap by default) with whole-process-group kill;
* wall-clock and child CPU accounting via wait4 rusage; peak RSS;
* optional wrappers: resource scope (ResourceManager) and network isolation (`unshare -rn`), recorded in the result.
"""
from __future__ import annotations

import os
import shutil
import signal
import subprocess
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

from ...common.util import sha256_file
from ..errors import WCError
from ..timeutil import Clock
from .failure import FailureClass, classify_process

OPERATIONAL_CAP_S = 24 * 3600


class ProducerInvocationError(WCError):
    error_class = "PRODUCER_INVOCATION"


def base_env(job_dir: Path, extra: dict | None = None) -> dict:
    env = {"PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C.UTF-8",
           "LC_ALL": "C.UTF-8", "TZ": "UTC", "HOME": str(job_dir)}
    allowed = {"TZ", "LANG", "LC_ALL", "FAKETIME", "JAVA_TOOL_OPTIONS_DISABLED"}
    for k, v in (extra or {}).items():
        if k not in allowed:
            raise ProducerInvocationError(f"environment override {k} is not allow-listed")
        if k.upper() in ("MOBILITY_DB_TOKEN",) or "TOKEN" in k.upper() or "SECRET" in k.upper():
            raise ProducerInvocationError(f"refusing to pass credential-like variable {k} to a producer")
        env[k] = str(v)
    return env


def network_isolation_available() -> bool:
    exe = shutil.which("unshare")
    if not exe:
        return False
    try:
        return subprocess.run([exe, "-rn", "true"], capture_output=True, timeout=10).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


@dataclass
class ProcessResult:
    argv: list
    cwd: str
    rc: int | None
    signal: int | None
    timed_out: bool
    wall_s: float
    cpu_user_s: float
    cpu_sys_s: float
    max_rss_kb: int
    started_utc: str
    ended_utc: str
    stdout_path: str
    stderr_path: str
    stdout_sha256: str
    stderr_sha256: str
    wrappers: list = field(default_factory=list)
    network_isolated: bool = False
    failure_class: str = FailureClass.SUCCESS.value

    def to_dict(self) -> dict:
        return asdict(self)


def validate_path(p: str | Path, must_exist: bool = True) -> Path:
    q = Path(p)
    if "\x00" in str(q):
        raise ProducerInvocationError("NUL byte in path")
    q = q.resolve()
    if must_exist and not q.exists():
        raise ProducerInvocationError(f"path does not exist: {q}")
    return q


def run_process(argv: list[str], job_dir: Path, *, env: dict, timeout_s: float = OPERATIONAL_CAP_S,
                wrappers: list[list[str]] | None = None, isolate_network: bool = False, clock: Clock | None = None,
                stdout_name: str = "stdout.log", stderr_name: str = "stderr.log") -> ProcessResult:
    if not argv or not all(isinstance(a, str) for a in argv):
        raise ProducerInvocationError("argv must be a non-empty list of strings")
    clock = clock or Clock()
    job_dir = validate_path(job_dir)
    full: list[str] = []
    applied = []
    for w in wrappers or []:
        full += w
        applied.append(w[0])
    if isolate_network:
        if not network_isolation_available():
            raise ProducerInvocationError("network isolation requested but unshare -rn is unavailable")
        full += ["unshare", "-rn"]
        applied.append("unshare-rn")
    full += argv
    out_p, err_p = job_dir / stdout_name, job_dir / stderr_name
    started = clock.now()
    t0 = time.monotonic()
    timed_out = False
    with open(out_p, "wb") as fo, open(err_p, "wb") as fe:
        proc = subprocess.Popen(full, cwd=str(job_dir), env=env, stdout=fo, stderr=fe, stdin=subprocess.DEVNULL,
                                start_new_session=True)
        deadline = t0 + timeout_s
        status = None
        rusage = None
        while True:
            pid, st, ru = os.wait4(proc.pid, os.WNOHANG)
            if pid == proc.pid:
                status, rusage = st, ru
                break
            if time.monotonic() >= deadline:
                timed_out = True
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                _, status, rusage = os.wait4(proc.pid, 0)
                break
            time.sleep(0.05)
        proc.returncode = 0  # reaped via wait4; prevent Popen from waiting again
    wall = time.monotonic() - t0
    rc = os.WEXITSTATUS(status) if os.WIFEXITED(status) else None
    sig = os.WTERMSIG(status) if os.WIFSIGNALED(status) else None
    oom = sig == 9 and not timed_out
    fc = classify_process(rc, timed_out, sig, oom)
    return ProcessResult(argv=list(full), cwd=str(job_dir), rc=rc, signal=sig, timed_out=timed_out, wall_s=round(wall, 3),
                         cpu_user_s=round(rusage.ru_utime, 3), cpu_sys_s=round(rusage.ru_stime, 3),
                         max_rss_kb=int(rusage.ru_maxrss), started_utc=started, ended_utc=clock.now(),
                         stdout_path=str(out_p), stderr_path=str(err_p), stdout_sha256=sha256_file(out_p),
                         stderr_sha256=sha256_file(err_p), wrappers=applied, network_isolated=isolate_network,
                         failure_class=fc.value)
