"""Canon_D integration (frozen F1-OTP-CANON-1.3, frozen_specs/authoritative/06_CANON_EXTRACT_FINAL.java).

The frozen source is used byte-for-byte (SHA-256 checked) — copied as CanonExtractFinal.java, compiled with the
pinned javac against the pinned OTP jar into a content-addressed classes directory, and executed as
`java -cp otp.jar:classes CanonExtractFinal graph.obj D out configSha osmSha otpSha`. No redesign, no extra
reflection. FIXTURE_STUB mode runs the clearly-labelled stub (never REAL).
"""
from __future__ import annotations

import re
import shutil
import sys
from dataclasses import asdict, dataclass
from datetime import date, timedelta
from pathlib import Path

from ...common.util import sha256_file, sha256_obj
from .. import paths
from ..config.spec import ProtocolSpec
from ..deps.pins import BinaryMode, ResolvedDependencies
from ..errors import WCError
from .process import base_env, run_process

STUB = paths.REPO_ROOT / "fixtures" / "stub_binaries" / "stub_canon.py"


class CanonError(WCError):
    error_class = "CANON_ERROR"


def horizon(t_local_date: date, days: int) -> list[str]:
    """D = [t, t + 6] for the frozen 7-day horizon (spec17 §5): explicit dates, never ambient 'today'."""
    return [(t_local_date + timedelta(days=i)).isoformat() for i in range(days)]


@dataclass(frozen=True)
class CanonDigest:
    schema: str
    sha256: str
    records: int


@dataclass
class CanonResult:
    status: str                   # OK | ERROR
    digest: CanonDigest | None
    canon_bytes_sha256: str | None
    canon_path: str | None
    horizon: list
    config_digest: str
    osm_sha256: str
    otp_sha256: str
    router_artifact_id: str
    binary_mode: str
    canon_source_sha256: str
    wall_s: float
    error: str | None = None

    def to_dict(self) -> dict:
        d = asdict(self)
        return d


class CanonRunner:
    def __init__(self, spec: ProtocolSpec, deps: ResolvedDependencies, cache_dir: Path, clock,
                 java_flags: tuple[str, ...] = ("-Xmx2G", "-Duser.timezone=UTC")) -> None:
        self.spec, self.deps, self.clock = spec, deps, clock
        self.cache_dir = Path(cache_dir)
        self.java_flags = java_flags
        self.source = spec.root / spec["sources"]["CANON06"]["path"]
        self.source_sha = sha256_file(self.source)
        if self.source_sha != spec["sources"]["CANON06"]["sha256"]:
            raise CanonError("frozen Canon source digest mismatch")
        self.mode = deps.mode
        self._classes: Path | None = None

    def compile(self) -> Path:
        """Compile the frozen source once per (source, OTP jar, javac) identity; returns classes dir."""
        if self.mode != BinaryMode.REAL_PINNED_BINARY:
            raise CanonError("compile() requires REAL_PINNED_BINARY")
        if self._classes:
            return self._classes
        assert self.deps.otp_jar is not None and self.deps.javac is not None
        otp_sha = sha256_file(self.deps.otp_jar)
        javac_id = {s.name: s.actual_sha256 for s in self.deps.statuses}.get("javac")
        key = sha256_obj([self.source_sha, otp_sha, javac_id])[:24]
        out = self.cache_dir / f"canon-classes-{key}"
        if not (out / "CanonExtractFinal.class").exists():
            tmp = self.cache_dir / f".tmp-canon-{key}"
            if tmp.exists():
                shutil.rmtree(tmp)
            (tmp / "src").mkdir(parents=True)
            shutil.copyfile(self.source, tmp / "src" / f"{self.spec['canon']['main_class']}.java")
            pr = run_process([str(self.deps.javac), "-cp", str(self.deps.otp_jar), "-d", str(tmp / "classes"),
                              str(tmp / "src" / f"{self.spec['canon']['main_class']}.java")], tmp, env=base_env(tmp),
                             timeout_s=1800, clock=self.clock)
            if pr.rc != 0:
                raise CanonError(f"javac failed: {Path(pr.stderr_path).read_text()[-1500:]}")
            if out.exists():
                shutil.rmtree(out)
            (tmp / "classes").rename(out)
            shutil.rmtree(tmp, ignore_errors=True)
        self._classes = out
        return out

    def run(self, graph_obj: Path, d: list[str], config_digest: str, osm_sha256: str, otp_sha256: str,
            router_artifact_id: str, job_dir: Path, wrappers: list | None = None) -> CanonResult:
        job_dir.mkdir(parents=True, exist_ok=True)
        out = job_dir / "canon13.txt"
        if self.mode == BinaryMode.REAL_PINNED_BINARY:
            classes = self.compile()
            argv = [str(self.deps.java), *self.java_flags, "-cp", f"{self.deps.otp_jar}:{classes}",
                    self.spec["canon"]["main_class"]]
        else:
            argv = [sys.executable, str(STUB)]
        argv += [str(graph_obj), ",".join(d), str(out), config_digest, osm_sha256, otp_sha256]
        pr = run_process(argv, job_dir, env=base_env(job_dir), timeout_s=24 * 3600, wrappers=wrappers, clock=self.clock,
                         stdout_name="canon_stdout.log", stderr_name="canon_stderr.log")
        txt = Path(pr.stdout_path).read_text()
        m = re.search(r"^" + re.escape(self.spec["canon"]["output_marker"]) + r" ([0-9a-f]{64}) records (\d+)$", txt, re.M)
        def result(status: str, dg: CanonDigest | None, path: str | None, err: str | None) -> CanonResult:
            return CanonResult(status, dg, dg.sha256 if dg else None, path, list(d), config_digest, osm_sha256, otp_sha256,
                               router_artifact_id, self.mode.value, self.source_sha, pr.wall_s, err)
        if pr.rc != 0 or not m or not out.exists():
            return result("ERROR", None, None, Path(pr.stderr_path).read_text()[-1500:] or "no digest")
        if sha256_file(out) != m.group(1):
            return result("ERROR", None, None, "canon bytes digest != printed digest")
        schema = self.spec["canon"]["schema"]
        if self.mode != BinaryMode.REAL_PINNED_BINARY:
            schema += "-FIXTURE-STUB"
        return result("OK", CanonDigest(schema, m.group(1), int(m.group(2))), str(out), None)
