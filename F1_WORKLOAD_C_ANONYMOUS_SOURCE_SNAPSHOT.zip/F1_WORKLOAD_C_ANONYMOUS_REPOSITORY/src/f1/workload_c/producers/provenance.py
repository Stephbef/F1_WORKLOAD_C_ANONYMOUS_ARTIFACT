"""Producer provenance records (bound into every artifact)."""
from __future__ import annotations

import os
import platform
import socket
from dataclasses import asdict, dataclass, field

from ...common.util import sha256_obj


def host_identity() -> dict:
    """Coarse host identity (no secrets): hostname digest, platform, cpu count, memory."""
    mem_kb = 0
    try:
        for ln in open("/proc/meminfo"):
            if ln.startswith("MemTotal:"):
                mem_kb = int(ln.split()[1])
    except OSError:
        pass
    return {"hostname_sha256": sha256_obj(socket.gethostname()), "platform": platform.platform(terse=True),
            "machine": platform.machine(), "cpu_count": os.cpu_count(), "mem_total_kb": mem_kb,
            "python": platform.python_version()}


@dataclass(frozen=True)
class ProducerProvenance:
    producer: str                 # e.g. "gtfs-validator 8.0.1" | "otp 2.10.0" | "FIXTURE-STUB:..."
    binary_mode: str              # REAL_PINNED_BINARY | FIXTURE_STUB_BINARY
    binary_sha256: str
    runtime_identity: dict        # JDK version + identity digest, etc.
    config_digest: str
    input_digests: dict
    resource_envelope: dict
    started_utc: str
    ended_utc: str
    wall_s: float
    cpu_s: float
    host: dict
    stdout_sha256: str
    stderr_sha256: str
    result_digest: str | None
    argv_digest: str
    failure_class: str
    extra: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def digest(self) -> str:
        return sha256_obj(self.to_dict())
