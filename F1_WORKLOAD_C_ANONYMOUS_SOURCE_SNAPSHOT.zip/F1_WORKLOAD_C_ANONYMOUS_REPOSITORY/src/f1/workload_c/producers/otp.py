"""OpenTripPlanner 2.10.0 producer (ROUTER artifacts).

Build = `java <envelope JVM flags> -jar otp-shaded-2.10.0.jar --buildStreet DIR` then `--loadStreet --save DIR`
(identical to the frozen conformance harness). Bound inputs: exact OTP jar digest, exact JDK identity, local GTFS
logical-version files, local OSM extract, generated build-config.json with ABSOLUTE service bounds resolved before
invocation from an explicit build date (OTP defaults -P1Y/P3Y relative to BUILD_DAY are resolved, never left to
the wall clock), transitModelTimeZone, semantic-config digest (frozen cfgproj), resource envelope, network isolation
(unshare -rn), JVM timezone UTC and LC_ALL=C.UTF-8. Output: graph.obj digest, logs, timings, provenance, Canon_D.
"""
from __future__ import annotations

import shutil
import sys
from dataclasses import asdict, dataclass, field
from datetime import date
from pathlib import Path

from ...common.util import canonical_json, sha256_file, sha256_obj
from .. import paths
from ..config.spec import ProtocolSpec
from ..deps.pins import BinaryMode, ResolvedDependencies
from ..resources.manager import ResourceEnvelope
from ..storage.blobstore import BlobStore
from .canon import CanonResult, CanonRunner
from .failure import FailureClass
from .process import OPERATIONAL_CAP_S, base_env, run_process
from .provenance import ProducerProvenance, host_identity
from .semconfig import resolve_service_bounds, semantic_config_digest

STUB = paths.REPO_ROOT / "fixtures" / "stub_binaries" / "stub_otp.py"


@dataclass(frozen=True)
class OtpFeedInput:
    feed_id: str
    logical_version_id: str
    canonical_content_sha256: str
    zip_path: str


@dataclass(frozen=True)
class OtpRequest:
    request_slot: str                  # fixed-R slot, e.g. "ROUTER:region=R:..."
    region_id: str
    feeds: tuple[OtpFeedInput, ...]
    osm_path: str
    model_timezone: str
    build_date: str                    # explicit local build date (trigger day) — the BUILD_DAY for bound resolution
    horizon: tuple[str, ...]           # Canon_D horizon dates
    birth_cut_id: str
    namespace: str
    service_start: str | None = None   # None -> OTP default -P1Y resolved against build_date
    service_end: str | None = None     # None -> OTP default P3Y resolved against build_date


@dataclass
class OtpOutcome:
    failure_class: str
    router: dict | None
    canon: dict | None
    provenance: dict
    build_config: dict
    semantic_config_digest: str
    argv: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def build_config_for(req: OtpRequest) -> tuple[dict, dict]:
    """Return (build-config.json content, local file mapping). Feed order is canonical (sorted by feed id)."""
    start, end = resolve_service_bounds(date.fromisoformat(req.build_date), req.service_start, req.service_end)
    feeds, files = [], {}
    for i, f in enumerate(sorted(req.feeds, key=lambda x: x.feed_id)):
        local = f"feed{i:02d}.gtfs.zip"
        files[local] = f.zip_path
        feeds.append({"type": "gtfs", "feedId": f.feed_id, "source": local})
    files["street.osm.pbf"] = req.osm_path
    cfg = {"transitServiceStart": start, "transitServiceEnd": end, "transitModelTimeZone": req.model_timezone,
           "transitFeeds": feeds, "osm": [{"source": "street.osm.pbf"}]}
    return cfg, files


class OtpRouterProducer:
    """Concrete OtpProducer."""

    def __init__(self, spec: ProtocolSpec, deps: ResolvedDependencies, blobs: BlobStore, work_root: Path, clock,
                 envelope: ResourceEnvelope, canon: CanonRunner, timeout_s: float = OPERATIONAL_CAP_S,
                 wrappers_factory=None, isolate_network: bool = True, stub_behavior: str = "ok",
                 extra_wrappers: list | None = None) -> None:
        self.spec, self.deps, self.blobs, self.clock = spec, deps, blobs, clock
        self.work_root = Path(work_root)
        self.envelope, self.canon = envelope, canon
        self.timeout_s, self.wrappers_factory = timeout_s, wrappers_factory
        self.isolate_network, self.stub_behavior = isolate_network, stub_behavior
        self.extra_wrappers = extra_wrappers or []          # e.g. [["faketime", "2031-03-15 04:00:00"]] (D2 tests)
        self.mode = deps.mode
        if self.mode == BinaryMode.REAL_PINNED_BINARY:
            if not (deps.otp_jar and deps.java):
                raise ValueError("REAL_PINNED_BINARY OTP requires verified jar and JDK")
            self.binary_sha = sha256_file(deps.otp_jar)
            self.producer_name = "otp 2.10.0"
        else:
            self.binary_sha = sha256_file(STUB)
            self.producer_name = "FIXTURE-STUB:otp"

    def jvm_flags(self, job: Path) -> list[str]:
        return list(self.envelope.jvm_flags) + [f"-Djava.io.tmpdir={job / 'tmp'}"]

    def commands(self, job: Path) -> list[list[str]]:
        if self.mode == BinaryMode.REAL_PINNED_BINARY:
            base = [str(self.deps.java)] + self.jvm_flags(job) + ["-jar", str(self.deps.otp_jar)]
            return [base + ["--buildStreet", str(job / "graph")], base + ["--loadStreet", "--save", str(job / "graph")]]
        base = [sys.executable, str(STUB), "--stub-behavior", self.stub_behavior]
        return [base + ["--buildStreet", str(job / "graph")], base + ["--loadStreet", "--save", str(job / "graph")]]

    def build_dir(self, job: Path, env_overrides: dict | None = None, extra_wrappers: list | None = None,
                  jvm_flags: list[str] | None = None) -> tuple[FailureClass, list]:
        """Run the two frozen OTP steps on job/graph (which must already hold build-config + local inputs)."""
        (job / "tmp").mkdir(exist_ok=True)
        argvs = self.commands(job)
        if jvm_flags is not None and self.mode == BinaryMode.REAL_PINNED_BINARY:
            j = argvs[0].index("-jar")
            argvs = [[a[0]] + list(jvm_flags) + [f"-Djava.io.tmpdir={job / 'tmp'}"] + a[j:] for a in argvs]
        wrappers = (self.wrappers_factory("otp") if self.wrappers_factory else []) + self.extra_wrappers + \
            (extra_wrappers or [])
        env = base_env(job, env_overrides)
        prs = []
        fc = FailureClass.SUCCESS
        for i, argv in enumerate(argvs):
            pr = run_process(argv, job, env=env, timeout_s=self.timeout_s, wrappers=wrappers,
                             isolate_network=self.isolate_network, clock=self.clock,
                             stdout_name=f"step{i}_stdout.log", stderr_name=f"step{i}_stderr.log")
            prs.append(pr)
            if pr.failure_class != FailureClass.SUCCESS.value:
                fc = FailureClass(pr.failure_class)
                break
        if fc == FailureClass.SUCCESS and not (job / "graph" / "graph.obj").exists():
            fc = FailureClass.INFRA_ERROR
        return fc, prs

    def produce(self, req: OtpRequest) -> OtpOutcome:
        cfg, files = build_config_for(req)
        sem = semantic_config_digest(cfg, date.fromisoformat(req.build_date))
        job = self.work_root / f"otp-{sha256_obj([asdict(req), self.mode.value])[:20]}"
        if job.exists():
            shutil.rmtree(job)
        (job / "graph").mkdir(parents=True)
        (job / "tmp").mkdir()
        inputs = {}
        for local, src in sorted(files.items()):
            shutil.copyfile(src, job / "graph" / local)                    # inputs are local, hashed copies
            inputs[local] = sha256_file(job / "graph" / local)
        (job / "graph" / "build-config.json").write_text(canonical_json(cfg))
        osm_sha = inputs["street.osm.pbf"]
        argvs = self.commands(job)
        fc, prs = self.build_dir(job)
        graph = job / "graph" / "graph.obj"
        router = None
        canon_res: CanonResult | None = None
        if fc == FailureClass.SUCCESS and not graph.exists():
            fc = FailureClass.INFRA_ERROR
        artifact_id = "ROUTER:" + sha256_obj([req.request_slot, req.birth_cut_id, sorted(inputs.items()), sem,
                                              self.binary_sha, list(req.horizon)])[:32]
        if fc == FailureClass.SUCCESS:
            g_sha = sha256_file(graph)
            canon_res = self.canon.run(graph, list(req.horizon), sem, osm_sha, self.binary_sha, artifact_id, job / "canon")
            if canon_res.status != "OK" or canon_res.digest is None:
                fc = FailureClass.INFRA_ERROR
            else:
                router = {"artifact_id": artifact_id, "artifact_class": "ROUTER", "request_slot": req.request_slot,
                          "region_id": req.region_id, "birth_cut_id": req.birth_cut_id, "namespace": req.namespace,
                          "gtfs_logical_versions": {f.feed_id: [f.logical_version_id, f.canonical_content_sha256]
                                                    for f in sorted(req.feeds, key=lambda x: x.feed_id)},
                          "osm_sha256": osm_sha, "otp_sha256": self.binary_sha, "jdk": self._runtime(),
                          "semantic_config_digest": sem, "service_window": [cfg["transitServiceStart"], cfg["transitServiceEnd"]],
                          "horizon_D": list(req.horizon), "graph_sha256": g_sha, "canon_digest": canon_res.digest.sha256,
                          "canon_schema": canon_res.digest.schema, "binary_mode": self.mode.value,
                          "producer_start": prs[0].started_utc, "producer_end": prs[-1].ended_utc, "status": "OK"}
        prov = ProducerProvenance(
            producer=self.producer_name, binary_mode=self.mode.value, binary_sha256=self.binary_sha,
            runtime_identity=self._runtime(), config_digest=sem, input_digests=inputs,
            resource_envelope=self.envelope.to_dict(), started_utc=prs[0].started_utc, ended_utc=prs[-1].ended_utc,
            wall_s=round(sum(p.wall_s for p in prs), 3), cpu_s=round(sum(p.cpu_user_s + p.cpu_sys_s for p in prs), 3),
            host=host_identity(), stdout_sha256=sha256_obj([p.stdout_sha256 for p in prs]),
            stderr_sha256=sha256_obj([p.stderr_sha256 for p in prs]),
            result_digest=router["canon_digest"] if router else None, argv_digest=sha256_obj(argvs),
            failure_class=fc.value, extra={"steps": [{"rc": p.rc, "wall_s": p.wall_s, "timed_out": p.timed_out,
                                                       "signal": p.signal, "wrappers": p.wrappers} for p in prs],
                                           "graph_sha256": router["graph_sha256"] if router else None,
                                           "network_isolated": all(p.network_isolated for p in prs)})
        return OtpOutcome(fc.value, router, canon_res.to_dict() if canon_res else None, prov.to_dict(), cfg, sem,
                          [list(a) for a in argvs])

    def _runtime(self) -> dict:
        st = {s.name: s for s in self.deps.statuses}
        if self.mode == BinaryMode.REAL_PINNED_BINARY and "jdk" in st:
            return {"jdk": st["jdk"].detail, "jdk_identity_sha256": st["jdk"].actual_sha256}
        return {"stub_interpreter": sys.version.split()[0]}
