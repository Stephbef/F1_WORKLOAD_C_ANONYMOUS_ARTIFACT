"""Strict UTC timestamp handling. All persisted instants use the canonical form YYYY-MM-DDTHH:MM:SSZ so that
lexicographic order equals chronological order (the frozen logical-version tool sorts the string form)."""
from __future__ import annotations

import re
from datetime import datetime, timezone

_CANON = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")


def to_canonical_utc(value: str) -> str:
    """Normalise an ISO-8601 instant (with offset or Z; fractional seconds truncated) to canonical UTC."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError("empty timestamp")
    s = value.strip()
    if len(s) == 10:
        dt = datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    else:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            raise ValueError(f"timestamp without offset is ambiguous: {value!r}")
    return dt.astimezone(timezone.utc).replace(microsecond=0).strftime("%Y-%m-%dT%H:%M:%SZ")


def is_canonical(value: str) -> bool:
    return isinstance(value, str) and bool(_CANON.match(value))


def epoch(value: str) -> int:
    if not is_canonical(value):
        value = to_canonical_utc(value)
    return int(datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc).timestamp())


def from_epoch(ts: int) -> str:
    return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class Clock:
    """Injectable clock. Real mode uses wall time; FIXTURE mode uses a deterministic ticking clock so that
    fixture artifacts are byte-reproducible (retrieval time is provenance only, never identity)."""

    def now(self) -> str:
        return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class FixedTickClock(Clock):
    def __init__(self, start: str = "2026-10-08T00:00:00Z", step_s: int = 1) -> None:
        self._t = epoch(start)
        self._step = step_s

    def now(self) -> str:
        v = from_epoch(self._t)
        self._t += self._step
        return v
