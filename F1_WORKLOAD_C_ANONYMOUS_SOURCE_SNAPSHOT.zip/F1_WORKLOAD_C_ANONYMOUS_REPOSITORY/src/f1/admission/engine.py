"""Witnessed Sound Admission (WSA).

admit(R, Gamma, t) returns c* in W_t(R, Gamma) = {c in Cuts(H_t) ∩ Gamma : forall r in R, kappa_eff_r(c)} or None,
and durably appends a hash-chained record. The engine only sees artifacts' contracts, birth metadata,
the history and Gamma; it never imports or invokes producers (Ax-O, clause iv).
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path

from ..catalog.artifact import Artifact
from ..common.util import F1Error, append_jsonl, canonical_json, read_jsonl, sha256_bytes, sha256_obj
from ..contracts.lang import Contract, Evaluator
from ..core.gamma import Gamma
from ..core.history import Cut, History, cut_key

CLASSES = ("K0", "K1", "K2", "K3")


def effective_contracts(art: Artifact, cls: str) -> tuple[list[Contract], bool]:
    """kappa_eff = K_cls OR K0 (D9). Returns (disjuncts, fell_back) where fell_back means K_cls absent."""
    k0 = art.contract("K0")
    if k0 is None:
        raise F1Error(f"artifact {art.artifact_id} has no K0 fallback contract")
    if cls == "K0":
        return [k0], False
    kc = art.contract(cls)
    if kc is None:
        return [k0], True
    return [kc, k0], False


class AdmissionEngine:
    def __init__(self, history: History, evaluator: Evaluator, journal_path: str | Path | None = None):
        self.h = history
        self.ev = evaluator
        self.journal_path = Path(journal_path) if journal_path else None
        self._last_hash = None
        if self.journal_path and self.journal_path.exists():
            for rec in read_jsonl(self.journal_path):
                self._last_hash = rec["h"]

    # ---- unary -----------------------------------------------------------------------------
    def kappa_eff(self, art: Artifact, cls: str, cut: Cut) -> tuple[bool, float]:
        disj, _ = effective_contracts(art, cls)
        total = 0.0
        for c in disj:
            v, dt, _ = self.ev.evaluate(c, lambda i: self.h.content(cut, i))
            total += dt
            if v:
                return True, total
        return False, total

    def kappa_raw(self, art: Artifact, cls: str, cut: Cut) -> tuple[bool | None, float]:
        c = art.contract(cls)
        if c is None:
            return None, 0.0
        v, dt, _ = self.ev.evaluate(c, lambda i: self.h.content(cut, i))
        return v, dt

    def check(self, art: Artifact, cls: str, cut: Cut) -> bool:
        if not self.h.is_consistent(cut):
            raise F1Error("check() requires a consistent cut")
        return self.kappa_eff(art, cls, cut)[0]

    # ---- joint -----------------------------------------------------------------------------
    def candidate_cuts(self, gamma: Gamma, limit: int | None = None) -> list[Cut]:
        return list(self.h.enumerate_cuts(gamma.allowed(self.h), limit=limit))

    def witnesses(self, R: list[Artifact], cls: str, gamma: Gamma):
        for cut in self.h.enumerate_cuts(gamma.allowed(self.h)):
            if all(self.kappa_eff(r, cls, cut)[0] for r in R):
                yield cut

    def admit(self, R: list[Artifact], cls: str, gamma: Gamma, event_id: str, t: float) -> dict:
        t0 = time.perf_counter()
        witness, n = None, 0
        for cut in self.h.enumerate_cuts(gamma.allowed(self.h)):
            n += 1
            if all(self.kappa_eff(r, cls, cut)[0] for r in R):
                witness = cut
                break
        rec = {
            "event_id": event_id, "cls": cls, "t": t, "R": sorted(r.artifact_id for r in R),
            "gamma": gamma.to_json(), "witness": witness, "admitted": witness is not None,
            "n_cuts_examined": n, "seconds": time.perf_counter() - t0,
            "history_fp": self.h.fingerprint(),
        }
        self._journal(rec)
        return rec

    def _journal(self, rec: dict) -> None:
        if not self.journal_path:
            return
        rec["prev"] = self._last_hash
        rec["h"] = sha256_bytes(canonical_json({k: v for k, v in rec.items() if k != "h"}).encode())
        append_jsonl(self.journal_path, rec)
        self._last_hash = rec["h"]


def replay_journal(journal_path: str | Path, history: History, artifacts: dict[str, Artifact], evaluator: Evaluator) -> dict:
    """Verify the hash chain and re-verify every recorded witness (T1b persistence)."""
    prev, n, verified = None, 0, 0
    eng = AdmissionEngine(history, evaluator)
    for rec in read_jsonl(journal_path):
        n += 1
        body = {k: v for k, v in rec.items() if k != "h"}
        if rec.get("prev") != prev:
            raise F1Error(f"journal chain broken at record {n}")
        if sha256_bytes(canonical_json(body).encode()) != rec["h"]:
            raise F1Error(f"journal record {n} tampered")
        prev = rec["h"]
        if rec["admitted"]:
            cut = rec["witness"]
            g = Gamma.from_json(rec["gamma"])
            if not history.is_consistent(cut) or not g.contains(history, cut):
                raise F1Error(f"journal record {n}: witness not in Cuts ∩ Gamma")
            for aid in rec["R"]:
                if not eng.kappa_eff(artifacts[aid], rec["cls"], cut)[0]:
                    raise F1Error(f"journal record {n}: kappa_eff fails at recorded witness for {aid}")
            verified += 1
    return {"records": n, "witnesses_verified": verified}
