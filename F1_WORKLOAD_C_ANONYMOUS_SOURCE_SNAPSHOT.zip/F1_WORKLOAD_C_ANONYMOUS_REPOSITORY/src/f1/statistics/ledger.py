"""Canonical ledger: every global population/job count derived from run records, with exact (no +-1) assertions.
Downstream reports read counts from LEDGER.json only."""
from __future__ import annotations

from collections import Counter
from pathlib import Path

from ..catalog.artifact import Catalog
from ..common.util import F1Error, atomic_write_json, read_json, read_jsonl


def _lines(p: Path) -> int:
    if not p.exists():
        return 0
    with open(p, "rb") as f:
        return sum(1 for ln in f if ln.strip())


def _latest(p: Path) -> dict:
    last = {}
    for r in read_jsonl(p):
        last[r["key"]] = r
    return last


def build(run_dir: Path, workloads: list[str], classes=("K0", "K1", "K2", "K3")) -> dict:
    raw, orc = run_dir / "raw", run_dir / "oracle"
    errors = []

    def check(name, lhs, rhs):
        if lhs != rhs:
            errors.append(f"{name}: {lhs} != {rhs}")

    births = list(read_jsonl(raw / "births_requested.jsonl"))
    prod = _latest(raw / "production_runs.jsonl")
    keys = {b["key"] for b in births}
    L = {"births": {"requested": len(births), "unique_inputs": len(keys), "deduplicated": len(births) - len(keys),
                    "by_workload_producer": dict(Counter(f"{b['wl']}/{b['pid']}" for b in births)),
                    "production_runs": len(prod),
                    "production_runs_ok": sum(1 for r in prod.values() if r.get("status") == "ok")}}
    check("births requested = unique + deduplicated", L["births"]["requested"], L["births"]["unique_inputs"] + L["births"]["deduplicated"])
    check("production runs = unique birth inputs", L["births"]["production_runs"], L["births"]["unique_inputs"])
    fails = _lines(raw / "birth_failures.jsonl")
    arts = Catalog(raw / "catalog.jsonl").load()
    L["artifacts"] = {"total": len(arts), "by_workload_type": dict(Counter(f"{a.workload}/{a.artifact_type}" for a in arts)),
                      "failed_births": fails}
    types_per_birth = Counter()
    for a in arts:
        types_per_birth[(a.workload, a.cluster, a.producer_id, a.birth_time)] += 1
    check("artifacts = successful births x artifact types", len(arts), sum(types_per_birth.values()))
    check("successful births + failed births = requested", len(types_per_birth) + fails, len(births))
    pairs = list(read_jsonl(raw / "unary_pairs.jsonl"))
    events = list(read_jsonl(raw / "joint_events.jsonl"))
    L["populations"] = {"unary_pairs": len(pairs), "unary_by_workload_split": dict(Counter(f"{p['wl']}/{p['split']}" for p in pairs)),
                        "joint_events": len(events), "joint_by_scenario": dict(Counter(e["scenario"] for e in events))}
    check("joint events = sum over scenarios", len(events), sum(L["populations"]["joint_by_scenario"].values()))
    ua, ja, rp = _lines(raw / "unary_admission.jsonl"), _lines(raw / "joint_admission.jsonl"), list(read_jsonl(raw / "repair.jsonl"))
    L["admission"] = {"unary_rows": ua, "unary_checks": ua * len(classes), "joint_rows": ja,
                      "witness_searches": ja * len(classes), "repair_rows": len(rp),
                      "solver_invocations": sum(1 for r in rp if r.get("solver_invoked")),
                      "fast_path_events": sum(1 for r in rp if r.get("solver_invoked") is False),
                      "bruteforce_crosschecks": sum(1 for r in rp if "bruteforce_agrees" in r),
                      "ilp_crosschecks": sum(1 for r in rp if "ilp_agrees" in r)}
    check("unary admission rows = unary pairs", ua, len(pairs))
    check("joint admission rows = joint events", ja, len(events))
    check("repair rows = joint events x classes", len(rp), len(events) * len(classes))
    check("solver invocations + fast path = repair rows", L["admission"]["solver_invocations"] + L["admission"]["fast_path_events"], len(rp))
    if (orc / "oracle_requests.json").exists():
        req = read_json(orc / "oracle_requests.json")
        runs = _latest(orc / "oracle_runs.jsonl")
        by_rep = Counter("rep0" if str(r.get("rep")) == "0" else ("sample" if r.get("rep") == "s" else "replica") for r in runs.values())
        by_wl = Counter(r.get("wl") for r in runs.values())
        L["oracle"] = {"requested_instances": req["requested_instances"], "requested_by_source": req["requested_by_source"],
                       "unique_inputs": req["unique_inputs"], "dedup_hits": req["dedup_hits"],
                       "runs_total": len(runs), "runs_rep0": by_rep["rep0"], "runs_replica": by_rep["replica"],
                       "runs_sample": by_rep["sample"], "runs_by_workload": dict(by_wl),
                       "runs_by_producer": dict(Counter(r.get("pid") for r in runs.values())),
                       "runs_ok": sum(1 for r in runs.values() if r.get("status") == "ok")}
        o = L["oracle"]
        check("oracle requested = sum over sources", o["requested_instances"], sum(o["requested_by_source"].values()))
        check("oracle requested = unique + hits", o["requested_instances"], o["unique_inputs"] + o["dedup_hits"])
        check("oracle rep0 runs = unique inputs", o["runs_rep0"], o["unique_inputs"])
        check("oracle total = rep0 + replicas + samples", o["runs_total"], o["runs_rep0"] + o["runs_replica"] + o["runs_sample"])
        check("oracle total = sum over workloads", o["runs_total"], sum(o["runs_by_workload"].values()))
        check("oracle total = planned jobs", o["runs_total"], req["jobs_total"])
        check("oracle by workload = planned", dict(o["runs_by_workload"]), req["jobs_by_workload"])
    L["checkpoints"] = {"production_runs_lines": _lines(raw / "production_runs.jsonl"),
                        "admission_jobs_lines": _lines(raw / "admission_jobs.jsonl"),
                        "oracle_runs_lines": _lines(orc / "oracle_runs.jsonl"),
                        "stage_markers": len(list((run_dir / "stages").glob("*.done")))}
    L["checkpoints"]["total_records"] = sum(L["checkpoints"].values())
    if (run_dir / "statistics" / "metrics.json").exists():
        L["exclusions"] = read_json(run_dir / "statistics" / "metrics.json").get("exclusions", {})
    L["assertions_passed"] = not errors
    if errors:
        raise F1Error("canonical ledger does not reconcile: " + "; ".join(errors))
    return L


def write(run_dir: Path, workloads: list[str]) -> dict:
    L = build(run_dir, workloads)
    atomic_write_json(run_dir / "statistics" / "LEDGER.json", L)
    md = ["# CANONICAL LEDGER", "", "All counts are derived from run records; every identity below is asserted exactly.", ""]
    for sec, v in L.items():
        md.append(f"- **{sec}**: {v}")
    (run_dir / "statistics" / "LEDGER.md").write_text("\n".join(md) + "\n")
    return L
