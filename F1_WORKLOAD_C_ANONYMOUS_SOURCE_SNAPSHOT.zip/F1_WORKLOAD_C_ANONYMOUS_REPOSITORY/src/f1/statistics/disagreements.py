"""Contract/oracle disagreement classification (U1–U4).

A disagreement is an unsafe admission: kappa_eff accepts (r, c) while OracleUse(r, c) is false. (Rejections of usable
contexts are recall losses, not soundness failures.) Classification precedence, applied where determinable:

  U4  producer nondeterminism: replicas of the same frozen input disagree (birth or evaluated input)
  U3  hidden / unversioned context: reads outside the captured read-set or network attempts were traced, or K0
      accepted byte-identical read contents yet the output differs (untracked context not caught by tracing)
  U1  evaluator / implementation mismatch: the transparent reference K3 (our executable model of the producer's
      semantics) ALSO accepts, so the disagreement lies in our re-implementation, parser or canonicalisation
  U2  fundamental missing decision dependence: K3 correctly rejects but the evaluated contract accepts, i.e. the
      contract omitted a dependency needed to preserve the producer output (the critical soundness failure)
  UNDETERMINED  K3 unavailable for the artifact
Nothing is repaired: every disagreement row carries the evidence needed for independent inspection.
"""
from __future__ import annotations

import math

CLASSES = ("K0", "K1", "K2", "K3")


def classify(cls: str, k3_accepts, nondeterministic: bool, hidden: bool) -> tuple[str, str]:
    if nondeterministic:
        return "U4", "replicas of the same frozen producer input disagree"
    if hidden:
        return "U3", "reads outside the captured read-set or network attempts were traced"
    if cls == "K0":
        return "U3", "K0 accepted byte-identical read contents yet the output differs: untracked context (or undetected nondeterminism)"
    if cls == "K3":
        return "U1", "the transparent reference itself disagrees with the producer: re-implementation mismatch"
    if k3_accepts is True:
        return "U1", "the transparent reference also accepts: evaluator/parser/canonicalisation mismatch"
    if k3_accepts is False:
        return "U2", "the transparent reference rejects but the contract accepts: missing decision dependence"
    return "UNDETERMINED", "no transparent reference available for this artifact"


def binom_upper(k: int, n: int, alpha: float = 0.05) -> float | None:
    """One-sided exact (Clopper–Pearson) upper confidence bound for a binomial proportion."""
    if n <= 0:
        return None
    if k >= n:
        return 1.0

    def cdf(p):  # P[X <= k]
        tot, term = 0.0, (1 - p) ** n
        for i in range(0, k + 1):
            if i > 0:
                term *= (n - i + 1) / i * p / (1 - p)
            tot += term
        return tot
    lo, hi = k / n, 1.0
    for _ in range(100):
        mid = (lo + hi) / 2
        if cdf(mid) > alpha:
            lo = mid
        else:
            hi = mid
    return hi


def unary_disagreements(pairs: dict, admission: dict, oracle: dict, arts: dict, h_content) -> list[dict]:
    """pairs/admission/oracle keyed by pair_id; h_content(art, cut) -> {item: content_ref} for read-set items."""
    out = []
    for pid, o in oracle.items():
        if o.get("use") is not False:
            continue
        a = arts[pairs[pid]["artifact_id"]]
        row = admission[pid]
        nondet = bool(o.get("oracle_nondeterministic") or o.get("birth_nondeterministic"))
        hidden = bool(a.run.get("hidden_reads") or a.run.get("net_attempts") or o.get("oracle_hidden_reads")
                      or o.get("oracle_net_attempts"))
        for cls in CLASSES:
            if row.get(f"{cls}_eff") is not True:
                continue
            label, rule = classify(cls, row.get("K3_eff") if a.contracts.get("K3") else None, nondet, hidden)
            cut = pairs[pid]["cut"]
            now = h_content(a, cut)
            out.append({"kind": "unary", "pair_id": pid, "artifact_id": a.artifact_id, "workload": a.workload,
                        "cluster": a.cluster, "artifact_type": a.artifact_type, "cls": cls, "label": label, "rule": rule,
                        "t": pairs[pid]["t"], "age_s": pairs[pid]["age_s"], "birth_cut": a.birth_cut, "cut": cut,
                        "changed_items": sorted(i for i in a.read_set if now.get(i) != a.birth_refs.get(i)),
                        "decisions": {c: row.get(f"{c}_eff") for c in CLASSES},
                        "artifact_value": a.value, "oracle_value": o.get("oracle_value"),
                        "hidden_reads_birth": a.run.get("hidden_reads"), "hidden_reads_oracle": o.get("oracle_hidden_reads"),
                        "nondeterministic": nondet, "excluded_from_primary_metrics": nondet})
    return out


def joint_disagreements(events: dict, joint_adm: dict, joint_oracle: dict, arts: dict) -> list[dict]:
    out = []
    for eid, j in joint_adm.items():
        o = joint_oracle.get(eid)
        if not o or not o.get("complete"):
            continue
        e = events[eid]
        for cls in CLASSES:
            idx = j.get(f"{cls}_witness_idx")
            if idx is None:
                continue
            for i, aid in enumerate(e["R"]):
                if o["oracle_use_matrix"][i][idx] == "1":
                    continue
                a = arts[aid]
                k3 = (j.get(f"{cls}_K3_at_witness") or [None] * len(e["R"]))[i]
                label, rule = classify(cls, k3 if a.contracts.get("K3") else None, bool(o.get("nondeterministic")),
                                       bool(a.run.get("hidden_reads") or a.run.get("net_attempts")))
                out.append({"kind": "joint", "event_id": eid, "scenario": e["scenario"], "cell": e["cell"],
                            "artifact_id": aid, "workload": a.workload, "cluster": a.cluster,
                            "artifact_type": a.artifact_type, "cls": cls, "label": label, "rule": rule,
                            "witness": j.get(f"{cls}_witness"), "artifact_value": a.value})
    return out


def summarize_soundness(unary_rows: list[dict], disagreements: list[dict], alpha: float) -> dict:
    """Per (workload, artifact type, class): admissions evaluated, disagreement counts by label, exact upper bound
    on the U2 rate (and the rule-of-three approximation when zero U2 are observed)."""
    out: dict = {}
    for r in unary_rows:
        for cls in CLASSES:
            if r.get(f"{cls}_eff") is True:
                d = out.setdefault(f"{r['wl']}/{r['artifact_type']}/{cls}", {"admissions": 0, "U1": 0, "U2": 0, "U3": 0,
                                                                              "U4": 0, "UNDETERMINED": 0})
                d["admissions"] += 1
    for x in disagreements:
        if x["kind"] != "unary" or x["excluded_from_primary_metrics"]:
            continue
        key = f"{x['workload']}/{x['artifact_type']}/{x['cls']}"
        d = out.setdefault(key, {"admissions": 0, "U1": 0, "U2": 0, "U3": 0, "U4": 0, "UNDETERMINED": 0})
        d[x["label"]] += 1
    for d in out.values():
        n = d["admissions"]
        d["u2_upper_bound"] = binom_upper(d["U2"], n, alpha)
        d["rule_of_three_upper_bound"] = (3.0 / n) if (n > 0 and d["U2"] == 0) else None
        d["statement"] = (f"{d['U2']} U2 failures observed in {n} evaluated admissions; one-sided {int((1 - alpha) * 100)}% "
                          f"upper bound on the U2 rate = {d['u2_upper_bound']}. This is an empirical bound, not a proof of soundness."
                          if n > 0 else "no admissions evaluated")
    return out
