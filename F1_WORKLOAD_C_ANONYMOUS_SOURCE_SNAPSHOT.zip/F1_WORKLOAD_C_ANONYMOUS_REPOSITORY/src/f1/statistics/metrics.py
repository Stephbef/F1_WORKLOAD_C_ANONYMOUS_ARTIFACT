"""Metric engine (M1–M5) and two-stage cluster bootstrap.

Unary population: test-split pairs (r, c-hat_t), excluding pairs whose oracle run failed or whose producer input
was non-deterministic (exclusions are counted and reported). Primary aggregation = macro (mean over artifacts of
per-artifact rates); micro (pooled) is reported alongside. Validation pairs are used ONLY to choose TTL tau*.
"""
from __future__ import annotations

import math
from collections import defaultdict

import numpy as np

CLASSES = ("K0", "K1", "K2", "K3")


# ---------------------------------------------------------------------------------------------
# generic per-unit ratio metrics
# ---------------------------------------------------------------------------------------------
def unit_rates(rows: list[dict], unit_key: str, num, den) -> dict:
    """Per unit: (cluster, numerator count, denominator count)."""
    acc: dict = {}
    for r in rows:
        if not den(r):
            continue
        u = r[unit_key]
        c = acc.setdefault(u, [r["cluster"], 0.0, 0.0])
        c[2] += 1
        if num(r):
            c[1] += 1
    return acc


def macro(acc: dict) -> float | None:
    vals = [n / d for _, n, d in acc.values() if d > 0]
    return float(np.mean(vals)) if vals else None


def micro(acc: dict) -> float | None:
    n = sum(v[1] for v in acc.values())
    d = sum(v[2] for v in acc.values())
    return (n / d) if d > 0 else None


def cluster_bootstrap(acc: dict, B: int, seed: int, ci: float = 0.95) -> dict:
    """Two-stage bootstrap: resample clusters, then units within each sampled cluster; macro statistic."""
    if not acc:
        return {"lo": None, "hi": None, "B": B}
    by_c: dict = defaultdict(list)
    for _, (c, n, d) in acc.items():
        if d > 0:
            by_c[c].append(n / d)
    clusters = sorted(by_c)
    if not clusters:
        return {"lo": None, "hi": None, "B": B}
    arrs = [np.array(by_c[c]) for c in clusters]
    rng = np.random.default_rng(seed)
    stats = np.empty(B)
    for b in range(B):
        pick = rng.integers(0, len(clusters), len(clusters))
        vals = []
        for ci_ in pick:
            a = arrs[ci_]
            vals.append(a[rng.integers(0, len(a), len(a))])
        stats[b] = np.concatenate(vals).mean()
    alpha = (1 - ci) / 2
    return {"lo": float(np.quantile(stats, alpha)), "hi": float(np.quantile(stats, 1 - alpha)), "B": B,
            "n_clusters": len(clusters), "n_units": int(sum(len(a) for a in arrs))}


def cluster_bootstrap_values(units: dict, B: int, seed: int, ci: float = 0.95) -> dict:
    """Two-stage cluster bootstrap of the mean of arbitrary per-unit values. units: unit -> (cluster, value)."""
    by_c: dict = defaultdict(list)
    for c, v in units.values():
        if v is not None and math.isfinite(v):
            by_c[c].append(v)
    clusters = sorted(by_c)
    if not clusters:
        return {"mean": None, "lo": None, "hi": None, "B": B, "n_units": 0, "n_clusters": 0}
    arrs = [np.array(by_c[c]) for c in clusters]
    rng = np.random.default_rng(seed)
    stats = np.empty(B)
    for b in range(B):
        pick = rng.integers(0, len(clusters), len(clusters))
        stats[b] = np.concatenate([arrs[i][rng.integers(0, len(arrs[i]), len(arrs[i]))] for i in pick]).mean()
    alpha = (1 - ci) / 2
    allv = np.concatenate(arrs)
    return {"mean": float(allv.mean()), "median": float(np.median(allv)), "lo": float(np.quantile(stats, alpha)),
            "hi": float(np.quantile(stats, 1 - alpha)), "B": B, "n_units": int(len(allv)), "n_clusters": len(clusters),
            "quantiles": {q: float(np.quantile(allv, q)) for q in (0.1, 0.25, 0.5, 0.75, 0.9)}}


def incremental_vs_k0(test: list[dict], cls: str, B: int, seed: int) -> dict:
    """Incremental reuse of class K over K0 (kappa_eff^K = K OR K0, so K0-accepted contexts are never credited to K).
    Avoided producer cost counts only pairs where K0 rejects, K accepts and OracleUse is true."""
    e, e0 = f"{cls}_eff", "K0_eff"
    per_art_nb: dict = {}
    per_art_dr: dict = {}
    tot = {"additional_avoided_s": 0.0, "incremental_contract_s": 0.0, "incremental_admission_s": 0.0,
           "recovered_pairs": 0, "incremental_unsafe_pairs": 0, "pairs": 0}
    by_art: dict = defaultdict(list)
    for r in test:
        by_art[r["artifact_id"]].append(r)
    for aid, rs in by_art.items():
        cl = rs[0]["cluster"]
        nb = []
        for r in rs:
            if not math.isfinite(r["cost_s"]):
                continue
            rec = (r[e0] is False) and (r[e] is True) and (r["use"] is True)
            avoided = r["cost_s"] if rec else 0.0
            d_eval = r[f"{cls}_eval_s"] - r["K0_eval_s"]
            d_adm = (r[f"{cls}_check_s"] - r[f"{cls}_eval_s"]) - (r["K0_check_s"] - r["K0_eval_s"])
            nb.append(avoided - d_eval - d_adm)
            tot["additional_avoided_s"] += avoided
            tot["incremental_contract_s"] += d_eval
            tot["incremental_admission_s"] += d_adm
            tot["recovered_pairs"] += int(rec)
            tot["incremental_unsafe_pairs"] += int((r[e0] is False) and (r[e] is True) and (r["use"] is False))
            tot["pairs"] += 1
        if nb:
            per_art_nb[aid] = (cl, float(np.mean(nb)))
        useful = [r for r in rs if r["use"] is True]
        if useful:
            per_art_dr[aid] = (cl, float(np.mean([r[e] is True for r in useful]) - np.mean([r[e0] is True for r in useful])))
    tot["delta_nb_total_s"] = tot["additional_avoided_s"] - tot["incremental_contract_s"] - tot["incremental_admission_s"]
    return {"delta_recall": cluster_bootstrap_values(per_art_dr, B, seed),
            "delta_nb_per_pair_s": cluster_bootstrap_values(per_art_nb, B, seed), "totals": tot}


def summarize(acc: dict, B: int, seed: int) -> dict:
    d = {"macro": macro(acc), "micro": micro(acc), "n_units": sum(1 for v in acc.values() if v[2] > 0),
         "n_obs": int(sum(v[2] for v in acc.values()))}
    d["ci"] = cluster_bootstrap(acc, B, seed)
    return d


# ---------------------------------------------------------------------------------------------
# unary metrics
# ---------------------------------------------------------------------------------------------
def unary_metrics(rows: list[dict], ttl_grid_s: list[float], B: int, seed: int) -> dict:
    """rows: joined unary records (keys: artifact_id, cluster, split, use, age_s, K*_eff, K*_raw, B1, cost_s, K*_eval_s)."""
    test = [r for r in rows if r["split"] == "test"]
    val = [r for r in rows if r["split"] == "validation"]
    out: dict = {"n_pairs_test": len(test), "n_pairs_validation": len(val)}
    u = lambda r: r["use"] is True
    nu = lambda r: r["use"] is False
    out["M1_hash_overinvalidation"] = summarize(unit_rates(test, "artifact_id", lambda r: (r["K0_raw"] is False) and u(r), lambda r: True), B, seed)
    out["M1_cond_useful_given_hash_reject"] = summarize(unit_rates(test, "artifact_id", u, lambda r: r["K0_raw"] is False), B, seed)
    out["M1_version_pinning_overinvalidation"] = summarize(unit_rates(test, "artifact_id", lambda r: (r["B1"] is False) and u(r), lambda r: True), B, seed)
    out["oracle_use_rate"] = summarize(unit_rates(test, "artifact_id", u, lambda r: True), B, seed)
    # TTL curve and tau* (validation only)
    def ttl_point(rs, tau):
        acc_r = unit_rates(rs, "artifact_id", lambda r: r["age_s"] <= tau, u)
        acc_f = unit_rates(rs, "artifact_id", lambda r: r["age_s"] <= tau, nu)
        acc_m2 = unit_rates(rs, "artifact_id", lambda r: r["age_s"] <= tau and nu(r), lambda r: True)
        return acc_r, acc_f, acc_m2
    curve, best = [], None
    for tau in ttl_grid_s:
        vr, vf, _ = ttl_point(val, tau)
        j = (macro(vr) or 0.0) - (macro(vf) or 0.0)
        if best is None or j > best[1] + 1e-12:
            best = (tau, j)
        tr, tf, tm2 = ttl_point(test, tau)
        curve.append({"tau_s": tau, "recall": macro(tr), "false_admission_rate": macro(tf), "M2": macro(tm2),
                      "recall_micro": micro(tr), "M2_micro": micro(tm2)})
    out["ttl_curve"] = curve
    if best is not None and val:
        tau = best[0]
        _, _, tm2 = ttl_point(test, tau)
        out["tau_star_s"] = tau
        out["M2_ttl_unsafe_admission_at_tau_star"] = summarize(tm2, B, seed)
    else:
        out["tau_star_s"] = None
        out["M2_ttl_unsafe_admission_at_tau_star"] = None
    # M3 per class
    m3 = {}
    for cls in CLASSES:
        e = f"{cls}_eff"
        m3[cls] = {
            "recall": summarize(unit_rates(test, "artifact_id", lambda r, e=e: r[e] is True, u), B, seed),
            "unsafe_admission": summarize(unit_rates(test, "artifact_id", lambda r, e=e: r[e] is True and nu(r), lambda r: True), B, seed),
            "conditional_false_admission": summarize(unit_rates(test, "artifact_id", nu, lambda r, e=e: r[e] is True), B, seed),
            "raw_recall": summarize(unit_rates(test, "artifact_id", lambda r, c=cls: r[f"{c}_raw"] is True, u), B, seed),
            "fallback_rate": float(np.mean([bool(r.get(f"{cls}_fallback")) for r in test])) if test else None,
            "unsafe_count": int(sum(1 for r in test if r[e] is True and nu(r))),
            "eval_seconds_mean": float(np.mean([r[f"{cls}_eval_s"] for r in test])) if test else None,
            "eval_seconds_cold_sample_mean": (float(np.mean([r[f"{cls}_eval_cold_s"] for r in test if f"{cls}_eval_cold_s" in r]))
                                              if any(f"{cls}_eval_cold_s" in r for r in test) else None),
            "eval_cold_sample_n": int(sum(1 for r in test if f"{cls}_eval_cold_s" in r)),
            "parse_amortised_s": float(np.mean([r.get(f"{cls}_parse_amortised_s", 0.0) for r in test])) if test else None,
        }
        # G1: avoided producer cost minus evaluation overhead, per pair (true reuse only counts as benefit)
        ben = [((r["cost_s"] if (r[e] is True and u(r)) else 0.0) - r[f"{cls}_eval_s"]) for r in test
               if math.isfinite(r["cost_s"])]
        m3[cls]["net_benefit_per_pair_s"] = float(np.mean(ben)) if ben else None
        acc_nb = {}
        for r in test:
            if not math.isfinite(r["cost_s"]):
                continue
            a = acc_nb.setdefault(r["artifact_id"], [r["cluster"], 0.0, 0.0])
            a[1] += (r["cost_s"] if (r[e] is True and u(r)) else 0.0) - r[f"{cls}_eval_s"]
            a[2] += 1
        m3[cls]["net_benefit_ci"] = cluster_bootstrap(acc_nb, B, seed)
    out["M3"] = m3
    out["incremental_vs_K0"] = {cls: incremental_vs_k0(test, cls, B, seed) for cls in ("K1", "K2", "K3")}
    # sensitivity: fully cold evaluation cost on the seeded sample (no parse cache at all)
    cold = [dict(r, **{f"{c}_eval_s": r[f"{c}_eval_cold_s"] for c in CLASSES},
                 **{f"{c}_check_s": r[f"{c}_eval_cold_s"] + (r[f"{c}_check_s"] - r[f"{c}_eval_s"]) for c in CLASSES})
            for r in test if all(f"{c}_eval_cold_s" in r for c in CLASSES)]
    out["incremental_vs_K0_cold_sample_sensitivity"] = ({cls: incremental_vs_k0(cold, cls, B, seed)["totals"] for cls in ("K1", "K2", "K3")}
                                                        if cold else None)
    return out


# ---------------------------------------------------------------------------------------------
# joint metrics (M4) and repair metrics (M5)
# ---------------------------------------------------------------------------------------------
def joint_metrics(rows: list[dict], B: int, seed: int) -> dict:
    """rows: joined joint records (event_id, cluster, scenario, cell, oracle_unary, oracle_W_nonempty, K*_unary, K*_admitted)."""
    out = {}
    groups: dict = defaultdict(list)
    for r in rows:
        groups[(r["scenario"], r["cell"])].append(r)
        groups[(r["scenario"], "ALL")].append(r)
    for (sc, cell), rs in sorted(groups.items()):
        key = f"{sc}/{cell}"
        g = {"n_events": len(rs)}
        acc = unit_rates(rs, "event_id", lambda r: all(r["oracle_unary"]) and not r["oracle_W_nonempty"], lambda r: True)
        g["M4_oracle"] = summarize(acc, B, seed)
        anom = [r for r in rs if all(r["oracle_unary"]) and not r["oracle_W_nonempty"]]
        g["anomaly_count"] = len(anom)
        g["individually_acceptable_events"] = sum(1 for r in rs if all(r["oracle_unary"]))
        g["clusters_with_oracle_joint_failure"] = len({r["cluster"] for r in anom})
        g["anomalies_per_cluster"] = {c: sum(1 for r in anom if r["cluster"] == c) for c in sorted({r["cluster"] for r in rs})}
        g["clusters_total"] = len({r["cluster"] for r in rs})
        for cls in CLASSES:
            acc_k = unit_rates(rs, "event_id", lambda r, c=cls: all(r[f"{c}_unary"]) and not r[f"{c}_admitted"], lambda r: True)
            acc_n = unit_rates(rs, "event_id", lambda r, c=cls: all(r[f"{c}_unary"]) and not r["oracle_W_nonempty"], lambda r: True)
            acc_a = unit_rates(rs, "event_id", lambda r, c=cls: r[f"{c}_admitted"], lambda r: True)
            acc_u = unit_rates(rs, "event_id", lambda r, c=cls: r[f"{c}_admitted"] and not r["oracle_W_nonempty"], lambda r: True)
            g[cls] = {"naive_false_compositions": int(sum(1 for r in rs if all(r[f"{cls}_unary"]) and not r["oracle_W_nonempty"])),
                      "M4_contract": summarize(acc_k, B, seed), "naive_composition_error": summarize(acc_n, B, seed),
                      "admission_rate": summarize(acc_a, B, seed), "unsafe_joint_admission": summarize(acc_u, B, seed)}
        out[key] = g
    return out


def repair_metrics(rows: list[dict], B: int, seed: int) -> dict:
    out = {}
    groups: dict = defaultdict(list)
    for r in rows:
        groups[(r["scenario"], r["cell"], r["cls"])].append(r)
        groups[(r["scenario"], "ALL", r["cls"])].append(r)
    for (sc, cell, cls), rs in sorted(groups.items()):
        fin = [r for r in rs if math.isfinite(r["recompute_all"]) and r["recompute_all"] > 0 and math.isfinite(r["opt_cost"])]
        acc = {}
        acc_cur = {}
        for r in fin:
            acc[r["event_id"]] = [r["cluster"], 1.0 - r["opt_cost"] / r["recompute_all"], 1.0]
            if math.isfinite(r["current_cut_cost"]) and r["current_cut_cost"] > 0:
                acc_cur[r["event_id"]] = [r["cluster"], 1.0 - r["opt_cost"] / r["current_cut_cost"], 1.0]
        fair_cur, fair_all = {}, {}
        e2e = {"f1": 0.0, "current_cut": 0.0, "recompute_all": 0.0, "shared": 0.0, "f1_specific": 0.0}
        for r in fin:
            sh, f1s = r.get("shared_decision_s", 0.0), r.get("f1_specific_s", 0.0)
            e2e["shared"] += sh
            e2e["f1_specific"] += f1s
            e2e["f1"] += sh + f1s + r["opt_cost"]
            e2e["recompute_all"] += r["recompute_all"]
            if math.isfinite(r["current_cut_cost"]):
                e2e["current_cut"] += sh + r["current_cut_cost"]
                if r["current_cut_cost"] > 0:   # symmetric: shared decision cost cancels
                    fair_cur[r["event_id"]] = (r["cluster"], (r["current_cut_cost"] - r["opt_cost"] - f1s) / r["current_cut_cost"])
            fair_all[r["event_id"]] = (r["cluster"], (r["recompute_all"] - r["opt_cost"] - sh - f1s) / r["recompute_all"])
        net_all, net_cur, nets = {}, {}, {"vs_recompute_all": [], "vs_current_cut": []}
        for r in fin:
            ov = r.get("contract_eval_s", 0.0) + r.get("admission_excl_s", 0.0) + r.get("solver_excl_s", 0.0)
            na = r["recompute_all"] - r["opt_cost"] - ov
            nets["vs_recompute_all"].append((na, r["recompute_all"] - r["opt_cost"]))
            net_all[r["event_id"]] = (r["cluster"], na / r["recompute_all"])
            if math.isfinite(r["current_cut_cost"]):
                nc = r["current_cut_cost"] - r["opt_cost"] - ov
                nets["vs_current_cut"].append((nc, r["current_cut_cost"] - r["opt_cost"]))
                if r["current_cut_cost"] > 0:
                    net_cur[r["event_id"]] = (r["cluster"], nc / r["current_cut_cost"])
        out[f"{sc}/{cell}/{cls}"] = {
            "n_events": len(rs), "n_finite": len(fin),
            "M5_net_fair_vs_current_cut": cluster_bootstrap_values(fair_cur, B, seed),
            "M5_net_fair_vs_recompute_all": cluster_bootstrap_values(fair_all, B, seed),
            "end_to_end_total_s": e2e,
            "incremental_f1_minus_current_cut_s": e2e["f1"] - e2e["current_cut"],
            "incremental_f1_minus_recompute_all_s": e2e["f1"] - e2e["recompute_all"],
            "solver_invocations": int(sum(1 for r in rs if r.get("solver_invoked"))),
            "fast_path_events": int(sum(1 for r in rs if r.get("solver_invoked") is False)),
            "M5_net_vs_recompute_all": cluster_bootstrap_values(net_all, B, seed),
            "M5_net_vs_current_cut": cluster_bootstrap_values(net_cur, B, seed),
            "net_repair_benefit_total_s": {k: float(sum(x[0] for x in v)) for k, v in nets.items()},
            "events_net_negative": {k: int(sum(1 for x in v if x[0] < 0)) for k, v in nets.items()},
            "events_raw_positive_net_negative": {k: int(sum(1 for x in v if x[1] > 0 and x[0] < 0)) for k, v in nets.items()},
            "overhead_total_s": {"contract_eval": float(sum(r.get("contract_eval_s", 0.0) for r in fin)),
                                 "admission": float(sum(r.get("admission_excl_s", 0.0) for r in fin)),
                                 "solver": float(sum(r.get("solver_excl_s", 0.0) for r in fin))},
            "M5_savings_vs_recompute_all": summarize(acc, B, seed),
            "M5_savings_vs_current_cut": summarize(acc_cur, B, seed),
            "opt_cost_total_s": float(sum(r["opt_cost"] for r in fin)),
            "recompute_all_total_s": float(sum(r["recompute_all"] for r in fin)),
            "current_cut_total_s": float(sum(r["current_cut_cost"] for r in fin if math.isfinite(r["current_cut_cost"]))),
            "solver_seconds_total": float(sum(r.get("solver_s", 0.0) for r in rs)),
            "oracle_opt_total_s": float(sum(r["oracle_opt_cost"] for r in fin if r.get("oracle_opt_cost") is not None and math.isfinite(r["oracle_opt_cost"]))),
            "bruteforce_checked": int(sum(1 for r in rs if "bruteforce_agrees" in r)),
            "bruteforce_agreement": float(np.mean([r["bruteforce_agrees"] for r in rs if "bruteforce_agrees" in r])) if any("bruteforce_agrees" in r for r in rs) else None,
            "ilp_checked": int(sum(1 for r in rs if "ilp_agrees" in r)),
            "infeasible": int(sum(1 for r in rs if not r["feasible"])),
        }
    return out


def scalability_summary(repair_rows: list[dict]) -> dict:
    """RQ5 instrumentation: witness and repair runtime against cut-space size (by power-of-two buckets)."""
    b: dict = defaultdict(list)
    for r in repair_rows:
        n = max(1, int(r.get("n_cuts", 1)))
        b[(r["cls"], 1 << (n - 1).bit_length())].append(r)
    out = {}
    for (cls, k), rs in sorted(b.items()):
        out[f"{cls}/cuts<={k}"] = {"events": len(rs),
                                   "witness_s_median": float(np.median([x.get("witness_s", 0.0) for x in rs])),
                                   "solver_s_median": float(np.median([x.get("solver_s", 0.0) for x in rs])),
                                   "nodes_median": float(np.median([x.get("nodes", 0) for x in rs])),
                                   "solver_s_max": float(np.max([x.get("solver_s", 0.0) for x in rs]))}
    return out
