"""Pre-registered decision gates G1–G6, evaluated deterministically from metrics and the frozen gate configuration."""
from __future__ import annotations

import math

from ..common.util import sha256_obj


def _lo(x):
    return None if x is None else x.get("lo")


def _pt(x):
    return None if x is None else (x.get("mean") if "mean" in x else x.get("macro"))


def _unary_types(w):
    return {t: u for t, u in (w.get("unary") or {}).items() if "__" not in t}


def g1(w, cfg):
    rows, best = [], None
    for t, u in _unary_types(w).items():
        for k in cfg["tolerant_classes"]:
            d = u["incremental_vs_K0"][k]["delta_nb_per_pair_s"]
            rows.append({"artifact_type": t, "cls": k, "dNB_mean": d["mean"], "dNB_lo": d["lo"], "dNB_hi": d["hi"],
                         "dRecall_mean": u["incremental_vs_K0"][k]["delta_recall"]["mean"]})
    if not rows:
        return {"outcome": "NOT_EVALUABLE", "evidence": rows}
    if any(r["dNB_lo"] is not None and r["dNB_lo"] > 0 for r in rows):
        out = "PASS"
    elif any(r["dNB_mean"] is not None and r["dNB_mean"] > 0 for r in rows):
        out = "INCONCLUSIVE"
    else:
        out = "FAIL"
    return {"outcome": out, "evidence": rows}


def g2(soundness, wl, cfg):
    res, outcome = {}, "PASS_EMPIRICAL"
    found = False
    for key, d in soundness.items():
        w, t, k = key.split("/")
        if w != wl or k not in cfg["claimed_sound_classes"]:
            continue
        found = True
        verdict = "FAIL" if d["U2"] > 0 else "PASS_EMPIRICAL"
        if verdict == "FAIL":
            outcome = "FAIL"
        res[f"{t}/{k}"] = {"verdict": verdict, **d}
    return {"outcome": outcome if found else "NOT_EVALUABLE", "evidence": res}


def g3(w, k1_structure_ok: bool, k2_disclosure: dict, cfg):
    if not k1_structure_ok:
        return {"outcome": "FAIL", "reason": "K1 structural check failed", "evidence": {}}
    pos = {k: [] for k in ("K1", "K2", "K3")}
    for t, u in _unary_types(w).items():
        for k in ("K1", "K2", "K3"):
            lo = u["incremental_vs_K0"][k]["delta_recall"]["lo"]
            if lo is not None and lo > 0:
                pos[k].append(t)
    if pos["K1"]:
        out = "PASS"
    elif pos["K2"]:
        out = "PASS_REQUIRES_K2"
    elif pos["K3"]:
        out = "FAIL"
    else:
        out = "NO_USEFUL_REUSE"
    return {"outcome": out, "types_with_positive_dRecall_lower_bound": pos, "k2_disclosure": k2_disclosure}


def g4(w, cfg):
    res, threatened = {}, False
    for t, u in _unary_types(w).items():
        cls_pts = []
        for k in cfg["legitimate_classes"]:
            m = u["M3"][k]
            cls_pts.append((k, m["recall"]["macro"], m["unsafe_admission"]["macro"], m["eval_seconds_mean"] or 0.0))
        dom = []
        for c in u["ttl_curve"]:
            if c["recall"] is None or c["M2"] is None:
                continue
            ok_all = True
            for k, rec, uns, cost in cls_pts:
                if rec is None or uns is None:
                    ok_all = False
                    break
                weak = c["recall"] >= rec and c["M2"] <= uns and 0.0 <= cost
                strict = c["recall"] > rec or c["M2"] < uns or 0.0 < cost
                ok_all = ok_all and weak and strict
            if ok_all:
                dom.append(c["tau_s"])
        res[t] = {"dominating_tau_s": dom}
        threatened = threatened or bool(dom)
    if not res:
        return {"outcome": "NOT_EVALUABLE", "evidence": res}
    return {"outcome": "THREATENED" if threatened else "NOT_DOMINATED", "evidence": res}


def g5(w, cfg, gc):
    j = w.get("joint") or {}
    key = f"{cfg['primary_scenario']}/ALL"
    if key not in j:
        return {"outcome": "NOT_EVALUABLE", "reason": "no primary asynchronous joint events"}
    g = j[key]
    n_cl = g["clusters_with_oracle_joint_failure"]
    lo = g["M4_oracle"]["ci"]["lo"]
    anomalies = g.get("anomaly_count", 0)
    cells = {k.split("/", 1)[1]: v["M4_oracle"]["macro"] for k, v in j.items()
             if k.startswith(cfg["primary_scenario"] + "/") and not k.endswith("/ALL")}
    ev = {"events": g["n_events"], "anomalies": anomalies, "rate": g["M4_oracle"]["macro"], "ci": g["M4_oracle"]["ci"],
          "clusters_with_anomaly": n_cl, "clusters_total": g["clusters_total"], "gamma_sensitivity": cells,
          "naive_composition_error": {k: g[k]["naive_composition_error"]["macro"] for k in ("K0", "K1", "K2", "K3")}}
    if anomalies == 0:
        out = "FAIL"
    elif n_cl >= int(gc["min_clusters_with_anomaly"]) and lo is not None and lo > 0:
        out = "PASS"
    else:
        out = "INCONCLUSIVE"
    return {"outcome": out, "evidence": ev}


def g6(w, cfg, gc):
    r = w.get("repair") or {}
    ev, passed = {}, False
    for k in cfg["legitimate_classes"]:
        key = f"{cfg['primary_scenario']}/ALL/{k}"
        if key not in r:
            continue
        m = r[key]["M5_net_fair_vs_current_cut"] if gc["baseline"] == "current_cut" else r[key]["M5_net_fair_vs_recompute_all"]
        ev[k] = {"M5_net_fair_mean": m["mean"], "lo": m["lo"], "hi": m["hi"], "n": m["n_units"],
                 "M5_net_asymmetric_mean": r[key]["M5_net_vs_current_cut"]["mean"],
                 "end_to_end_total_s": r[key]["end_to_end_total_s"], "solver_invocations": r[key]["solver_invocations"],
                 "net_total_s": r[key]["net_repair_benefit_total_s"],
                 "events_raw_positive_net_negative": r[key]["events_raw_positive_net_negative"]}
        passed = passed or (m["lo"] is not None and m["lo"] > 0)
    if not ev:
        return {"outcome": "NOT_EVALUABLE", "evidence": ev}
    return {"outcome": "PASS" if passed else "REPAIR_NOT_RETAINED", "evidence": ev}


def evaluate(metrics: dict, soundness: dict, k1_ok: dict, k2_disclosure: dict, gates_cfg: dict) -> dict:
    out = {"gates_config_sha256": sha256_obj(gates_cfg), "by_workload": {}}
    gc = gates_cfg["gates"]
    for wl, w in metrics["by_workload"].items():
        out["by_workload"][wl] = {
            "G1": g1(w, gates_cfg) | {"name": gc["G1"]["name"], "rule": gc["G1"]["rule"], "if_fail": gc["G1"]["if_fail"]},
            "G2": g2(soundness, wl, gates_cfg) | {"name": gc["G2"]["name"], "rule": gc["G2"]["rule"], "if_fail": gc["G2"]["if_fail"]},
            "G3": g3(w, k1_ok.get(wl, True), k2_disclosure.get(wl, {}), gates_cfg) | {"name": gc["G3"]["name"], "rule": gc["G3"]["rule"], "if_fail": gc["G3"]["if_fail"]},
            "G4": g4(w, gates_cfg) | {"name": gc["G4"]["name"], "rule": gc["G4"]["rule"], "if_fail": gc["G4"]["if_fail"]},
            "G5": g5(w, gates_cfg, gc["G5"]) | {"name": gc["G5"]["name"], "rule": gc["G5"]["rule"], "if_fail": gc["G5"]["if_fail"]},
            "G6": g6(w, gates_cfg, gc["G6"]) | {"name": gc["G6"]["name"], "rule": gc["G6"]["rule"], "if_fail": gc["G6"]["if_fail"]},
        }
    return out


def to_markdown(g: dict, engineering_only: bool) -> str:
    md = ["# DECISION GATES", ""]
    if engineering_only:
        md += ["**ENGINEERING ONLY — NOT SCIENTIFIC RESULTS**", ""]
    md += [f"Gate configuration sha256: `{g['gates_config_sha256']}` (frozen before execution).", "",
           "Outcomes are computed mechanically from statistics/metrics.json; they are not interpretations.", ""]
    for wl, gs in g["by_workload"].items():
        md += [f"## Workload {wl}", "", "| Gate | Name | Outcome |", "|---|---|---|"]
        for k in ("G1", "G2", "G3", "G4", "G5", "G6"):
            md.append(f"| {k} | {gs[k]['name']} | **{gs[k]['outcome']}** |")
        md.append("")
        for k in ("G1", "G2", "G3", "G4", "G5", "G6"):
            md += [f"### {k} — {gs[k]['name']}", "", f"Rule: {gs[k]['rule']}", "", f"If not passed: {gs[k]['if_fail']}", ""]
    return "\n".join(md) + "\n"
