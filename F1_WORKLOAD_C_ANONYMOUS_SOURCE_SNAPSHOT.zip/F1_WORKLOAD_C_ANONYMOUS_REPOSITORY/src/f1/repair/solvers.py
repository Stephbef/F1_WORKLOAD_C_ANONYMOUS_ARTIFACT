"""Minimum-cost re-derivation (OPT).

OPT(R, Gamma, t) = min_{c in Cuts(H_t) ∩ Gamma} sum_{r in R : not kappa_eff_r(c)} cost_r

This is a weighted Max-CSP / minimum-cost correction set instance (inherited combinatorics; no hardness claim).
Three solvers, cross-checked in tests:
  * opt_bruteforce : reference, enumerates every candidate cut.
  * opt_bnb        : exact branch-and-bound over items; a contract is decided once its footprint is assigned
                     (footprint transfer); lower bound = cost of already-violated contracts; inf = hard.
  * opt_ilp        : optional 0/1 ILP (PuLP + HiGHS) over one-hot version variables and footprint tuples.
Any candidate cut yields a valid repair, so solver optimality affects cost only, never soundness.
"""
from __future__ import annotations

import itertools
import math
import time
from typing import Callable

from ..common.util import F1Error
from ..core.history import Cut, History

Sat = Callable[[int, Cut], bool]  # (artifact index, cut) -> kappa_eff


def _result(cost, cut, Q, solver, t0, nodes):
    return {"opt_cost": cost, "opt_cut": cut, "Q": Q, "solver": solver,
            "seconds": time.perf_counter() - t0, "nodes": nodes, "feasible": cut is not None}


def opt_bruteforce(h: History, allowed: dict[str, list[str]], costs: list[float], sat: Sat) -> dict:
    t0 = time.perf_counter()
    best, best_cut, best_q, n = math.inf, None, None, 0
    for cut in h.enumerate_cuts(allowed):
        n += 1
        q = [i for i in range(len(costs)) if not sat(i, cut)]
        c = sum(costs[i] for i in q)
        if c < best:
            best, best_cut, best_q = c, cut, q
    return _result(best if best_cut is not None else math.inf, best_cut, best_q, "bruteforce", t0, n)


def opt_bnb(h: History, allowed: dict[str, list[str]], costs: list[float], sat: Sat,
            footprints: list[list[str]]) -> dict:
    t0 = time.perf_counter()
    items_all = h.item_names()
    refcount = {i: sum(1 for fp in footprints if i in fp) for i in items_all}
    order = sorted(items_all, key=lambda i: (-refcount[i], len(allowed[i]), i))
    pos = {it: k for k, it in enumerate(order)}
    # contract i is decided after the last of its footprint items is assigned
    decide_at: dict[int, list[int]] = {}
    for i, fp in enumerate(footprints):
        missing = [x for x in fp if x not in pos]
        if missing:
            raise F1Error(f"footprint item(s) {missing} not in history")
        k = max((pos[x] for x in fp), default=-1)
        decide_at.setdefault(k, []).append(i)
    pre = decide_at.get(-1, [])
    best = {"cost": math.inf, "cut": None, "q": None}
    nodes = 0
    partial: Cut = {}

    def rec(k: int, cost: float, q: list[int]):
        nonlocal nodes
        nodes += 1
        if cost >= best["cost"]:
            return
        if k == len(order):
            best.update(cost=cost, cut=dict(partial), q=list(q))
            return
        it = order[k]
        for vid in allowed[it]:
            if not h.compatible(partial, it, vid):
                continue
            partial[it] = vid
            add, nq = 0.0, q
            for i in decide_at.get(k, []):
                if not sat(i, partial):
                    add += costs[i]
                    nq = nq + [i]
            if cost + add < best["cost"]:
                rec(k + 1, cost + add, nq)
            del partial[it]

    c0 = sum(costs[i] for i in pre if not sat(i, {}))
    q0 = [i for i in pre if not sat(i, {})]
    rec(0, c0, q0)
    return _result(best["cost"], best["cut"], sorted(best["q"]) if best["q"] is not None else None, "bnb", t0, nodes)


def ilp_available() -> bool:
    try:
        import pulp  # noqa: F401
        return "HiGHS" in pulp.listSolvers(onlyAvailable=True)
    except Exception:
        return False


def opt_ilp(h: History, allowed: dict[str, list[str]], costs: list[float], sat: Sat,
            footprints: list[list[str]], time_limit: float = 600.0) -> dict:
    import pulp
    t0 = time.perf_counter()
    items = h.item_names()
    prob = pulp.LpProblem("opt_repair", pulp.LpMinimize)

    def binvar(name):  # PuLP >= 4 creates variables through the problem; older versions through LpVariable
        if hasattr(prob, "add_variable"):
            return prob.add_variable(name, cat="Binary")
        return pulp.LpVariable(name, cat="Binary")

    y = {(i, v): binvar(f"y_{a}_{b}")
         for a, i in enumerate(items) for b, v in enumerate(allowed[i])}
    for i in items:
        if not allowed[i]:
            return _result(math.inf, None, None, "ilp", t0, 0)
        prob += pulp.lpSum(y[(i, v)] for v in allowed[i]) == 1
    # cut consistency: selecting (it, v) requires item x at index >= req
    for it in items:
        for v in allowed[it]:
            for x, need in h.requires(it, v).items():
                ok = [w for w in allowed[x] if h.idx(x, w) >= need]
                prob += y[(it, v)] <= pulp.lpSum(y[(x, w)] for w in ok)
    obj = []
    for r, fp in enumerate(footprints):
        fp = sorted(fp)
        sat_tuples = []
        for combo in itertools.product(*[allowed[x] for x in fp]):
            part = dict(zip(fp, combo))
            if sat(r, part):
                sat_tuples.append(part)
        z = binvar(f"z_{r}")
        us = []
        for k, part in enumerate(sat_tuples):
            u = binvar(f"u_{r}_{k}")
            for x, w in part.items():
                prob += u <= y[(x, w)]
            us.append(u)
        prob += z <= pulp.lpSum(us) if us else z <= 0
        if math.isinf(costs[r]):
            prob += z == 1
        else:
            obj.append(costs[r] * (1 - z))
    prob += pulp.lpSum(obj) if obj else 0
    ret = prob.solve(pulp.HiGHS(msg=False, timeLimit=time_limit))
    # PuLP < 4 returns an int status code; PuLP >= 4 returns a stats object with .status (enum)
    code = int(getattr(getattr(ret, "status", ret), "value", getattr(ret, "status", ret)))
    if code != 1:
        return _result(math.inf, None, None, "ilp", t0, 0) | {"status": code}
    cut = {i: next(v for v in allowed[i] if (y[(i, v)].value() or 0) > 0.5) for i in items}
    q = [r for r in range(len(costs)) if not sat(r, cut)]
    return _result(sum(costs[r] for r in q), cut, q, "ilp", t0, 0)
