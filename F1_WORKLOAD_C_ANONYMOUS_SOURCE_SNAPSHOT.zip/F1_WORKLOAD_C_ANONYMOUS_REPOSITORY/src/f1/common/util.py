"""Common utilities: canonical JSON, hashing, content-addressed store, atomic IO, config."""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import shutil
import tempfile
import time
from pathlib import Path
from typing import Any, Iterable, Iterator

import yaml


class F1Error(RuntimeError):
    """Base class for all harness errors. Never swallowed silently."""


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=_json_default)


def _json_default(o: Any):
    if isinstance(o, (set, frozenset)):
        return sorted(o)
    if isinstance(o, Path):
        return str(o)
    if hasattr(o, "item"):  # numpy scalars
        return o.item()
    raise TypeError(f"not JSON serialisable: {type(o)}")


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_obj(obj: Any) -> str:
    return sha256_bytes(canonical_json(obj).encode("utf-8"))


def sha256_file(path: str | Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def atomic_write_bytes(path: str | Path, data: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp-")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def atomic_write_json(path: str | Path, obj: Any, indent: int | None = 2) -> None:
    txt = json.dumps(obj, sort_keys=True, indent=indent, ensure_ascii=False, default=_json_default)
    atomic_write_bytes(path, (txt + "\n").encode("utf-8"))


def read_json(path: str | Path) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def append_jsonl(path: str | Path, rec: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    line = canonical_json(rec) + "\n"
    with open(path, "a", encoding="utf-8") as f:
        f.write(line)
        f.flush()
        os.fsync(f.fileno())


def read_jsonl(path: str | Path) -> Iterator[Any]:
    path = Path(path)
    if not path.exists():
        return iter(())
    def gen():
        with open(path, "r", encoding="utf-8") as f:
            for ln, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    yield json.loads(line)
                except json.JSONDecodeError as e:
                    # A torn final line can only come from a crash mid-write; it is reported, not hidden.
                    raise F1Error(f"corrupt JSONL line {ln} in {path}: {e}") from e
    return gen()


def write_jsonl(path: str | Path, recs: Iterable[Any]) -> None:
    data = "".join(canonical_json(r) + "\n" for r in recs)
    atomic_write_bytes(path, data.encode("utf-8"))


def load_yaml(path: str | Path) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def parse_iso(s: str) -> float:
    """Parse an ISO-8601 date or datetime (UTC assumed when no offset) into epoch seconds."""
    from datetime import datetime, timezone
    s = s.strip()
    if len(s) == 10:
        dt = datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    else:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
    return dt.timestamp()


def iso_of(ts: float) -> str:
    from datetime import datetime, timezone
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


DAY = 86400.0


class CAS:
    """Content-addressed blob store. Blobs are stored gzip-compressed under their sha256 (of raw bytes).

    Directory blobs (e.g. an advisory database tree) are represented as a JSON manifest
    {relpath: blob_sha} stored as an ordinary blob, so identical files are never duplicated.
    """

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, h: str) -> Path:
        return self.root / h[:2] / h[2:4] / (h + ".gz")

    def _raw(self, h: str) -> Path:
        return self.root / h[:2] / h[2:4] / (h + ".raw")

    def has(self, h: str) -> bool:
        return self._path(h).exists() or self._raw(h).exists()

    def put(self, data: bytes, compress: bool | None = None) -> str:
        """Store bytes. Already-compressed formats (parquet, gzip, zip) are stored raw so they can be
        hard-linked/read in place; everything else is gzip-compressed."""
        h = sha256_bytes(data)
        if self.has(h):
            return h
        if compress is None:
            compress = not (data[:4] == b"PAR1" or data[:2] == b"\x1f\x8b" or data[:2] == b"PK")
        if compress:
            atomic_write_bytes(self._path(h), gzip.compress(data, compresslevel=6, mtime=0))
        else:
            atomic_write_bytes(self._raw(h), data)
            os.chmod(self._raw(h), 0o444)
        return h

    def put_file(self, path: str | Path) -> str:
        with open(path, "rb") as f:
            return self.put(f.read())

    def raw_path(self, h: str) -> Path | None:
        p = self._raw(h)
        return p if p.exists() else None

    def get(self, h: str) -> bytes:
        rp = self._raw(h)
        if rp.exists():
            data = rp.read_bytes()
        else:
            p = self._path(h)
            if not p.exists():
                raise F1Error(f"CAS blob missing: {h}")
            data = gzip.decompress(p.read_bytes())
        if sha256_bytes(data) != h:
            raise F1Error(f"CAS blob corrupt: {h}")
        return data

    def put_tree(self, files: dict[str, bytes]) -> str:
        manifest = {rel: self.put(b) for rel, b in sorted(files.items())}
        return self.put(canonical_json({"__tree__": manifest}).encode())

    def put_tree_refs(self, manifest: dict[str, str]) -> str:
        return self.put(canonical_json({"__tree__": dict(sorted(manifest.items()))}).encode())

    def tree_manifest(self, h: str) -> dict[str, str]:
        obj = json.loads(self.get(h).decode())
        if not isinstance(obj, dict) or "__tree__" not in obj:
            raise F1Error(f"CAS blob {h} is not a tree")
        return obj["__tree__"]

    def is_tree(self, h: str) -> bool:
        if self.raw_path(h) is not None:
            return False
        try:
            b = self.get(h)
        except F1Error:
            return False
        return b.startswith(b'{"__tree__"')

    def materialize(self, h: str, dest: str | Path) -> Path:
        """Write a blob (file) or tree (directory) to dest."""
        dest = Path(dest)
        if self.is_tree(h):
            dest.mkdir(parents=True, exist_ok=True)
            for rel, bh in self.tree_manifest(h).items():
                self._materialize_blob(bh, dest / rel)
        else:
            self._materialize_blob(h, dest)
        return dest

    def _materialize_blob(self, h: str, out: Path) -> None:
        out.parent.mkdir(parents=True, exist_ok=True)
        rp = self.raw_path(h)
        if rp is not None:
            try:
                os.link(rp, out)  # immutable raw blob: hard link, no copy
                return
            except OSError:
                shutil.copyfile(rp, out)
                return
        out.write_bytes(self.get(h))


def rmtree_quiet(p: str | Path) -> None:
    shutil.rmtree(p, ignore_errors=True)
