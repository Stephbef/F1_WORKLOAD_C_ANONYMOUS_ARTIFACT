"""Content loader over the CAS with a bounded, content-addressed parse cache.

Every cached object is a deterministic function of an IMMUTABLE content hash (advisory snapshot, license table,
policy file, lockfile, table schema), so caching can never change a contract decision: it only avoids re-parsing the
same immutable snapshot (T-I tests cached == uncached). Decisions themselves are never cached here.
Parse-miss CPU time is tracked so that evaluation cost can be reported with parse cost amortised per evaluation.
"""
from __future__ import annotations

import time
from collections import OrderedDict
from pathlib import Path
from typing import Any, Callable

from .util import CAS

# per-kind bounds: large objects (table column caches) are kept few; small parsed objects many
KIND_LIMITS = {"dq-table": 2, "rustsec-db": 8, "lictable": 4}


class Loader:
    def __init__(self, cas: CAS, max_parsed: int = 256, enabled: bool = True):
        self.cas = cas
        self.enabled = enabled
        self._parsed: dict[str, OrderedDict] = {}
        self._max = max_parsed
        self.stats = {"hits": 0, "misses": 0, "miss_cpu_s": 0.0, "by_kind": {}}

    def bytes(self, ref: str) -> bytes:
        return self.cas.get(ref)

    def text(self, ref: str) -> str:
        return self.cas.get(ref).decode("utf-8")

    def tree(self, ref: str) -> dict[str, str]:
        return self.parsed("tree", ref, lambda L, r: L.cas.tree_manifest(r))

    def materialize(self, ref: str, dest: str | Path) -> Path:
        return self.cas.materialize(ref, dest)

    def parsed(self, kind: str, ref: str, parser: Callable[["Loader", str], Any]) -> Any:
        k = self.stats["by_kind"].setdefault(kind, {"hits": 0, "misses": 0, "miss_cpu_s": 0.0})
        cache = self._parsed.setdefault(kind, OrderedDict())
        if self.enabled and ref in cache:
            cache.move_to_end(ref)
            self.stats["hits"] += 1
            k["hits"] += 1
            return cache[ref]
        t0 = time.process_time()
        val = parser(self, ref)
        dt = time.process_time() - t0
        self.stats["misses"] += 1
        self.stats["miss_cpu_s"] += dt
        k["misses"] += 1
        k["miss_cpu_s"] += dt
        if self.enabled:
            cache[ref] = val
            if len(cache) > KIND_LIMITS.get(kind, self._max):
                cache.popitem(last=False)
        return val
