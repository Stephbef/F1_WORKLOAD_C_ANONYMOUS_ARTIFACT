"""Oracle firewall.

Three mechanisms (all tested):
1. Role audit hook: a process started with role 'admission' raises FirewallViolation on any attempt to
   open a path inside the oracle store (sys.addaudithook intercepts builtin open/os.open/io.open).
2. Stage ordering: the oracle store directory is only created by the oracle stage, which refuses to run
   unless a SEAL over all admission-side outputs exists and verifies.
3. Seal verification: metrics/statistics stages re-verify the seal; any post-seal modification of an
   admission-side file aborts the run.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from .util import F1Error, atomic_write_json, now_iso, read_json, sha256_file

ROLE_ENV = "F1_ROLE"
ORACLE_DIR_ENV = "F1_ORACLE_DIR"


class FirewallViolation(F1Error):
    """Raised on any attempted breach of the admission/oracle separation."""


_installed = False


def current_role() -> str:
    return os.environ.get(ROLE_ENV, "orchestrator")


def assert_may_execute_producers() -> None:
    """Ax-O enforcement: the admission role never executes a producer (neither at birth nor as an oracle)."""
    if current_role() == "admission":
        raise FirewallViolation("admission role attempted to execute a producer (opacity violation)")


def install_role_guard(role: str, oracle_dir: str | Path) -> None:
    """Install an irreversible audit hook forbidding the admission role from touching the oracle store."""
    global _installed
    os.environ[ROLE_ENV] = role
    os.environ[ORACLE_DIR_ENV] = str(Path(oracle_dir).resolve())
    if role != "admission" or _installed:
        return
    forbidden = str(Path(oracle_dir).resolve())

    def hook(event: str, args: tuple) -> None:
        if event in ("open", "os.open", "os.listdir", "os.scandir", "shutil.copyfile"):
            try:
                p = args[0]
                if isinstance(p, int):
                    return
                rp = os.path.realpath(os.fsdecode(p))
            except Exception:
                return
            if rp == forbidden or rp.startswith(forbidden + os.sep):
                raise FirewallViolation(f"admission role attempted to access oracle store: {rp}")

    sys.addaudithook(hook)
    _installed = True


def seal(admission_files: list[Path], seal_path: Path, extra: dict | None = None) -> dict:
    files = sorted({str(Path(p)) for p in admission_files})
    missing = [p for p in files if not Path(p).exists()]
    if missing:
        raise F1Error(f"cannot seal: missing admission outputs {missing}")
    rec = {
        "sealed_at": now_iso(),
        "files": {p: sha256_file(p) for p in files},
        "extra": extra or {},
    }
    if seal_path.exists():
        raise F1Error(f"seal already exists at {seal_path}; refusing to overwrite (resume must verify instead)")
    atomic_write_json(seal_path, rec)
    for p in files:
        try:
            os.chmod(p, 0o444)
        except OSError as e:  # read-only bit is defence in depth; the hash seal is the authoritative guard
            print(f"[seal] warning: could not chmod {p}: {e}")
    return rec


def verify_seal(seal_path: Path) -> dict:
    if not seal_path.exists():
        raise FirewallViolation(f"no admission seal at {seal_path}: oracle/metrics must not run before sealing")
    rec = read_json(seal_path)
    for p, h in rec["files"].items():
        if not Path(p).exists():
            raise FirewallViolation(f"sealed file vanished: {p}")
        if sha256_file(p) != h:
            raise FirewallViolation(f"sealed file modified after seal: {p}")
    return rec
