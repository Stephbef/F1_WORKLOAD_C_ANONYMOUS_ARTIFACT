# java/

`CanonExtractFinal.java` is a byte-identical copy of the frozen `frozen_specs/authoritative/06_CANON_EXTRACT_FINAL.java`
(F1-OTP-CANON-1.3; SHA-256 bound in the derived spec). It is NOT edited. At run time `producers/canon.py` copies the
frozen source (verifying its digest), compiles it with the pinned javac 25.0.4.1 against the pinned OTP 2.10.0 jar into
a content-addressed classes directory and executes it. Manual compile check:

    javac -cp .deps/otp-shaded-2.10.0.jar -d /tmp/canon-classes java/CanonExtractFinal.java
