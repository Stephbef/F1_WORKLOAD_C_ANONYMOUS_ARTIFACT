# F1_WORKLOAD_C_PRECAMPAIGN_FINAL

**Read:** 00 → 18 → 17.

**Reproduce:** `conformance/scripts/run_all_s0g.sh`.

**Target server:** `target_server_conformance/run_target_l26.sh`.
