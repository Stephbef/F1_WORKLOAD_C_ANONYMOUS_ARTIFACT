# 02 — Explicit field serialization

**Removed:** `prims()` generic introspection of stop and station fields.

**Replacements:**
- `stopFields()`: level index, vehicleType, boarding areas, plus the explicit id, coordinates, wheelchair, parent and timezone columns.
- `stationFields()`: priority, transfersNotAllowed, routeToCentroid, plus id, coordinates and timezone.

Every field is classified in `03_STOP_STATION_ROUTING_FIELD_MATRIX.csv`.

**Remaining reflection:** only **named** private-field reads where OTP 2.10.0 offers no getter. It is fail-closed: an absent field raises `NoSuchFieldException`. It is not generic introspection.
- FrequencyEntry: `startTime`, `endTime`, `headway_s`, `exactTimes`, `tripTimes`.
- PathwayEdge: `traversalTime`, `slope`.
