# 21 — Self-contained local protocol (authoritative)

## 1. Producers
| Producer | Pin | Runtime / flags |
|---|---|---|
| OTP | 2.10.0 jar SHA-256 8acd28081f859cfbb4a18a7979789fc02d472f229ce656167f3da5971eea7990 | Java 25 (OpenJDK 25.0.4.1) |
| gtfs-validator | 8.0.1 cli SHA-256 19293ddd9b6f954f216d4f12054bd8a3232921751c4484339e339764a91000e2 | `-d <consumer date> -c <country> -svu -t 1` |
| osmium-tool | 1.16.0-1build1 | — |

**VAL_GATE:** PASS iff zero ERROR notices.

## 2. Logical versions
- **Canonical hash:**
  - Input: GTFS-named members only, at basename level and lower-cased.
  - Normalization: BOM removed; CRLF converted to LF.
  - Hash: SHA-256 of the sorted (name, sha256) pairs.
- **Collapsing.** Consecutive equal hashes collapse into one logical version; its availability is the first archive-observed time. A recurrence after a different hash is a new version.
- **Ordering.** Logical versions are computed before any region step.

## 3. Regions
- **Feed eligibility:** active, no authentication, bounding-box diagonal ≤ 500 km, licence class A/B/C, logical history covering 2025-04-01..2026-06-30 with no gap > 30 days.
- **Deduplication:** redirects; identical URL or canonical hash; merged bundles with ≥ 50 % agency overlap; aliases.
- **Feed-connectivity edges:** ≥ 3 stop pairs within 400 m (5-minute walk catchment), using the version in force at 2025-04-01; convex hulls intersecting or ≤ 2 km apart; same agency_timezone.
- **Region:** a connected component of 2–8 feeds, each with ≥ 1 edge. Components with > 8 feeds are split by removing the weakest edges. Total zip size ≤ 500 MB.
- **Region id:** `R:` + sorted feed ids joined by `+`.
- **Selection and split:** rank(domain, id) = SHA-256(seed_bytes(domain) ‖ 0x00 ‖ UTF8(region_id)), ascending; first 24 by "region-selection"; of those, first 8 by "validation-test" = validation, rest = test (tools/select_regions_hashrank.py).

## 4. Schedule
- **Validator:** at availability; region FIFO with 1 worker; the artifact exists at completion.
- **OTP:** 02:00 local if newer inputs exist; inputs are the latest available version of each feed; 1 build per region; a trigger is skipped if a build is running.
- **Consumer:** 06:00 local.
- **Time:** agency timezone; Java 25 tzdata. A non-existent time moves to the next valid minute; an ambiguous time takes its first occurrence.
- **Failures:** no scientific timeouts. An operational 24 h cap applies (affected instants excluded from primary metrics). A build failure means "no artifact"; it is not ∞.

## 5. Γ
- Per feed: logical versions archived ≤ t, with service on every date of [t, t + 6], and ≤ 2 superseding versions.
- Sensitivity: horizon 3 / 13 days; depth 1 / 4; current-only control.

## 6. Contracts
- **VAL:**
  - K0: canonical hash + date + country + validator.
  - K1: per-file hashes.
  - K2 = K1.
  - K3: re-run.
- **ROUTER:**
  - K0: feed hashes + OSM + semantic config + OTP.
  - K1: per-file hashes of the routing files.
  - K2_D: per-feed SHA-256 of the routing-relevant GTFS input projection over ActiveClosure_D (agencies/routes/trips/stop_times/frequencies/calendars on D/active stops+stations+levels+boarding areas/transfers and pathways touching active elements), valid while D ⊆ the resolved imported window (08_K2_CANON_FINAL_ALIGNMENT.md).
  - K3: rebuild + Canon_D 1.3.

## 7. Oracle
Canon_D 1.3 (06_CANON_EXTRACT_FINAL.java; schema F1-OTP-CANON-1.3). The query battery is secondary only: 200 OD pairs per region (query-battery seed), Tuesday 08:00 and Saturday 12:00 local, default and wheelchair profiles. A battery divergence with equal Canon_D is an oracle bug.

## 8. Baselines
| ID | Baseline |
|---|---|
| N0 | full rebuild |
| N1 | `--loadStreet` + cache.enabled, warm page cache |
| N2 | current-cut K0 rerun |
| N3 | pinning + interval join |
| N4 | TTL {1, 6, 24, 72, 168} h, τ selected on validation regions |
| N5 | same contracts, current cut only |
| N6 | per-dataset validation cache |

Resources: 14_RESOURCE_ENVELOPE_FINAL.md (OTP 8 cores/CPUQuota 800%/MemoryMax 32G/-Xms24g -Xmx24g/ActiveProcessorCount=8/G1; validator 2c/4g; F1/N5 2c/8g; N1 identical OTP envelope).

## 9. Metrics and statistics
- **HSR_witness(K):** P[∃ c ≠ c_cur ∈ W | c_cur ∉ W].
- **HSR_repair(K):** P[OPT_hist < OPT_cur | W = ∅, OPT_cur > 0].
- **ΔCost_history:** OPT_cur − min(OPT_cur, OPT_hist).
- **ΔE2E_history(K2):** Cost_N5 − Cost_F1.
- **Unit:** region × distinct root content change.
- **Reporting order:** raw per-region results, number of regions, number of root changes, exact sign test, BCa bootstrap (B = 9,999; bootstrap seed), wild-cluster bootstrap.
- **Holm family:** {H_witness(K0), H_repair(K0), H_hist(K2), H_native(K2)}.

## 10. Mutations
- **Sample:** ids sorted, ranked with the mutation seed, top ceil(5 % · n).
- **Families:**
  - stop_times, frequencies, calendar_dates;
  - transfers, block_id;
  - coordinates, pathways (traversal time, slope, steps), wheelchair;
  - route_type, timezones, namespace;
  - horizon, shapes (reverse);
  - validator date / file;
  - M-FUTURE-1/2, M-CT, M-FREQ, M-STOP-ACTIVE / INACTIVE, M-AGENCY-FUTURE / ACTIVE.

## 11. Seeds
- seed_bytes(domain) = SHA-256(UTF8(MASTER_HEX + "|" + domain)), MASTER_HEX = SHA-256("F1-SIGMOD2027-WORKLOAD-C-PROTOCOL-V4-MASTER-SEED").
- Domains: region-selection, validation-test, mutation, query-battery, bootstrap, wild-bootstrap, od-sampling, harness.
- An integer seed, where needed, is the first 8 bytes of seed_bytes, big-endian.

## 12. Canon 1.3 additions (authoritative)
- **Header:** adds `0modeltz|<TransitRepository time zone>`.
- **Route records:** for active routes (05_ROUTE_AGENCY_CANON_SPEC.md).
- **Stop fields:** id, lat/lon, wheelchair, parent, timezone, level index, vehicleType, boarding areas.
- **Station fields:** id, lat/lon, timezone, priority, transfersNotAllowed, routeToCentroid.
- **Reflection:** no generic reflection; named-field reads only for FrequencyEntry and PathwayEdge.
- **Field classification:** `03_STOP_STATION_ROUTING_FIELD_MATRIX.csv` and `09_ROUTING_FIELD_COVERAGE_FINAL.csv`.

## 13. Resources and target conformance
- **Resources:** 14_RESOURCE_ENVELOPE_FINAL.md.
- **L28:** `target_server_conformance/`.
