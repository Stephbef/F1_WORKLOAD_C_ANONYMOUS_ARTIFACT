# 14 — Resource envelope (authoritative)

| Component | Envelope |
|---|---|
| OTP | 8 dedicated cores (cpuset / AllowedCPUs + CPUQuota 800 %); `-XX:ActiveProcessorCount=8 -Xms24g -Xmx24g -XX:+UseG1GC -Duser.timezone=UTC -Djava.io.tmpdir=<job dir>`; MemoryMax 32G; LC_ALL=C.UTF-8; isolated network; local SSD; 1 build per region; ≤ 8 concurrent builds |
| Validator | 2 cores; `-Xmx4g`; `-t 1`; 1 worker per region |
| F1 / N5 | 2 cores; 8 GB; single-threaded witness search and solver |
| N1 | identical OTP envelope |

**Rules:**
- No selective resizing.
- Overflow is an infrastructure "no artifact" event.
- Global infeasibility triggers a documented amendment before execution.
