# 15 — L28 target-resource conformance

**Package:** `target_server_conformance/`.

**Runner steps (`run_target_l26.sh`):**
1. Verifies ≥ 8 CPUs, ≥ 32 GiB RAM, taskset, and cgroup / systemd control.
2. Collects lscpu, free, cgroup, cpuset, ulimit and the Java version.
3. Runs the conformance D1–D10 + DF suite under taskset + systemd scope (MemoryMax 32G, CPUQuota 800 %, AllowedCPUs), with `-Xms24g -Xmx24g -XX:ActiveProcessorCount=8 -XX:+UseG1GC`.
4. Writes `target_result.json`.

**Exit codes:** 0 PASS, 1 FAIL, 2 BLOCKED.

**This host:** 1 CPU, 3 GiB, so the result is **BLOCKED** (`target_result_THIS_HOST_BLOCKED.json`).
