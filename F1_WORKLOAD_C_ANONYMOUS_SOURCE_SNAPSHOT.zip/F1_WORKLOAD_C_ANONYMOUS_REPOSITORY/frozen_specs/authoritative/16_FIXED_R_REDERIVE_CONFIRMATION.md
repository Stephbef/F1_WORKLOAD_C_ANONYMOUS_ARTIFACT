# 16 — Fixed R and rederive

These are unchanged and unaffected by the explicit-field changes.

- **Fixed R:** the designated artifact slots.
- **rederive(r, c):** a new derivation instance born at c in the same request slot. Request identity ≠ birth-context identity.
- **Catalog substitution:** a secondary diagnostic only.
- **T1 / T2:** valid with finite costs.
