# 07 — Static audit (grep on 06_CANON_EXTRACT_FINAL.java)

```
2:import java.lang.reflect.Field;
35:      try { Field f = c.getDeclaredField(n); f.setAccessible(true); return f.getInt(o); } catch (NoSuchFieldException ignored) {}
40:      try { Field f = c.getDeclaredField(n); f.setAccessible(true); return f.get(o); } catch (NoSuchFieldException ignored) {}
46:    return b.toString();
98:      emit("pattern", id(p.getId()), id(p.getRoute().getId()), en(p.getMode()), gt == null ? "<null>" : gt.toString(), sp.toString());
149:  static final Set<String> agencyRecs = new TreeSet<>(); static final Set<String> seenTrips = new HashSet<>(); static final List<String>
```

**Classification of each grep match:**

| Match | Classification |
|---|---|
| `java.lang.reflect.Field` / `getDeclaredField` / `setAccessible` | SAFE: named fields only (file 02), fail-closed |
| `b.toString()` | SAFE: StringBuilder to String (building the times string), not object serialization |
| `gt.toString()` | SAFE: Integer route_type to decimal string |
| `HashSet seenTrips` | NOT PART OF CANON: deduplication guard. Output records are sorted before hashing |

There is no identity, no hashCode, and no default serialization in Canon output.
