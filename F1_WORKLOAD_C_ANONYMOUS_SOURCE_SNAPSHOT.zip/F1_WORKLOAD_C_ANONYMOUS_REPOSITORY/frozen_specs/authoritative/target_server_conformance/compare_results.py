#!/usr/bin/env python3
"""Writes the machine-readable L28 verdict. PASS only if the envelope was instantiated and every expected test passed."""
import argparse, csv, json, os
p = argparse.ArgumentParser(); p.add_argument("--blocked"); p.add_argument("--results"); p.add_argument("--expected")
p.add_argument("--env"); p.add_argument("--jflags", default=""); p.add_argument("--suite-rc", type=int, default=1); a = p.parse_args()
if a.blocked:
    print(json.dumps({"resource_envelope_verified": False, "reason": a.blocked, "tests": {}, "overall": "BLOCKED"}, indent=1)); raise SystemExit
env = open(a.env).read() if a.env and os.path.exists(a.env) else ""
res = {r["test"]: r["result"] for r in csv.DictReader(open(a.results))} if a.results and os.path.exists(a.results) else {}
exp = [r["test"] for r in csv.DictReader(open(a.expected))]
tests = {t: res.get(t, "MISSING") for t in exp}
jvm_ok = all(f in a.jflags for f in ("-Xms24g", "-Xmx24g", "-XX:ActiveProcessorCount=8", "-XX:+UseG1GC"))
overall = "PASS" if jvm_ok and a.suite_rc == 0 and all(v == "PASS" for v in tests.values()) else ("BLOCKED" if any(v == "BLOCKED" for v in tests.values()) else "FAIL")
print(json.dumps({"resource_envelope_verified": jvm_ok, "cpu_verified": "lscpu" in env, "memory_verified": "free -h" in env,
                  "jvm_verified": jvm_ok, "tests": tests, "overall": overall}, indent=1))
