#!/bin/bash
# Executed INSIDE the constrained scope: records the limits actually applied to this process.
set -euo pipefail
OUT="$1"; JAVA="${JAVA:-java}"; cg=$(awk -F: '$1=="0"{print $3}' /proc/self/cgroup); base="/sys/fs/cgroup$cg"
rd(){ [ -r "$1" ] && cat "$1" || echo "UNREADABLE"; }
if [ "$(stat -fc %T /sys/fs/cgroup)" != "cgroup2fs" ]; then   # cgroup v1: synthesize v2-style values from v1 controllers
  cpu=$(awk -F: '$2~/cpu,|cpu$|,cpu/{print $3}' /proc/self/cgroup | head -1); mem=$(awk -F: '$2~/memory/{print $3}' /proc/self/cgroup); cs=$(awk -F: '$2~/cpuset/{print $3}' /proc/self/cgroup)
  mkdir -p /tmp/f1v1; echo "$(rd /sys/fs/cgroup/cpu$cpu/cpu.cfs_quota_us) $(rd /sys/fs/cgroup/cpu$cpu/cpu.cfs_period_us)" > /tmp/f1v1/cpu.max
  rd /sys/fs/cgroup/memory$mem/memory.limit_in_bytes > /tmp/f1v1/memory.max; rd /sys/fs/cgroup/cpuset$cs/cpuset.cpus > /tmp/f1v1/cpuset.cpus.effective; base=/tmp/f1v1; cg="v1:$cpu"
fi
jv=$("$JAVA" $JFLAGS -XX:+PrintFlagsFinal -version 2>/dev/null | awk '/ ActiveProcessorCount |InitialHeapSize |MaxHeapSize |UseG1GC /{print $2"="$4}' | tr '\n' ' ')
python3 - "$OUT" "$cg" "$(rd $base/cpu.max)" "$(rd $base/memory.max)" "$(rd $base/cpuset.cpus.effective)" "$(grep Cpus_allowed_list /proc/self/status | awk '{print $2}')" "$(nproc)" "$jv" "$JFLAGS" <<'PY'
import json, sys
out, cg, cpumax, memmax, cpuset, allowed, nproc, jv, jflags = sys.argv[1:]
f = dict(x.split("=", 1) for x in jv.split())
cpu_ok = cpumax.split()[0] == "800000" and cpumax.split()[1] == "100000" if cpumax != "UNREADABLE" and len(cpumax.split()) == 2 else False
mem_ok = memmax == str(32 * 1024**3); set_ok = int(nproc) == 8
jvm_ok = f.get("ActiveProcessorCount") == "8" and f.get("MaxHeapSize") == str(24 * 1024**3) and f.get("InitialHeapSize") == str(24 * 1024**3) and f.get("UseG1GC") == "true"
json.dump({"cgroup": cg, "cpu.max": cpumax, "memory.max": memmax, "cpuset.cpus.effective": cpuset, "Cpus_allowed_list": allowed,
           "visible_cpus": int(nproc), "jvm_final_flags": f, "jflags": jflags, "cpu_quota_ok": cpu_ok, "memory_max_ok": mem_ok,
           "cpuset_ok": set_ok, "jvm_ok": jvm_ok, "resource_envelope_verified": cpu_ok and mem_ok and set_ok and jvm_ok}, open(out, "w"), indent=1)
PY
