#!/bin/bash
# Verifies that the host can instantiate the authoritative OTP envelope. Exit 0 = OK, 2 = BLOCKED.
set -euo pipefail
REQ_CPUS=8; REQ_MEM_GIB=32   # 24 GiB heap + JVM/native headroom
cpus=$(nproc --all); mem_gib=$(awk '/MemTotal/ {printf "%d", $2/1048576}' /proc/meminfo)
ok=true
[ "$cpus" -ge "$REQ_CPUS" ] || { echo "BLOCKED: $cpus CPUs < $REQ_CPUS"; ok=false; }
[ "$mem_gib" -ge "$REQ_MEM_GIB" ] || { echo "BLOCKED: ${mem_gib} GiB RAM < ${REQ_MEM_GIB} GiB"; ok=false; }
command -v taskset >/dev/null || { echo "BLOCKED: taskset missing"; ok=false; }
command -v systemd-run >/dev/null || [ -w /sys/fs/cgroup ] || { echo "BLOCKED: no cgroup control (systemd-run or writable cgroup v2)"; ok=false; }
$ok && { echo "HOST OK: cpus=$cpus mem=${mem_gib}GiB"; exit 0; } || exit 2
