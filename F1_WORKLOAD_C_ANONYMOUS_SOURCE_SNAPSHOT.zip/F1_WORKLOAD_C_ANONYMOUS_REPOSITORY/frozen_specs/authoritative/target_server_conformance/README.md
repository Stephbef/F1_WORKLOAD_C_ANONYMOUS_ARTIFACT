# Target-server L28 conformance

Run on the research server:

```
OTP_JAR=/path/otp-shaded-2.10.0.jar ./run_target_l26.sh
```

**Exit codes:**
- 0: PASS.
- 1: FAIL.
- 2: BLOCKED (the host cannot instantiate the envelope).

**Output:** `target_result.json`.

**Envelope:**
- 8 cores (taskset + systemd scope AllowedCPUs / CPUQuota);
- MemoryMax 32G;
- `-Xms24g -Xmx24g -XX:ActiveProcessorCount=8 -XX:+UseG1GC`.

**Rule:** no manual PASS.
