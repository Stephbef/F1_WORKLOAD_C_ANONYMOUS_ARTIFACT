#!/bin/bash
set -euo pipefail
OUT="${1:-environment.txt}"
{ echo "== date"; date -u +%FT%TZ; echo "== lscpu"; lscpu; echo "== free -h"; free -h; echo "== cgroup"; cat /proc/self/cgroup
  echo "== cpuset"; cat /sys/fs/cgroup/cpuset.cpus.effective 2>/dev/null || true; echo "== ulimit -a"; ulimit -a
  echo "== java"; "${JAVA:-java}" -version 2>&1; echo "== uname"; uname -a; } > "$OUT"
