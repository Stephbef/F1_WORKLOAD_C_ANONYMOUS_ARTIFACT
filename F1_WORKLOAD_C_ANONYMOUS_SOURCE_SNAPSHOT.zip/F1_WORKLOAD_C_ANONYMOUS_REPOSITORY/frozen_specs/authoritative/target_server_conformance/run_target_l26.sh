#!/bin/bash
# L28: authoritative envelope via systemd-run --scope (CPUQuota, MemoryMax, AllowedCPUs) or direct cgroup v2. taskset-only => BLOCKED.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"; CONF="$HERE/../conformance"; RES="$HERE/target_result.json"; PROOF="$HERE/TARGET_RESOURCE_RUNTIME_PROOF.json"
blocked(){ python3 "$HERE/compare_results.py" --blocked "$1" > "$RES"; cat "$RES"; exit 2; }
"$HERE/verify_host.sh" || blocked "host cannot instantiate envelope"
"$HERE/collect_environment.sh" "$HERE/environment_target.txt"
CPUS="${OTP_CPUSET:-0-7}"; export JFLAGS="-XX:ActiveProcessorCount=8 -Xms24g -Xmx24g -XX:+UseG1GC -Duser.timezone=UTC"
if command -v systemd-run >/dev/null && systemd-run --scope --quiet -p MemoryMax=32G -p CPUQuota=800% -p AllowedCPUs="$CPUS" true 2>/dev/null; then
  WRAP=(systemd-run --scope --quiet -p MemoryMax=32G -p CPUQuota=800% -p AllowedCPUs="$CPUS")
elif [ "$(stat -fc %T /sys/fs/cgroup)" = "cgroup2fs" ] && [ -w /sys/fs/cgroup ]; then
  CG=/sys/fs/cgroup/f1_l28_$$; mkdir "$CG"; echo "800000 100000" > "$CG/cpu.max"; echo $((32*1024**3)) > "$CG/memory.max"; echo "$CPUS" > "$CG/cpuset.cpus"
  WRAP=(bash -c 'echo $$ > '"$CG"'/cgroup.procs; exec "$@"' _)
elif [ -w /sys/fs/cgroup/cpu ] && [ -w /sys/fs/cgroup/memory ] && [ -w /sys/fs/cgroup/cpuset ]; then   # cgroup v1
  N=f1_l28_$$; for c in cpu memory cpuset; do mkdir "/sys/fs/cgroup/$c/$N"; done
  echo 100000 > /sys/fs/cgroup/cpu/$N/cpu.cfs_period_us; echo 800000 > /sys/fs/cgroup/cpu/$N/cpu.cfs_quota_us
  echo $((32*1024**3)) > /sys/fs/cgroup/memory/$N/memory.limit_in_bytes
  echo "$CPUS" > /sys/fs/cgroup/cpuset/$N/cpuset.cpus; cat /sys/fs/cgroup/cpuset/cpuset.mems > /sys/fs/cgroup/cpuset/$N/cpuset.mems
  WRAP=(bash -c 'for c in cpu memory cpuset; do echo $$ > /sys/fs/cgroup/$c/'"$N"'/tasks; done; exec "$@"' _)
else blocked "no systemd-run scope, no writable cgroup v2, no writable cgroup v1 (taskset-only is not accepted)"; fi
"${WRAP[@]}" env JFLAGS="$JFLAGS" bash "$HERE/runtime_proof.sh" "$PROOF"
python3 -c "import json,sys; sys.exit(0 if json.load(open('$PROOF'))['resource_envelope_verified'] else 1)" || blocked "runtime proof: envelope not verified inside constrained process"
set +e; "${WRAP[@]}" env JFLAGS="$JFLAGS" bash "$CONF/scripts/run_determinism_suite.sh" > "$HERE/target_determinism_stdout.txt" 2>&1; rc=$?; set -e
cp "$CONF/logs/determinism_results.csv" "$HERE/target_determinism_results.csv"
python3 "$HERE/compare_results.py" --results "$HERE/target_determinism_results.csv" --expected "$HERE/expected_results.csv" --env "$HERE/environment_target.txt" --jflags "$JFLAGS" --suite-rc "$rc" > "$RES"; cat "$RES"
python3 -c "import json,sys; sys.exit(0 if json.load(open('$RES'))['overall']=='PASS' else 1)"
