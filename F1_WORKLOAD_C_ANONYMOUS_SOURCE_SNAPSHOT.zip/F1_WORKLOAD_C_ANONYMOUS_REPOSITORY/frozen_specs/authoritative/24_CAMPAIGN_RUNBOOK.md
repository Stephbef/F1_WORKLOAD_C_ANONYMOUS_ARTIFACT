# 24 — Operator runbook (to complete readiness; DO NOT RUN THE CAMPAIGN)

1. **On the target server:**
   - run `target_server_conformance/run_target_l26.sh` (needs systemd-run or writable cgroup v2, ≥ 8 CPUs, ≥ 32 GiB);
   - keep `TARGET_RESOURCE_RUNTIME_PROOF.json` and `target_result.json`.
2. **If both are PASS:** create the local semantic seal (hash list in 27).
3. **With a Mobility Database token and egress:**
   - catalog snapshot (hash it);
   - datasets → `tools/logical_versions.py`;
   - eligibility and connectivity (17 §3);
   - licences (policy in 17);
   - `tools/select_regions_hashrank.py`.
4. **Geofabrik extracts:** snapshot 2025-04-01 + `osmium extract --strategy complete_ways --bbox <hull + 5 km>`; record hashes.
5. **Freeze seal** → implementation → pre-campaign conformance (P1–P25) → implementation seal.

**DO NOT EXECUTE THE SCIENTIFIC CAMPAIGN WITHOUT SEPARATE AUTHORIZATION.**
