# 08 — K2_D ↔ Canon_D (final)

K2_D adds, symmetrically to the explicit Canon fields:
- **Routes:** agency_id, route_type, bikes_allowed, network membership of active routes.
- **Stops:** level_id → levels.level_index, the vehicle_type extension, boarding-area rows of active stops.
- **Agency:** timezone of agencies of active routes.

**Fields not representable in GTFS** (station priority, transfersNotAllowed, routeToCentroid) take constant defaults under GTFS import. Their K2 dependency is therefore the absence of such inputs, and the OTP version is pinned.

**Status:** no UNKNOWN. **K2_D approaches K3 in input disclosure.**
