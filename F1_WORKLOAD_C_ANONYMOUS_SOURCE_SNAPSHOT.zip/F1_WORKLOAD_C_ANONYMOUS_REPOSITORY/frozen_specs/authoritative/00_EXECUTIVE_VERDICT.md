# 00 — Executive verdict

**CAMPAIGN READINESS BLOCKED — EXACT UNRESOLVED BLOCKERS LISTED**

**Done:**
- sandbox audit;
- runner portability (cgroup v1 / v2 / systemd, fail-closed, in-scope proof);
- packaging fixes.

**Blocked:**
- target server (L28 → local seal);
- Mobility Database (403, no token) → population, licences, selection, split;
- Geofabrik (403) → OSM;
- therefore freeze, implementation and seals.

**Seals:** none created.
