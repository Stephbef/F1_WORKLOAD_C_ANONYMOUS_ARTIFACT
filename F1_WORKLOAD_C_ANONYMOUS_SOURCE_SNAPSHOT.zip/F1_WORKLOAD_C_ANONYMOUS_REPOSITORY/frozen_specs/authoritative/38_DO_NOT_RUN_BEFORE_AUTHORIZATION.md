# 38 — DO NOT RUN BEFORE AUTHORIZATION

No scientific Workload-C campaign may be executed without a separate, explicit, written scientific-campaign authorization from the PI / co-leads. The authorization must reference valid freeze and implementation seals.

**No such seals exist.** The local semantic seal, the scientific freeze seal and the implementation seal have not been created, because blockers remain (39_FINAL_BLOCKER_MATRIX.md).

**Prohibited until then:**
- any study-region execution;
- HSR computation;
- F1-vs-N5 or F1-vs-N1 comparison on study data.
