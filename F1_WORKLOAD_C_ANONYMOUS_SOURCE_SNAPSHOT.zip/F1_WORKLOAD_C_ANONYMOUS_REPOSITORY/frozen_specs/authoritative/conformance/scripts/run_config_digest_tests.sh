#!/bin/bash
set -euo pipefail; HERE="$(cd "$(dirname "$0")/.." && pwd)"; C="$HERE/fixtures/config_digest"
OUT="$HERE/logs/config_results.csv"; echo "test,config_a,config_b,expected,actual,result" > "$OUT"
tail -n +2 "$HERE/expected/config_expected.csv" | while IFS=, read -r t a b bd exp; do
  if [ "$exp" = "BLOCKED_EXIT3" ]; then
    set +e; python3 "$HERE/tools/cfgproj.py" "$C/$a" "$bd" >/dev/null 2>&1; rc=$?; set -e
    [ $rc -eq 3 ] && act=BLOCKED_EXIT3 || act="exit$rc"
  else
    ha=$(python3 "$HERE/tools/cfgproj.py" "$C/$a" "$bd"); hb=$(python3 "$HERE/tools/cfgproj.py" "$C/$b" "$bd")
    [ "$ha" = "$hb" ] && act=EQ || act=NE
  fi
  [ "$act" = "$exp" ] && r=PASS || r=FAIL; echo "$t,$a,$b,$exp,$act,$r" >> "$OUT"
done
grep -q ",FAIL$" "$OUT" && { echo "CONFIG SUITE: FAIL"; exit 1; } || echo "CONFIG SUITE: ALL PASS"
