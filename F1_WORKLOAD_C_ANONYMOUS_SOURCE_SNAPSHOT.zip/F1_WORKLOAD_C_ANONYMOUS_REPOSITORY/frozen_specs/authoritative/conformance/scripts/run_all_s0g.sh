#!/bin/bash
set -euo pipefail; D="$(dirname "$0")"; HERE="$(cd "$D/.." && pwd)"; : > "$HERE/logs/run.log"
{ echo "host: $(uname -a)"; echo "java: $(${JAVA:-/usr/lib/jvm/java-25-openjdk-amd64/bin/java} -version 2>&1 | head -1)"; echo "date: $(date -u +%FT%TZ)"; } > "$HERE/logs/environment.txt"
"$D/run_config_digest_tests.sh"; "$D/run_oracle_conformance.sh"; "$D/run_determinism_suite.sh"
echo "S0G CONFORMANCE: ALL SUITES PASS"
