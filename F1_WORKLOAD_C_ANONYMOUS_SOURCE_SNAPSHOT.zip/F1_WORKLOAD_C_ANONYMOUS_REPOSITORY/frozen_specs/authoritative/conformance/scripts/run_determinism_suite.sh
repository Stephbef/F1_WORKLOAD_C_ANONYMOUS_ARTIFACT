#!/bin/bash
set -euo pipefail; source "$(dirname "$0")/common.sh"; verify_prereqs
OUT="$HERE/logs/determinism_results.csv"; echo "test,variant,expected,actual,result,digest" > "$OUT"
build base dbase; REF=$(canon dbase)
rec(){ local t="$1" v="$2" h="$3"; local act r; if [ -z "$h" ]; then act=ERROR; else [ "$h" = "$REF" ] && act=EQ || act=NE; fi; [ "$act" = EQ ] && r=PASS || r=FAIL; echo "$t,$v,EQ,$act,$r,$h" >> "$OUT"; log "$t $r"; }
blocked(){ echo "$1,$2,EQ,BLOCKED,BLOCKED," >> "$OUT"; log "$1 BLOCKED"; }
build base dD1; rec D1 "independent rebuild" "$(canon dD1)"
if command -v faketime >/dev/null; then build base dD2 faketime "2031-03-15 04:00:00"; rec D2 "faketime 2031" "$(canon dD2)"; else blocked D2 "faketime missing"; fi
if unshare -rn true 2>/dev/null; then build base dD3 unshare -rn; rec D3 "unshare -rn" "$(canon dD3)"; else blocked D3 "unshare unavailable"; fi
build base dD4; rec D4 "third rebuild" "$(canon dD4)"
build d5 dD5; rec D5 "cache.enabled" "$(canon dD5)"
build d6a dD6a; build d6b dD6b; A=$(canon dD6a); B=$(canon dD6b); [ "$A" = "$B" ] && echo "D6,feed order,EQ,EQ,PASS,$A" >> "$OUT" || echo "D6,feed order,EQ,NE,FAIL,$A/$B" >> "$OUT"
rec D7 "JVM restart re-extraction" "$(canon dbase)"
if (sync && echo 3 > /proc/sys/vm/drop_caches) 2>/dev/null; then build base dD8; rec D8 "page cache dropped + fresh dir" "$(canon dD8)"; else blocked D8 "drop_caches not permitted"; fi
WORK_SAVE="$WORK"; WORK="/var/tmp/s0g_other_path"; mkdir -p "$WORK/classes"; cp -r "$WORK_SAVE/classes/." "$WORK/classes/"; build base dD9; H9=$(canon dD9); WORK="$WORK_SAVE"; rec D9 "different host path" "$H9"
build base dD10 env TZ=Asia/Tokyo LANG=fr_FR.UTF-8 LC_ALL=fr_FR.UTF-8; rec D10 "TZ/locale variation" "$(canon dD10)"
JFLAGS="-XX:ActiveProcessorCount=8 -Xmx24g -XX:+UseG1GC -Duser.timezone=UTC" build base dDF; rec DF "final JVM flags (no -Xms commit; host 1 core / 3 GiB)" "$(canon dDF)"
grep -q ",FAIL," "$OUT" && { echo "DETERMINISM SUITE: FAIL"; exit 1; }
grep -q ",BLOCKED," "$OUT" && { echo "DETERMINISM SUITE: BLOCKED"; exit 2; }
echo "DETERMINISM SUITE: ALL PASS"
