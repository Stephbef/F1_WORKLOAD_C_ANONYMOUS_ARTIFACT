#!/bin/bash
set -euo pipefail; source "$(dirname "$0")/common.sh"; verify_prereqs
OUT="$HERE/logs/oracle_results.csv"; echo "test,fixture_a,fixture_b,expected,actual,result,digest_a,digest_b" > "$OUT"; fail=0
declare -A built
tail -n +2 "$HERE/expected/oracle_expected.csv" | while IFS=, read -r t a b exp; do
  for x in "$a" "$b"; do f="${x%@*}"; [ -n "${built[$x]:-}" ] || [ -f "$WORK/$x/graph.obj" ] || build "$f" "$x"; done
  ha=$(canon "$a"); hb=$(canon "$b")
  if [ -z "$ha" ] || [ -z "$hb" ]; then act=ERROR; else [ "$ha" = "$hb" ] && act=EQ || act=NE; fi
  [ "$act" = "$exp" ] && r=PASS || r=FAIL
  echo "$t,$a,$b,$exp,$act,$r,$ha,$hb" >> "$OUT"; log "$t $r"
done
grep -q ",FAIL," "$OUT" && { echo "ORACLE SUITE: FAIL"; exit 1; } || echo "ORACLE SUITE: ALL PASS ($(($(wc -l < "$OUT")-1)) tests)"
