#!/bin/bash
# Shared, fail-closed helpers for the S0g conformance harness.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
JAVA="${JAVA:-/usr/lib/jvm/java-25-openjdk-amd64/bin/java}"; JAVAC="${JAVAC:-/usr/lib/jvm/java-25-openjdk-amd64/bin/javac}"
OTP_JAR="${OTP_JAR:-/tmp/pins/otp-shaded-2.10.0.jar}"; OTP_SHA="8acd28081f859cfbb4a18a7979789fc02d472f229ce656167f3da5971eea7990"
WORK="${WORK:-/tmp/s0g_work}"; HORIZON="2008-06-03,2008-06-04,2008-06-05,2008-06-06,2008-06-07,2008-06-08,2008-06-09"; BUILD_DATE="2008-06-01"
JFLAGS="${JFLAGS:--Xmx2G -Duser.timezone=UTC}"
log(){ echo "[$(date -u +%FT%TZ)] $*" | tee -a "$HERE/logs/run.log"; }
verify_prereqs(){
  [ -x "$JAVA" ] || { echo "BLOCKED: java missing"; exit 2; }
  "$JAVA" -version 2>&1 | grep -q 'version "25' || { echo "BLOCKED: Java 25 required"; exit 2; }
  [ -f "$OTP_JAR" ] || { echo "BLOCKED: OTP jar missing at $OTP_JAR"; exit 2; }
  [ "$(sha256sum "$OTP_JAR" | cut -c1-64)" = "$OTP_SHA" ] || { echo "FAIL: OTP jar digest mismatch"; exit 1; }
  (cd "$HERE/fixtures" && sha256sum --quiet -c ../expected/FIXTURES.sha256) || { echo "FAIL: fixture hash mismatch"; exit 1; }
  mkdir -p "$WORK/classes"; "$JAVAC" -cp "$OTP_JAR" -d "$WORK/classes" "$HERE/tools/CanonExtractFinal.java"
}
build(){  # build <fixture> <workname> [wrapper...]
  local f="$1" w="$2"; shift 2; local d="$WORK/$w"; rm -rf "$d"; mkdir -p "$d"; cp "$HERE/fixtures/oracle/$f/"* "$d/"
  log "build $f -> $w :: ${*:-} $JAVA $JFLAGS -jar otp.jar --buildStreet/--loadStreet --save"
  (cd "$d" && "$@" "$JAVA" $JFLAGS -jar "$OTP_JAR" --buildStreet . > street.log 2>&1 && "$@" "$JAVA" $JFLAGS -jar "$OTP_JAR" --loadStreet --save . > transit.log 2>&1)
}
canon(){  # canon <workname> -> digest
  local d="$WORK/$1"; local cfg; cfg=$(python3 "$HERE/tools/cfgproj.py" "$d/build-config.json" "$BUILD_DATE")
  local osm; osm=$(sha256sum "$d/street.osm.pbf" | cut -c1-64)
  "$JAVA" -Xmx2G -Duser.timezone=UTC -cp "$OTP_JAR:$WORK/classes" CanonExtractFinal "$d/graph.obj" "$HORIZON" "$d/canon12.txt" "$cfg" "$osm" "$OTP_SHA" 2>/dev/null | grep CANON11_SHA256 | awk '{print $2}'
}
