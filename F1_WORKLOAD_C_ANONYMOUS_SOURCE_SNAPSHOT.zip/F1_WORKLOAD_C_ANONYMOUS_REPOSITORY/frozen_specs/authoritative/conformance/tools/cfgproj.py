#!/usr/bin/env python3
"""SemanticRoutingConfigProjection (F1-OTP-CANON-1.2). Usage: cfgproj.py build-config.json BUILD_DATE(YYYY-MM-DD)
Whitelist projection of routing-semantic OTP 2.10.0 build-config keys; operational locators excluded; any unclassified
key -> exit 3 (BLOCKED, fail closed). Relative service bounds (ISO-8601 periods) are resolved against BUILD_DATE."""
import datetime as dt, hashlib, json, re, sys
SEMANTIC_TOP = {"transitServiceStart", "transitServiceEnd", "transitModelTimeZone", "transitFeeds", "osm", "osmDefaults",
    "islandPruning", "maxStopToShapeSnapDistance", "maxTransferDuration", "transferRequests", "discardMinTransferTimes",
    "matchBusRoutesToStreets", "areaVisibility", "maxAreaNodes", "platformEntriesLinking", "staticParkAndRide",
    "staticBikeParkAndRide", "subwayAccessTime", "includeEllipsoidToGeoidDifference", "distanceBetweenElevationSamples",
    "multiThreadElevationCalculations", "maxElevationPropagationMeters", "readCachedElevations", "dem", "demDefaults",
    "boardingLocationTags", "stopConsolidationFile", "routingAccessibility"}
OPERATIONAL_TOP = {"cache", "configVersion", "dataImportReport", "buildReportDir", "storage", "localFileNamePatterns",
    "streetGraph", "graph", "writeCachedElevations"}
OPERATIONAL_SUB = {"source"}
def period(s, base):
    m = re.fullmatch(r"(-)?P(?:(\d+)Y)?(?:(\d+)M)?(?:(\d+)W)?(?:(\d+)D)?", s)
    if not m: return None
    sign = -1 if m.group(1) else 1; y, mo, w, d = (int(x or 0) for x in m.groups()[1:])
    yy, mm = base.year + sign * y, base.month + sign * mo
    yy += (mm - 1) // 12; mm = (mm - 1) % 12 + 1
    day = min(base.day, [31, 29 if yy % 4 == 0 and (yy % 100 != 0 or yy % 400 == 0) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][mm - 1])
    return (dt.date(yy, mm, day) + dt.timedelta(days=sign * (7 * w + d))).isoformat()
def project(cfg, build_date):
    out = {}
    for k, v in cfg.items():
        if k in OPERATIONAL_TOP: continue
        if k not in SEMANTIC_TOP: print(f"BLOCKED unclassified config key: {k}", file=sys.stderr); sys.exit(3)
        if k in ("transitServiceStart", "transitServiceEnd"):
            r = period(v, build_date); out[k] = r if r else dt.date.fromisoformat(v).isoformat()
        elif isinstance(v, list):
            items = [{sk: sv for sk, sv in sorted(it.items()) if sk not in OPERATIONAL_SUB} if isinstance(it, dict) else it for it in v]
            out[k] = sorted(items, key=lambda it: json.dumps(it, sort_keys=True))
        else: out[k] = v
    for k, default in (("transitServiceStart", "-P1Y"), ("transitServiceEnd", "P3Y")):   # OTP defaults, resolved
        out.setdefault(k, period(default, build_date))
    return out
if __name__ == "__main__":
    p = project(json.load(open(sys.argv[1])), dt.date.fromisoformat(sys.argv[2]))
    print(hashlib.sha256(json.dumps(p, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest())
