# 05 — Route record

**Emission rule:** a route record is emitted for each active route, i.e. a route with ≥ 1 active pattern.

**Fields:**
- route id;
- agency id (`<null>` if absent);
- operator id;
- mode name;
- gtfsType;
- netexSubmode;
- bikesAllowed name;
- sorted groupsOfRoutes ids.

**Agency records:** one per agency referenced by an active route (id, timezone).
