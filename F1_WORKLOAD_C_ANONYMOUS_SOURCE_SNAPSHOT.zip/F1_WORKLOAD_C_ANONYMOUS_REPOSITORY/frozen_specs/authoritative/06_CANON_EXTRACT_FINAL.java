import java.io.File;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.util.*;
import org.opentripplanner.core.model.id.FeedScopedId;
import org.opentripplanner.routing.graph.SerializedGraphObject;
import org.opentripplanner.street.model.edge.Edge;
import org.opentripplanner.street.model.edge.PathwayEdge;
import org.opentripplanner.street.model.vertex.Vertex;
import org.opentripplanner.transfer.constrained.model.*;
import org.opentripplanner.transfer.regular.model.PathTransfer;
import org.opentripplanner.transit.model.network.TripPattern;
import org.opentripplanner.transit.model.organization.Agency;
import org.opentripplanner.transit.model.site.Entrance;
import org.opentripplanner.transit.model.site.Station;
import org.opentripplanner.transit.model.site.StopLocation;
import org.opentripplanner.transit.model.timetable.FrequencyEntry;
import org.opentripplanner.transit.model.timetable.Trip;
import org.opentripplanner.transit.model.timetable.TripTimes;
import org.opentripplanner.transit.service.TransitRepository;

/** F1-OTP-CANON-1.3: active routing-semantic closure of an OTP 2.10.0 graph over horizon D.
 *  java -cp otp.jar:. CanonExtract11 graph.obj D1,D2,.. out configSha256 osmSha256  -> prints SHA-256 */
public class CanonExtractFinal {
  static final List<String> out = new ArrayList<>();
  static void emit(String... f) { out.add(String.join("|", f)); }
  static String id(FeedScopedId i) { return i == null ? "<null>" : i.getFeedId() + ":" + i.getId(); }
  static String en(Enum<?> e) { return e == null ? "<null>" : e.name(); }
  static String num(double v) { return String.format(Locale.ROOT, "%.7f", v); }
  static String m3(double v) { return String.format(Locale.ROOT, "%.3f", v); }
  static int intField(Object o, String n) throws Exception {
    for (Class<?> c = o.getClass(); c != null; c = c.getSuperclass())
      try { Field f = c.getDeclaredField(n); f.setAccessible(true); return f.getInt(o); } catch (NoSuchFieldException ignored) {}
    throw new NoSuchFieldException(n);
  }
  static Object objField(Object o, String n) throws Exception {
    for (Class<?> c = o.getClass(); c != null; c = c.getSuperclass())
      try { Field f = c.getDeclaredField(n); f.setAccessible(true); return f.get(o); } catch (NoSuchFieldException ignored) {}
    throw new NoSuchFieldException(n);
  }
  static String times(TripTimes<?> t) {
    StringBuilder b = new StringBuilder();
    for (int i = 0; i < t.getNumStops(); i++) b.append(t.getScheduledArrivalTime(i)).append('-').append(t.getScheduledDepartureTime(i)).append(',');
    return b.toString();
  }
  static String tripAttrs(Trip tp) {
    return String.join("|", id(tp.getId()), id(tp.getServiceId()), tp.getGtfsBlockId() == null ? "<null>" : tp.getGtfsBlockId(),
        en(tp.getDirection()), en(tp.getWheelchairBoarding()), en(tp.getBikesAllowed()), en(tp.getCarsAllowed()));
  }

  public static void main(String[] a) throws Exception {
    SerializedGraphObject g = SerializedGraphObject.load(new File(a[0]));
    TransitRepository tr = g.transitRepository;
    List<LocalDate> D = new ArrayList<>();
    for (String d : a[1].split(",")) D.add(LocalDate.parse(d));
    Collections.sort(D);
    Map<LocalDate, gnu.trove.set.TIntSet> running = tr.getServiceCodesRunningForDate();
    // 1. active service codes per date
    // 2-3. active trips / frequency trips / patterns
    Set<String> activeTrips = new TreeSet<>(), activeStops = new TreeSet<>(), activeStations = new TreeSet<>(), activeRoutes = new TreeSet<>();
    for (TripPattern p : tr.getAllTripPatterns()) {
      List<String> rec = new ArrayList<>();
      for (TripTimes<?> t : p.getScheduledTimetable().getTripTimes())
        for (LocalDate d : D) {
          gnu.trove.set.TIntSet c = running.get(d);
          if (c != null && c.contains(t.getServiceCode())) { rec.add("triptimes|" + id(t.getTrip().getId()) + "|" + d + "|" + times(t)); activeTrips.add(id(t.getTrip().getId())); emitTripOnce(t.getTrip(), p); }
        }
      for (FrequencyEntry f : p.getScheduledTimetable().getFrequencyEntries()) {
        TripTimes<?> t = (TripTimes<?>) objField(f, "tripTimes");
        for (LocalDate d : D) {
          gnu.trove.set.TIntSet c = running.get(d);
          if (c != null && c.contains(t.getServiceCode())) {
            rec.add("frequency|" + id(t.getTrip().getId()) + "|" + d + "|" + intField(f, "startTime") + "|" + intField(f, "endTime") + "|"
                + intField(f, "headway_s") + "|" + objField(f, "exactTimes") + "|" + times(t));
            activeTrips.add(id(t.getTrip().getId())); emitTripOnce(t.getTrip(), p);
          }
        }
      }
      if (rec.isEmpty()) continue;                        // inactive pattern: excluded from Canon_D
      out.addAll(rec);
      StringBuilder sp = new StringBuilder();
      for (int i = 0; i < p.getStops().size(); i++) {
        StopLocation s = p.getStop(i);
        sp.append(id(s.getId())).append('/').append(en(p.getBoardType(i))).append('/').append(en(p.getAlightType(i))).append(',');
        activeStops.add(id(s.getId()));
        if (s.getParentStation() != null) activeStations.add(id(s.getParentStation().getId()));
      }
      activeRoutes.add(id(p.getRoute().getId()));
      Agency ag = p.getRoute().getAgency();
      if (ag != null) agencyRecs.add("agency|" + id(ag.getId()) + "|" + ag.getTimezone().getId());
      var rt = p.getRoute(); List<String> gr = new ArrayList<>(); rt.getGroupsOfRoutes().forEach(x -> gr.add(id(x.getId()))); Collections.sort(gr);
      agencyRecs.add("route|" + id(rt.getId()) + "|agency=" + (ag == null ? "<null>" : id(ag.getId())) + "|operator=" + (rt.getOperator() == null ? "<null>" : id(rt.getOperator().getId()))
          + "|mode=" + en(rt.getMode()) + "|gtfsType=" + (rt.getGtfsType() == null ? "<null>" : rt.getGtfsType()) + "|submode=" + (rt.getNetexSubmode() == null ? "<null>" : rt.getNetexSubmode().name())
          + "|bikes=" + en(rt.getBikesAllowed()) + "|groups=" + String.join(",", gr));
      Integer gt = p.getRoute().getGtfsType();
      emit("pattern", id(p.getId()), id(p.getRoute().getId()), en(p.getMode()), gt == null ? "<null>" : gt.toString(), sp.toString());
    }
    // 4. active stops and stations (routing fields only)
    for (StopLocation s : tr.getSiteRepository().listStopLocations())
      if (activeStops.contains(id(s.getId())))
        emit("stop", id(s.getId()), num(s.getCoordinate().latitude()), num(s.getCoordinate().longitude()), en(s.getWheelchairAccessibility()),
             s.getParentStation() == null ? "<null>" : id(s.getParentStation().getId()), s.getTimeZone() == null ? "<null>" : s.getTimeZone().getId(), stopFields(s));
    for (Station st : tr.getSiteRepository().listStations())
      if (activeStations.contains(id(st.getId())))
        emit("station", id(st.getId()), num(st.getCoordinate().latitude()), num(st.getCoordinate().longitude()), st.getTimezone() == null ? "<null>" : st.getTimezone().getId(), stationFields(st));
    Set<String> activeElems = new TreeSet<>(activeStops); activeElems.addAll(activeStations);
    for (Entrance e : tr.getSiteRepository().listEntrances())
      if (e.getParentStation() != null && activeStations.contains(id(e.getParentStation().getId()))) {
        activeElems.add(id(e.getId()));
        emit("entrance", id(e.getId()), num(e.getCoordinate().latitude()), num(e.getCoordinate().longitude()), en(e.getWheelchairAccessibility()), id(e.getParentStation().getId()));
      }
    // 5-7. transfers, pathways, stop links restricted to active state
    for (PathTransfer pt : g.transferRepository.listPathTransfers())
      if (activeStops.contains(id(pt.from.getId())) && activeStops.contains(id(pt.to.getId()))) {
        List<String> modes = new ArrayList<>(); pt.getModes().forEach(m -> modes.add(m.name())); Collections.sort(modes);
        emit("pathtransfer", id(pt.from.getId()), id(pt.to.getId()), m3(pt.getDistanceMeters()), String.join(",", modes));
      }
    for (ConstrainedTransfer ct : tr.getConstrainedTransferService().listAll()) {
      String f = point(ct.getFrom(), activeTrips, activeStops, activeStations, activeRoutes), t = point(ct.getTo(), activeTrips, activeStops, activeStations, activeRoutes);
      if (f == null || t == null) continue;               // references inactive state
      TransferConstraint c = (TransferConstraint) ct.getTransferConstraint();
      emit("constrained", f, t, en(c.getPriority()), String.valueOf(c.isStaySeated()), String.valueOf(c.isGuaranteed()), String.valueOf(c.isNotAllowed()),
           c.isMinTransferTimeSet() ? String.valueOf(c.getMinTransferTime()) : "<unset>", String.valueOf(c.getMaxWaitTime()));
    }
    for (Vertex v : g.graph.getVertices())
      for (Edge e : v.getOutgoing()) {
        String fl = e.getFromVertex().getLabelString(), tl = e.getToVertex().getLabelString();
        boolean touches = touchesActive(fl, activeElems) || touchesActive(tl, activeElems);
        if (e instanceof PathwayEdge pe && touches)
          emit("pathway", fl, tl, "t=" + intField(pe, "traversalTime"), "d=" + m3(pe.getDistanceMeters()), "steps=" + pe.getSteps(),
               "slope=" + String.format(Locale.ROOT, "%.6f", (double) objField(pe, "slope")), "wc=" + pe.isWheelchairAccessible());
        else if (e.getClass().getSimpleName().equals("StreetTransitStopLink") && touches) {
          // semantic form: active stop/entrance id + coordinates of the street-side attachment (split labels are creation-order artifacts)
          boolean fromActive = touchesActive(fl, activeElems);
          Vertex other = fromActive ? e.getToVertex() : e.getFromVertex();
          emit("stoplink", fromActive ? fl : tl, fromActive ? "out" : "in", num(other.getLat()), num(other.getLon()));
        }
      }
    out.addAll(tripRecs); out.addAll(agencyRecs);
    Collections.sort(out);
    List<String> hdr = List.of("0schema|F1-OTP-CANON-1.3", "0otp|2.10.0|" + a[5], "0config|" + a[3], "0osm|" + a[4], "0horizon|" + D, "0modeltz|" + (tr.getTimeZone() == null ? "<null>" : tr.getTimeZone().getId()));
    List<String> all = new ArrayList<>(hdr); all.addAll(out);
    byte[] blob = String.join("\n", all).getBytes(StandardCharsets.UTF_8);
    java.nio.file.Files.write(java.nio.file.Path.of(a[2]), blob);
    System.out.println("CANON11_SHA256 " + HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(blob)) + " records " + out.size());
  }
  static final Set<String> agencyRecs = new TreeSet<>(); static final Set<String> seenTrips = new HashSet<>(); static final List<String> tripRecs = new ArrayList<>();
  static void emitTripOnce(Trip tp, TripPattern p) {
    if (seenTrips.add(id(tp.getId()))) tripRecs.add("trip|" + tripAttrs(tp) + "|" + id(p.getId()));
  }
  /** Explicit stop serialization (OTP 2.10.0 RegularStop / StationElement routing fields). */
  static String stopFields(StopLocation s) {
    String lvl = "<null>";
    if (s instanceof org.opentripplanner.transit.model.site.StationElement<?, ?> se && se.getLevelIndex() != null)
      lvl = String.format(Locale.ROOT, "%.3f", se.getLevelIndex());
    String vt = "<null>", ba = "";
    if (s instanceof org.opentripplanner.transit.model.site.RegularStop rs) {
      vt = en(rs.getVehicleType());
      List<String> b = new ArrayList<>(); for (var x : rs.getBoardingAreas()) b.add(id(x.getId())); Collections.sort(b); ba = String.join(",", b);
    }
    return "level=" + lvl + ";vehicleType=" + vt + ";boardingAreas=" + ba;
  }
  /** Explicit station serialization. */
  static String stationFields(Station st) {
    return "priority=" + en(st.getPriority()) + ";transfersNotAllowed=" + st.isTransfersNotAllowed() + ";routeToCentroid=" + st.shouldRouteToCentroid();
  }
  static boolean touchesActive(String label, Set<String> ids) {
    return ids.contains(label);   // exact match: stop/entrance/station vertex labels are their FeedScopedId strings
  }
  static String point(TransferPoint p, Set<String> trips, Set<String> stops, Set<String> stations, Set<String> routes) {
    if (p instanceof TripTransferPoint q) return trips.contains(id(q.getTrip().getId())) ? "trip:" + id(q.getTrip().getId()) + "@" + q.getStopPositionInPattern() : null;
    if (p instanceof StopTransferPoint q) return stops.contains(id(q.getStop().getId())) ? "stop:" + id(q.getStop().getId()) : null;
    if (p instanceof StationTransferPoint q) return stations.contains(id(q.getStation().getId())) ? "station:" + id(q.getStation().getId()) : null;
    if (p instanceof RouteStopTransferPoint q) return routes.contains(id(q.getRoute().getId())) && stops.contains(id(q.getStop().getId())) ? "routestop:" + id(q.getRoute().getId()) + "@" + id(q.getStop().getId()) : null;
    if (p instanceof RouteStationTransferPoint q) return routes.contains(id(q.getRoute().getId())) && stations.contains(id(q.getStation().getId())) ? "routestation:" + id(q.getRoute().getId()) + "@" + id(q.getStation().getId()) : null;
    throw new IllegalStateException("unknown TransferPoint subtype: " + p.getClass().getName());
  }
}
