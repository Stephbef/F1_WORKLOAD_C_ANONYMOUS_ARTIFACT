"""Portable deterministic selection (F1-OTP-CANON-1.2 protocol). seed_bytes(domain) = SHA-256(UTF8(MASTER_HEX + '|' + domain)).
rank(id) = SHA-256(seed_bytes(domain) || 0x00 || UTF8(region_id)), compared as 32-byte big-endian strings; ascending."""
import csv, hashlib, sys
MASTER_HEX = hashlib.sha256(b"F1-SIGMOD2027-WORKLOAD-C-PROTOCOL-V4-MASTER-SEED").hexdigest()
def seed_bytes(domain): return hashlib.sha256((MASTER_HEX + "|" + domain).encode("utf-8")).digest()
def rank(domain, rid): return hashlib.sha256(seed_bytes(domain) + b"\x00" + rid.encode("utf-8")).digest()
if __name__ == "__main__":
    ids = sorted({r["region_id"] for r in csv.DictReader(open(sys.argv[1]))})
    if len(ids) < 24: sys.exit(f"B1 FAIL — POPULATION TARGET UNSATISFIED: {len(ids)} eligible regions")
    sel = sorted(ids, key=lambda r: rank("region-selection", r))[:24]
    spl = sorted(sel, key=lambda r: rank("validation-test", r))
    w = csv.writer(open(sys.argv[2], "w", newline="")); w.writerow(["region_id", "split", "selection_rank_hex", "split_rank_hex"])
    for i, r in enumerate(spl): w.writerow([r, "validation" if i < 8 else "test", rank("region-selection", r).hex(), rank("validation-test", r).hex()])
