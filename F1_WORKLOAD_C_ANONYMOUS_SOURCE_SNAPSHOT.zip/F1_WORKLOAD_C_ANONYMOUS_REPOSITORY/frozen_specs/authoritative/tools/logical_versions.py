"""Logical content-version chains (frozen rule, file 04). Input CSV: feed_id,archive_id,archive_observed_utc,zip_path
Output CSV: feed_id,logical_version_id,canonical_content_sha256,first_observed_utc,archive_ids(;)"""
import csv, hashlib, sys, zipfile
GTFS = {"agency.txt","stops.txt","routes.txt","trips.txt","stop_times.txt","calendar.txt","calendar_dates.txt","fare_attributes.txt",
        "fare_rules.txt","timeframes.txt","fare_media.txt","fare_products.txt","fare_leg_rules.txt","fare_leg_join_rules.txt",
        "fare_transfer_rules.txt","areas.txt","stop_areas.txt","networks.txt","route_networks.txt","shapes.txt","frequencies.txt",
        "transfers.txt","pathways.txt","levels.txt","location_groups.txt","location_group_stops.txt","locations.geojson",
        "booking_rules.txt","translations.txt","feed_info.txt","attributions.txt"}
def canonical_hash(zip_path):
    parts = []
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            name = info.filename.split("/")[-1].lower()
            if name not in GTFS or info.is_dir(): continue
            b = z.read(info)
            if b.startswith(b"\xef\xbb\xbf"): b = b[3:]
            b = b.replace(b"\r\n", b"\n")
            parts.append((name, hashlib.sha256(b).hexdigest()))
    parts.sort()
    return hashlib.sha256("\n".join(f"{n}:{h}" for n, h in parts).encode()).hexdigest()
def build(rows):
    out = []; last = {}
    for r in sorted(rows, key=lambda r: (r["feed_id"], r["archive_observed_utc"], r["archive_id"])):
        h = canonical_hash(r["zip_path"]); f = r["feed_id"]
        if f in last and last[f]["canonical_content_sha256"] == h:
            last[f]["archive_ids"].append(r["archive_id"]); continue
        n = sum(1 for o in out if o["feed_id"] == f) + 1
        rec = {"feed_id": f, "logical_version_id": f"{f}#L{n:05d}", "canonical_content_sha256": h,
               "first_observed_utc": r["archive_observed_utc"], "archive_ids": [r["archive_id"]]}
        out.append(rec); last[f] = rec
    return out
if __name__ == "__main__":
    rows = list(csv.DictReader(open(sys.argv[1])))
    w = csv.writer(open(sys.argv[2], "w", newline=""))
    w.writerow(["feed_id","logical_version_id","canonical_content_sha256","first_observed_utc","archive_ids"])
    for o in build(rows): w.writerow([o["feed_id"], o["logical_version_id"], o["canonical_content_sha256"], o["first_observed_utc"], ";".join(o["archive_ids"])])
