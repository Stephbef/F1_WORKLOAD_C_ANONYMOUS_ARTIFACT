# 10 — Oracle suite (final; 35 comparisons)

**Coverage:**
- O1–O13, O8x, O8gen: base suite.
- O14–O22: horizon closure.
- O23 / O24: agencies.
- O25 / O26 / O26z: pathways.
- **ORA1–ORA3:** Route→Agency.
- **O34:** level index.

**Expected-results ledger:** `conformance/expected/oracle_expected.csv`.

**Final from-scratch run:** 35 / 35 PASS.
