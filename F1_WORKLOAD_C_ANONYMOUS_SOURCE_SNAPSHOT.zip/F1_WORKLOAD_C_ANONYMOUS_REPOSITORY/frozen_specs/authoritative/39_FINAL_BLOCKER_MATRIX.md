# 39 — R1–R43

| Gate | Status | Note |
|---|---|---|
| R1 host audited | PASS (sandbox) / BLOCKED (target) | target not reachable |
| R2 cgroup mode supported | PASS (code: v1 + v2 + systemd) | — |
| R3 constraints proven inside scope | BLOCKED | needs target |
| R4 L28 | BLOCKED | needs target |
| R5 local seal | BLOCKED | needs R4 |
| R6–R9 Mobility snapshot / logical versions / ≥ 24 regions / licences | BLOCKED | api.mobilitydatabase.org 403 + no token |
| R10–R12 selection / split / test seal | BLOCKED | need R6–R9 (algorithms frozen) |
| R13 OSM | BLOCKED | download.geofabrik.de 403 |
| R14 producers pinned | PASS | OTP 2.10.0, validator 8.0.1, Java 25, osmium 1.16.0 |
| R15 resource envelope frozen | PASS | 14_RESOURCE_ENVELOPE_FINAL.md |
| R16–R17 protocol freeze and seal | BLOCKED | need R4–R13 |
| R18–R39 implementation, tests, seals | BLOCKED (not started) | must follow the freeze |
| R40 unauthorized campaign rejected | PASS (vacuously) | no campaign entry point exists |
| R41 campaign entry point exists | BLOCKED | not implemented |
| R42 campaign not executed | PASS | — |
| R43 integrity | PASS | 36_RESEARCH_INTEGRITY_AUDIT.md |
