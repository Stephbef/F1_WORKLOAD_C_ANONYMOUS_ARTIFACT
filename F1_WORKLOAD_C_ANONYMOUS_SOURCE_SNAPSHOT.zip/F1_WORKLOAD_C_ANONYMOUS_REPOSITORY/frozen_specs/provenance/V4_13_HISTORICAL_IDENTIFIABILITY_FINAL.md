# 13 — Historical identifiability (final; finite costs only)

**Setting:**
- Region tz L; feeds A, B.
- Schedule as in file 11.
- Γ: 7-day horizon, rollback depth 2 (logical versions).
- Costs finite: c_v (validator) ≪ c_g (OTP).

**T1 — pure witness (finite).**
- Before 02:00: ROUTER(A0, B0), VAL(A0), VAL(B0) exist.
- 02:00: no new version, so no build.
- 03:00: A1 becomes available (archive-observed). The validator starts; its runtime extends past 06:00 (queue behind another feed's job, or a long validation).
- 06:00 request: R = {VAL(A0), VAL(B0), ROUTER(A0, B0)}, the latest of each type.
  - The current cut (A1, B0) fails (K0, K1 and K2 fail for VAL(A0) at A1).
  - (A0, B0) ∈ Γ (coverage and depth) is a witness.
- **Pure witness; no re-derivation; finite costs.** N5 must re-derive at (A1, B0): VAL(A1) plus ROUTER if its contract fails.

**T2 — historical repair (finite).**
- 02:00: ROUTER(A0, B0).
- 03:00: A1 available. 04:00: VAL(A1) completes.
- 06:00: R = {VAL(A1), VAL(B0), ROUTER(A0, B0)}.
  - Current repair at (A1, B0) needs ROUTER(A1, B0) (cost c_g) under K0/K1, and under K2 if A1 changes service in the horizon.
  - Historical target (A0, B0) needs only VAL(A0) (cost c_v).
  - **OPT_hist = c_v < c_g = OPT_current.**

**T3 — tolerance without history.** A1 changes only service beyond the horizon, so ROUTER-K2 holds at (A1, B0), with VAL(A1) available.

**T4 — history cannot help.** A1 is effective immediately and A0 does not cover the horizon, so A0 ∉ Γ and a rebuild is required.

**Verdict:** all four traces exist under the final schedule with finite costs. **F21 PASS.**
