# 22 — Statistics and mutations (self-contained)

## Primary family (Holm correction)
- H_witness: HSR_witness(K0) > 0.
- H_repair: HSR_repair(K0) > 0.
- H_hist: ΔE2E_history(K2) > 0.
- H_native: Cost_F1(K2) < Cost_N1.

## Metric definitions
- **HSR_witness(K):** P[∃ c ≠ c_cur ∈ W_t(R, Γ) | c_cur ∉ W_t(R, Γ)].
- **HSR_repair(K):** P[OPT_hist < OPT_current | W_t = ∅, OPT_current > 0].
- **ΔCost_history:** OPT_current − min(OPT_current, OPT_hist).

## Units and reporting
- Unit: region × distinct root content change.
- Order:
  1. raw per-region results;
  2. number of regions;
  3. number of root changes;
  4. exact sign test;
  5. BCa bootstrap (B = 9,999; bootstrap seed);
  6. wild-cluster bootstrap (Rademacher; wild-bootstrap seed).

## Mutations
- **Sample:** sort the test artifact ids, shuffle with the mutation seed, take ceil(5 % · n).
- **Families:**
  - stop_times;
  - frequencies;
  - calendar_dates;
  - transfers;
  - block_id;
  - coordinates;
  - pathways;
  - wheelchair;
  - route_type;
  - timezones;
  - namespace;
  - horizon (3 days);
  - shapes (reverse test);
  - validator date / file.
- **V5 additions:**
  - **M-FUTURE-1:** future-only trip. Canon_D unchanged, K2 holds.
  - **M-FUTURE-2:** the same trip shifted into D. Canon_D changes, K2 rejects.
  - **M-CT:** constrained-transfer change.
  - **M-FREQ:** frequency in/out of D.
  - **M-STOP-ACTIVE / M-STOP-INACTIVE.**

## Query battery (secondary only)
- 200 OD pairs per region (query-battery seed) from street vertices within 400 m of stops.
- Departures: Tuesday 08:00 and Saturday 12:00 local; default and wheelchair profiles.
- Comparison: the (arrival, transfers) Pareto set and route sequences.
- A battery divergence with equal Canon_D is an **oracle bug**.
