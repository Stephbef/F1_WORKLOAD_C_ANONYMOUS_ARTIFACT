# 18 — Mutation preregistration (final)

**Sample:**
- sort the test artifact IDs per template;
- shuffle with the mutation seed;
- take ceil(0.05·n).

| ID | Family (matrix 07) | Mutation |
|---|---|---|
| M-ST | stop_times | drop from K2 |
| M-FQ | frequencies | drop |
| M-CD | calendar_dates | drop |
| M-TR | transfers.txt | drop |
| M-BL | block_id | drop |
| M-XY | coordinates | drop |
| M-PW | pathways / levels / entrances | drop |
| M-WC | wheelchair | drop |
| M-RT | route_type | drop |
| M-TZ | timezones | drop |
| M-NS | namespace | drop feedId binding |
| M-HZ | horizon | shortened to 3 days |
| M-SH | shapes | reverse test |
| M-VD | validator date | — |
| M-VF | validator file omission | — |

**Common to all mutations:**
- **Expected oracle change:** a Canon difference on opportunities where the omitted dependency changed.
- **Expected contract behaviour:** the mutant admits.
- **Detection:** a missing semantic dependence.
- Mutations are synthetic contract edits over real structure, and are **not** a scientific outcome.
