# 20 — Statistical analysis plan (final V4)

**Units:**
- Primary unit: region × distinct root content change (logical version).
- **Not units:** Γ variants, polls, duplicate content, request cells.

**Reporting hierarchy:**
1. Raw per-region effects.
2. Number of regions with the effect.
3. Number of distinct root changes.
4. Exact sign test.
5. BCa bootstrap (B = 9,999; bootstrap seed).
6. Wild-cluster bootstrap (Rademacher; wild-bootstrap seed).

**Multiplicity:** Holm over {H_witness(K0), H_repair(K0), H_hist(K2), H_native(K2)}. No additions after execution.
