# 17 — Cost accounting (final)

- **Primary:** steady-state warm.
- **Secondary:** cold (page cache dropped; verified possible in this environment).
- **Amortized preprocessing:**
  - street graph build;
  - OTP cache creation;
  - F1 feature/parse caches;
  - logical-version hashing.
- **Recorded:** CPU, wall, producer, contract evaluation, witness search, solver, journal/fsync, cache maintenance, storage, I/O bytes.
- **Symmetry:** identical warm state for F1, N5 and N1.
