# 18 — Region rules (self-contained)

## Eligible feeds
- GTFS Schedule, status active (not deprecated / inactive / development), no authentication.
- Bounding-box diagonal ≤ 500 km.
- Licence class A, B or C (D and E excluded).
- Logical versions computed **before** any region step (file `tools/logical_versions.py`).
- Logical history covering 2025-04-01..2026-06-30 with no gap > 30 days.

## Deduplication
- Drop redirects and duplicates.
- Collapse an identical latest URL or an identical canonical content hash.
- Drop merged bundles whose agency_id overlap with another eligible feed is ≥ 50 %.
- Collapse alias providers (normalized name).

## Feed connectivity graph
An edge F_i–F_j exists iff all of the following hold:
- ≥ 3 distinct stop pairs within 400 m (great-circle), using stops.txt of each feed's logical version in force at 2025-04-01. 400 m is about a 5-minute walk, the conventional bus-stop walking catchment.
- The convex hulls of the stop sets intersect or lie within 2 km.
- The feeds share the same agency_timezone.

## Region
- A connected component with 2–8 feeds; every feed has ≥ 1 edge.
- A component with > 8 feeds is split by removing its weakest edges (fewest pairs, then smallest feed ids) until each part has ≤ 8.
- Total latest-zip size ≤ 500 MB.
- Canonical region id: `R:` + the sorted feed ids joined by `+`.

## Selection and split
- Selection: sorted ids; Python `random.Random(region-selection seed).shuffle`; first 24.
- Split: shuffle the 24 with the validation-test seed; first 8 validation, last 16 test.
- If < 24 regions are eligible: **B1 FAIL**. The target is never reduced automatically.

## Seeds
- seed(domain) = first 64 bits of SHA-256(MASTER || '|' || domain).
- MASTER = SHA-256('F1-SIGMOD2027-WORKLOAD-C-PROTOCOL-V4-MASTER-SEED') = 0ccf15f46abd87cd62e2f17ed319cca0bf69f249a5f1a2135bbb448a1a9c9b4b.
- region-selection = 12315358096030423863.
- validation-test = 16591930606484844613.
- Other domains: tools/seeds.py.
