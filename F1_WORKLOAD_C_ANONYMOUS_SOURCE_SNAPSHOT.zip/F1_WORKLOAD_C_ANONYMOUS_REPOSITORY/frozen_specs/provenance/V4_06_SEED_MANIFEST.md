# 06 — Seed manifest (B10, frozen)

**Master:**
- MASTER = SHA-256("F1-SIGMOD2027-WORKLOAD-C-PROTOCOL-V4-MASTER-SEED")
- This is a public, outcome-independent label.

**Domain seeds:**
- seed(domain) = first 64 bits of SHA-256(MASTER || "|" || domain), as an unsigned integer.
- Implementation: `tools/seeds.py`.

**Values:**
```
MASTER 0ccf15f46abd87cd62e2f17ed319cca0bf69f249a5f1a2135bbb448a1a9c9b4b
region-selection 12315358096030423863
validation-test 16591930606484844613
mutation 17400222729329553666
query-battery 886775004358718833
bootstrap 3159872451478059269
wild-bootstrap 10415707003536326787
od-sampling 1434794816599162115
harness 9485707173891747959
```

**Usage:**

| Seed | Used for | Library |
|---|---|---|
| region-selection | Python 3.12 `random.Random(seed).shuffle` over sorted region IDs | `select_regions.py` |
| validation-test | Shuffle of the selected 24 | `select_regions.py` |
| mutation | Selection of 5 % of test artifacts | sorted IDs, then shuffle, then take ceil(0.05·n) |
| query-battery | OD sampling | file 19 |
| bootstrap / wild-bootstrap | Resampling | numpy `default_rng(seed)` |
| harness | Test harness | — |

**Scope:** no other randomness is permitted.
