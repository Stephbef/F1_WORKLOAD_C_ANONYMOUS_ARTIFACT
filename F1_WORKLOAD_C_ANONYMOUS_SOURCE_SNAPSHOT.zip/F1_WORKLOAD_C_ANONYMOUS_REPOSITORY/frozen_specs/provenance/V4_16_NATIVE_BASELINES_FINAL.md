# 16 — Native baselines (final)

## N1 — strongest fair OTP
- Persisted street graph (`--buildStreet` once; `--loadStreet --save`).
- OTP 2.10 graph-build cache (`cache.enabled = true`).
- Same frozen OSM; warm page cache.
- Builds are CLI processes, since OTP offers no persistent build server, so a warm JVM is not claimed.
- Executed mechanically on fixtures; semantics unchanged (D5).

## N5 — history ablation
- Same K contracts, evaluator, caches, producer timing and costs, current state, Γ and artifact availability as F1.
- Current cut only.
- ΔE2E_history(K2) = Cost_N5(K2) − Cost_F1(K2) is the **primary** value-of-history measure.

## Others
N0, N2, N3, N4 and N6 as in V3.
