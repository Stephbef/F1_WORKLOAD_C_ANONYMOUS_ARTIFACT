# 02 — Licence policy (B2): policy frozen, ledger BLOCKED

**Deterministic classes:**

| Class | Meaning | Treatment |
|---|---|---|
| A | Licence explicitly permits redistribution (e.g., CC BY, CC0, ODbL, an open government licence with redistribution) | Include; raw zips may ship in the artifact, with attribution |
| B | Use and retrieval permitted, redistribution not granted or silent | Include; the artifact ships dataset IDs + SHA-256 + a re-download script, never raw zips |
| C | Unclear: no licence URL, or terms unreadable | **Exclude** |
| D | Incompatible (research or derivative use prohibited, or login-only terms) | **Exclude** |

**Derived data:** hashes, counts and canonical digests may be released for A and B.

**Ledger status:** BLOCKED. Licence texts need the live catalog (B1).
