# 18 — Statistical analysis plan V2

## Units
| Unit | Definition |
|---|---|
| Region | Cluster; 16 test (if the population allows, see file 03) |
| Feed | Nested in region |
| Root change | One feed-version publication (feed, dataset) |
| Evaluation instant | Daily request |
| Γ variant | Sensitivity only, never a unit |
| Artifact, joint request | Descriptive |

## Primary prevalence (H_witness, H_repair)
- **Unit:** region × root change. A root change counts once if any request in its influence period shows the outcome under the primary Γ.
- Report:
  - number of regions with ≥ 1 event;
  - number of root changes;
  - proportion per region.

## Inference with about 16 clusters
- **Region-level paired differences** (economics: F1 − N5, F1 − N1, per region, totals over the window):
  - exact two-sided **sign test** on the region signs;
  - **BCa cluster bootstrap** (B = 9,999) for the mean difference;
  - **wild-cluster bootstrap** (Rademacher weights) as a robustness check.
- **Prevalence:** BCa cluster bootstrap for the per-region proportion. The exact binomial over regions applies for "≥ 1 event in a region".
- **Rationale.** Percentile bootstrap undercovers with few clusters. Sign and BCa tests remain valid at about 16 units. Wild-cluster handles heteroskedastic regions.

## Shared dependencies
- There is no shared global input across regions: the OSM extracts are per region, and producer versions are identical by design.
- Same-country clusters are reported, with a country-blocked sensitivity analysis.

## Multiplicity
- Holm correction over the 4 primary hypotheses.
- Everything else is descriptive and labelled as such.

## Inconclusive rule
- Fewer than 3 regions contributing events ⇒ INCONCLUSIVE.
- A CI that includes 0 ⇒ INCONCLUSIVE.

## Validation regions
Used only for TTL τ.
