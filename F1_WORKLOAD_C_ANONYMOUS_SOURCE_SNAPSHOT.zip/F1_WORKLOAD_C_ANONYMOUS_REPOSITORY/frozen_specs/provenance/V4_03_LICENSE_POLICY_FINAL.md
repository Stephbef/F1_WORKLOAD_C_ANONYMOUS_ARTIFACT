# 03 — Licence policy (final): policy FROZEN, ledger BLOCKED

**Classes:**

| Class | Meaning | Treatment |
|---|---|---|
| A | Raw redistribution permitted | Publish raw zips |
| B | Research processing permitted, redistribution constrained | Publish Mobility Database IDs, URLs, hashes, derived metadata and Canon digests only |
| C | Attribution required (combinable with A or B) | Attribution file in the artifact |
| D | Unclear | **Excluded** before selection |
| E | Incompatible | **Excluded** before selection |

**Artifact contents always published:**
- benchmark scripts;
- Mobility Database IDs;
- hashes;
- logical-version ledger;
- Canon digests.

**Ledger:** requires B1.
