# 10 — Region connectivity and consumer time (B10)

## Feed connectivity graph

**Vertices:** eligible feeds (file 01 filters).

**Edge F_i–F_j** if **all** of the following hold:
- **(a) Stop proximity.** At least 3 distinct stop pairs (stop of F_i, stop of F_j) within 400 m great-circle distance, computed on the stops.txt of each feed's logical version **at window start**.
  - *400 m rationale:* about a 5-minute walk, the walking catchment conventionally used for bus-stop access in transit planning.
  - The threshold is frozen now and is not tuned.
  - Requiring 3 pairs avoids a single coincidental pair.
- **(b) Overlap.** The convex hulls of the two stop sets intersect, or are within 2 km.
- **(c) Same timezone.** Both feeds share agency_timezone.

**Region:**
- a connected component with 2–8 feeds;
- every feed must have ≥ 1 edge;
- components larger than 8 are split by removing the weakest edges (fewest qualifying pairs, then smallest feed IDs) until each part has ≤ 8.

**Street connectivity:** the frozen OSM extract must contain all stops (each within 100 m of a routable street after OTP linking; checked at S0c on the latest version, not the scientific window).

## Consumer time
- 06:00 **local** region time.
- Timezone = the shared agency_timezone.
- DST rules per file 06.
