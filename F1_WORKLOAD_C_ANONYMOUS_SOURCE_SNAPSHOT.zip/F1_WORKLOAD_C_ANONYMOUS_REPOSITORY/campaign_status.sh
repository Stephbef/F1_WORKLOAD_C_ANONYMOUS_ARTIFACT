#!/usr/bin/env bash
# Read-only status of a one-shot campaign: ./campaign_status.sh /data/f1_workload_c
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[ $# -eq 1 ] || { echo "usage: $0 <work-root>" >&2; exit 2; }
PYTHONPATH="$HERE/src" exec "${PYTHON:-python3}" -c 'import sys; from f1.workload_c.oneshot.cli import status_main; sys.exit(status_main(sys.argv[1:]))' "$1"
