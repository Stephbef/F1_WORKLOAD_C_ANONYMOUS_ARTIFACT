# Anonymization Notes

This review artifact was derived from the frozen implementation by packaging-only transformations:

1. removed the previous Git bundle/history and package-delivery identity files;
2. removed sandbox environment and internal delivery logs not needed for scientific reproduction;
3. replaced non-scientific sandbox filesystem paths in legacy engineering evidence;
4. initialized a fresh anonymous Git history;
5. added `ANONYMIZED_REVIEW_ARTIFACT` and changed only Git-ancestry assertions in tests so historical private commits are not required in the anonymous repository;
6. replaced the top-level README with a reviewer-facing anonymous README.

No file under `src/`, `configs/workload_c/`, or `frozen_specs/` was modified for anonymization.

The reports retained in `reports/` are engineering/gate evidence and do not contain authoritative study outcomes.
