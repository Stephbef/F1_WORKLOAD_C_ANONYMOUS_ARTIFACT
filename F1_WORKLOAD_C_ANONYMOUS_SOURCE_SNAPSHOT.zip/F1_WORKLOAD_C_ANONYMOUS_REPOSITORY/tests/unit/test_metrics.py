import math

from f1.statistics.metrics import cluster_bootstrap, joint_metrics, macro, repair_metrics, unary_metrics, unit_rates


def row(aid, cl, split, use, age, k0, k1=None, b1=None, cost=10.0):
    r = {"artifact_id": aid, "cluster": cl, "split": split, "use": use, "age_s": age, "cost_s": cost, "B1": k0 if b1 is None else b1}
    for c in ("K0", "K1", "K2", "K3"):
        v = k0 if c == "K0" else (k1 if k1 is not None else k0)
        r[f"{c}_eff"], r[f"{c}_raw"], r[f"{c}_eval_s"], r[f"{c}_fallback"] = v, v, 0.5, False
        r[f"{c}_check_s"] = 0.5
    return r


def test_macro_vs_micro():
    acc = {"a": ["c", 1, 1], "b": ["c", 0, 3]}
    assert macro(acc) == 0.5
    assert abs(sum(v[1] for v in acc.values()) / sum(v[2] for v in acc.values()) - 0.25) < 1e-12


def test_unary_formulas_and_ttl_validation_only():
    rows = [
        # artifact a: usable twice, hash rejects both -> M1 rate 1.0 for a; K1 accepts both
        row("a", "c1", "test", True, 3600, False, True), row("a", "c1", "test", True, 7200, False, True),
        # artifact b: one unusable pair accepted by K1 (unsafe), one usable rejected by all
        row("b", "c2", "test", False, 3600, False, True), row("b", "c2", "test", True, 90000, False, False),
        # validation rows: short ages usable, long ages unusable -> tau* = 3600
        row("v", "c3", "validation", True, 3600, False), row("v", "c3", "validation", False, 90000, False),
    ]
    m = unary_metrics(rows, [3600, 86400 * 2], B=50, seed=1)
    assert m["M1_hash_overinvalidation"]["macro"] == (1.0 + 0.5) / 2
    assert m["M3"]["K1"]["recall"]["macro"] == (1.0 + 0.0) / 2
    assert m["M3"]["K1"]["unsafe_admission"]["macro"] == (0.0 + 0.5) / 2
    assert m["M3"]["K1"]["unsafe_count"] == 1
    assert m["tau_star_s"] == 3600
    # M2 at tau*=3600 on test: pair b/3600 unusable & age<=tau -> b rate 0.5, a rate 0
    assert m["M2_ttl_unsafe_admission_at_tau_star"]["macro"] == 0.25
    # G1 net benefit for K1: a: 2*(10-0.5); b: (0-0.5)+(0-0.5)  -> mean over 4 pairs
    assert abs(m["M3"]["K1"]["net_benefit_per_pair_s"] - (2 * 9.5 - 1.0) / 4) < 1e-12


def test_joint_and_repair_formulas():
    base = {"cluster": "c", "scenario": "dash", "cell": "x"}
    rows = [dict(base, event_id="e1", oracle_unary=[True, True], oracle_W_nonempty=False,
                 **{f"{c}_unary": [True, True] for c in ("K0", "K1", "K2", "K3")}, **{f"{c}_admitted": False for c in ("K0", "K1", "K2", "K3")}),
            dict(base, event_id="e2", oracle_unary=[True, False], oracle_W_nonempty=False,
                 **{f"{c}_unary": [True, False] for c in ("K0", "K1", "K2", "K3")}, **{f"{c}_admitted": False for c in ("K0", "K1", "K2", "K3")})]
    j = joint_metrics(rows, B=20, seed=1)
    assert j["dash/x"]["M4_oracle"]["macro"] == 0.5
    assert j["dash/x"]["K0"]["naive_composition_error"]["macro"] == 0.5
    rr = [dict(base, event_id="e1", cls="K0", opt_cost=2.0, recompute_all=8.0, current_cut_cost=4.0, solver_s=0.1, feasible=True)]
    r = repair_metrics(rr, B=20, seed=1)
    assert r["dash/x/K0"]["M5_savings_vs_recompute_all"]["macro"] == 0.75
    assert r["dash/x/K0"]["M5_savings_vs_current_cut"]["macro"] == 0.5


def test_bootstrap_ci_brackets_estimate():
    acc = {f"u{i}": [f"c{i % 4}", float(i % 3 == 0), 1.0] for i in range(40)}
    ci = cluster_bootstrap(acc, B=300, seed=3)
    assert ci["lo"] <= macro(acc) <= ci["hi"]
