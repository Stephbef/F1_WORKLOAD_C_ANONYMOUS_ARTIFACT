import itertools

import pytest

from conftest import DAY, put_json
from f1.common.util import F1Error
from f1.core.gamma import Gamma
from f1.core.history import History, Version, read_history_parquet, write_history_parquet


def hist(cas):
    vs = [Version("x", "x0", 0, put_json(cas, 0)), Version("x", "x1", 10, put_json(cas, 1)), Version("x", "x2", 20, put_json(cas, 2)),
          Version("u", "u0", 1, put_json(cas, "a")), Version("u", "u1", 15, put_json(cas, "b"))]
    # u1 was derived from x1
    return History(vs, [(("x", "x1"), ("u", "u1"))])


def test_version_order_and_latest(cas):
    h = hist(cas)
    assert [v.vid for v in h.items["x"]] == ["x0", "x1", "x2"]
    assert h.latest_cut(12) == {"x": "x1", "u": "u0"}
    assert h.latest_cut(-1) is None
    assert h.current("x", 25).vid == "x2"


def test_cut_consistency_causal(cas):
    h = hist(cas)
    assert h.is_consistent({"x": "x1", "u": "u1"})
    assert h.is_consistent({"x": "x2", "u": "u1"})
    assert not h.is_consistent({"x": "x0", "u": "u1"})  # u1 depends on x1
    assert not h.is_consistent({"x": "x0"})              # incomplete cut


def test_transitive_requirements(cas):
    vs = [Version("a", "a0", 0, put_json(cas, 0)), Version("b", "b0", 1, put_json(cas, 0)), Version("c", "c0", 2, put_json(cas, 0)),
          Version("a", "a1", 3, put_json(cas, 1))]
    h = History(vs, [(("a", "a0"), ("b", "b0")), (("b", "b0"), ("c", "c0"))])
    assert h.requires("c", "c0") == {"a": 0, "b": 0}


def test_enumeration_equals_filtered_product(cas):
    h = hist(cas)
    allowed = {"x": ["x2", "x1", "x0"], "u": ["u1", "u0"]}
    got = list(h.enumerate_cuts(allowed))
    want = [dict(zip(["u", "x"], c)) for c in itertools.product(allowed["u"], allowed["x"]) if h.is_consistent(dict(zip(["u", "x"], c)))]
    assert sorted(map(str, got)) == sorted(map(str, want))
    assert all(h.is_consistent(c) for c in got)


def test_cycle_and_duplicate_rejected(cas):
    with pytest.raises(F1Error):
        History([Version("a", "v", 0, "h"), Version("a", "v", 1, "h")])
    vs = [Version("a", "a0", 0, "h"), Version("b", "b0", 0, "h")]
    with pytest.raises(F1Error):
        History(vs, [(("a", "a0"), ("b", "b0")), (("b", "b0"), ("a", "a0"))])


def test_parquet_roundtrip(cas, tmp_path):
    h = hist(cas)
    write_history_parquet(h.to_rows("c1"), tmp_path / "h.parquet")
    h2 = History.from_rows(read_history_parquet(tmp_path / "h.parquet")["c1"])
    assert h2.fingerprint() == h.fingerprint()


def test_gamma_rules(cas):
    h = hist(cas)
    assert Gamma("g", 25, {"x": {"latest": True}}, default="any").allowed(h)["x"] == ["x2"]
    assert Gamma("g", 25, {"x": {"last_k": 2}}).allowed(h)["x"] == ["x2", "x1"]
    # window: versions current at some instant in [t-w, t]: x1 was current at 25-12=13
    assert Gamma("g", 25, {"x": {"window_s": 12}}).allowed(h)["x"] == ["x2", "x1"]
    assert Gamma("g", 25, {"x": {"window_s": 0}}).allowed(h)["x"] == ["x2"]
    assert Gamma("g", 25, {"x": {"fixed": ["x0"]}}).allowed(h)["x"] == ["x0"]
    assert Gamma("g", 12, {"x": {"any": True}}).allowed(h)["x"] == ["x1", "x0"]
    g = Gamma("g", 25, {"x": {"last_k": 2}, "u": {"latest": True}})
    assert g.contains(h, {"x": "x1", "u": "u1"}) and not g.contains(h, {"x": "x0", "u": "u1"})
    assert Gamma.from_json(g.to_json()).digest() == g.digest()
