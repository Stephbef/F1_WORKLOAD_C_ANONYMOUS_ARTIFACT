import json
import pytest

from conftest import in_set, put_json
from f1.contracts.lang import Contract, ContractError, Evaluator, FootprintViolation, assert_k1_structure, disclosure_metrics, validate
from f1.core.history import History, Version


def F(item, f="test_value", **args):
    n = {"op": "feat", "item": item, "f": f}
    if args:
        n["args"] = args
    return n


def C(v):
    return {"op": "const", "v": v}


def test_validation_and_footprint():
    assert validate({"op": "and", "args": [{"op": "eq", "a": F("a"), "b": C(1)}, {"op": "le", "a": F("b"), "b": C(2)}]}) == {"a", "b"}
    with pytest.raises(ContractError):
        validate({"op": "bogus"})
    with pytest.raises(ContractError):
        validate({"op": "feat", "item": "a", "f": "no_such_feature"})
    with pytest.raises(ContractError):
        Contract.from_json({"artifact_id": "r", "cls": "K2", "footprint": ["z"], "expr": {"op": "eq", "a": F("a"), "b": C(1)}})


def test_k1_structure_excludes_thresholds_branches_and_logic():
    assert_k1_structure({"op": "and", "args": [{"op": "eq", "a": F("a"), "b": C(1)}]})
    for bad in ({"op": "le", "a": F("a"), "b": C(1)},
                {"op": "or", "args": [{"op": "eq", "a": F("a"), "b": C(1)}]},
                {"op": "and", "args": [{"op": "not", "a": {"op": "eq", "a": F("a"), "b": C(1)}}]},
                {"op": "and", "args": [{"op": "eq", "a": {"op": "setminus", "a": F("a"), "b": C([])}, "b": C([])}]}):
        with pytest.raises(ContractError):
            Contract.build("r", "K1", bad)


def test_disclosure_metrics():
    m = disclosure_metrics({"op": "and", "args": [{"op": "le", "a": F("a"), "b": C(1)}, {"op": "eq", "a": F("a"), "b": C(2)}]})
    assert m["n_order_comparisons"] == 1 and m["n_feature_refs"] == 2 and m["n_distinct_features"] == 1


def test_evaluator_sandbox_memo_and_ops(cas, loader):
    ra, rb = put_json(cas, 5), put_json(cas, ["k1|x", "k2|y"])
    ev = Evaluator(loader)
    c = Contract.build("r", "K2", {"op": "le", "a": F("a"), "b": C(7)})
    assert ev.evaluate(c, {"a": ra}.__getitem__)[0] is True
    assert ev.evaluate(c, {"a": ra}.__getitem__)[2] is True  # footprint-transfer memo hit
    dk = Contract.build("r", "K2", {"op": "eq", "a": {"op": "drop_keys", "a": F("b"), "b": C(["k1"])}, "b": C(["k2|y"])})
    assert ev.evaluate(dk, {"b": rb}.__getitem__)[0] is True
    # undefined statistic never satisfies an order comparison
    rn = put_json(cas, None)
    assert ev.evaluate(c, {"a": rn}.__getitem__)[0] is False


def test_sandbox_blocks_items_outside_footprint(cas, loader):
    from f1.contracts.lang import ItemView, _eval
    views = {"a": ItemView("a", put_json(cas, 1), loader)}
    with pytest.raises(FootprintViolation):
        _eval({"op": "eq", "a": F("b"), "b": C(1)}, views, {})


def test_K1_workload_B_is_complete_feature_disclosure_without_thresholds(cas, loader):
    """Formal K1 decision for workload B: K1 must pin EVERY decision statistic (completeness => soundness) and may
    never contain thresholds/branches (G3). On growing tables continuous statistics change, so K1 = K0 there."""
    from f1.contracts.lang import assert_k1_structure, walk
    from f1.producers.dq import DQProducer
    checks = [{"id": "n", "stat": {"kind": "null_fraction", "col": "a"}, "op": "le", "thr": 0.1},
              {"id": "p", "stat": {"kind": "present", "col": "a"}, "op": "ge", "thr": 1},
              {"id": "q", "stat": {"kind": "quantile", "col": "a", "q": 0.9}, "op": "le", "thr": 5}]
    p = DQProducer(checks, uses_ref=False, policy_id="t")
    out = {"gate": "PASS", "issues": [], "stats": {"n": 0.05, "p": 1.0, "q": 3.0}}
    k1 = p.contracts("dq_gate", {}, None, loader, out)["K1"]
    assert_k1_structure(k1)
    pinned = sorted(json.dumps(n["args"]["stat"], sort_keys=True) for n in walk(k1) if n["op"] == "feat")
    assert pinned == sorted(json.dumps(c["stat"], sort_keys=True) for c in checks)
    assert not any(n["op"] in ("le", "lt", "ge", "gt") for n in walk(k1))
