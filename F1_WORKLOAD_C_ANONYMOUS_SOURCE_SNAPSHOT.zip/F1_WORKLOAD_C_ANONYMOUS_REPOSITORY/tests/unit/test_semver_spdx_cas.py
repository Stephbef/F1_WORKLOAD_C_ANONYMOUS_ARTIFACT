import gzip

import pytest

from f1.common.util import CAS, F1Error
from f1.producers.license_spdx import dnf, evaluate, satisfied
from f1.producers.rustsec import (affecting_triples, allowed_licenses_from, parse_advisory, parse_policy,
                                  policy_ignores_from, registry_packages, req_matches)

SEMVER = [(">= 1.2.3", "1.2.3", 1), (">= 1.2.3", "1.2.2", 0), ("^0.9.5", "0.9.7", 1), ("^0.9.5", "0.10.0", 0),
          ("^1.2", "1.9.0", 1), ("^1.2", "2.0.0", 0), ("^0.0.3", "0.0.4", 0), ("< 0.1", "0.0.9", 1), ("< 0.1", "0.1.0", 0),
          ("~1.2.3", "1.2.9", 1), ("~1.2.3", "1.3.0", 0), ("=1.2", "1.2.7", 1), ("=1.2", "1.3.0", 0), (">1.2", "1.3.0", 1),
          (">1.2", "1.2.9", 0), ("<=1.2", "1.2.9", 1), ("<=1.2", "1.3.0", 0), (">= 1.0.0, < 1.5.0", "1.4.9", 1),
          (">= 1.0.0, < 1.5.0", "1.5.0", 0), ("1.*", "1.9.9", 1), ("1.*", "2.0.0", 0), ("*", "3.4.5", 1),
          (">= 1.0.0", "1.1.0-beta.1", 0), (">= 1.1.0-alpha", "1.1.0-beta.1", 1), ("^0.2.0-alpha.1", "0.2.0-alpha.2", 1)]


@pytest.mark.parametrize("req,ver,exp", SEMVER)
def test_cargo_semver(req, ver, exp):
    assert req_matches(req, ver) is bool(exp)


LOCK = '''version = 3
[[package]]
name = "a"
version = "1.0.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
[[package]]
name = "b"
version = "0.3.1"
source = "sparse+https://index.crates.io/"
[[package]]
name = "local"
version = "0.1.0"
'''


def test_lock_and_advisory_matching():
    assert registry_packages(LOCK) == ["a@1.0.0", "b@0.3.1"]
    adv = parse_advisory('```toml\n[advisory]\nid = "RUSTSEC-1"\npackage = "a"\n[versions]\npatched = [">= 1.0.1"]\n```\n', "crates/a/RUSTSEC-1.md")
    info = parse_advisory('```toml\n[advisory]\nid = "RUSTSEC-2"\npackage = "b"\ninformational = "unmaintained"\n[versions]\npatched = []\n```', "x.md")
    db = {"a": [adv], "b": [info]}
    assert affecting_triples(db, ["a@1.0.0", "b@0.3.1"]) == ["RUSTSEC-1|a|1.0.0"]
    assert affecting_triples(db, ["a@1.0.1"]) == []


def test_policy_parsing():
    pol = parse_policy('[advisories]\nignore = ["RUSTSEC-1", {id = "RUSTSEC-9", reason = "x"}]\n[licenses]\nallow = ["MIT"]\n')
    assert policy_ignores_from(pol) == ["RUSTSEC-1", "RUSTSEC-9"]
    assert allowed_licenses_from(pol, ["Apache-2.0"]) == ["MIT"]
    assert allowed_licenses_from({}, ["Apache-2.0"]) == ["Apache-2.0"]
    assert "__unparsable__" in parse_policy("[[[broken")


def test_spdx():
    assert dnf("MIT OR Apache-2.0") == [frozenset({"Apache-2.0"}), frozenset({"MIT"})]
    assert satisfied("MIT/Apache-2.0", {"Apache-2.0"})
    assert satisfied("(MIT OR Apache-2.0) AND Unicode-DFS-2016", {"MIT", "Unicode-DFS-2016"})
    assert not satisfied("MIT AND GPL-3.0", {"MIT"})
    assert satisfied("Apache-2.0 WITH LLVM-exception", {"Apache-2.0"})
    assert not satisfied(None, {"MIT"}) and dnf("MIT AND (") is None
    out = evaluate(["a@1", "b@2"], {"a@1": "MIT", "b@2": None}, ["MIT"])
    assert out == {"gate": "FAIL", "issues": ["b@2|None"]}


def test_cas_roundtrip_raw_tree_and_corruption(tmp_path):
    cas = CAS(tmp_path / "c")
    h = cas.put(b"hello")
    assert cas.get(h) == b"hello"
    p = cas.put(b"PAR1....PAR1")
    assert cas.raw_path(p) is not None and cas.get(p) == b"PAR1....PAR1"
    t = cas.put_tree({"a/x.txt": b"1", "b.txt": b"2"})
    out = cas.materialize(t, tmp_path / "m")
    assert (out / "a" / "x.txt").read_bytes() == b"1"
    gz = cas._path(h)
    gz.write_bytes(gzip.compress(b"tampered"))
    with pytest.raises(F1Error):
        cas.get(h)
