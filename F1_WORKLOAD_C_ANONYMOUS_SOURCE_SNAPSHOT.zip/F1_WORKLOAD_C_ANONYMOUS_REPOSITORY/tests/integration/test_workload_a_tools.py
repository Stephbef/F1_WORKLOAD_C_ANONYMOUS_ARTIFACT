"""Workload-A producer integration with the real pinned cargo-audit (skipped when tools/dev data are absent).
Cross-checks our K3 re-implementation of the matching rule against cargo-audit on several real
(lockfile, advisory-DB snapshot) pairs: an engineering U1 diagnostic on development data only."""
import subprocess
from pathlib import Path

import pytest

from conftest import ROOT
from f1.common.loader import Loader
from f1.common.util import CAS
from f1.contracts.lang import FEATURES, ItemView
from f1.core.history import History, Version
from f1.producers.cargo_audit import CargoAuditProducer

BIN = ROOT / "tools" / "cargo-audit"
ADB = ROOT / "work" / "dev_a" / "data" / "cache" / "git" / "advisory-db.git"
HEX = ROOT / "work" / "dev_a" / "data" / "cache" / "git" / "sharkdp__hexyl.git"
pytestmark = pytest.mark.skipif(not (BIN.exists() and ADB.exists() and HEX.exists()),
                                reason="needs tools/cargo-audit and dev clones (run scripts/dev_smoke_a.sh)")


def git(repo, *a):
    return subprocess.run(["git", "-C", str(repo), *a], capture_output=True, check=True).stdout


def db_tree(cas, commit):
    files = {}
    for line in git(ADB, "ls-tree", "-r", commit, "--", "crates").decode().splitlines():
        meta, path = line.split("\t", 1)
        files[path] = git(ADB, "cat-file", "blob", meta.split()[2])
    return cas.put_tree(files)


def test_k3_matches_cargo_audit_on_real_pairs(tmp_path):
    cas = CAS(tmp_path / "cas")
    loader = Loader(cas)
    locks = git(HEX, "log", "--format=%H", "HEAD", "--", "Cargo.lock").decode().split()[::12][:4]
    dbs = [git(ADB, "rev-list", "-1", f"--before={d}", "HEAD").decode().strip() for d in ("2023-03-01", "2024-01-01", "2025-06-01")]
    vs = [Version("P", "p0", 0, cas.put(b""))]
    for i, c in enumerate(locks):
        vs.append(Version("S", f"s{i}", i, cas.put(git(HEX, "show", f"{c}:Cargo.lock"))))
    for j, c in enumerate(dbs):
        vs.append(Version("V", f"v{j}", j, db_tree(cas, c)))
    h = History(vs)
    p = CargoAuditProducer(str(BIN), tmp_path / "dbcache")
    checked = 0
    for s in h.items["S"]:
        for v in h.items["V"]:
            cut = {"S": s.vid, "V": v.vid, "P": "p0"}
            res, out = p.execute(cut, h, cas, tmp_path / "sb")
            assert res.status == "ok", res.stderr_tail
            assert res.hidden_reads == [] and res.net_attempts == 0
            views = [ItemView(i, h.content(cut, i), loader) for i in ("P", "S", "V")]
            assert FEATURES["k3_vuln"](views, mode="report") == out["report"], (cut, out)
            checked += 1
    assert checked == len(locks) * len(dbs)
