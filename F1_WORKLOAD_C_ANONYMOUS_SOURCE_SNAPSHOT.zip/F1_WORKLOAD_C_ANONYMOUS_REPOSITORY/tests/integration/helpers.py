import copy
import os
import subprocess
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]


def make_config(tmp: Path, **overrides) -> Path:
    cfg = yaml.safe_load((ROOT / "configs" / "smoke_synthetic.yaml").read_text())
    cfg["root"] = str(ROOT)
    cfg["paths"] = {"data": str(tmp / "data"), "outputs": str(tmp / "out"), "work": str(tmp / "work"),
                    "configs": str(ROOT / "configs"), "frozen": str(tmp / "FREEZE_MANIFEST.json")}
    cfg["synthetic"].update({"n_clusters": 3, "n_x_versions": 12, "birth_days": 6, "horizon_days": 4})
    cfg["statistics"]["bootstrap"] = 50
    for k, v in overrides.items():
        if isinstance(v, dict) and isinstance(cfg.get(k), dict):
            cfg[k].update(v)
        else:
            cfg[k] = v
    p = tmp / "cfg.yaml"
    p.write_text(yaml.safe_dump(cfg))
    return p


def run_f1(*args, check=True):
    env = dict(os.environ, PYTHONPATH=str(ROOT / "src"))
    p = subprocess.run([sys.executable, "-m", "f1", *args], capture_output=True, text=True, env=env, timeout=1800)
    if check and p.returncode != 0:
        raise AssertionError(f"f1 {args} failed ({p.returncode}):\n{p.stdout[-3000:]}\n{p.stderr[-3000:]}")
    return p
