"""Failure injection, determinism detection and producer integration (engineering only)."""
import json
import math
import os
from pathlib import Path

import pytest

from conftest import make_artifact, put_json
from helpers import make_config, run_f1
from f1.admission.engine import AdmissionEngine, effective_contracts
from f1.common.util import F1Error
from f1.contracts.lang import Contract, Evaluator
from f1.core.gamma import Gamma
from f1.core.history import History, Version
from f1.producers.synthetic import SyntheticProducer
from f1.repair.solvers import opt_bnb, opt_bruteforce


def syn_history(cas):
    return History([Version("X", "x0", 0, put_json(cas, [5.0])), Version("P", "p0", 0, put_json(cas, {"version": "v1", "limit": 10.0}))])


def test_producer_crash_is_an_error_not_a_success(cas, tmp_path):
    h = syn_history(cas)
    res, out = SyntheticProducer(crash=True).execute({"X": "x0", "P": "p0"}, h, cas, tmp_path)
    assert res.status == "error" and out is None and "injected producer crash" in res.stderr_tail


def test_producer_timeout(cas, tmp_path):
    h = syn_history(cas)
    res, out = SyntheticProducer(sleep_s=5, timeout_s=1).execute({"X": "x0", "P": "p0"}, h, cas, tmp_path)
    assert res.status == "timeout" and out is None


def test_hidden_read_is_detected(cas, tmp_path):
    secret = tmp_path / "outside_secret.txt"
    secret.write_text("x")
    h = syn_history(cas)
    res, out = SyntheticProducer(hidden_read=str(secret)).execute({"X": "x0", "P": "p0"}, h, cas, tmp_path / "sb")
    assert res.status == "ok"
    assert str(secret.resolve()) in res.hidden_reads, res.hidden_reads
    assert res.trace_method != "none"


def test_clean_run_has_no_hidden_reads_and_is_deterministic(cas, tmp_path):
    h = syn_history(cas)
    outs = []
    for k in range(3):
        res, out = SyntheticProducer().execute({"X": "x0", "P": "p0"}, h, cas, tmp_path / f"sb{k}")
        assert res.status == "ok" and res.hidden_reads == [] and res.net_attempts == 0
        outs.append(out)
    assert outs[0] == outs[1] == outs[2]


def test_missing_binary_and_digest_mismatch(tmp_path):
    from f1.producers.cargo_audit import CargoAuditProducer
    with pytest.raises(F1Error):
        CargoAuditProducer(str(tmp_path / "nope"), tmp_path)
    fake = tmp_path / "fake"
    fake.write_text("#!/bin/sh\n")
    with pytest.raises(F1Error):
        CargoAuditProducer(str(fake), tmp_path, expected_sha256="0" * 64)


def test_missing_contract_falls_back_to_k0(cas):
    h = syn_history(cas)
    a = make_artifact("r", h, {"X": "x0", "P": "p0"}, ["X", "P"], {})
    disj, fell_back = effective_contracts(a, "K2")
    assert fell_back and [c.cls for c in disj] == ["K0"]
    a.contracts.pop("K0")
    with pytest.raises(F1Error):
        effective_contracts(a, "K0")


def test_infinite_cost_is_a_hard_constraint(cas, loader):
    vs = [Version("X", "x0", 0, put_json(cas, "x0")), Version("X", "x1", 1, put_json(cas, "x1"))]
    h = History(vs)
    from conftest import in_set
    a1 = make_artifact("a1", h, {"X": "x0"}, ["X"], {"K2": in_set("X", ["x0"])}, cost=math.inf)
    a2 = make_artifact("a2", h, {"X": "x1"}, ["X"], {"K2": in_set("X", ["x1"])}, cost=3.0)
    eng = AdmissionEngine(h, Evaluator(loader))
    allowed = Gamma("g", 2, {"X": {"any": True}}).allowed(h)
    sat = lambda i, c: eng.kappa_eff([a1, a2][i], "K2", c)[0]
    r = opt_bnb(h, allowed, [math.inf, 3.0], sat, [["X"], ["X"]])
    assert r["opt_cut"] == {"X": "x0"} and r["Q"] == [1] and r["opt_cost"] == 3.0
    a3 = make_artifact("a3", h, {"X": "x1"}, ["X"], {"K2": in_set("X", ["x1"])}, cost=math.inf)
    sat3 = lambda i, c: eng.kappa_eff([a1, a3][i], "K2", c)[0]
    assert opt_bruteforce(h, allowed, [math.inf, math.inf], sat3)["opt_cost"] == math.inf


def test_broken_dataset_version_is_detected(cas):
    ref = cas.put(b"some content")
    p = cas._path(ref)
    p.write_bytes(b"not gzip at all")
    with pytest.raises(Exception):
        cas.get(ref)


def test_nondeterministic_producer_is_detected_and_excluded(tmp_path):
    cfg = make_config(tmp_path, synthetic={"producer_params": {"syn-a": {"nondeterministic": True}}},
                      determinism={"birth_replicas": 3, "sample_fraction": 0.5})
    run_f1("full", "--config", str(cfg))
    run = tmp_path / "out" / "smoke-synthetic"
    det = json.loads((run / "oracle" / "determinism.json").read_text())
    assert len(det["nondeterministic_inputs"]) > 0
    m = json.loads((run / "statistics" / "metrics.json").read_text())
    assert m["exclusions"].get("nondeterministic_producer_input", 0) > 0


def test_all_births_failing_stops_the_run(tmp_path):
    cfg = make_config(tmp_path, synthetic={"producer_params": {"syn-a": {"crash": True}, "syn-b": {"crash": True}}})
    p = run_f1("full", "--config", str(cfg), check=False)
    assert p.returncode != 0 and "no artifact could be produced" in (p.stdout + p.stderr)
    fails = (tmp_path / "out" / "smoke-synthetic" / "raw" / "birth_failures.jsonl").read_text().strip().splitlines()
    assert len(fails) > 0


def test_partial_failure_is_recorded_not_hidden(tmp_path):
    cfg = make_config(tmp_path, synthetic={"producer_params": {"syn-b": {"crash": True}}})
    run_f1("full", "--config", str(cfg))
    run = tmp_path / "out" / "smoke-synthetic"
    rep = json.loads((run / "RUN_REPORT.json").read_text())
    assert rep["observed_facts"]["failed_births"] > 0


def test_unavailable_producer_has_infinite_cost(tmp_path):
    cfg = make_config(tmp_path, unavailable_producers=["syn-b"])
    run_f1("full", "--config", str(cfg))
    run = tmp_path / "out" / "smoke-synthetic"
    arts = [json.loads(l) for l in (run / "raw" / "catalog.jsonl").read_text().splitlines()]
    assert any(a["producer_id"] == "syn-b" and a["cost_s"] == math.inf for a in arts)


# ---------------------------------------------------------------------------------------------
# P_DQ on small synthetic parquet tables
# ---------------------------------------------------------------------------------------------
def _table(cas, rows):
    import io
    import pyarrow as pa
    import pyarrow.parquet as pq
    buf = io.BytesIO()
    pq.write_table(pa.table(rows), buf)
    return cas.put_tree_refs({"data.parquet": cas.put(buf.getvalue(), compress=False)})


def test_dq_producer_outputs_and_contracts(cas, loader, tmp_path):
    from f1.producers.dq import DQProducer
    checks = [{"id": "present_a", "stat": {"kind": "present", "col": "a"}, "op": "ge", "thr": 1},
              {"id": "null_b", "stat": {"kind": "null_fraction", "col": "b"}, "op": "le", "thr": 0.3},
              {"id": "q90_a", "stat": {"kind": "quantile", "col": "a", "q": 0.9}, "op": "le", "thr": 100},
              {"id": "dup_k", "stat": {"kind": "duplicate_fraction", "cols": ["k"]}, "op": "le", "thr": 0.0},
              {"id": "set_c", "stat": {"kind": "outside_set_fraction", "col": "c", "values": ["x", "y"]}, "op": "le", "thr": 0.0},
              {"id": "mono", "stat": {"kind": "negative_increment_fraction", "cols": ["g"], "order": "k", "value": "a"}, "op": "le", "thr": 0.0}]
    d0 = _table(cas, {"k": [1, 2, 3, 4], "g": ["u", "u", "v", "v"], "a": [1.0, 2.0, 3.0, 4.0], "b": [1, None, 3, 4], "c": ["x", "y", "x", "x"]})
    d1 = _table(cas, {"k": [1, 2, 3, 4, 5], "g": ["u", "u", "v", "v", "v"], "a": [1.0, 2.0, 3.0, 4.0, 5.0], "b": [1, 2, 3, 4, 5], "c": ["x", "y", "x", "x", "y"]})
    d2 = _table(cas, {"k": [1, 1, 3], "g": ["u", "u", "v"], "a": [5.0, 1.0, 3.0], "b": [None, None, 3], "c": ["x", "z", "x"]})
    h = History([Version("D", "d0", 0, d0), Version("D", "d1", 1, d1), Version("D", "d2", 2, d2)])
    p = DQProducer(checks, uses_ref=False, policy_id="t")
    res, out = p.execute({"D": "d0"}, h, cas, tmp_path)
    assert res.status == "ok", res.stderr_tail
    assert out["gate"] == "PASS", out
    assert out["stats"]["null_b"] == 0.25  # one null out of four
    assert res.hidden_reads == []
    exprs = p.contracts("dq_gate", {"D": "d0"}, h, loader, out)
    ev = Evaluator(loader)
    eng_eval = lambda cls, vid: ev.evaluate(Contract.build("r", cls, exprs[cls]), lambda i: h.content({"D": vid}, i))[0]
    for cls in ("K1", "K2", "K3"):
        assert eng_eval(cls, "d0") is True              # well-formed at birth
    res1, out1 = p.execute({"D": "d1"}, h, cas, tmp_path)
    res2, out2 = p.execute({"D": "d2"}, h, cas, tmp_path)
    assert out1["gate"] == "PASS" and out2["gate"] == "FAIL"
    assert eng_eval("K1", "d1") is False                # statistics changed -> feature pinning rejects
    assert eng_eval("K2", "d1") is True and eng_eval("K3", "d1") is True   # decision region preserved
    assert eng_eval("K2", "d2") is False and eng_eval("K3", "d2") is False
