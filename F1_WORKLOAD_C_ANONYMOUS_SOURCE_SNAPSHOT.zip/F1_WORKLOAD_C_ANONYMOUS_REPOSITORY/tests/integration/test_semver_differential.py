"""T-C: RustSec/semver equivalence. Real cargo-audit (pinned binary) vs our matcher on adversarial synthetic DBs.
Engineering target: U1 = 0 on every case cargo-audit accepts; cases cargo-audit rejects at DB load are asserted to be
rejected (acquisition excludes such snapshots, so they never reach evaluation)."""
import os
from pathlib import Path

import pytest

from conftest import ROOT
from semver_cases import CASES, build, run_audit
from f1.producers.rustsec import affecting_triples, parse_advisory, registry_packages, rustsec_matches

BIN = ROOT / "tools" / "cargo-audit"
pytestmark = pytest.mark.skipif(not BIN.exists(), reason="pinned cargo-audit binary not fetched (make tools)")
REJECTED_BY_CARGO_AUDIT = {"ca-wild", "ca-overlap"}


def ours(db: Path, lock: Path):
    dbp = {}
    for root, _, fs in os.walk(db / "crates"):
        for f in fs:
            a = parse_advisory(open(os.path.join(root, f)).read(), f)
            dbp.setdefault(a["package"], []).append(a)
    return affecting_triples(dbp, registry_packages(lock.read_text()))


@pytest.mark.parametrize("case", CASES, ids=[c[0] for c in CASES])
def test_case_against_real_cargo_audit(case, tmp_path):
    db, lock = build(tmp_path, [case])
    real, err = run_audit(BIN, db, lock, tmp_path)
    if case[0] in REJECTED_BY_CARGO_AUDIT:
        assert real is None, "cargo-audit unexpectedly accepted an invalid database"
        return
    assert real is not None, err
    assert ours(db, lock) == real


def test_all_valid_cases_jointly(tmp_path):
    valid = [c for c in CASES if c[0] not in REJECTED_BY_CARGO_AUDIT]
    db, lock = build(tmp_path, valid)
    real, err = run_audit(BIN, db, lock, tmp_path)
    assert real is not None, err
    assert set(ours(db, lock)) == set(real) and len(real) >= 30


def test_rustsec_zero_fill_semantics():
    assert rustsec_matches("> 1.2", "1.2.5") and not rustsec_matches("<= 1.2", "1.2.9")
    assert rustsec_matches(">= 1.1.0", "1.2.0-alpha")      # plain ordering, no Cargo pre-release rule
    with pytest.raises(ValueError):
        rustsec_matches("2.*", "2.0.0")
