"""End-to-end engineering tests on the synthetic workload (outputs are NOT scientific results)."""
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from helpers import ROOT, make_config, run_f1

sys.path.insert(0, str(ROOT / "src"))


@pytest.fixture(scope="module")
def full_run(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("e2e")
    cfg = make_config(tmp)
    p = run_f1("full", "--config", str(cfg))
    return tmp, cfg, p


def test_full_pipeline_produces_all_outputs(full_run):
    tmp, cfg, p = full_run
    run = tmp / "out" / "smoke-synthetic"
    for f in ["RUN_REPORT.json", "RUN_REPORT.md", "SEAL.json", "RUN_COMPLETE.json", "statistics/metrics.json",
              "statistics/per_cluster_distributions.json", "raw/catalog.jsonl", "raw/history_synthetic.parquet",
              "oracle/unary_oracle.jsonl", "oracle/determinism.json", "manifests/environment_report.json",
              "manifests/run_manifest.json", "tables/unary_summary.csv", "tables/unary_summary.tex"]:
        assert (run / f).exists(), f
    assert list((run / "figures").glob("*.pdf"))
    m = json.loads((run / "statistics/metrics.json").read_text())
    u = m["by_workload"]["synthetic"]["unary"]["tier"]
    for cls in ("K0", "K1", "K2", "K3"):  # engineering invariant: contracts sound by construction on the synthetic producer
        assert u["M3"][cls]["unsafe_count"] == 0
    rep = m["by_workload"]["synthetic"]["repair"]
    assert all(v["bruteforce_agreement"] in (None, 1.0) for v in rep.values())
    journal = list((run / "raw" / "admission").glob("*.journal.jsonl"))
    assert journal and all(j.stat().st_size > 0 for j in journal)


def test_resume_skips_completed_stages(full_run):
    tmp, cfg, _ = full_run
    p = run_f1("full", "--config", str(cfg))
    from f1.runner.cli import STAGES
    assert p.stdout.count("already complete") == len(STAGES) - 1  # every stage except the always-regenerated report
    run = tmp / "out" / "smoke-synthetic"
    (run / "stages" / "metrics.done").unlink()
    (run / "stages" / "figures.done").unlink()
    p = run_f1("full", "--config", str(cfg))
    assert "[metrics] start" in p.stdout and "[figures] start" in p.stdout and "[births] start" not in p.stdout


def test_journal_replay_verifies_witnesses(full_run):
    tmp, cfg, _ = full_run
    sys.path.insert(0, str(ROOT / "src"))
    from f1.admission.engine import replay_journal
    from f1.catalog.artifact import Catalog
    from f1.common.loader import Loader
    from f1.common.util import CAS
    from f1.contracts.lang import Evaluator
    from f1.core.history import History, read_history_parquet
    run = tmp / "out" / "smoke-synthetic"
    hist = read_history_parquet(run / "raw" / "history_synthetic.parquet")
    arts = {a.artifact_id: a for a in Catalog(run / "raw" / "catalog.jsonl").load()}
    import f1.producers.synthetic  # noqa: F401
    for j in (run / "raw" / "admission").glob("*.journal.jsonl"):
        cluster = j.name.split("__")[1].split(".")[0]
        r = replay_journal(j, History.from_rows(hist[cluster]), arts, Evaluator(Loader(CAS(tmp / "data" / "cas"))))
        assert r["records"] > 0


def test_post_seal_tampering_is_detected(full_run):
    tmp, cfg, _ = full_run
    run = tmp / "out" / "smoke-synthetic"
    f = run / "raw" / "unary_admission.jsonl"
    os.chmod(f, 0o644)
    original = f.read_bytes()
    try:
        f.write_bytes(original + b"\n")
        p = run_f1("stage", "--config", str(cfg), "--name", "metrics", check=False)
        assert p.returncode != 0 and "modified after seal" in (p.stdout + p.stderr)
    finally:
        f.write_bytes(original)


def test_admission_role_cannot_read_oracle_store(full_run):
    tmp, cfg, _ = full_run
    run = tmp / "out" / "smoke-synthetic"
    target = run / "oracle" / "unary_oracle.jsonl"
    code = f"""
import sys; sys.path.insert(0, {str(ROOT / 'src')!r})
from f1.common.firewall import install_role_guard, FirewallViolation
install_role_guard('admission', {str(run / 'oracle')!r})
open({str(run / 'raw' / 'catalog.jsonl')!r}).read()          # allowed
try:
    open({str(target)!r}).read()
    print('LEAK'); sys.exit(1)
except FirewallViolation:
    print('BLOCKED')
"""
    p = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
    assert p.returncode == 0 and "BLOCKED" in p.stdout, p.stdout + p.stderr


def test_oracle_refuses_without_seal(tmp_path):
    cfg = make_config(tmp_path)
    p = run_f1("stage", "--config", str(cfg), "--name", "oracle", check=False)
    assert p.returncode != 0 and "no admission seal" in (p.stdout + p.stderr)


def test_config_change_blocks_resume(full_run, tmp_path):
    tmp, cfg, _ = full_run
    import yaml
    c = yaml.safe_load(Path(cfg).read_text())
    c["seed"] = 999
    alt = tmp / "cfg_changed.yaml"
    alt.write_text(yaml.safe_dump(c))
    p = run_f1("full", "--config", str(alt), check=False)
    assert p.returncode != 0 and "configuration changed" in (p.stdout + p.stderr)
