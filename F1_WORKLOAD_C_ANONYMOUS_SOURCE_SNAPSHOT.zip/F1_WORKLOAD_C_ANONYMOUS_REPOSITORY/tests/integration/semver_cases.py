"""Adversarial RustSec/semver cases shared by the differential test (real cargo-audit vs our matcher)."""
import json
import os
import subprocess

# (crate, lockfile versions, patched, unaffected, extra advisory fields, second advisory (patched, unaffected) or None)
CASES = [
    ("ca-exact", ["1.2.3", "1.2.4"], ["=1.2.4"], [], {}, None),
    ("ca-incl-lo", ["1.0.0", "0.9.9"], [">= 1.0.0"], [], {}, None),
    ("ca-excl-lo", ["1.0.0", "1.0.1"], ["> 1.0.0"], [], {}, None),
    ("ca-incl-hi", ["2.0.0", "2.0.1"], [], ["<= 2.0.0"], {}, None),
    ("ca-excl-hi", ["2.0.0", "1.9.9"], [], ["< 2.0.0"], {}, None),
    ("ca-open", ["5.0.0", "0.1.0"], [">= 3.0.0"], [], {}, None),
    ("ca-compound", ["1.4.9", "1.5.0", "1.3.0", "1.3.5"], [">= 1.5.0", ">= 1.3.0, < 1.4.0"], [], {}, None),
    ("ca-wild", ["1.9.9", "2.0.0"], ["2.*"], [], {}, None),
    ("ca-caret0", ["0.0.3", "0.0.4", "0.1.0"], ["^0.0.4"], [], {}, None),
    ("ca-caret01", ["0.1.5", "0.2.0", "0.1.2"], ["^0.1.5"], [], {}, None),
    ("ca-caret1", ["1.2.0", "1.9.0", "2.0.0"], ["^1.2.0"], [], {}, None),
    ("ca-tilde", ["1.2.9", "1.3.0", "1.2.2"], ["~1.2.3"], [], {}, None),
    ("ca-pre", ["1.1.0-beta.1", "1.1.0", "1.0.9"], [">= 1.1.0"], [], {}, None),
    ("ca-pre2", ["1.1.0-beta.2", "1.1.0-alpha.1"], [">= 1.1.0-beta.1"], [], {}, None),
    ("ca-pre-num", ["1.0.0-rc.10", "1.0.0-rc.9"], [">= 1.0.0-rc.10"], [], {}, None),
    ("ca-overlap", ["1.5.0", "3.0.0", "0.5.0"], [">= 1.0.0"], ["< 2.0.0"], {}, None),
    ("ca-disjoint", ["1.5.0", "3.0.0", "2.5.0"], [">= 3.0.0"], ["< 2.0.0"], {}, None),
    ("ca-none", ["9.9.9"], [], [], {}, None),
    ("ca-withdrawn", ["1.0.0"], [], [], {"withdrawn": "2024-01-01"}, None),
    ("ca-info", ["1.0.0"], [], [], {"informational": "unmaintained"}, None),
    ("ca-unsound", ["1.0.0"], [], [], {"informational": "unsound"}, None),
    ("ca-build", ["0.11.0+wasi-snapshot-preview1", "0.12.0+wasi-0.2.4"], [">= 0.12.0"], [], {}, None),
    ("ca-multi", ["1.0.0", "2.0.0", "0.5.0"], [">= 2.0.0"], [], {}, (["< 1.0.0", ">= 3.0.0"], [])),
    ("ca-partial", ["1.4.0", "1.5.0", "2.0.0"], [">= 1.5"], [], {}, None),
    ("ca-lt-partial", ["0.9.0", "1.0.0"], [], ["< 1"], {}, None),
    ("ca-caret-pre", ["0.2.0-alpha.2", "0.2.0", "0.3.0"], ["^0.2.0-alpha.1"], [], {}, None),
    ("ca-eq-partial", ["1.2.0", "1.3.0"], ["=1.2"], [], {}, None),
    ("ca-gt-partial", ["1.2.5", "1.3.0"], ["> 1.2"], [], {}, None),
    ("ca-le-partial", ["1.2.9", "1.3.0"], [], ["<= 1.2"], {}, None),
    ("ca-eq-partial2", ["1.2.5", "1.2.0"], ["=1.2"], [], {}, None),
    ("ca-pre-cross", ["1.2.0-alpha", "1.0.5"], [">= 1.1.0"], [], {}, None),
    ("ca-pre-unaff", ["0.9.0-rc.1", "1.0.0-rc.1"], [], ["< 1.0.0"], {}, None),
    ("ca-tilde-partial", ["1.4.0", "2.0.0"], ["~1"], [], {}, None),
    ("ca-caret-partial", ["1.4.0", "2.0.0", "1.1.9"], ["^1.2"], [], {}, None),
    ("ca-lt-pre", ["2.0.0-beta.1", "2.0.0"], [], ["< 2.0.0-beta.2"], {}, None),
    ("ca-two-patched", ["1.0.5", "1.1.0", "2.0.1", "1.9.0"], ["^1.0.5", ">= 2.0.1"], [], {}, None),
]

LOCK_SOURCE = "registry+https://github.com/rust-lang/crates.io-index"


def advisory_text(aid, crate, patched, unaffected, extra):
    fm = ["[advisory]", f'id = "{aid}"', f'package = "{crate}"', 'date = "2023-01-01"', f'url = "https://example.invalid/{aid}"']
    fm += [f'{k} = "{v}"' for k, v in extra.items()]
    fm += ["", "[versions]", f"patched = {json.dumps(patched)}", f"unaffected = {json.dumps(unaffected)}"]
    return "```toml\n" + "\n".join(fm) + "\n```\n\n# Synthetic advisory\n\nEngineering differential test.\n"


def lock_text(entries):
    out = ["version = 3"]
    for crate, v in entries:
        out += ["", "[[package]]", f'name = "{crate}"', f'version = "{v}"', f'source = "{LOCK_SOURCE}"']
    return "\n".join(out) + "\n"


def run_audit(binary, db_dir, lock_path, home):
    p = subprocess.run([binary, "audit", "--db", str(db_dir), "--no-fetch", "--stale", "--json", "--file", str(lock_path)],
                       capture_output=True, text=True, env={"HOME": str(home), "PATH": "/usr/bin:/bin"})
    if not p.stdout.strip().startswith("{"):
        return None, p.stderr
    d = json.loads(p.stdout)
    return sorted({f"{x['advisory']['id']}|{x['package']['name']}|{x['package']['version']}" for x in d["vulnerabilities"]["list"]}), None


def build(tmp, cases):
    """Write one advisory DB + lockfile for the given cases; returns (db_dir, lock_path)."""
    db = tmp / "db" / "crates"
    db.mkdir(parents=True, exist_ok=True)
    entries, n = [], 0
    for crate, vers, patched, unaff, extra, second in cases:
        entries += [(crate, v) for v in vers]
        advs = [(patched, unaff, extra)] + ([(second[0], second[1], {})] if second else [])
        for p, u, ex in advs:
            n += 1
            aid = f"RUSTSEC-2023-{9000 + n:04d}" if crate != "ca-multi" or n % 2 else f"RUSTSEC-2023-{9500 + n:04d}"
            (db / crate).mkdir(exist_ok=True)
            (db / crate / f"{aid}.md").write_text(advisory_text(aid, crate, p, u, ex))
    lock = tmp / "Cargo.lock"
    lock.write_text(lock_text(entries))
    return tmp / "db", lock
