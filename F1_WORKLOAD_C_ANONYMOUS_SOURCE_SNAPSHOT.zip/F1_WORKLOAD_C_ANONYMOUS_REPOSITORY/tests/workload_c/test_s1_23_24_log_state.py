import json

import pytest

from f1.workload_c.errors import InvalidTransitionError, LedgerIntegrityError
from f1.workload_c.state.journal import AppendOnlyJournal, StructuredLog
from f1.workload_c.state.run_state import TRANSITIONS, PhaseState, RunStateLedger, check_transition
from f1.workload_c.timeutil import FixedTickClock


@pytest.mark.gate("S1-23")
def test_append_only_chain_and_stable_fields(tmp_path):
    log = StructuredLog(tmp_path / "e.jsonl", "run1", "FIXTURE", FixedTickClock())
    for i in range(5):
        log.emit("EVT", phase="02", component="c", status="OK", feed_id=f"f{i}", duration_s=0.5,
                 output_hashes={"x": "y"})
    recs = log.journal.records()
    assert [r["seq"] for r in recs] == list(range(5))
    assert set(StructuredLog.FIELDS) <= set(recs[0])
    assert recs[0]["prev"] == "0" * 64 and recs[1]["prev"] != recs[0]["prev"]
    j2 = AppendOnlyJournal(tmp_path / "e.jsonl")          # reopen continues the chain
    j2.append({"event": "more"})
    assert j2.length == 6 and j2.verify()[0] == 6


@pytest.mark.gate("S1-23")
@pytest.mark.parametrize("attack", ["edit", "delete", "reorder", "torn", "noncanonical"])
def test_tampering_detected(tmp_path, attack):
    j = AppendOnlyJournal(tmp_path / "j.jsonl")
    for i in range(4):
        j.append({"event": f"e{i}"})
    lines = (tmp_path / "j.jsonl").read_bytes().split(b"\n")[:-1]
    if attack == "edit":
        lines[1] = lines[1].replace(b"e1", b"eX")
    elif attack == "delete":
        del lines[1]
    elif attack == "reorder":
        lines[1], lines[2] = lines[2], lines[1]
    elif attack == "noncanonical":
        lines[1] = json.dumps(json.loads(lines[1]), indent=1).replace("\n", "").encode()
    data = b"\n".join(lines) + b"\n"
    if attack == "torn":
        data = data[:-5]
    (tmp_path / "j.jsonl").write_bytes(data)
    with pytest.raises(LedgerIntegrityError):
        AppendOnlyJournal(tmp_path / "j.jsonl")


@pytest.mark.gate("S1-23")
def test_truncation_and_rewrite_detected_against_recorded_head(tmp_path):
    j = AppendOnlyJournal(tmp_path / "j.jsonl")
    for i in range(4):
        j.append({"event": f"e{i}"})
    head, n = j.head, j.length
    lines = (tmp_path / "j.jsonl").read_bytes().split(b"\n")[:-1]
    (tmp_path / "j.jsonl").write_bytes(b"\n".join(lines[:2]) + b"\n")      # valid prefix, but truncated
    with pytest.raises(LedgerIntegrityError):
        AppendOnlyJournal(tmp_path / "j.jsonl").verify(expect_head=head, expect_min_length=n)
    p2 = tmp_path / "k.jsonl"
    k = AppendOnlyJournal(p2)
    for i in range(3):
        k.append({"event": f"e{i}"})
    h3 = k.head
    p2.unlink()
    k2 = AppendOnlyJournal(p2)                                              # rewritten from scratch
    for i in range(4):
        k2.append({"event": f"other{i}"})
    with pytest.raises(LedgerIntegrityError):
        k2.verify(expect_head=h3, expect_min_length=3)


@pytest.mark.gate("S1-23")
def test_no_headline_metrics_in_operational_log(tmp_path):
    log = StructuredLog(tmp_path / "e.jsonl", "r", "FIXTURE", FixedTickClock())
    for k in ("HSR_witness", "hsr_repair", "f1_vs_n5", "delta_e2e_history"):
        with pytest.raises(ValueError):
            log.emit("X", **{k: 0.5})


ALL = list(PhaseState)


@pytest.mark.gate("S1-24")
@pytest.mark.parametrize("old,new", [(a, b) for a in ALL for b in ALL])
def test_transition_matrix(old, new):
    allowed = {(PhaseState.PENDING, PhaseState.RUNNING), (PhaseState.RUNNING, PhaseState.COMPLETE),
               (PhaseState.RUNNING, PhaseState.FAILED), (PhaseState.RUNNING, PhaseState.BLOCKED),
               (PhaseState.FAILED, PhaseState.RUNNING), (PhaseState.BLOCKED, PhaseState.RUNNING)}
    if (old, new) in allowed:
        check_transition(old, new)
    else:
        with pytest.raises(InvalidTransitionError):
            check_transition(old, new)
    assert sum(len(v) for v in TRANSITIONS.values()) == 6


@pytest.mark.gate("S1-24")
def test_ledger_rules_and_replay(tmp_path):
    L = RunStateLedger(tmp_path / "s.jsonl", "r", ["p0", "p1", "p2"], FixedTickClock())
    kw = dict(config_digest="c", implementation_id="i")
    with pytest.raises(InvalidTransitionError):
        L.transition("p1", PhaseState.RUNNING, **kw)          # p0 not COMPLETE
    L.transition("p0", PhaseState.RUNNING, **kw)
    with pytest.raises(InvalidTransitionError):
        L.transition("p0", PhaseState.COMPLETE, **kw)         # COMPLETE requires committed outputs
    L.transition("p0", PhaseState.COMPLETE, outputs={"a": "h"}, **kw)
    with pytest.raises(InvalidTransitionError):
        L.transition("p0", PhaseState.RUNNING, **kw)          # COMPLETE is terminal
    L.transition("p1", PhaseState.RUNNING, **kw)
    L.transition("p1", PhaseState.FAILED, error={"error_class": "X"}, **kw)
    L.transition("p1", PhaseState.RUNNING, **kw)
    assert L.attempts("p1") == 2
    L.transition("p1", PhaseState.BLOCKED, **kw)
    with pytest.raises(InvalidTransitionError):
        L.transition("zz", PhaseState.RUNNING, **kw)
    L2 = RunStateLedger(tmp_path / "s.jsonl", "r", ["p0", "p1", "p2"], FixedTickClock())
    assert L2.snapshot() == {"p0": "COMPLETE", "p1": "BLOCKED", "p2": "PENDING"} and L2.attempts("p1") == 2
    rec = L2.last("p0")
    for k in ("run_id", "phase", "ts", "config_digest", "implementation_id", "inputs", "outputs", "error"):
        assert k in rec
    with pytest.raises(InvalidTransitionError):
        RunStateLedger(tmp_path / "s.jsonl", "another-run", ["p0", "p1", "p2"], FixedTickClock())


@pytest.mark.gate("S1-24")
def test_forged_invalid_transition_in_ledger_rejected_on_replay(tmp_path):
    j = AppendOnlyJournal(tmp_path / "s.jsonl")
    j.append({"run_id": "r", "phase": "p0", "from": "PENDING", "to": "COMPLETE", "outputs": {"a": "b"}})
    with pytest.raises(InvalidTransitionError):
        RunStateLedger(tmp_path / "s.jsonl", "r", ["p0"], FixedTickClock())
