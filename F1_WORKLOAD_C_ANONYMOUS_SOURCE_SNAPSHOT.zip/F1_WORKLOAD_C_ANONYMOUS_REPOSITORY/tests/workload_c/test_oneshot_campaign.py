"""One-shot server campaign gates OSC-01…OSC-55 (FIXTURE backend + static checks; no real execution)."""
import csv
import functools
import hashlib
import json
import os
import subprocess
import tempfile
import zipfile
from datetime import date
from pathlib import Path

import pytest

from conftest import ROOT
from f1.workload_c.oneshot import cli, core, stages
from f1.workload_c.oneshot.fixture_backend import FixtureBackend

FIX = ROOT / "frozen_specs/authoritative/conformance/fixtures/oracle"


def run(work: Path, faults=None, *extra) -> int:
    args = ["--work-root", str(work), "--backend", "fixture", *extra]
    if faults:
        args += ["--fixture-faults", json.dumps(faults)]
    if not any(x in extra for x in ("--resume", "--dry-run", "--preflight-only")):
        args.append("--new-campaign")
    return cli.main(args)


@functools.lru_cache(maxsize=None)
def case(name: str):
    faults = {"A": None, "B": {"l28_fail": True}, "C": {"e1_validation": True}, "D": {"n4_unclassifiable": True},
              "E": {"source_modified_after_validation": True}, "F": {"test_integrity_fail": True}}[name]
    work = Path(tempfile.mkdtemp(prefix=f"osc-{name}-"))
    rc = run(work, faults)
    return work, rc


def journal(work: Path) -> list[dict]:
    return core.Journal(work / "journal" / "campaign.jsonl").records()


def kinds(work, k):
    return [r["payload"] for r in journal(work) if r["kind"] == k]


def done(work):
    return [p["stage"] for p in kinds(work, "STAGE_COMPLETE")]


def outputs_empty(work):
    d = work / "campaign" / "test_outputs"
    return not d.exists() or not any(d.rglob("*"))


# ---------------------------------------------------------------------------------------- identity / regression
@pytest.mark.gate("OSC-01")
def test_input_identity():
    ev = json.loads((ROOT / "docs/oneshot/ONESHOT_INPUT_IDENTITY.json").read_text())
    assert ev["input_head"] == "9de0214c3794276ebbada588d92ca518b6e7c888"
    assert ev["input_zip_sha256"] == "bcf165f0a5a0d1ecf2658c65c8893a288c24b32debd51b17c30e9b566e8a7fe4"
    if (ROOT / ".git").exists() and not (ROOT / "ANONYMIZED_REVIEW_ARTIFACT").exists():
        assert subprocess.run(["git", "merge-base", "--is-ancestor", ev["input_head"], "HEAD"], cwd=ROOT).returncode == 0


@pytest.mark.gate("OSC-02")
def test_complete_scientific_regression():
    rep = Path(os.environ.get("F1_WC_REPORT_DIR", ROOT / "reports"))

    def ok(p, n, pending=()):
        rows = list(csv.DictReader(open(p)))
        assert len(rows) == n and all(r["status"] == "PASS" or (r["gate"] in pending and r["status"] == "PENDING")
                                      for r in rows), p
    ok(rep / "s1" / "S1_GATE_LEDGER.csv", 30)
    ok(rep / "S2_GATE_LEDGER.csv", 50)
    ok(rep / "P3_GATE_LEDGER.csv", 26)
    ok(rep / "S3_GATE_LEDGER.csv", 66, ("S3-50",))
    ok(rep / "S4A1_GATE_LEDGER.csv", 33)
    cr = json.loads((ROOT / "docs/oneshot/CHANGE_RECORDS_ONESHOT.json").read_text())["records"]
    assert {r["id"] for r in cr} == {"ONESHOT-CR-01", "ONESHOT-CR-02", "ONESHOT-CR-03", "ONESHOT-CR-04"}
    assert all(r["change_class"] == ("E1" if r["id"] in ("ONESHOT-CR-03", "ONESHOT-CR-04") else "E2") for r in cr)


@pytest.mark.gate("OSC-02")
def test_frozen_gate_ledger_untouched_and_osc_ledger_separate():
    """Regression for the defect found by the full run: the frozen scripts/gate_ledger.py (S4A.1.1 freeze) must stay
    byte-identical; the OSC ledger is produced by scripts/gate_ledger_osc.py."""
    fz = json.loads((ROOT / "docs/s4a1/S4A1_1_SEMANTIC_FREEZE.json").read_text())["files"]
    assert hashlib.sha256((ROOT / "scripts/gate_ledger.py").read_bytes()).hexdigest() == fz["scripts/gate_ledger.py"]
    assert "OSC-" not in (ROOT / "scripts/gate_ledger.py").read_text()
    w = (ROOT / "scripts/gate_ledger_osc.py").read_text()
    assert w.count("OSC-") >= 55 and "gate_ledger_osc.py" in (ROOT / "scripts/run_tests.sh").read_text()


@pytest.mark.gate("OSC-03")
@pytest.mark.gate("OSC-04")
def test_launcher_one_command():
    for f in ("run_f1_workload_c_campaign.sh", "campaign_status.sh", "install_server_dependencies.sh"):
        p = ROOT / f
        assert p.exists() and os.access(p, os.X_OK), f
    t = (ROOT / "run_f1_workload_c_campaign.sh").read_text()
    assert "--mobility-token-file" in t and "f1.workload_c.oneshot.cli" in t and 'args+=("--new-campaign")' in t
    assert [s.sid for s in stages.STAGES][0] == "S00_PREFLIGHT" and len(stages.STAGES) == 18   # one state machine


# ---------------------------------------------------------------------------------------- secrets / identity
@pytest.mark.gate("OSC-05")
@pytest.mark.gate("OSC-47")
def test_secret_redaction(tmp_path):
    from f1.workload_c.oneshot.real_backend import FileSecretProvider
    from f1.workload_c.security.secrets import REDACTOR
    tok = tmp_path / "token"
    canary = "CANARY-TOKEN-" + "x" * 24
    tok.write_text(canary)
    s = FileSecretProvider(str(tok)).get("MOBILITY_DB_TOKEN")
    assert s.reveal() == canary and canary not in REDACTOR.redact(f"auth {canary} failed")
    j = core.Journal(tmp_path / "j.jsonl")
    j.append("X", message=f"token={canary}")
    assert canary not in (tmp_path / "j.jsonl").read_text()
    work, _ = case("A")
    for p in work.rglob("*"):
        if p.is_file() and p.suffix in (".json", ".jsonl", ".log", ".md", ".csv"):
            assert "MOBILITY_DB_TOKEN=" not in p.read_text(errors="ignore")


@pytest.mark.gate("OSC-06")
def test_target_identity_capture():
    work, _ = case("A")
    ident = json.loads((work / "runtime" / "TARGET_SERVER_IDENTITY.json").read_text())
    assert ident["campaign_id"] and ident["disk_free_bytes"] > 0
    src = (ROOT / "src/f1/workload_c/oneshot/real_backend.py").read_text()
    for k in ("hostname", "kernel", "architecture", "cpu_model", "logical_cpus", "mem_total", "mem_available", "java",
              "numpy", "cgroup", "systemd", "filesystem", "disk_free_bytes", "ulimits", "timezone", "ntp",
              "dependency_hashes"):
        assert f'"{k}"' in src, k


# ---------------------------------------------------------------------------------------- hard stops (CASE B …)
@pytest.mark.gate("OSC-07")
@pytest.mark.gate("OSC-40")
def test_case_b_l28_hard_stop():
    work, rc = case("B")
    assert rc == 10 and done(work)[-1] == "S00_PREFLIGHT"
    assert (work / "output" / "F1_WORKLOAD_C_CAMPAIGN_SAFE_STOP_L28.zip").exists()
    assert "S10_VALIDATION" not in done(work) and outputs_empty(work)
    z = zipfile.ZipFile(work / "output" / "F1_WORKLOAD_C_CAMPAIGN_SAFE_STOP_L28.zip")
    assert "runtime/SAFE_STOP_REPORT.json" in z.namelist() and "journal/campaign.jsonl" in z.namelist()


@pytest.mark.gate("OSC-08")
def test_dependency_hard_stop(tmp_path):
    assert run(tmp_path / "w", {"dependency_missing": True}) == 10
    assert (tmp_path / "w" / "output" / "F1_WORKLOAD_C_CAMPAIGN_SAFE_STOP_PREFLIGHT.zip").exists()
    src = (ROOT / "src/f1/workload_c/oneshot/real_backend.py").read_text()
    assert "2.4.4" in src and "6.0.3" in src and "osmium version 1.16.0" in src and "REAL_PINNED_BINARY" in src


@pytest.mark.gate("OSC-09")
def test_network_hard_stop(tmp_path):
    assert run(tmp_path / "w", {"network_fail": True}) == 10
    assert done(tmp_path / "w")[-1] == "S01_L28"


@pytest.mark.gate("OSC-10")
def test_disk_hard_stop(tmp_path):
    assert run(tmp_path / "w", {"disk_full": True}) == 10
    assert done(tmp_path / "w") == [] and kinds(tmp_path / "w", "SAFE_STOP")[0]["stage"] == "S00_PREFLIGHT"


@pytest.mark.gate("OSC-11")
def test_cache_protocol_sealed_before_timing():
    from f1.workload_c.oneshot.cache_protocol import build_protocol
    work, _ = case("A")
    d = done(work)
    assert d.index("S03_CACHE_PROTOCOL") < d.index("S10_VALIDATION")
    proto = json.loads((work / "runtime" / "PHYSICAL_CACHE_STATE_PROTOCOL.json").read_text())
    assert proto["sealed_before_any_comparative_timing"] and proto["status"] == "ESTABLISHED"
    assert build_protocol({"drop_caches": False})["status"] == "UNAVAILABLE"          # real host without privilege
    src = (ROOT / "src/f1/workload_c/oneshot/real_producer.py").read_text()
    assert "COMPLETE common immutable input corpus" in src and "self.warm(invoke_utc)" in src


# ---------------------------------------------------------------------------------------- population / selection
@pytest.mark.gate("OSC-12")
@pytest.mark.gate("OSC-13")
@pytest.mark.gate("OSC-14")
def test_population_selection_split():
    work, _ = case("A")
    led = list(csv.DictReader(open(work / "runtime" / "REAL_POPULATION_FILTER_LEDGER.csv")))
    assert int([r for r in led if r["stage"] == "eligible_regions"][0]["count"]) >= 24
    sel = json.loads((work / "runtime" / "SELECTED_24_REGIONS.json").read_text())["regions"]
    split = json.loads((work / "runtime" / "VALIDATION_TEST_SPLIT.json").read_text())
    assert len(sel) == 24 and len(split["validation"]) == 8 and len(split["test"]) == 16
    work2, _ = case("D")
    assert json.loads((work2 / "runtime" / "SELECTED_24_REGIONS.json").read_text())["regions"] == sel   # deterministic


@pytest.mark.gate("OSC-15")
@pytest.mark.gate("OSC-21")
def test_test_sealing_and_no_test_before_authorization(tmp_path):
    work, _ = case("A")
    m = work / "campaign" / "test_inputs" / "TEST_INPUT_MANIFEST.json"
    assert not os.access(m, os.W_OK) or os.geteuid() == 0
    for c in ("B", "C", "D", "E"):
        w, _ = case(c)
        assert outputs_empty(w) and "S15_TEST_INTEGRITY" not in done(w), c
    w, _ = case("C")
    c = core.Campaign(w, json.loads((w / "CAMPAIGN_ID.json").read_text()), core.Journal(w / "journal/campaign.jsonl"),
                      FixtureBackend())
    with pytest.raises(core.SafeStop):
        stages.require_authorization(c)


@pytest.mark.gate("OSC-16")
def test_osm_rule_provenance_and_implementation():
    p = ROOT / "docs/oneshot/provenance/V3_05_OSM_OSMIUM_PIN_MANIFEST.md"
    meta = json.loads((ROOT / "docs/oneshot/provenance/V3_05_OSM_PROVENANCE.json").read_text())
    assert hashlib.sha256(p.read_bytes()).hexdigest() == meta["sha256"] == \
        "24e65766fa99e34e5f8fabc881ea37b4af96b2365d5c632e837b11fa334fed19"
    from f1.workload_c.oneshot import osm_v3 as O
    assert O.choose_snapshot(["250315", "250401", "250501"]) == "250401"
    assert O.choose_snapshot(["250315", "250501", "260101"]) == "250501"
    with pytest.raises(O.OsmRuleError):
        O.choose_snapshot(["240101"])
    sq = {"type": "Polygon", "coordinates": [[[0, 0], [10, 0], [10, 10], [0, 10], [0, 0]]]}
    small = {"type": "Polygon", "coordinates": [[[1, 1], [4, 1], [4, 4], [1, 4], [1, 1]]]}
    idx = {"features": [{"properties": {"id": "big", "urls": {"pbf": "https://x/big-latest.osm.pbf"}}, "geometry": sq},
                        {"properties": {"id": "small", "urls": {"pbf": "https://x/small-latest.osm.pbf"}}, "geometry": small}]}
    assert O.select_extract(idx, [(2, 2), (3, 3), (2, 3)])["properties"]["id"] == "small"
    assert O.select_extract(idx, [(2, 2), (6, 6), (2, 6)])["properties"]["id"] == "big"
    bb = O.expanded_bbox([(0.0, 45.0), (0.1, 45.1)])
    assert abs((45.0 - bb[1]) - 5 / 111.32) < 1e-9
    src = (ROOT / "src/f1/workload_c/oneshot/osm_v3.py").read_text()
    assert '"--strategy", "complete_ways"' in src and 'GEOFABRIK = "https://download.geofabrik.de"' in src
    import shutil
    if shutil.which("osmium"):                                          # real osmium clip on a frozen fixture OSM
        with tempfile.TemporaryDirectory() as d:
            cp = subprocess.run(["osmium", "extract", "--strategy", "complete_ways", "--bbox", "-180,-90,180,90",
                                 str(FIX / "base/street.osm.pbf"), "-o", f"{d}/r.osm.pbf"], capture_output=True)
            assert cp.returncode == 0 and Path(f"{d}/r.osm.pbf").stat().st_size > 0


@pytest.mark.gate("OSC-17")
@pytest.mark.gate("OSC-18")
def test_real_producer_path_and_fixture_forbidden(tmp_path):
    src = (ROOT / "src/f1/workload_c/oneshot/real_producer.py").read_text()
    for needle in ("self.val.produce(ValidatorRequest(", "self.otp.produce(OtpRequest(", "BOUNDS[0], BOUNDS[1]"):
        assert needle in src
    from f1.workload_c.oneshot.real_backend import RealBackend
    assert RealBackend.binary_mode == "REAL_PINNED_BINARY" and RealBackend.accepted_l28_states == ("EXECUTED_ON_TARGET",)

    class FakeReal(FixtureBackend):
        namespace_validation = "VALIDATION"
    w = tmp_path / "w"
    c = core.open_campaign(w, cli.source_identity(), "REAL", True, False, FakeReal())
    with pytest.raises(core.SafeStop):
        stages.s08_producers(c)                                      # FIXTURE_STUB can never serve REAL


@pytest.mark.gate("OSC-19")
@pytest.mark.gate("OSC-20")
@pytest.mark.gate("OSC-35")
def test_readiness_and_partition_sizes():
    work, rc = case("A")
    assert rc == 0
    r = json.loads((work / "runtime" / "VALIDATION_READINESS.json").read_text())
    assert r["prior_stages_sealed"] and r["test_outputs_absent"] and r["frozen_semantics"]
    assert json.loads((work / "runtime" / "VALIDATION_EXECUTION.json").read_text())["n_regions"] == 8
    assert len(json.loads((work / "campaign/test_outputs/TEST_EXECUTION.json").read_text())["regions"]) == 16


# ---------------------------------------------------------------------------------------- N4
@pytest.mark.gate("OSC-22")
@pytest.mark.gate("OSC-23")
@pytest.mark.gate("OSC-24")
def test_n4_selection():
    work, _ = case("A")
    n4 = json.loads((work / "runtime" / "N4_VALIDATION_SELECTION_LEDGER.json").read_text())
    assert n4["candidates"] == [1, 6, 24, 72, 168] and sorted(map(int, n4["outcomes"])) == [1, 6, 24, 72, 168]
    from f1.workload_c.oneshot.audit import _tau_recomputes
    assert _tau_recomputes(n4)
    assert stages.TAUS == (1, 6, 24, 72, 168)
    import inspect
    src = inspect.getsource(stages.s11_n4)
    assert "F1" not in src.replace("TauOutcome", "") and "hsr" not in src.lower()
    test_exec = json.loads((work / "campaign/test_outputs/TEST_EXECUTION.json").read_text())
    assert test_exec["selected_tau_h"] == n4["selected_tau_h"]


@pytest.mark.gate("OSC-25")
@pytest.mark.gate("OSC-27")
def test_case_c_validation_e1_safe_stop():
    work, rc = case("C")
    assert rc == 10 and kinds(work, "SAFE_STOP")[0]["stage"] == "S10_VALIDATION"
    inc = kinds(work, "INCIDENT")
    assert inc and inc[0]["category"] == "E1" and inc[0]["resolution"] == "UNRESOLVED"
    assert (work / "runtime" / "VALIDATION_INCIDENT_LOG.jsonl").exists()
    assert (work / "output" / "F1_WORKLOAD_C_CAMPAIGN_SAFE_STOP_VALIDATION.zip").exists() and outputs_empty(work)


@pytest.mark.gate("OSC-26")
@pytest.mark.gate("OSC-33")
def test_case_e_source_change_after_validation_blocks_test():
    work, rc = case("E")
    assert rc == 10 and kinds(work, "SAFE_STOP")[0]["stage"] == "S14_PRETEST_AUDIT"
    audit = json.loads((work / "runtime" / "PRETEST_AUDIT.json").read_text())
    assert "H_no_source_change_after_validation" in audit["failed"] and audit["reads_performance"] is False
    auth = json.loads((work / "TEST_CAMPAIGN_AUTHORIZATION.json").read_text())
    assert auth["authorized"] is False and outputs_empty(work)


@pytest.mark.gate("OSC-28")
@pytest.mark.gate("OSC-29")
@pytest.mark.gate("OSC-30")
def test_incident_categories_force_stop(tmp_path):
    from f1.workload_c.oneshot.audit import automatic_pretest_audit
    work, _ = case("A")
    import shutil
    w = tmp_path / "copy"
    shutil.copytree(work, w)
    c = core.Campaign(w, json.loads((w / "CAMPAIGN_ID.json").read_text()), core.Journal(w / "journal/campaign.jsonl"),
                      FixtureBackend())
    for cat, key in (("E2", "G_no_unresolved_E2"), ("S1", "D_no_S1_amendment"), ("R1", "E_no_R1")):
        c.incident(cat, "S10_VALIDATION", f"synthetic {cat}", True)
        assert key in automatic_pretest_audit(c)["failed"], cat
    src = (ROOT / "src/f1/workload_c/oneshot/stages.py").read_text()
    assert 'inc["category"] in ("S1", "R1")' in src


@pytest.mark.gate("OSC-31")
@pytest.mark.gate("OSC-32")
@pytest.mark.gate("OSC-34")
def test_closure_freeze_authorization_binding(tmp_path):
    work, _ = case("A")
    clo = json.loads((work / "runtime" / "VALIDATION_CLOSURE_REPORT.json").read_text())
    assert clo["ok"] and clo["regression"]["status"] == "PASS" and clo["unresolved_incidents"] == 0
    fz = work / "FINAL_CAMPAIGN_FREEZE" / "FINAL_CAMPAIGN_FREEZE.json"
    assert (work / "FINAL_CAMPAIGN_FREEZE/FINAL_CAMPAIGN_FREEZE.sha256").read_text().split()[0] == core.sha256_file(fz)
    auth = json.loads((work / "TEST_CAMPAIGN_AUTHORIZATION.json").read_text())
    assert auth["authorized"] is True and auth["mode"] == "automatic_preregistered_authorization"
    assert auth["campaign_freeze_sha256"] == core.sha256_file(fz)
    import shutil
    w = tmp_path / "copy"
    shutil.copytree(work, w)
    a = json.loads((w / "TEST_CAMPAIGN_AUTHORIZATION.json").read_text())
    a["campaign_freeze_sha256"] = "0" * 64
    (w / "TEST_CAMPAIGN_AUTHORIZATION.json").write_text(json.dumps(a))
    c = core.Campaign(w, json.loads((w / "CAMPAIGN_ID.json").read_text()), core.Journal(w / "journal/campaign.jsonl"),
                      FixtureBackend())
    with pytest.raises(core.SafeStop):
        stages.require_authorization(c)


@pytest.mark.gate("OSC-36")
@pytest.mark.gate("OSC-39")
def test_no_retuning_and_analysis_immutable():
    import inspect
    from f1.workload_c.oneshot import campaign_runner
    src = inspect.getsource(stages) + inspect.getsource(campaign_runner)
    for bad in ("select_tau(", "write_text(\"{\"", "configs/workload_c", "git ", "patch"):
        if bad == "select_tau(":
            assert src.count(bad) == 1                              # only S11 selects τ
        elif bad != "patch":
            assert bad not in src
    assert "FrozenAnalysisImpl()" in inspect.getsource(campaign_runner.final_analysis)
    work, _ = case("A")
    ana = json.loads((work / "campaign/test_outputs/FINAL_ANALYSIS.json").read_text())
    assert len(ana["hypotheses"]) == 4


@pytest.mark.gate("OSC-37")
@pytest.mark.gate("OSC-38")
def test_replay_and_mutations():
    work, _ = case("A")
    chk = json.loads((work / "campaign/test_outputs/TEST_INTEGRITY_REPLAY_MUTATIONS.json").read_text())
    assert chk["ok"] and chk["replayed"] > 0 and chk["n_mutations"] > 0
    assert set(chk["mutation_status_counts"]) <= {"INVALID_MUTATION", "APPLIED"}


@pytest.mark.gate("OSC-50")
def test_case_d_n4_unclassifiable_safe_stop():
    work, rc = case("D")
    assert rc == 10 and kinds(work, "SAFE_STOP")[0]["stage"] == "S11_N4"
    assert json.loads((work / "runtime/N4_VALIDATION_SELECTION_LEDGER.json").read_text())["status"] == "BLOCKED"
    assert outputs_empty(work)


@pytest.mark.gate("OSC-50")
def test_case_f_test_integrity_failure_preserves_partial():
    work, rc = case("F")
    assert rc == 10 and kinds(work, "SAFE_STOP")[0]["stage"] == "S16_ANALYSIS"
    assert (work / "campaign/test_outputs/TEST_EXECUTION.json").exists()            # partial data preserved
    assert not (work / "campaign/test_outputs/FINAL_ANALYSIS.json").exists()         # no final analysis
    assert (work / "output" / "F1_WORKLOAD_C_CAMPAIGN_SAFE_STOP_ANALYSIS.zip").exists()


@pytest.mark.gate("OSC-41")
@pytest.mark.gate("OSC-50")
def test_case_g_interrupt_and_resume(tmp_path):
    w = tmp_path / "w"
    assert run(w, None, "--stop-after", "S07_TEST_SEALING") == 0
    before = {p["stage"]: p["digests"] for p in kinds(w, "STAGE_COMPLETE")}
    cid = json.loads((w / "CAMPAIGN_ID.json").read_text())["campaign_id"]
    assert run(w, None, "--resume", "--stop-after", "S09_VALIDATION_READINESS") == 0
    after = {p["stage"]: p["digests"] for p in kinds(w, "STAGE_COMPLETE")}
    assert all(after[k] == v for k, v in before.items()) and json.loads((w / "CAMPAIGN_ID.json").read_text())[
        "campaign_id"] == cid
    (w / "runtime" / "SELECTED_24_REGIONS.json").chmod(0o644)
    (w / "runtime" / "SELECTED_24_REGIONS.json").write_text("{}")                   # tamper a sealed output
    assert run(w, None, "--resume") == 3                                            # resume refused


@pytest.mark.gate("OSC-42")
@pytest.mark.gate("OSC-50")
def test_case_h_concurrent_launcher_rejected(tmp_path):
    w = tmp_path / "w"
    lock = core.acquire_lock(w)
    try:
        assert run(w, None) == 4
    finally:
        lock.close()


@pytest.mark.gate("OSC-43")
def test_idempotency(tmp_path):
    w = tmp_path / "w"
    assert run(w, None, "--stop-after", "S00_PREFLIGHT") == 0
    assert run(w, None) == 3                                    # --new-campaign over an existing campaign refused
    assert cli.main(["--work-root", str(w), "--backend", "fixture"]) == 2      # no mode → refused (launcher adds one)


@pytest.mark.gate("OSC-44")
@pytest.mark.gate("OSC-45")
def test_dry_run_and_preflight_only(tmp_path, capsys):
    w = tmp_path / "w"
    assert run(w, None, "--dry-run") == 0
    out = json.loads(capsys.readouterr().out)
    assert out["mode"] == "DRY_RUN" and not (w / "CAMPAIGN_ID.json").exists()
    assert run(w, None, "--preflight-only") == 0
    out = json.loads(capsys.readouterr().out)
    assert out["mode"] == "PREFLIGHT_ONLY" and "l28" in out and not (w / "journal").exists()


@pytest.mark.gate("OSC-46")
def test_status_read_only():
    work, _ = case("A")
    before = sorted((str(p), p.stat().st_mtime_ns) for p in work.rglob("*") if p.is_file())
    from f1.workload_c.oneshot.status import campaign_status
    st = campaign_status(work)
    after = sorted((str(p), p.stat().st_mtime_ns) for p in work.rglob("*") if p.is_file())
    assert before == after and st["results_package"] and st["test_authorized"] is True


@pytest.mark.gate("OSC-48")
@pytest.mark.gate("OSC-50")
def test_case_a_final_results_package():
    work, rc = case("A")
    assert rc == 0 and done(work)[-1] == "S17_RESULTS_PACKAGE"
    pkg = work / "output" / "F1_WORKLOAD_C_FIXTURE_CAMPAIGN_RESULTS_FINAL.zip"
    assert (work / "output" / (pkg.name + ".sha256")).read_text().split()[0] == core.sha256_file(pkg)
    names = zipfile.ZipFile(pkg).namelist()
    for need in ("FINAL_CAMPAIGN_FREEZE/FINAL_CAMPAIGN_FREEZE.json", "TEST_CAMPAIGN_AUTHORIZATION.json",
                 "runtime/N4_VALIDATION_SELECTION_LEDGER.json", "runtime/REAL_POPULATION_FILTER_LEDGER.csv",
                 "campaign/test_outputs/FINAL_ANALYSIS.json", "SHA256SUMS.txt"):
        assert need in names, need
    assert any(n.endswith("COLD_SECONDARY_TIMINGS.jsonl") for n in names)


@pytest.mark.gate("OSC-49")
def test_no_fabricated_real_evidence():
    for p in ROOT.rglob("*"):
        if ".git" in p.parts or not p.is_file() or p.suffix not in (".json", ".jsonl", ".csv"):
            continue
        t = p.read_text(errors="ignore")
        assert '"physical_l28": "EXECUTED_ON_TARGET"' not in t, p
        assert '"namespace": "TEST"' not in t or "test" in p.name.lower() and "fixture" in str(p).lower(), p
    work, _ = case("A")
    assert json.loads((work / "runtime/L28_RESULT.json").read_text())["physical_l28"] == "FIXTURE_SIMULATED"


# ---------------------------------------------------------------------------------------- router semconfig (amendment)
@pytest.mark.gate("OSC-51")
@pytest.mark.gate("OSC-52")
def test_semconfig_digest_stable_across_days_and_sensitive_to_semantics():
    from f1.workload_c.oneshot.semconfig_policy import BOUNDS, fixed
    from f1.workload_c.producers.otp import OtpFeedInput, OtpRequest, build_config_for
    from f1.workload_c.producers.semconfig import semantic_config_digest
    assert BOUNDS == ("2024-04-01", "2029-06-30")

    def dg(day, tz="America/Los_Angeles"):
        r = fixed(OtpRequest("ROUTER:region=R:x", "R:x", (OtpFeedInput("A", "A#1", "h", "/a.zip"),), "/o.pbf", tz, day,
                             ("2025-06-01",), "CUT:x", "FIXTURE"))
        cfg, _ = build_config_for(r)
        return semantic_config_digest(cfg, date.fromisoformat(day)), cfg
    d1, c1 = dg("2025-06-10")
    d2, c2 = dg("2025-06-11")
    assert d1 == d2 and c1["transitServiceStart"] == "2024-04-01" and c1["transitServiceEnd"] == "2029-06-30"
    assert dg("2025-06-10", "Europe/Paris")[0] != d1                     # an actual semantic field changes the digest
    rel1 = semantic_config_digest(build_config_for(OtpRequest("ROUTER:region=R:x", "R:x", (), "/o", "UTC", "2025-06-10",
                                                              (), "C", "F"))[0], date(2025, 6, 10))
    rel2 = semantic_config_digest(build_config_for(OtpRequest("ROUTER:region=R:x", "R:x", (), "/o", "UTC", "2025-06-11",
                                                              (), "C", "F"))[0], date(2025, 6, 11))
    assert rel1 != rel2                                                  # the defect the amendment removes


@pytest.mark.gate("OSC-53")
def test_k2_still_rejects_router_not_covering_d(tmp_path):
    from f1.workload_c.contracts.generators import ContractSystem
    from f1.workload_c.contracts.model import EvaluationContext
    from f1.workload_c.config.spec import load_protocol_spec
    from f1.workload_c.storage.blobstore import BlobStore
    cs = ContractSystem(BlobStore(tmp_path / "s"), load_protocol_spec().gtfs_member_names)
    z = (FIX / "base/feedA.gtfs.zip").read_bytes()
    ref = cs.blobs.put(z, "application/zip")
    from f1.workload_c.ingestion.gtfs import canonical_content_hash
    feeds = {"A": {"logical_version_id": "A#1", "canonical_content_sha256": canonical_content_hash(
        z, load_protocol_spec().gtfs_member_names), "raw_zip_sha256": ref.sha256}}
    common = dict(feeds=feeds, osm_sha256="o", semantic_config_digest="s", otp_sha256="t", country="US",
                  validator_sha256="v")
    birth = EvaluationContext("CUT:b", consumer_date="2024-06-01", horizon=("2024-06-01",), **common)
    art = {"artifact_id": "R1", "request_slot": "ROUTER:region=R:x", "birth_cut_id": "CUT:b",
           "gtfs_logical_versions": {"A": "A#1"}, "service_window": ["2024-04-01", "2024-12-31"],
           "canon_digest": "c", "graph_sha256": "g", "horizon_D": ["2024-06-01"]}
    k2 = cs.generate_router(art, birth, "K2")
    inside = EvaluationContext("CUT:b", consumer_date="2024-07-01", horizon=("2024-07-01",), **common)
    outside = EvaluationContext("CUT:b", consumer_date="2025-01-05", horizon=("2025-01-05", "2025-01-06"), **common)
    assert cs.evaluate(k2, outside).verdict == "INVALID"
    assert cs.evaluate(k2, inside).verdict in ("VALID", "INVALID")      # coverage is necessary, not sufficient


@pytest.mark.gate("OSC-54")
@pytest.mark.gate("OSC-55")
def test_every_router_path_uses_fixed_bounds_and_no_relative_fallback():
    from f1.workload_c.oneshot.semconfig_policy import BOUNDS, FixedBoundsOtp, RelativeBoundsRefused, fixed
    from f1.workload_c.producers.otp import OtpRequest
    seen = []

    class Rec:
        def produce(self, r):
            seen.append((r.service_start, r.service_end))
            return "ok"
    w = FixedBoundsOtp(Rec())
    w.produce(OtpRequest("ROUTER:region=R:x", "R:x", (), "/o", "UTC", "2025-06-10", (), "C", "F"))
    assert seen == [BOUNDS]
    with pytest.raises(RelativeBoundsRefused):
        fixed(OtpRequest("ROUTER:region=R:x", "R:x", (), "/o", "UTC", "2025-06-10", (), "C", "F", "-P1Y", "P3Y"))
    rp = (ROOT / "src/f1/workload_c/oneshot/real_producer.py").read_text()
    rb = (ROOT / "src/f1/workload_c/oneshot/real_backend.py").read_text()
    assert "FixedBoundsOtp(otp)" in rp and "FixedBoundsOtp(otp)" in rb                 # adapter, native, refs, mutations
    assert "else FixedBoundsOtp(otp))" in rp and "CanonReference(FixedBoundsOtp(otp)" in rp     # adapter (incl. K3,
    assert '"service_bounds": list(_bounds())' in rb                                    # cold) + mutation refs
    nb = (ROOT / "src/f1/workload_c/engines/baselines_n.py").read_text()
    assert 'reg.get("service_bounds")' in nb
    cfg = json.loads((ROOT / "configs/workload_c/oneshot_campaign.json").read_text())
    assert cfg["router_semantic_config_policy"] == "FIXED_CAMPAIGN_ABSOLUTE_SERVICE_BOUNDS"
    assert cfg["router_service_bounds"] == list(BOUNDS)


# ============================================================================== real-wiring corrections (audit)
def _fx_campaign(tag):
    from f1.workload_c.campaign.e2e_s4a1 import TICKS, build
    camp, run = build(Path(tempfile.mkdtemp(prefix=f"osc-wire-{tag}-")))
    camp.produce_shared = lambda until_utc: None          # build() already produced the shared ledger exactly once
    return camp, run, TICKS


def _decisions(camp, arms):
    s3 = sorted((r["method"], r["level"], r["request_id"], r["action"], r["mode"],
                 tuple(sorted(a for _, a in r["bound_artifacts"] if a))) for r in [json.loads(json.dumps(
                     __import__("f1.workload_c.engines.stats", fromlist=["record_to_json"]).record_to_json(x)))
                     for x in camp.records])
    s4 = sorted((m, tau, d.request.request_id, tuple((s.slot_id, s.action, s.artifact_id) for s in d.slots))
                for (m, tau), a in arms.items() for d in a.decisions)
    return s3, s4


METHODS = [("N0", None), ("N2", None), ("N3", None), ("N6", None), ("N4", 24), ("N4", 168)]


@pytest.mark.gate("OSC-11")
@pytest.mark.gate("OSC-50")
def test_counterbalanced_order_used_and_decisions_order_invariant(monkeypatch):
    from f1.workload_c.oneshot import cache_protocol, interleave
    arms = list(range(16))
    pos = {a: set() for a in arms}
    for k in range(16):
        o = cache_protocol.arm_order(arms, k)
        assert o == cache_protocol.arm_order(arms, k)                      # deterministic
        for i, a in enumerate(o):
            pos[a].add(i)
    assert all(len(v) == 16 for v in pos.values())                       # no arm keeps a fixed position
    camp, run, ticks = _fx_campaign("seq")                               # frozen sequential execution
    seq_arms = run.run(METHODS, ticks)
    camp.run(ticks)
    ref = _decisions(camp, seq_arms)
    camp2, _r2, _ = _fx_campaign("int")
    log = Path(tempfile.mkdtemp()) / "order.jsonl"
    s4 = interleave.OneShotS4Runner(camp2, _r2.pf)
    got = interleave.run_interleaved(camp2, s4, METHODS, ticks, log)
    assert _decisions(camp2, got) == ref                                 # identical decisions / artifacts
    orders = [json.loads(ln)["order"] for ln in log.read_text().splitlines()]
    assert len({tuple(o) for o in orders}) == len(orders) and orders[1] == orders[0][1:] + orders[0][:1]
    camp3, _r3, _ = _fx_campaign("rev")                                  # a different execution order
    monkeypatch.setattr(interleave, "arm_order", lambda a, k: list(reversed(a)))
    got3 = interleave.run_interleaved(camp3, interleave.OneShotS4Runner(camp3, _r3.pf), METHODS, ticks)
    assert _decisions(camp3, got3) == ref
    src = (ROOT / "src/f1/workload_c/oneshot/campaign_runner.py").read_text()
    assert "run_interleaved(camp, runner, methods, ticks" in src and "camp.run(ticks)" not in src


class _FakeNativeBuilderMixin:
    """Stands in for the pinned OTP process only: records calls; returns measured process numbers (not synthetic)."""
    def setup_fake(self, root):
        from f1.workload_c.engines.baselines_n import FixtureNativeOtpBuilder
        self._fx = FixtureNativeOtpBuilder(root / "fx")
        self.built = []


@pytest.mark.gate("OSC-17")
@pytest.mark.gate("OSC-11")
def test_real_native_mechanism_for_n2_n3_n4_n6(monkeypatch, tmp_path):
    from f1.workload_c.engines import baselines_n
    from f1.workload_c.interfaces import session3 as S
    from f1.workload_c.oneshot import interleave
    camp, run, ticks = _fx_campaign("native")
    builders, warms = {}, []

    def fake_initial(self, region_id, envelope_digest=None):
        self.preprocessing[region_id] = {"wall_s": 777.0, "cpu_s": 700.0, "identity": f"street-{id(self)}"}
        return S.NativeOtpState(region_id, str(tmp_path / "street.obj"), "s" * 64, str(tmp_path / f"c{id(self)}"),
                                "m", "env", None, None)

    def fake_build(self, view):
        router = [s for s in view.request.request_slots if s.startswith("ROUTER:")][0]
        job = tmp_path / f"job{id(self)}"
        job.mkdir(exist_ok=True)
        (job / "graph.obj").write_bytes(b"g")
        self.last_evidence = {"job": str(job)}
        self.last_cpu_s = 45.5
        self.built.append(view.request.tick_utc)
        st = S.RederivationStep(router, view.request.current_cut.cut_id, "otp", 0.0, "SUCCESS", "N1:" + "a" * 24, "pd",
                                123.25)
        new = S.NativeOtpState(view.native_state.region_id, "p", "s" * 64, "c", "m2", "env",
                               tuple(view.current_router_inputs), "b" * 64)
        return st, new, ()
    monkeypatch.setattr(baselines_n.RealNativeOtpBuilder, "initial_state", fake_initial)
    monkeypatch.setattr(baselines_n.RealNativeOtpBuilder, "build", fake_build)

    def factory(method, tau, mc):
        b = interleave.WarmingNativeBuilder(None, tmp_path / f"{method}{tau}", "env",
                                            warm=lambda t: warms.append((method, tau, t)))
        b.built = []
        builders[(method, tau)] = b
        return interleave.NativeSlotProducer(camp.r, camp.cs, camp.contexts, b, lambda *a: "canon-native", real=True)
    s4 = interleave.OneShotS4Runner(camp, run.pf, native_factory=factory)
    keys = [("N2", None), ("N3", None)] + [("N4", t) for t in (1, 6, 24, 72, 168)] + [("N6", None)]
    arms = interleave.run_interleaved(camp, s4, keys, ticks)
    for key in keys:
        b = builders[key]
        items = [i for d in arms[key].decisions for i in d.costs.items]
        nat = [i for i in items if i.component == "producer:otp:n1_native"]
        assert len(nat) == len(b.built), key                                 # every native rerun reached ITS builder
        assert all(i.wall_s == 123.25 and i.cpu_s == 45.5 for i in nat), key # measured, not 0.0 / 1800
        assert b.built or key[0] == "N4", key                                # long τ may never expire in 6 days
        pre = [i for i in items if i.component == "n1_native_preprocessing"]
        assert len(pre) == 1 and pre[0].wall_s == 777.0, key                  # charged once to THIS arm
        mine = [w[2] for w in warms if (w[0], w[1]) == key]
        assert all(t in mine for t in b.built), key                          # warm before every native rebuild
        assert ticks[0] in mine, key                                          # and before the arm's street build
        ent = [e for s in arms[key].mc.overlay.slots() for e in arms[key].mc.overlay.instances(s)
               if s.startswith("ROUTER:")]
        assert len(ent) == len(b.built) and all(dict(e.output_digests)["mechanism"] == "N1_NATIVE_CONFIG"
                                                for e in ent), key
    router = "ROUTER:region=R:S4"
    for key in keys:                                                          # drive the exact S4 native path per arm
        before = {k: len(v.built) for k, v in builders.items()}
        st = arms[key].nat.rederive(router, camp.r.current_cut(ticks[-1]), ticks[-1], 0.0)
        assert st.outcome == "SUCCESS" and st.measured_wall_s == 123.25, key
        after = {k: len(v.built) for k, v in builders.items()}
        assert after[key] == before[key] + 1 and all(after[k] == before[k] for k in keys if k != key), key
    assert any(len(builders[("N4", t)].built) > 1 for t in (1, 6, 24)) and all(builders[("N4", t)].built
                                                                                 for t in (1, 6, 24, 72, 168))
    assert len({id(b) for b in builders.values()}) == len(keys) == 8          # isolated per-arm native state
    assert len({b.root for b in builders.values()}) == 8                      # every N4 τ arm owns its builder root
    p = interleave.NativeSlotProducer(camp.r, camp.cs, camp.contexts, builders[("N2", None)], lambda *a: "c", real=True)
    monkeypatch.setattr(baselines_n.RealNativeOtpBuilder, "build",
                        lambda self, v: (S.RederivationStep("ROUTER:region=R:S4", "CUT", "otp", 0.0, "SUCCESS", "N1:x",
                                                            "pd", 0.0), v.native_state, ()))
    with pytest.raises(interleave.SyntheticNativeDurationRefused):            # REAL: synthetic duration forbidden
        p.produce("ROUTER:region=R:S4", camp.r.current_cut(ticks[1]), ticks[1])
    rb = (ROOT / "src/f1/workload_c/oneshot/real_backend.py").read_text()
    assert "native_wall_s = None" in rb and "NativeSlotProducer(region, cs, ctxf, b, canon_fn, real=True)" in rb


@pytest.mark.gate("OSC-11")
@pytest.mark.gate("OSC-17")
def test_n1_native_warm_and_cold_pass_mechanism(monkeypatch, tmp_path):
    from f1.workload_c.engines import baselines_n
    from f1.workload_c.engines.core import Produced
    from f1.workload_c.oneshot import interleave
    camp, run, ticks = _fx_campaign("n1warm")
    warms = []
    wb = interleave.WarmingNativeBuilder(None, tmp_path / "n1", "env", warm=lambda t: warms.append(t))
    fx = baselines_n.FixtureNativeOtpBuilder(tmp_path / "fx")
    monkeypatch.setattr(baselines_n.RealNativeOtpBuilder, "initial_state",
                        lambda self, rid, env=None: fx.initial_state(rid, env))
    monkeypatch.setattr(baselines_n.RealNativeOtpBuilder, "build", lambda self, view: fx.build(view))
    camp.native_builder = wb
    s4 = interleave.OneShotS4Runner(camp, run.pf)

    def before(kind, arm, t):
        wb.current_tick = t
    arms = interleave.run_interleaved(camp, s4, METHODS, ticks, None, before)
    reb = [t for what, t in wb.warm_calls if what == "native_rebuild"]
    assert reb and set(reb) <= set(ticks) and ("street_build", ticks[0]) in wb.warm_calls   # N1 warm before builds

    class Generic:
        def execute(self, slot, cut, t):
            return Produced("SUCCESS", "G", (), 11.0, 1.0, "g", {"output_digests": [("canon", "x")]})

    class Native:
        def produce(self, slot, cut, t):
            return Produced("SUCCESS", "N", (), 22.0, 2.0, "n", {"output_digests": [("mechanism", "N1_NATIVE_CONFIG")]})
    drops = []
    path = interleave.cold_pass_mechanism(camp.r, camp, arms, tmp_path, Generic(), lambda lab: Native(),
                                          lambda: drops.append(1))
    rows = [json.loads(ln) for ln in path.read_text().splitlines()]
    assert rows and len(drops) == len(rows)                                   # page cache dropped before EACH
    for r in rows:
        native = r["slot_id"].startswith("ROUTER:") and r["arm"].split(":")[0].split("@")[0] in ("N1", "N2", "N3",
                                                                                                "N4", "N6")
        assert (r["marker"] == "N1_NATIVE_CONFIG") == native and r["cold_wall_s"] == (22.0 if native else 11.0), r
    assert any(r["arm"].startswith(("N2", "N3", "N4", "N6")) and r["marker"] == "N1_NATIVE_CONFIG" for r in rows)
    assert any(r["arm"].startswith(("F1", "N5", "N0")) and r["marker"] == "GENERIC" for r in rows)


@pytest.mark.gate("OSC-45")
def test_real_preflight_only_uses_temporary_runtime(monkeypatch, tmp_path):
    from f1.workload_c.campaign import s2
    from f1.workload_c.oneshot import real_backend
    seen = {}

    def fake_l28(out, sandbox, work):
        seen["out"], seen["work"] = Path(out), Path(work)
        Path(out).mkdir(parents=True, exist_ok=True)
        return {"authoritative": {"overall": "BLOCKED", "physical_l28": "NOT_EXECUTED_ON_TARGET", "reason": "test"}}
    monkeypatch.setattr(s2, "run_l28", fake_l28)
    monkeypatch.setattr(real_backend.RealBackend, "preflight_network",
                        lambda self: {"mobility_auth": "NOT_PROBED", "mobility_tls": "TEST", "osm_source": "FAIL"})
    tok = tmp_path / "tok"
    tok.write_text("SYNTHETIC")
    wr = tmp_path / "wr"
    rc = cli.main(["--work-root", str(wr), "--backend", "real", "--preflight-only", "--mobility-token-file", str(tok)])
    assert rc in (0, 5) and "out" in seen
    assert not str(seen["out"]).startswith(str(wr)) and not seen["out"].exists()      # temporary, cleaned up
    assert not (wr / "CAMPAIGN_ID.json").exists() and not (wr / "runtime").exists() and not (wr / "journal").exists()
    assert not (wr / "work").exists()


# ============================================================================== REAL OSM hull = Phase-05 in_force_lv (E1)
def _stops_zip(points):
    import io
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("stops.txt", "stop_id,stop_name,stop_lat,stop_lon,location_type\n" +
                   "".join(f"s{i},S{i},{lat},{lon},0\n" for i, (lon, lat) in enumerate(points)))
    return buf.getvalue()


@pytest.mark.gate("OSC-16")
def test_real_osm_hull_uses_exact_phase05_in_force_lv(monkeypatch, tmp_path):
    from f1.workload_c.oneshot import osm_v3, real_backend
    instant = json.loads((ROOT / "configs/workload_c/spec_interpretations.json").read_text())["parameters"][
        "in_force_instant_utc"]
    assert instant == "2025-04-01T00:00:00Z"                                   # frozen INT-01
    a_pts = [(-122.40, 37.70), (-122.30, 37.70), (-122.30, 37.80), (-122.40, 37.80)]
    b_pts = [(-73.99, 40.70), (-73.90, 40.70), (-73.90, 40.80)]                 # geographically different
    blobs = {"za": _stops_zip(a_pts), "zb": _stops_zip(b_pts)}
    A = {"feed_id": "F", "index": 1, "logical_version_id": "F#A", "canonical_content_sha256": "ca",
         "raw_zip_sha256s": ["za"], "first_observed_utc": "2025-03-15T08:00:00Z"}
    B = {"feed_id": "F", "index": 2, "logical_version_id": "F#B", "canonical_content_sha256": "cb",
         "raw_zip_sha256s": ["zb"], "first_observed_utc": "2025-04-01T12:00:00Z"}
    region = {"region_id": "R:F", "feeds": [{"feed_id": "F", "in_force_lv": "F#A"}]}
    with_b = osm_v3.in_force_hull_points(region, [A, B], blobs.__getitem__, instant)
    without_b = osm_v3.in_force_hull_points(region, [A], blobs.__getitem__, instant)
    assert sorted(with_b) == sorted(a_pts) and not set(b_pts) & set(with_b)    # A only; B contributes zero points
    assert osm_v3.convex_hull(with_b) == osm_v3.convex_hull(without_b)
    assert osm_v3.expanded_bbox(osm_v3.convex_hull(with_b)) == osm_v3.expanded_bbox(osm_v3.convex_hull(without_b))
    old = max([v for v in (A, B) if v["first_observed_utc"] <= "2025-04-01T23:59:59Z"], key=lambda v: v["index"])
    assert old is B                                                            # the defect the fix removes
    for bad_region, versions, getter in (
            ({"region_id": "R:F", "feeds": [{"feed_id": "F"}]}, [A], blobs.__getitem__),              # missing lv
            (region, [B], blobs.__getitem__),                                                         # no record
            (region, [A, dict(A, canonical_content_sha256="other")], blobs.__getitem__),             # inconsistent
            (region, [A], lambda h: (_ for _ in ()).throw(OSError("unreadable"))),                    # unreadable
            ({"region_id": "R:F", "feeds": [{"feed_id": "F", "in_force_lv": "F#B"}]}, [A, B], blobs.__getitem__)):
        with pytest.raises(osm_v3.OsmHullError):                                                     # fail closed
            osm_v3.in_force_hull_points(bad_region, versions, getter, instant)
    assert len(osm_v3.in_force_hull_points(region, [A, dict(A)], blobs.__getitem__, instant)) == 4    # consistent dup

    seen = {}

    def fake_pin(rid, hull, out_dir, osmium="osmium", fetch=None, index_cache=None):     # no network in tests
        seen["hull"] = hull
        p = out_dir / "r.osm.pbf"
        out_dir.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b"x")
        return {"region_id": rid, "raw_path": str(p), "region_path": str(p), "region_sha256": "h"}
    monkeypatch.setattr(osm_v3, "pin_region", fake_pin)

    class DP:
        def versions_of_region(self, rid):
            return [A, B]

        class blobs:                                 # noqa: N801
            get = staticmethod(blobs.__getitem__)
    c = type("C", (), {"state": {"dp": DP()}, "work_root": tmp_path})()
    rb = real_backend.RealBackend(None)
    rb.osm_pin(c, region, tmp_path / "osm")                                    # the REAL path itself
    assert seen["hull"] == osm_v3.convex_hull(a_pts)
    from f1.workload_c.oneshot.core import SafeStop
    with pytest.raises(SafeStop):
        rb.osm_pin(c, {"region_id": "R:F", "feeds": [{"feed_id": "F"}]}, tmp_path / "osm")
    assert "23:59:59" not in (ROOT / "src/f1/workload_c/oneshot/real_backend.py").read_text()
    from f1.workload_c.campaign import dataplane
    assert 'version_in_force(vs, p["in_force_instant_utc"])' in (ROOT / "src/f1/workload_c/campaign/dataplane.py"
                                                                  ).read_text() and dataplane   # Phase-05 source
