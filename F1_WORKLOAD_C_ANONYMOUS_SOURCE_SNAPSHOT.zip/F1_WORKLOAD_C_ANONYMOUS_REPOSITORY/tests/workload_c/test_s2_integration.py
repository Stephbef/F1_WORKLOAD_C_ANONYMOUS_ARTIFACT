"""Session-2 gates S2-01, S2-03, S2-04, S2-47..S2-50 (integrity, S1 rerun, INT audit, orchestrator, E2E, real-mode,
no study data)."""
import csv
import json
import os
import hashlib
import re
import subprocess
import sys
from pathlib import Path

import pytest

from conftest import ROOT, make_orchestrator

S1_COMMIT = "ce6fa0ba449ad8a0cfa49743de40011c632c6b39"
S1_TREE = "f2e8ca4d4e5fad7f08143929c7a660e4193854dd"
S1_ZIP_SHA = "b1b9cd45ae7e7135324e46f539895e5cfb02619ddb106f7031e5c759319228c8"
REPORTS = Path(os.environ.get("F1_WC_REPORT_DIR", ROOT / "reports"))


def _git(*a):
    return subprocess.run(["git", *a], cwd=ROOT, capture_output=True, text=True)


@pytest.mark.gate("S2-01")
def test_session1_integrity_recorded_and_ancestry():
    ev = json.loads((ROOT / "docs" / "S1_INTEGRITY_EVIDENCE.json").read_text())
    assert ev["input_zip_sha256"] == S1_ZIP_SHA and ev["sha256sums_verified"] == ev["sha256sums_entries"] == 320
    assert ev["source_manifest_verified"] == 225 and ev["frozen_specs_verified"] == 27
    assert ev["bundle_commit"] == S1_COMMIT and ev["bundle_tree"] == S1_TREE and ev["checkout_matches_source_manifest"]
    if (ROOT / ".git").exists() and not (ROOT / "ANONYMIZED_REVIEW_ARTIFACT").exists():
        assert _git("rev-parse", f"{S1_COMMIT}^{{tree}}").stdout.strip() == S1_TREE
        assert _git("merge-base", "--is-ancestor", S1_COMMIT, "HEAD").returncode == 0     # S2 extends S1


@pytest.mark.gate("S2-03")
def test_s1_gates_rerun_all_pass():
    rows = list(csv.DictReader(open(REPORTS / "s1" / "S1_GATE_LEDGER.csv")))
    assert len(rows) == 30 and all(r["status"] == "PASS" for r in rows)
    assert all(int(r["tests_skipped"]) == 0 and int(r["tests_failed"]) == 0 for r in rows)


AUDIT_FIELDS = ("ID", "Issue", "Current implementation", "Authoritative frozen evidence", "Resolution", "Code affected",
                "Tests affected", "Status")


@pytest.mark.gate("S2-04")
def test_int_audit_complete_and_consistent():
    txt = (ROOT / "docs" / "INT01_INT10_RESOLUTION_AUDIT.md").read_text()
    blocks = re.split(r"^## ", txt, flags=re.M)[1:]
    ids = [b.split()[0] for b in blocks]
    assert [i for i in ids if i.startswith("INT-")] == [f"INT-{k:02d}" for k in range(1, 11)] and "SCH-01" in ids
    allowed = {"FROZEN_PRE_S3"}                                     # PRE-S3: every item frozen before outcomes
    for b in blocks:
        for f in AUDIT_FIELDS:
            assert f"**{f}:**" in b, (b.split()[0], f)
        st = re.search(r"\*\*Status:\*\*\s*(\S+)", b).group(1)
        assert st in allowed, (b.split()[0], st)
    reg = json.loads((ROOT / "configs/workload_c/spec_interpretations.json").read_text())
    assert reg["status"] == "PI_CONFIRMED" and all(i["status"] == "FROZEN_PRE_S3" for i in reg["items"])
    assert reg["parameters"]["agency_identity"] == "exact_agency_id"
    assert reg["parameters"]["stop_rows_used"] == "boarding_points_location_type_blank_or_0"


@pytest.mark.gate("S2-47")
def test_orchestrator_integration_real_phases(cfg, tmp_path):
    o, _ = make_orchestrator(cfg, tmp_path, run_id="s2orch")
    res = o.run()
    assert res.status == "COMPLETE"
    d = res.run_dir / "phases"
    l28 = json.loads((d / "01_l28_target_conformance/target_result.json").read_text())
    assert l28["physical_l28"] == "NOT_EXECUTED_ON_TARGET" and l28["l28"]["overall"] != "PASS"
    assert l28["phase_gate"] == "FIXTURE_ONLY_ACCEPTED"
    pre = json.loads((d / "00_bootstrap_preflight/pinned_dependencies.json").read_text())
    assert {s["name"] for s in pre["statuses"]} >= {"otp", "gtfs-validator", "jdk"}
    seal = json.loads((d / "09_scientific_freeze/freeze_seal.json").read_text())
    assert seal["mock"] is False and any(k.startswith("frozen_specs/") for k in seal["files"])
    conf = json.loads((d / "10_implementation_conformance/implementation_conformance.json").read_text())
    assert conf["overall"] == "PASS" and conf["mock"] is False and conf["fixtures_verified"] == 146
    from f1.workload_c.campaign.phases import PHASES
    eng = {p.phase_id: p.engine for p in PHASES}
    assert eng["01_l28_target_conformance"] == eng["09_scientific_freeze"] == eng["10_implementation_conformance"] == "REAL_S2"
    phase_marker = ROOT / "configs/workload_c/session_phase.json"
    if phase_marker.exists() and json.loads(phase_marker.read_text())["phase"] == "S3":   # Session 3: real engines
        assert all(eng[p] == "REAL_S3" for p in ("11_validation", "13_scientific_test_campaign",
                                                 "14_result_reconciliation", "15_raw_result_seal",
                                                 "16_frozen_statistics"))
    else:
        assert eng["13_scientific_test_campaign"] == "MOCK_ADAPTER"


@pytest.mark.gate("S2-47")
def test_real_mode_phase01_blocks_without_target(tmp_path):
    from f1.workload_c.campaign import later_phases as lp
    from f1.workload_c.errors import PhaseBlocked

    class Ctx:
        mode = "REAL"
        namespace = "VALIDATION"
        services = {"l28_runner": lambda p: {"overall": "BLOCKED", "physical_l28": "NOT_EXECUTED_ON_TARGET"}}
        phase_dir = tmp_path
        written: dict = {}

        def rel(self, n):
            return n

        def write_json(self, n, o):
            pass
    with pytest.raises(PhaseBlocked):
        lp.phase01_l28(Ctx())


@pytest.mark.gate("S2-48")
def test_real_e2e_pipeline(real_e2e):
    s = real_e2e
    assert s["invariants_ok"] and s["binary_mode"] == "REAL_PINNED_BINARY" and s["scientific_results"] == "NONE"
    assert s["n_logical_versions"] == 4 and s["n_artifacts"] == 8 and s["n_contracts"] == 28
    classes = {tuple(v) for v in s["evaluation_verdicts"]}
    assert ("K2", "VALID") in classes and ("K0", "INVALID") in classes
    routers = [o for o in s["outcomes"] if o["slot"].startswith("ROUTER")]
    assert len(routers) == 3 and all(o["failure_class"] == "SUCCESS" for o in routers)
    assert len({o["canon"] for o in routers}) == 3          # Canon_D binds D: builds on different days differ
    # A,B,A through contracts: the first router (A1,B1) is K0/K2-INVALID while fixA is at version 2 (o5: changed
    # stop_times) and K0/K2-VALID again once fixA returns to the A content (version 3)
    d = Path(s["_dir"])
    sched = {e["t"]: e for e in json.loads((d / "schedule.json").read_text()) if e["kind"] == "CONSUMER_TICK"}
    ev = [json.loads(x) for x in (d / "evaluations.jsonl").read_text().splitlines() if x]
    first = sorted({e["artifact"] for e in ev})
    r1 = min(first, key=lambda a: min(e["tick"] for e in ev if e["artifact"] == a))
    by = {(sched[e["tick"]]["cut"]["fixA"], e["level"]): e["verdict"] for e in ev if e["artifact"] == r1}
    assert by[(2, "K0")] == "INVALID" and by[(2, "K2")] == "INVALID"
    assert by[(3, "K0")] == "VALID" and by[(3, "K2")] == "VALID"


@pytest.mark.gate("S2-48")
def test_stub_e2e_deterministic(tmp_path):
    from f1.workload_c.campaign.e2e import run_fixture_e2e
    a = run_fixture_e2e(tmp_path / "a", "stub")["summary"]
    b = run_fixture_e2e(tmp_path / "b", "stub")["summary"]
    assert a["invariants_ok"] and a["semantic_digest"] == b["semantic_digest"] and a["binary_mode"] == "FIXTURE_STUB_BINARY"


@pytest.mark.gate("S2-49")
def test_real_mode_refuses_with_session34_message(tmp_path):
    env = {**os.environ, "PYTHONPATH": str(ROOT / "src")}
    cp = subprocess.run([sys.executable, "-m", "f1.workload_c.campaign.cli", "run", "--real", "--run-root", str(tmp_path)],
                        env=env, capture_output=True, text=True)
    out = json.loads(cp.stdout)
    assert cp.returncode == 3 and out["reason"] == "REAL_MODE_NOT_YET_IMPLEMENTATION_COMPLETE"
    assert "Session 3/4" in out["detail"] and not any(tmp_path.iterdir())
    from f1.workload_c.campaign.orchestrator import Orchestrator
    from f1.workload_c.config.runtime import load_effective_config
    from f1.workload_c.errors import RealModeRefused
    with pytest.raises(RealModeRefused) as e:
        Orchestrator(load_effective_config(ROOT / "configs/workload_c/real.yaml"), tmp_path, "r").run()
    assert "Session 3/4" in str(e.value)


@pytest.mark.gate("S2-50")
def test_no_real_study_data_accessed():
    """S2-50 — LIFECYCLE CRITERION (ONESHOT-CR-01, E2, PI-approved): real backend capability may exist, but zero real
    study-data access occurred during build/regression and every non-real execution path is structurally isolated
    from it. The original S2-freeze test (no transport constructor anywhere) is preserved verbatim with its provenance
    in docs/oneshot/provenance/S2_50_ORIGINAL_TEST.py.txt / S2_50_HISTORICAL_PROVENANCE.json (commit f1e9368)."""
    import ast
    hits, sites = [], []
    for p in (ROOT / "src").rglob("*.py"):
        t = p.read_text()
        if "api.mobilitydatabase.org" in t:
            hits.append(str(p))
        for node in ast.walk(ast.parse(t)):
            if isinstance(node, ast.Call) and getattr(node.func, "id", getattr(node.func, "attr", "")) == "UrllibTransport":
                sites.append(p)
    assert hits == []
    allowed = ROOT / "src/f1/workload_c/oneshot/real_backend.py"
    assert sites == [allowed]                                     # exactly ONE construction site in the repository
    tree = ast.parse(allowed.read_text())
    rb = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "RealBackend"][0]
    owner = [f.name for f in rb.body if isinstance(f, ast.FunctionDef) and "UrllibTransport(" in ast.unparse(f)]
    assert owner == ["_real_transport"]                           # ... inside the gated method only
    gated = ast.unparse([f for f in rb.body if isinstance(f, ast.FunctionDef) and f.name == "_real_transport"][0])
    for cond in ("self.real_campaign", "self.secret_present()", "S00_PREFLIGHT", "S01_L28"):
        assert cond in gated, cond
    assert all("UrllibTransport(" not in ast.unparse(n) for n in tree.body if not isinstance(n, ast.ClassDef))
    cli_src = (ROOT / "src/f1/workload_c/oneshot/cli.py").read_text()
    assert "real_campaign=bool(args.new_campaign or args.resume)" in cli_src
    hist = json.loads((ROOT / "docs/oneshot/provenance/S2_50_HISTORICAL_PROVENANCE.json").read_text())
    orig = (ROOT / hist["original_test_text"]).read_bytes()
    assert hashlib.sha256(orig).hexdigest() == hist["original_test_text_sha256"]
    assert b'"UrllibTransport(" in t and "class UrllibTransport" not in t' in orig      # historical meaning preserved
    assert not any((ROOT / d).exists() and any((ROOT / d).rglob("*")) for d in
                   ("runtime", "campaign/validation", "campaign/test_outputs", "campaign/test_inputs"))
    for f in ROOT.rglob("*.json"):                               # no REAL population / VALIDATION / TEST output
        if ".git" in f.parts or ".deps" in f.parts:
            continue
        t = f.read_text(errors="ignore")
        assert '"namespace": "VALIDATION"' not in t and '"namespace": "REAL"' not in t, f
    assert "api.mobilitydatabase.org" in (ROOT / "configs/workload_c/real.yaml").read_text()
    from f1.workload_c.campaign import fixture
    from f1.workload_c.config.runtime import load_effective_config
    w = fixture.fixture_wiring(load_effective_config(ROOT / "configs/workload_c/fixture.yaml"))
    assert type(w["services"]["transport"]).__name__ == "MockMobilityServer"
    assert "mock.mobilitydatabase.invalid" in w["services"]["transport"].base
    audit = (ROOT / "docs" / "RESEARCH_INTEGRITY_AUDIT_S2.md").read_text()
    answers = re.findall(r"^\|\s*\d+\s*\|[^|]+\|\s*\*\*(\w+)\*\*\s*\|", audit, flags=re.M)
    assert len(answers) == 10 and set(answers) == {"NO"}


@pytest.mark.gate("S2-47")
def test_session3_interfaces_stable_and_typed():
    import typing
    from f1.workload_c.interfaces import session3 as S
    for name in S.SESSION3_INTERFACES:
        assert getattr(getattr(S, name), "_is_protocol", False), name
    hints = typing.get_type_hints(S.AdmissionEngine.admit)
    assert hints["binding"] is S.RequestBinding and hints["return"].__name__ == "AdmissionDecision"
    assert typing.get_type_hints(S.ConsumerRequest)["current_cut"].__name__ == "Cut"


def _no_network(monkeypatch, calls):
    import socket

    def refuse(*a, **k):
        calls.append(a)
        raise AssertionError("network I/O attempted")
    monkeypatch.setattr(socket.socket, "connect", refuse)
    monkeypatch.setattr(socket, "create_connection", refuse)


@pytest.mark.gate("S2-50")
def test_real_transport_unreachable_from_non_real_paths(tmp_path, monkeypatch):
    """Negative isolation proofs: import, fixture backend, --dry-run, tests without explicit real mode, missing token,
    failed preflight — none can reach the real transport or perform network I/O."""
    import importlib
    calls: list = []
    _no_network(monkeypatch, calls)
    from f1.workload_c.oneshot import real_backend as RBM
    importlib.reload(RBM)                                         # import has no network side effect
    from f1.workload_c.oneshot import cli, core
    from f1.workload_c.oneshot.fixture_backend import FixtureBackend
    tok = tmp_path / "token"
    tok.write_text("SYNTHETIC-NOT-A-TOKEN")
    w = tmp_path / "w"
    c = core.open_campaign(w, cli.source_identity(), "REAL", True, False, FixtureBackend())
    with pytest.raises(RBM.RealTransportRefused, match="not an explicit real-campaign"):
        RBM.RealBackend(str(tok))._real_transport(c)              # tests without explicit real mode
    with pytest.raises(RBM.RealTransportRefused, match="token file absent"):
        RBM.RealBackend(None, real_campaign=True)._real_transport(c)       # missing token
    with pytest.raises(RBM.RealTransportRefused, match="preflight"):
        RBM.RealBackend(str(tok), real_campaign=True)._real_transport(c)   # preflight (S00, S01) not passed
    rb = RBM.RealBackend(str(tok), real_campaign=True)
    with pytest.raises(RBM.RealTransportRefused):
        rb.external_access(c)                                     # S02 path refuses before any I/O
    with pytest.raises(RBM.RealTransportRefused):
        rb.dataplane_wiring(c)                                    # population path refuses before any I/O
    b = cli.make_backend("real", type("A", (), {"mobility_token_file": str(tok), "new_campaign": False,
                                                "resume": False, "fixture_faults": None})())
    assert b.real_campaign is False                               # dry-run / preflight-only never enable it
    assert cli.main(["--work-root", str(tmp_path / "d"), "--backend", "real", "--dry-run"]) in (0, 5)
    assert cli.main(["--work-root", str(tmp_path / "f"), "--backend", "fixture", "--new-campaign",
                     "--stop-after", "S05_SELECTION"]) == 0       # fixture campaign incl. population: mock only
    assert calls == []                                            # zero network I/O in all of the above
