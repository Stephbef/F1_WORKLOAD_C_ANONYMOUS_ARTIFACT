import base64
import json
import pickle
import urllib.parse

import pytest

from conftest import ROOT
from f1.workload_c.campaign.fixture import FIXTURE_CANARY
from f1.workload_c.errors import MissingSecretError, MobilityUnauthenticated
from f1.workload_c.security.secrets import (REDACTOR, EnvSecretProvider, scan_paths)
from f1.workload_c.state.journal import AppendOnlyJournal

FAKE = "unit-canary-token-ABCDEFGH-12345678"


@pytest.mark.gate("S1-08")
def test_env_provider_allowlist_and_masking():
    p = EnvSecretProvider({"MOBILITY_DB_TOKEN": FAKE})
    s = p.get("MOBILITY_DB_TOKEN")
    assert FAKE not in repr(s) and FAKE not in str(s) and s.reveal() == FAKE
    with pytest.raises(TypeError):
        pickle.dumps(s)
    with pytest.raises(MissingSecretError):
        p.get("AWS_SECRET_ACCESS_KEY")
    with pytest.raises(MissingSecretError):
        EnvSecretProvider({}).get("MOBILITY_DB_TOKEN")
    assert EnvSecretProvider({}).get("MOBILITY_DB_TOKEN", required=False) is None


@pytest.mark.gate("S1-08")
def test_redactor_forms_and_structures():
    REDACTOR.register(FAKE)
    forms = [FAKE, urllib.parse.quote(FAKE, safe=""), base64.b64encode(FAKE.encode()).decode()]
    for f in forms:
        assert f not in REDACTOR.redact_text(f"prefix {f} suffix")
    obj = {"Authorization": "Bearer abcdefghijklmnopqrstuvwxyz", "nested": [{"msg": f"tok={FAKE}"}],
           "refresh_token": "whatever-value-123456"}
    red = json.dumps(REDACTOR.redact(obj))
    assert FAKE not in red and "abcdefghijklmnop" not in red and "whatever-value" not in red
    assert REDACTOR.redact_text('{"access_token": "zzzzzzzzzzzzzzzzzz"}').count("zzzz") == 0


@pytest.mark.gate("S1-08")
def test_exception_and_journal_and_checkpoint_redaction(tmp_path):
    REDACTOR.register(FAKE)
    e = MobilityUnauthenticated(f"failure with {FAKE} inside", url=f"https://x/?token={FAKE}")
    assert FAKE not in json.dumps(REDACTOR.redact(e.to_record()))
    j = AppendOnlyJournal(tmp_path / "j.jsonl")
    j.append({"message": f"leak {FAKE}", "error": e.to_record()})
    assert FAKE not in (tmp_path / "j.jsonl").read_text()
    from f1.workload_c.checkpoint.store import CheckpointStore, RunIdentity
    (tmp_path / "o.txt").write_text("x")
    cs = CheckpointStore(tmp_path / "cp", tmp_path)
    ident = RunIdentity("r", "i", "c", "s", "FIXTURE", "FIXTURE")
    cs.write(ident, "00_x", {"o.txt": __import__("hashlib").sha256(b"x").hexdigest()}, "h" * 64, 1, f"m-{FAKE}")
    assert FAKE not in (tmp_path / "cp" / "00_x.json").read_text()


@pytest.mark.gate("S1-08")
def test_full_fixture_run_contains_no_secret(full_run):
    assert full_run["result"].status == "COMPLETE"
    srv = full_run["wiring"]["services"]["server"]
    issued = sorted(srv._issued) or [f"mock-access-{i:04d}-" + "x" * 16 for i in range(1, srv._n_issued + 1)]
    needles = [FIXTURE_CANARY, *issued, base64.b64encode(FIXTURE_CANARY.encode()).decode(),
               urllib.parse.quote(FIXTURE_CANARY, safe="")]
    assert scan_paths([full_run["dir"]], needles) == []
    # the canary really was used to authenticate (otherwise the scan would be vacuous)
    assert srv._n_issued >= 1 and srv.refresh_token == FIXTURE_CANARY


@pytest.mark.gate("S1-08")
def test_secret_scan_detects_planted_secret(tmp_path):
    (tmp_path / "a.log").write_text(f"oops {FAKE}")
    import zipfile
    with zipfile.ZipFile(tmp_path / "b.zip", "w") as z:
        z.writestr("inner.txt", FAKE)
    found = scan_paths([tmp_path], [FAKE])
    assert {f["path"].split("/")[-1] for f in found} == {"a.log", "b.zip", "b.zip!inner.txt"}


@pytest.mark.gate("S1-08")
def test_repository_fixtures_and_specs_contain_no_secret():
    assert scan_paths([ROOT / "fixtures", ROOT / "configs" / "workload_c", ROOT / "frozen_specs"],
                      [FIXTURE_CANARY]) == []
