import json

import pytest

from f1.workload_c.api.mobility import MobilityClient
from f1.workload_c.api.mock import Fault, MockMobilityServer
from f1.workload_c.api.transport import RecordingSleeper
from f1.workload_c.errors import (MobilityForbidden, MobilityMalformedResponse, MobilityNotFound,
                                  MobilityPaginationError, MobilityRateLimited, MobilityServerError,
                                  MobilityTransportError, MobilityUnauthenticated, SourceLocatorError)
from f1.workload_c.security.secrets import StaticSecretProvider
from f1.workload_c.timeutil import FixedTickClock

BASE = "https://mock.mobilitydatabase.invalid/v1"
TOKEN = "unit-test-refresh-token-0123456789"
MCFG = {"base_url": BASE, "auth_mode": "refresh_token_exchange", "page_limit": 3, "timeout_s": 5,
        "retry": {"max_attempts": 4, "base_delay_s": 1.0, "factor": 2.0, "max_delay_s": 5.0, "max_retry_after_s": 10.0},
        "token_env": "MOBILITY_DB_TOKEN", "require_token": True}


def feeds(n):
    return [{"id": f"mdb-{i:03d}", "status": "active", "data_type": "gtfs"} for i in range(n)]


def make(catalog=None, datasets=None, files=None, token=TOKEN, mcfg=None, **kw):
    srv = MockMobilityServer(BASE, catalog if catalog is not None else feeds(8), datasets or {}, files or {},
                             refresh_token=TOKEN, **kw)
    sl = RecordingSleeper()
    c = MobilityClient(mcfg or MCFG, StaticSecretProvider({"MOBILITY_DB_TOKEN": token}), srv, sl, FixedTickClock())
    return c, srv, sl


@pytest.mark.gate("S1-05")
def test_multi_page_catalog_stable_order():
    c, srv, _ = make(catalog=feeds(8))
    items, recs = c.list_gtfs_feeds()
    assert [x["id"] for x in items] == [f"mdb-{i:03d}" for i in range(8)]
    pages = [x for x in srv.calls if x["path"].endswith("/gtfs_feeds")]
    assert [p["query"] for p in pages] == ["limit=3&offset=0", "limit=3&offset=3", "limit=3&offset=6"]
    assert len(recs) == 3 and all(len(r.sha256) == 64 for r in recs)
    c2, _, _ = make(catalog=feeds(9))           # exact multiple: terminates on the empty page
    assert len(c2.list_gtfs_feeds()[0]) == 9


@pytest.mark.gate("S1-05")
def test_duplicate_identical_and_conflicting_records():
    cat = feeds(4)
    cat.insert(3, dict(cat[2]))                  # identical duplicate across the page boundary
    c, _, _ = make(catalog=cat)
    items, _ = c.list_gtfs_feeds()
    assert len(items) == 4 and c.stats.anomalies[0]["anomaly"] == "DUPLICATE_IDENTICAL_RECORD"
    cat2 = feeds(4)
    cat2.append({**cat2[0], "status": "deprecated"})
    c2, _, _ = make(catalog=cat2)
    with pytest.raises(MobilityPaginationError):
        c2.list_gtfs_feeds()


@pytest.mark.gate("S1-05")
def test_repeated_page_detected_and_record_without_id():
    c, srv, _ = make(catalog=feeds(6))
    page = json.dumps(feeds(3)).encode()
    srv.script("GET /v1/gtfs_feeds", [Fault(200, {}, page), Fault(200, {}, page)])
    with pytest.raises(MobilityPaginationError):
        c.list_gtfs_feeds()
    c2, _, _ = make(catalog=feeds(2) + [{"status": "active"}])
    items, _ = c2.list_gtfs_feeds()
    assert len(items) == 2 and c2.stats.anomalies[0]["anomaly"] == "RECORD_WITHOUT_ID"


@pytest.mark.gate("S1-05")
def test_dataset_pagination_and_malformed():
    ds = {"mdb-000": [{"id": f"d{i}", "downloaded_at": f"2025-01-{i + 1:02d}T00:00:00Z"} for i in range(7)]}
    c, srv, _ = make(datasets=ds)
    items, recs = c.list_datasets("mdb-000")
    assert [x["id"] for x in items] == [f"d{i}" for i in range(7)] and len(recs) == 3
    with pytest.raises(MobilityNotFound):
        c.list_datasets("mdb-999")
    srv.script("GET /v1/gtfs_feeds", [Fault(200, {}, b"{not json")])
    with pytest.raises(MobilityMalformedResponse):
        c.list_gtfs_feeds()
    srv.script("GET /v1/gtfs_feeds", [Fault(200, {}, b'{"x": 1}')])
    with pytest.raises(MobilityMalformedResponse):
        c.list_gtfs_feeds()


@pytest.mark.gate("S1-06")
def test_401_bad_credentials_and_403_forbidden():
    c, _, sl = make(token="wrong-token-value-xxxxxxxx")
    with pytest.raises(MobilityUnauthenticated) as e:
        c.list_gtfs_feeds()
    assert e.value.error_class == "MOBILITY_AUTH_401" and not e.value.retryable and sl.calls == []
    c2, srv2, _ = make()
    c2.list_gtfs_feeds()
    srv2.forbidden_tokens |= set(srv2._issued)
    with pytest.raises(MobilityForbidden) as e2:
        c2.list_gtfs_feeds()
    assert e2.value.error_class == "MOBILITY_FORBIDDEN_403"
    c3, srv3, _ = make()
    srv3.script("GET /v1/gtfs_feeds", [Fault(403)])
    with pytest.raises(MobilityForbidden):
        c3.list_gtfs_feeds()


@pytest.mark.gate("S1-06")
def test_expired_access_token_refreshed_once():
    c, srv, _ = make()
    c.list_gtfs_feeds()
    srv.revoke_all()
    items, _ = c.list_gtfs_feeds()
    assert len(items) == 8 and srv._n_issued == 2
    srv.script("GET /v1/gtfs_feeds", [Fault(401), Fault(401)])
    with pytest.raises(MobilityUnauthenticated):
        c.list_gtfs_feeds()                      # refresh attempted once, then classified 401


@pytest.mark.gate("S1-06")
def test_no_authorization_header_sent_to_file_host():
    url = "https://files.mock.mobilitydatabase.invalid/a.zip"
    c, srv, _ = make(files={url: b"PK.."})
    c.list_gtfs_feeds()
    assert c.download(url).body == b"PK.."
    assert srv.saw_auth_on_file_host is False
    with pytest.raises(SourceLocatorError):
        c.download("https://files.mock.mobilitydatabase.invalid/missing.zip")
    with pytest.raises(SourceLocatorError):
        c.download("ftp://x")


@pytest.mark.gate("S1-07")
def test_429_bounded_retry_honours_retry_after():
    c, srv, sl = make()
    srv.script("GET /v1/gtfs_feeds", [Fault(429, {"Retry-After": "3"}), Fault(429, {})])
    items, _ = c.list_gtfs_feeds()
    assert len(items) == 8 and sl.calls == [3.0, 2.0]       # Retry-After, then backoff(2) = 1*2^1


@pytest.mark.gate("S1-07")
def test_429_exhaustion_and_retry_after_cap():
    c, srv, sl = make()
    srv.script("GET /v1/gtfs_feeds", [Fault(429)] * 4)
    with pytest.raises(MobilityRateLimited):
        c.list_gtfs_feeds()
    assert sl.calls == [1.0, 2.0, 4.0]                      # max_attempts=4 -> 3 sleeps, deterministic
    c2, srv2, sl2 = make()
    srv2.script("GET /v1/gtfs_feeds", [Fault(429, {"Retry-After": "3600"})])
    with pytest.raises(MobilityRateLimited):
        c2.list_gtfs_feeds()
    assert sl2.calls == []


@pytest.mark.gate("S1-07")
def test_5xx_and_transport_bounded_retry():
    c, srv, sl = make()
    srv.script("GET /v1/gtfs_feeds", [Fault(500), Fault(503), Fault(transport=True)])
    assert len(c.list_gtfs_feeds()[0]) == 8 and sl.calls == [1.0, 2.0, 4.0]
    c2, srv2, sl2 = make()
    srv2.script("GET /v1/gtfs_feeds", [Fault(502)] * 4)
    with pytest.raises(MobilityServerError):
        c2.list_gtfs_feeds()
    c3, srv3, _ = make()
    srv3.script("GET /v1/gtfs_feeds", [Fault(transport=True)] * 4)
    with pytest.raises(MobilityTransportError):
        c3.list_gtfs_feeds()
    from f1.workload_c.api.mobility import RetryPolicy
    rp = RetryPolicy(10, 1.0, 2.0, 30.0, 60.0)
    assert [rp.backoff(i) for i in range(1, 8)] == [1, 2, 4, 8, 16, 30, 30]


@pytest.mark.gate("S1-05")
def test_raw_response_preservation(tmp_path):
    from f1.workload_c.storage.blobstore import BlobStore
    bs = BlobStore(tmp_path)
    srv = MockMobilityServer(BASE, feeds(5), {}, {}, refresh_token=TOKEN)
    c = MobilityClient(MCFG, StaticSecretProvider({"MOBILITY_DB_TOKEN": TOKEN}), srv, RecordingSleeper(),
                       FixedTickClock(), recorder=lambda r: bs.put(r.body, provenance={"url": r.url}).sha256)
    _, recs = c.list_gtfs_feeds()
    for r in recs:
        assert r.blob_sha256 == r.sha256 and bs.get(r.sha256) == r.body
