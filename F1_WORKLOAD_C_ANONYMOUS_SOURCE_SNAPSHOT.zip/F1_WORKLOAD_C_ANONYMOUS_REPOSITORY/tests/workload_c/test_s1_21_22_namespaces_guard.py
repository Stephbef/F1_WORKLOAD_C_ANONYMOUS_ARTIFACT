import copy

import pytest

from f1.workload_c.errors import NamespaceViolation, SpecValidationError, TestAuthorizationError
from f1.workload_c.interfaces.mocks import MockStatisticsEngine
from f1.workload_c.security.namespaces import (AuthorizationContext, IdentityCertificateVerifier, Namespace,
                                               TestExecutionGuard, assert_homogeneous, make_certificate,
                                               require_namespace)
from f1.workload_c.storage.blobstore import BlobStore, ManifestStore


@pytest.mark.gate("S1-21")
def test_namespace_required_and_enforced():
    require_namespace({"namespace": "TEST"}, Namespace.TEST)
    with pytest.raises(NamespaceViolation):
        require_namespace({}, Namespace.TEST)                                  # missing -> fail closed
    with pytest.raises(NamespaceViolation):
        require_namespace({"namespace": "FIXTURE"}, Namespace.TEST)            # FIXTURE consumed as TEST
    with pytest.raises(NamespaceViolation):
        require_namespace({"namespace": "prod"}, Namespace.TEST)
    with pytest.raises(NamespaceViolation):
        assert_homogeneous([{"namespace": "TEST"}, {"namespace": "VALIDATION"}], Namespace.TEST)


@pytest.mark.gate("S1-21")
def test_validation_outputs_cannot_enter_test_statistics():
    st = MockStatisticsEngine()
    st.analyze([{"unit_id": "u1", "namespace": "TEST"}], "TEST")
    with pytest.raises(NamespaceViolation):
        st.analyze([{"unit_id": "u1", "namespace": "TEST"}, {"unit_id": "v1", "namespace": "VALIDATION"}], "TEST")
    with pytest.raises(NamespaceViolation):
        st.analyze([{"unit_id": "f1", "namespace": "FIXTURE"}], "TEST")


@pytest.mark.gate("S1-21")
def test_manifest_store_namespace_isolation(tmp_path):
    ms = ManifestStore(BlobStore(tmp_path))
    h = ms.put({"schema": "x", "kind": "k", "namespace": "VALIDATION"}).sha256
    with pytest.raises(NamespaceViolation):
        ms.get(h, expect_namespace="TEST")
    assert ms.get(h, expect_namespace="VALIDATION")["namespace"] == "VALIDATION"


@pytest.mark.gate("S1-21")
def test_runtime_namespace_mode_coupling(cfg):
    from f1.workload_c.config.runtime import validate_runtime
    r = copy.deepcopy(cfg.runtime)
    with pytest.raises(SpecValidationError):
        validate_runtime({**r, "namespace": "TEST"})
    with pytest.raises(SpecValidationError):
        validate_runtime({**r, "mode": "REAL", "namespace": "FIXTURE", "failure_injection_allowed": False,
                          "clock": {"kind": "wall", "start": None}})


@pytest.mark.gate("S1-21")
def test_fixture_run_artifacts_all_fixture_namespace(full_run):
    from conftest import read_jsonl
    d = full_run["dir"]
    for rel in ("phases/11_validation/validation_raw.jsonl", "phases/13_scientific_test_campaign/test_raw.jsonl"):
        recs = read_jsonl(d / rel)
        assert recs and {r["namespace"] for r in recs} == {"FIXTURE"}
    v = {r["partition"] for r in read_jsonl(d / "phases/11_validation/validation_raw.jsonl")}
    t = {r["partition"] for r in read_jsonl(d / "phases/13_scientific_test_campaign/test_raw.jsonl")}
    assert v == {"validation"} and t == {"test"}
    led = read_jsonl(d / "logs/events.jsonl")
    assert {r["namespace"] for r in led} == {"FIXTURE"}
    ms = ManifestStore(BlobStore(d / "store"))
    for r in read_jsonl(d / "ledger/run_state.jsonl"):
        if r["to"] == "COMPLETE":
            m = ms.get(r["note"].split("=")[1], expect_namespace="FIXTURE", expect_kind="phase_output")
            assert m["phase"] == r["phase"]


def ctx(ns=Namespace.TEST, **kw):
    base = dict(namespace=ns, campaign_id="c", run_id="r", freeze_seal_sha256="s" * 64, implementation_id="i",
                config_digest="d")
    base.update(kw)
    return AuthorizationContext(**base)


@pytest.mark.gate("S1-22")
def test_unauthorized_test_execution_rejected():
    guard = TestExecutionGuard(IdentityCertificateVerifier({"PI_AUTHORIZED"}))
    with pytest.raises(TestAuthorizationError):
        guard.authorize(ctx(), None)                                                    # absent
    fixture_cert = make_certificate(ctx(), "x", "FIXTURE")
    with pytest.raises(TestAuthorizationError):
        guard.authorize(ctx(), fixture_cert)                                            # wrong issuer kind
    with pytest.raises(TestAuthorizationError):                                          # FIXTURE never authorizes TEST
        TestExecutionGuard(IdentityCertificateVerifier({"FIXTURE"})).authorize(ctx(), fixture_cert)
    good = make_certificate(ctx(), "pi", "PI_AUTHORIZED")
    guard.authorize(ctx(), good)
    for field, val in (("run_id", "other"), ("freeze_seal_sha256", "t" * 64), ("implementation_id", "j"),
                       ("config_digest", "e"), ("campaign_id", "c2")):
        with pytest.raises(TestAuthorizationError):
            guard.authorize(ctx(**{field: val}), good)                                  # identity mismatch
    tampered = dict(good, run_id="other")
    with pytest.raises(TestAuthorizationError):
        guard.authorize(ctx(run_id="other"), tampered)                                  # digest no longer matches
    with pytest.raises(TestAuthorizationError):
        guard.authorize(ctx(), {**good, "extra": 1})
    with pytest.raises(NamespaceViolation):
        guard.authorize(ctx(Namespace.VALIDATION), good)                                # campaign never in VALIDATION


@pytest.mark.gate("S1-22")
def test_orchestrator_phase13_refuses_forged_certificate(cfg, tmp_path, monkeypatch):
    """Replace the phase-12 certificate issuer with one producing a TEST-scoped FIXTURE certificate: phase 13 refuses."""
    from conftest import make_orchestrator
    from f1.workload_c.campaign import later_phases as lp
    from f1.workload_c.campaign import phases as ph

    def forged(c):
        seal = c.read_prior_json("09_scientific_freeze", "freeze_seal.json")
        a = lp._auth_ctx(c, seal["seal_sha256"])
        cert = make_certificate(AuthorizationContext(Namespace.TEST, a.campaign_id, a.run_id, a.freeze_seal_sha256,
                                                     a.implementation_id, a.config_digest), "attacker", "PI_AUTHORIZED")
        c.write_json("campaign_certificate.json", cert)
        return {}
    phs = tuple(p if p.phase_id != "12_campaign_gate_certificate" else ph.PhaseDef(p.number, p.phase_id, p.title,
                p.engine, forged) for p in ph.PHASES)
    import f1.workload_c.campaign.orchestrator as orch
    monkeypatch.setattr(orch, "PHASES", phs)
    o, _ = make_orchestrator(cfg, tmp_path, run_id="forge")
    res = o.run()
    assert res.status == "FAILED" and res.stopped_at == "13_scientific_test_campaign"
    assert res.error["error_class"] == "TEST_AUTHORIZATION_REQUIRED"
    assert not (res.run_dir / "phases/13_scientific_test_campaign/test_raw.jsonl").exists()
