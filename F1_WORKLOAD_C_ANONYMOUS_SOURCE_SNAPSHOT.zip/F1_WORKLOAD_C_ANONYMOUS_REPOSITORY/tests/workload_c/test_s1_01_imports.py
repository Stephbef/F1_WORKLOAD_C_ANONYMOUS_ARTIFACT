import compileall
import importlib
import pkgutil
import subprocess
import sys

import pytest

from conftest import ROOT


@pytest.mark.gate("S1-01")
def test_every_workload_c_module_imports():
    import f1.workload_c as pkg
    names = [m.name for m in pkgutil.walk_packages(pkg.__path__, "f1.workload_c.")]
    assert len(names) >= 35
    for n in names:
        importlib.import_module(n)


@pytest.mark.gate("S1-01")
def test_sources_byte_compile():
    assert compileall.compile_dir(str(ROOT / "src" / "f1"), quiet=1, force=True)


_NEW_MODULES_CHECK = """
import sys
{preload}
before = set(sys.modules)
import f1.workload_c.campaign.orchestrator, f1.workload_c.campaign.cli, f1.common.util  # noqa: E401
added = set(sys.modules) - before
heavy = sorted(m for m in added if m.split('.')[0] in ('numpy', 'pyarrow', 'pandas', 'matplotlib'))
assert not heavy, heavy
print('OK', len(added))
"""


def _new_modules_check(preload: str = "") -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, "-c", _NEW_MODULES_CHECK.format(preload=preload)],
                          env={"PYTHONPATH": str(ROOT / "src"), "PATH": "/usr/bin:/bin"}, capture_output=True, text=True)


@pytest.mark.gate("S1-01")
@pytest.mark.gate("S2-02")
def test_workload_c_introduces_no_heavy_dependency():
    """S1 correction 3.1: the invariant is that importing Workload C does not itself INTRODUCE numpy/pyarrow;
    modules the host harness loaded earlier are irrelevant."""
    cp = _new_modules_check()
    assert cp.returncode == 0, cp.stderr


@pytest.mark.gate("S1-01")
@pytest.mark.gate("S2-02")
def test_preloaded_numpy_by_host_is_not_a_failure():
    """Regression: a harness that imported (a module named) numpy BEFORE Workload C must not fail the check.
    A synthetic module object is used so the test does not depend on numpy being installed."""
    cp = _new_modules_check("import types; sys.modules['numpy'] = types.ModuleType('numpy')")
    assert cp.returncode == 0, cp.stderr
    if subprocess.run([sys.executable, "-c", "import numpy"], capture_output=True).returncode == 0:
        assert _new_modules_check("import numpy").returncode == 0     # real preloaded numpy, when installed


@pytest.mark.gate("S1-01")
def test_cli_entrypoint_help():
    cp = subprocess.run([sys.executable, "-m", "f1.workload_c.campaign.cli", "--help"],
                        env={"PYTHONPATH": str(ROOT / "src"), "PATH": "/usr/bin:/bin"}, capture_output=True, text=True)
    assert cp.returncode == 0 and "run" in cp.stdout


@pytest.mark.gate("S1-01")
def test_stable_interfaces_and_mocks_conform():
    from f1.workload_c.interfaces import protocols as P
    from f1.workload_c.campaign.fixture import build_adapters
    from f1.workload_c.config.runtime import load_effective_config
    cfg = load_effective_config(ROOT / "configs/workload_c/fixture.yaml")
    a = build_adapters(cfg)
    pairs = {"ValidatorProducer": a["validator"], "OtpProducer": a["otp"], "ResourceManager": a["resource_manager"],
             "OracleEvaluator": a["oracle"], "ContractGenerator": a["contract_gen"],
             "ContractEvaluator": a["contract_eval"], "AdmissionEngine": a["admission"], "RepairEngine": a["repair"],
             "Baseline": a["baselines"]["N5"], "CostRecorder": a["cost"], "ReplayEngine": a["replay"],
             "MutationEngine": a["mutation"], "StatisticsEngine": a["statistics"], "FreezeSealManager": a["freeze_seal"]}
    assert set(pairs) == set(P.INTERFACE_NAMES)
    for name, obj in pairs.items():
        assert isinstance(obj, getattr(P, name)), name
