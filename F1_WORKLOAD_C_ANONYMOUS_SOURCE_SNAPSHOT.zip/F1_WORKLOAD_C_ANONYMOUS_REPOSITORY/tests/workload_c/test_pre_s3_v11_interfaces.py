"""PRE-S3 V1.1 interface-closure gates P3-13..P3-20 (types/protocols only; no Session-3 algorithm)."""
import dataclasses
import inspect
import json
import typing

import pytest

from f1.workload_c.catalog.artifacts import ArtifactCatalog, ArtifactEntry
from f1.workload_c.contracts.model import EvaluationContext, EvaluationResult
from f1.workload_c.history.realized import Cut, RealizedHistory
from f1.workload_c.interfaces import session3 as S

T = "2025-06-03T13:00:00Z"
REG = "R:A+B"


def ctx(cut):
    return EvaluationContext(cut.cut_id, {}, "o", "s", "p", "v", "2025-06-03", "US", ("2025-06-03", "2025-06-04"))


def req(a=2, b=1, tick=T):
    cut = Cut.of(REG, {"A": a, "B": b})
    return S.ConsumerRequest(REG, S.canonical_request_slots(REG, ["A", "B"]), tick, cut, ctx(cut))


def bound(slot, aid, born="2025-06-03T01:00:00Z"):
    return S.BoundArtifact(slot, aid, "ROUTER" if slot.startswith("ROUTER") else "VAL_REPORT", "otp", "CUT:b",
                           (("A", 1), ("B", 1)), (("A", "A#L1", "h"),), (f"K2:{aid}",), "SUCCESS", born, "e" * 64,
                           "p" * 64, (("out", "o"),), "FIXTURE", "FIXTURE_STUB_BINARY")


def ev(aid, cut, verdict="VALID"):
    return EvaluationResult(f"K2:{aid}", cut.cut_id, verdict, "r", "evd")


def binding_for(r, born="2025-06-03T01:00:00Z"):
    bs = tuple((s, bound(s, f"a{i}", born)) for i, s in enumerate(r.request_slots))
    return S.RequestBinding(r, bs, tuple((b.artifact_id, ()) for _, b in bs), tuple((s, 1.0) for s in r.request_slots))


def gamma(admissible=True):
    return S.GammaEvidence(T, ("2025-06-03",), (("A", 1, 2, True, admissible), ("B", 1, 1, True, True)), admissible)


def witness(r, wcut, **kw):
    bs = []
    for i, s in enumerate(r.request_slots):
        b = bound(s, f"a{i}")
        bs.append(S.WitnessBinding(s, b, b.contract_ids, (ev(b.artifact_id, wcut),),
                                   S.TemporalEvidence(T, b.born_utc, (("A", 1, "2025-05-01T00:00:00Z"),))))
    args = dict(request_id=r.request_id, request_slots=r.request_slots, method="F1", level="K2", witness_cut=wcut,
                bindings=tuple(bs), gamma=gamma())
    args.update(kw)
    return S.JointWitness(**args)


# ------------------------------------------------------------------------------------------------- P3-13
@pytest.mark.gate("P3-13")
def test_joint_consumer_request():
    r = req()
    assert r.request_slots == ("VAL:feed=A", "VAL:feed=B", "ROUTER:region=R:A+B")          # A
    assert S.canonical_request_slots(REG, ["B", "A"]) == r.request_slots                    # B
    for bad in (("VAL:feed=B", "VAL:feed=A", "ROUTER:region=R:A+B"), ("VAL:feed=A", "VAL:feed=B"),
                ("VAL:feed=A", "ROUTER:region=R:A+B")):
        with pytest.raises(S.InterfaceInvariantError):
            S.ConsumerRequest(REG, bad, T, r.current_cut, r.context)
    with pytest.raises(S.InterfaceInvariantError):
        S.ConsumerRequest(REG, r.request_slots, T, r.current_cut, ctx(Cut.of(REG, {"A": 1, "B": 1})))
    assert "request_slot" not in {f.name for f in dataclasses.fields(S.ConsumerRequest)}
    t1, t2 = req(2, 1), req(2, 1, "2025-06-04T13:00:00Z")                                 # C: one request each
    assert t1.request_id == req(2, 1).request_id != t2.request_id and len(t1.request_slots) == 3


@pytest.mark.gate("P3-13")
def test_opt_over_slot_sets_T2():
    """T2: current (A1,B0) fails only ROUTER (c_g); historical (A0,B0) fails only VAL(A1) (c_v) -> OPT over SETS."""
    r = req(2, 1)
    hist = Cut.of(REG, {"A": 1, "B": 1})
    plan = S.RepairPlan(r.request_id, S.Mode.HISTORICAL, hist, ("VAL:feed=A",),
                        (S.RederivationStep("VAL:feed=A", hist.cut_id, "validator", 600.0),), 5400.0, 600.0, hist.cut_id)
    cur = S.RepairPlan(r.request_id, S.Mode.CURRENT, r.current_cut, ("VAL:feed=A", "ROUTER:region=R:A+B"),
                       (S.RederivationStep("VAL:feed=A", r.current_cut.cut_id, "validator", 600.0),
                        S.RederivationStep("ROUTER:region=R:A+B", r.current_cut.cut_id, "otp", 5400.0)), 6000.0, None, None)
    assert plan.failing_slots == ("VAL:feed=A",) and cur.opt_current == 6000.0
    with pytest.raises(S.InterfaceInvariantError):          # OPT must equal the slot-set sum
        S.RepairPlan(r.request_id, S.Mode.CURRENT, r.current_cut, ("VAL:feed=A",),
                     (S.RederivationStep("VAL:feed=A", r.current_cut.cut_id, "validator", 600.0),), 999.0, None, None)
    with pytest.raises(S.InterfaceInvariantError):          # historical only if strictly cheaper (tie -> current)
        S.RepairPlan(r.request_id, S.Mode.HISTORICAL, hist, ("VAL:feed=A",),
                     (S.RederivationStep("VAL:feed=A", hist.cut_id, "validator", 600.0),), 600.0, 600.0, hist.cut_id)
    with pytest.raises(S.InterfaceInvariantError):          # all steps target the plan's single cut
        S.RepairPlan(r.request_id, S.Mode.CURRENT, r.current_cut, ("VAL:feed=A",),
                     (S.RederivationStep("VAL:feed=A", hist.cut_id, "validator", 600.0),), 600.0, None, None)


# ------------------------------------------------------------------------------------------------- P3-14
@pytest.mark.gate("P3-14")
def test_joint_witness_and_negatives():
    r = req()
    w0 = Cut.of(REG, {"A": 1, "B": 1})
    w = witness(r, w0)
    assert len(w.bindings) == 3 and all(b.evaluations[0].cut_id == w0.cut_id for b in w.bindings)
    with pytest.raises(S.InterfaceInvariantError):          # one missing slot invalidates the witness
        witness(r, w0, bindings=w.bindings[:2])
    other = Cut.of(REG, {"A": 2, "B": 1})
    mixed = (w.bindings[0], dataclasses.replace(w.bindings[1], evaluations=(ev("a1", other),)), w.bindings[2])
    with pytest.raises(S.InterfaceInvariantError):          # individually valid artifacts from different cuts
        witness(r, w0, bindings=mixed)
    with pytest.raises(S.InterfaceInvariantError):          # future-born artifact
        S.TemporalEvidence(T, "2025-06-03T14:00:00Z", ())
    with pytest.raises(S.InterfaceInvariantError):          # future witness version
        S.TemporalEvidence(T, "2025-06-03T01:00:00Z", (("A", 3, "2025-06-04T00:00:00Z"),))
    b = w.bindings[0]
    with pytest.raises(S.InterfaceInvariantError):          # cross-slot substitution
        S.WitnessBinding("VAL:feed=A", bound("VAL:feed=B", "x"), b.contract_ids, b.evaluations, b.temporal)
    for kw in ({"level": "K3"}, {"method": "N5"}, {"gamma": gamma(False)}):
        with pytest.raises(S.InterfaceInvariantError):
            witness(r, w0, **kw)
    invalid = (dataclasses.replace(w.bindings[0], evaluations=(ev("a0", w0, "INVALID"),)),) + w.bindings[1:]
    with pytest.raises(S.InterfaceInvariantError):
        witness(r, w0, bindings=invalid)
    with pytest.raises(S.InterfaceInvariantError):          # R_t binding: artifact born after the tick
        binding_for(r, born="2025-06-03T13:00:01Z")
    bs = binding_for(r)
    with pytest.raises(S.InterfaceInvariantError):          # R_t binding: cross-slot
        S.RequestBinding(r, ((bs.bindings[0][0], bs.bindings[1][1]),) + bs.bindings[1:], bs.contracts, bs.estimates)


# ------------------------------------------------------------------------------------------------- P3-15
@pytest.mark.gate("P3-15")
def test_admission_decision_action_mode_and_repair():
    assert [a.value for a in S.Action] == ["REUSE", "REDERIVE", "NO_ARTIFACT"]
    assert [m.value for m in S.Mode] == ["CURRENT", "HISTORICAL"]
    r = req()
    cur = (EvaluationResult("K2:a0", r.current_cut.cut_id, "INVALID", "x", "e"),)
    S.AdmissionDecision(r, "F1", "K2", S.Action.REUSE, S.Mode.CURRENT, ())
    S.AdmissionDecision(r, "F1", "K2", S.Action.REUSE, S.Mode.HISTORICAL, cur, witness=witness(r, Cut.of(REG, {"A": 1, "B": 1})))
    plan = S.RepairPlan(r.request_id, S.Mode.CURRENT, r.current_cut, ("VAL:feed=A",),
                        (S.RederivationStep("VAL:feed=A", r.current_cut.cut_id, "validator", 600.0, "INFRA_ERROR"),),
                        600.0, None, None)
    ok_plan = dataclasses.replace(plan, steps=(dataclasses.replace(plan.steps[0], outcome="SUCCESS", new_artifact_id="n1"),))
    S.AdmissionDecision(r, "N5", "K2", S.Action.REDERIVE, S.Mode.CURRENT, cur, repair=ok_plan)
    S.AdmissionDecision(r, "N5", "K2", S.Action.NO_ARTIFACT, None, cur, repair=plan)          # failed attempt recorded
    with pytest.raises(S.InterfaceInvariantError):          # V1.2: a failed step can never end in REDERIVE
        S.AdmissionDecision(r, "N5", "K2", S.Action.REDERIVE, S.Mode.CURRENT, cur, repair=plan)
    bad = [dict(action=S.Action.NO_ARTIFACT, mode=S.Mode.CURRENT), dict(action=S.Action.REUSE, mode=None),
           dict(action=S.Action.REUSE, mode=S.Mode.HISTORICAL), dict(action=S.Action.REDERIVE, mode=S.Mode.CURRENT),
           dict(action=S.Action.REDERIVE, mode=S.Mode.HISTORICAL, repair=ok_plan),
           dict(action=S.Action.REUSE, mode=S.Mode.CURRENT, repair=ok_plan)]
    for kw in bad:
        with pytest.raises(S.InterfaceInvariantError):
            S.AdmissionDecision(r, "F1", "K2", current_evaluations=cur, **kw)
    with pytest.raises(S.InterfaceInvariantError):          # N5 may never be HISTORICAL
        S.AdmissionDecision(r, "N5", "K2", S.Action.REUSE, S.Mode.HISTORICAL, cur,
                            witness=witness(r, Cut.of(REG, {"A": 1, "B": 1})))
    with pytest.raises(S.InterfaceInvariantError):          # step-1 evaluations must be at the current cut
        S.AdmissionDecision(r, "F1", "K2", S.Action.REUSE, S.Mode.CURRENT,
                            (EvaluationResult("K2:a0", "CUT:other", "VALID", "x", "e"),))
    assert {f.name for f in dataclasses.fields(S.CostRecord)} == {"items"}                   # no repair info in costs
    assert typing.get_type_hints(S.AdmissionDecision)["repair"] == typing.Optional[S.RepairPlan]


def reachable_types(tp, seen=None):
    seen = set() if seen is None else seen
    for a in typing.get_args(tp) or ():
        reachable_types(a, seen)
    if dataclasses.is_dataclass(tp) and tp not in seen:
        seen.add(tp)
        for h in typing.get_type_hints(tp).values():
            reachable_types(h, seen)
    elif isinstance(tp, type):
        seen.add(tp)
    return seen


FORBIDDEN = {ArtifactEntry, ArtifactCatalog, RealizedHistory, S.JointWitness, S.WitnessBinding}


# ------------------------------------------------------------------------------------------------- P3-16
@pytest.mark.gate("P3-16")
def test_sanitized_n5_view():
    fields = {f.name for f in dataclasses.fields(S.BoundArtifact)}
    assert "rederived_from" not in fields and "instance" not in fields
    assert S.CurrentCutView is S.RequestBinding
    assert {f.name for f in dataclasses.fields(S.RequestBinding)} == {"request", "bindings", "contracts", "estimates"}
    assert not (reachable_types(S.CurrentCutView) & FORBIDDEN)
    hints = typing.get_type_hints(S.N5Baseline.decide)
    assert set(hints) == {"view", "level", "evaluator", "rederiver", "return"}
    for name, h in hints.items():
        if name != "return":                         # inputs only; outputs are constrained by AdmissionDecision checks
            assert not (reachable_types(h) & FORBIDDEN), h
    assert "cut" not in inspect.signature(S.CurrentCutEvaluator.evaluate).parameters
    assert "cut" not in inspect.signature(S.CurrentCutRederiver.rederive).parameters
    cat = ArtifactCatalog()
    kw = dict(producer_type="otp", artifact_class="ROUTER", birth_frontier=(("A", 1),), logical_inputs=[("A", "A#L1", "h")],
              contract_ids=["K2:x"], status="SUCCESS", provenance_digest="p", output_digests=[("o", "1")], cost={},
              namespace="FIXTURE", binary_mode="FIXTURE_STUB_BINARY")
    old = cat.add(request_slot="ROUTER:region=R:A+B", birth_cut_id="CUT:old", **kw)
    new = cat.rederive("ROUTER:region=R:A+B", "CUT:new", **kw)
    b = S.BoundArtifact.from_entry(new, "2025-06-03T01:00:00Z")
    blob = json.dumps(dataclasses.asdict(b))
    assert old.artifact_id not in blob and not hasattr(b, "rederived_from") and not hasattr(b, "instance")


# ------------------------------------------------------------------------------------------------- P3-17
@pytest.mark.gate("P3-17")
def test_n1_non_interference():
    hints = typing.get_type_hints(S.N1Baseline.decide)
    assert set(hints) == {"view", "evaluator", "rederiver", "native", "return"}
    for name, h in hints.items():
        if name != "return":
            assert not (reachable_types(h) & FORBIDDEN), h
    assert not (reachable_types(S.N1CurrentView) & FORBIDDEN)
    assert S.NativeOtpState in reachable_types(S.N1CurrentView)                          # its own native state
    r = req()
    st = S.NativeOtpState(REG, "/n1/street", "s" * 64, "/n1/cache", "c" * 64, "env", None, None)
    vb = tuple((s, bound(s, f"v{i}")) for i, s in enumerate(r.request_slots[:2]))
    v = S.N1CurrentView(r, vb, tuple((b.artifact_id, ()) for _, b in vb), (("A", "A#L2", "x"), ("B", "B#L1", "y")), st,
                        tuple((s, 1.0) for s in r.request_slots))
    assert v.native_state.region_id == REG
    with pytest.raises(S.InterfaceInvariantError):          # the router slot is never handed to N1 as a binding
        S.N1CurrentView(r, vb + ((r.request_slots[2], bound(r.request_slots[2], "rt")),), v.val_contracts,
                        v.current_router_inputs, st, v.estimates)
    with pytest.raises(S.InterfaceInvariantError):
        S.AdmissionDecision(r, "N1", "K0", S.Action.REUSE, S.Mode.HISTORICAL, (),
                            witness=witness(r, Cut.of(REG, {"A": 1, "B": 1})))


# ------------------------------------------------------------------------------------------------- P3-18
OBS = (S.ProducerRunObservation(REG, "otp", "2025-06-01T03:00:00Z", 5000.0, 4000.0, "SUCCESS"),
       S.ProducerRunObservation(REG, "otp", "2025-06-02T03:00:00Z", 5200.0, 4100.0, "SUCCESS"),
       S.ProducerRunObservation(REG, "otp", T, 1.0, 1.0, "SUCCESS"),                        # completed AT t: excluded
       S.ProducerRunObservation(REG, "otp", "2025-06-05T03:00:00Z", 9.0, 9.0, "SUCCESS"),  # future
       S.ProducerRunObservation("R:other", "otp", "2025-05-01T03:00:00Z", 7.0, 7.0, "SUCCESS"))


def ref_estimator(slot, producer_class, tick, prior: S.PriorCostView) -> float:     # V1.2: ordinary arithmetic median
    from reference_v12 import est_reference
    return est_reference(producer_class, prior)


@pytest.mark.gate("P3-18")
def test_cost_model_explicit_t_and_no_future_leakage():
    sig = inspect.signature(S.CostModel.estimate_rederive)
    assert list(sig.parameters)[1:] == ["slot_id", "producer_class", "tick_utc", "prior"]
    assert typing.get_type_hints(S.CostModel.estimate_rederive)["prior"] is S.PriorCostView
    p = S.PriorCostView.before(REG, T, OBS)
    assert [o.completed_utc for o in p.observations] == ["2025-06-01T03:00:00Z", "2025-06-02T03:00:00Z"]
    future_edit = OBS[:3] + (dataclasses.replace(OBS[3], wall_s=1e9),) + OBS[4:] + (
        S.ProducerRunObservation(REG, "otp", "2026-01-01T00:00:00Z", 1.0, 1.0, "SUCCESS"),)
    p2 = S.PriorCostView.before(REG, T, future_edit)
    assert p2 == p and p2.digest == p.digest                                               # bitwise identical
    assert ref_estimator("ROUTER", "otp", T, p) == ref_estimator("ROUTER", "otp", T, p2)
    with pytest.raises(S.InterfaceInvariantError):
        S.PriorCostView(REG, T, (OBS[3],))                                                 # future obs refused
    with pytest.raises(S.InterfaceInvariantError):
        S.PriorCostView(REG, T, (dataclasses.replace(OBS[0], source="F1_OVERLAY"),))      # only shared runs
    with pytest.raises(dataclasses.FrozenInstanceError):
        p.tick_utc = "2030-01-01T00:00:00Z"
    members = {n for n, _ in inspect.getmembers(S.CostModel) if not n.startswith("_")}
    assert members == {"estimate_rederive", "online_cost"}                                 # no hidden tick state
    rec = S.CostRecord((S.CostItem(S.CostCategory.A_PRODUCER, "producer:otp", 10.0, 8.0),
                        S.CostItem(S.CostCategory.B_CONTROL_PLANE, "witness_search", 1.0, 1.0),
                        S.CostItem(S.CostCategory.C_OFFLINE, "replay", 100.0, 100.0)))
    assert rec.online_wall_s == 11.0


# ------------------------------------------------------------------------------------------------- P3-19
@pytest.mark.gate("P3-19")
def test_firewall_completion():
    from f1.workload_c.security.firewall import ChangeClass as C, ChangeRecord as R, FirewallViolation, Stage, check_change
    for rec in (R(C.S1, Stage.POST_VALIDATION, formal_amendment="AM-1"),
                R(C.S1, Stage.POST_VALIDATION, restart_from_clean_freeze=True, restart_evidence_id="FREEZE-2"),
                R(C.S1, Stage.POST_VALIDATION, formal_amendment="AM-1", restart_from_clean_freeze=True),
                R(C.S1, Stage.CAMPAIGN, formal_amendment="AM-1", restart_from_clean_freeze=True, restart_evidence_id="F2"),
                R(C.S1, Stage.VALIDATION_OPEN, formal_amendment="AM-1"),
                R(C.E2, Stage.VALIDATION_OPEN, issue_id="I-7"),
                R(C.R1, Stage.IMPLEMENTATION, formal_amendment="AM", restart_from_clean_freeze=True, restart_evidence_id="F")):
        with pytest.raises(FirewallViolation):
            check_change(rec)
    check_change(R(C.S1, Stage.POST_VALIDATION, formal_amendment="AM-1", restart_from_clean_freeze=True,
                   restart_evidence_id="PRE-S3-FREEZE-2"))
    check_change(R(C.E2, Stage.VALIDATION_OPEN, issue_id="I-7", semantic_preservation_evidence="canon-35/35-EQ"))
    check_change(R(C.S1, Stage.IMPLEMENTATION))


# ------------------------------------------------------------------------------------------------- P3-20
@pytest.mark.gate("P3-20")
def test_replay_export_representability():
    names = {f.name for f in dataclasses.fields(S.RawExportRecord)}
    required = {"run", "region_id", "request_id", "request_slots", "root_changes", "tick_utc", "tick_local", "method",
                "level", "current_cut_id", "current_frontier", "gamma_size", "action", "mode", "witness_cut_id",
                "bound_artifacts", "contract_verdicts", "rederivations", "costs", "estimates", "opt_current", "opt_hist",
                "failures", "scheduler_state_digest", "provenance_digests", "excluded", "exclusion_reason"}
    assert required <= names
    for tname in S.SESSION3_DATA_TYPES:
        tp = getattr(S, tname)
        for fname, h in typing.get_type_hints(tp).items():
            assert "dict" not in str(h).lower(), (tname, fname, h)        # no untyped scientific dictionaries
    r = req()
    run = S.RunIdentityRecord("run", "FIXTURE", "impl", "cfg")
    rec = S.RawExportRecord(run, REG, r.request_id, r.request_slots, (("A", 2),), T, "2025-06-03T06:00:00-07:00", "N5",
                            "K2", r.current_cut.cut_id, r.current_cut.frontier, None, S.Action.REUSE, S.Mode.CURRENT,
                            None, (("VAL:feed=A", "a0"),), (("a0", "K2:a0", r.current_cut.cut_id, "VALID"),), (),
                            S.CostRecord(), (("VAL:feed=A", 600.0),), None, None, (), "sched", ("p",), False, None)
    again = dataclasses.replace(rec)
    assert rec.record_digest == again.record_digest and json.loads(json.dumps(dataclasses.asdict(rec), default=str))
    for proto in ("ReplayEngine", "StatisticsExporter", "FrozenAnalysis"):
        for h in typing.get_type_hints(getattr(getattr(S, proto), {"ReplayEngine": "replay", "StatisticsExporter": "export",
                                                                   "FrozenAnalysis": "run"}[proto])).values():
            assert "dict" not in str(h).lower(), proto
