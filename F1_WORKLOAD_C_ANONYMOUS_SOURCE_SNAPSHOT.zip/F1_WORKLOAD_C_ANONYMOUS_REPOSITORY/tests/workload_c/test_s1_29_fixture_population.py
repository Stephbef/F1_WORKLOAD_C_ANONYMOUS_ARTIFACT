import json

import pytest

from conftest import ROOT, read_csv, read_jsonl

EXPECTED = json.loads((ROOT / "fixtures/expected/fixture_population_expected.json").read_text())


@pytest.mark.gate("S1-29")
def test_population_has_more_than_24_eligible(full_run):
    el = read_csv(full_run["dir"] / "phases/05_eligible_regions/eligible_population.csv")
    assert len(el) == EXPECTED["n_eligible_regions"] == 33 > 24
    assert [r["region_id"] for r in el] == EXPECTED["eligible_region_ids"]
    sizes = sorted({int(r["n_feeds"]) for r in el})
    assert sizes[0] == 2 and sizes[-1] == 8
    assert {r["origin"] for r in el} == {"component", "split"}


@pytest.mark.gate("S1-29")
def test_controlled_exclusions_match_construction_intents(full_run, population):
    ex = {r["entity_id"]: r for r in read_csv(full_run["dir"] / "phases/05_eligible_regions/excluded_population.csv")}
    assert {k: v["reason_code"] for k, v in ex.items()} == EXPECTED["excluded"]
    ev = read_jsonl(full_run["dir"] / "phases/05_eligible_regions/region_connectivity_evidence.jsonl")
    checked = 0
    for fid, intent in population.intents.items():
        if not intent.startswith("EXCLUDED:"):
            continue
        code = intent.split(":", 1)[1].split("(")[0]
        if code in ("REGION_SINGLETON_NO_EDGE", "SPLIT_PART_SINGLETON"):
            assert ex[f"R:{fid}"]["reason_code"] == code, fid
            if "(" in intent:
                want = intent.split("(")[1].rstrip(")")
                assert any(want in e["reasons"] for e in ev if fid in (e["feed_a"], e["feed_b"])), fid
        else:
            assert ex[fid]["reason_code"] == code, (fid, ex.get(fid))
        checked += 1
    assert checked == 24
    required = {"HISTORY_INSUFFICIENT_START", "HISTORY_GAP_EXCEEDED", "LICENSE_UNCLEAR", "LICENSE_INCOMPATIBLE",
                "DEDUP_IDENTICAL_CONTENT", "DEDUP_IDENTICAL_URL", "DEDUP_ALIAS", "DEDUP_REDIRECT", "DEDUP_MERGED_BUNDLE",
                "REGION_SINGLETON_NO_EDGE", "BBOX_DIAGONAL_EXCEEDED", "MALFORMED_METADATA", "SPLIT_PART_SINGLETON",
                "STATUS_NOT_ACTIVE", "AUTHENTICATION_REQUIRED", "NO_HISTORY", "ARCHIVE_UNRETRIEVABLE", "MALFORMED_GTFS"}
    assert required <= {v["reason_code"] for v in ex.values()}


@pytest.mark.gate("S1-29")
def test_oversize_components_split(full_run):
    log = json.loads((full_run["dir"] / "phases/05_eligible_regions/region_split_log.json").read_text())
    assert sorted(c["n_feeds"] for c in log) == [9, 10]
    for c in log:
        assert len(c["removals"]) == 1 and c["removals"][0]["stop_pairs"] == 3


@pytest.mark.gate("S1-29")
def test_snapshot_anomalies_and_history_patterns(full_run):
    snap = json.loads((full_run["dir"] / "phases/02_mobility_snapshot/mobility_snapshot.json").read_text())
    kinds = {a["anomaly"] for a in snap["anomalies"]}
    assert "DUPLICATE_IDENTICAL_RECORD" in kinds and snap["n_feeds"] == 122
    assert sum(o["status"] == "SOURCE_LOCATOR_FAILURE" for o in snap["observations"]) == 1
    stats = json.loads((full_run["dir"] / "phases/02_mobility_snapshot/client_stats.json").read_text())
    assert stats["retries"] == 3 and stats["sleeps"] == [2.0, 2.0, 1.0]   # scripted 429, 503, transport failure


@pytest.mark.gate("S1-29")
def test_population_generation_deterministic(population):
    from f1.workload_c.fixturegen.population import build_fixture_population
    p2 = build_fixture_population()
    assert p2.feeds == population.feeds and p2.files == population.files and p2.datasets == population.datasets
