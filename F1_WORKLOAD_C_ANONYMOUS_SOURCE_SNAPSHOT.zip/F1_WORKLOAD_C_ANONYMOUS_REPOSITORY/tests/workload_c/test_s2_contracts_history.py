"""Session-2 gates S2-27..S2-44 (contracts, K2/Canon alignment, history, cuts, catalog, fixed-R, scheduler, DST)."""
import dataclasses
import io
import json
import random
import subprocess
import sys
import zipfile
from dataclasses import replace

import pytest

from conftest import ROOT
from f1.workload_c.catalog.artifacts import ArtifactCatalog, CatalogError, RequestSlot, designated_slots
from f1.workload_c.contracts.alignment import k2_canon_alignment
from f1.workload_c.contracts.generators import ContractSystem, ReferencePath
from f1.workload_c.contracts.k2 import k2_projection
from f1.workload_c.contracts.model import Contract, EvaluationContext
from f1.workload_c.fixturegen.gtfs_gen import FeedContent, FStop, build_zip
from f1.workload_c.history.realized import (Cut, Event, HistoryError, RealizedHistory, cut_at, enumerate_cuts,
                                            is_consistent)
from f1.workload_c.ingestion.gtfs import canonical_content_hash
from f1.workload_c.scheduler.ledger import to_history
from f1.workload_c.scheduler.timeutil_local import local_to_utc
from f1.workload_c.scheduler.workload_c import (FixtureDurationBackend, RegionScheduleInput, SchedulerError,
                                                VersionAvailability, simulate)
from f1.workload_c.storage.blobstore import BlobStore

D = ["2008-06-03", "2008-06-04", "2008-06-05"]
BASE = FeedContent("K", (("A1", "Agency K", "America/Los_Angeles"),),
                   (FStop("s1", 37.77, -122.42), FStop("s2", 37.78, -122.41), FStop("s3", 37.79, -122.40)),
                   service_start="20080101", service_end="20081231")


def zip_with(content=BASE, edit=None):
    b = build_zip(content)
    if edit is None:
        return b
    src = zipfile.ZipFile(io.BytesIO(b))
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w") as z:
        for n in src.namelist():
            data = src.read(n).decode()
            data = edit(n, data)
            if data is not None:
                z.writestr(n, data)
        for n, data in (edit("__extra__", None) or {}).items():
            z.writestr(n, data)
    return out.getvalue()


@pytest.fixture()
def system(tmp_path, spec):
    blobs = BlobStore(tmp_path / "b")
    return ContractSystem(blobs, spec.gtfs_member_names), blobs


def ctx(blobs, spec, feeds: dict, cut="CUT:c", D_=tuple(D), sem="s" * 64, osm="o" * 64, otp="p" * 64):
    refs = {}
    for f, b in feeds.items():
        r = blobs.put(b)
        refs[f] = {"logical_version_id": f + "#L1", "canonical_content_sha256": canonical_content_hash(b, spec.gtfs_member_names),
                   "raw_zip_sha256": r.sha256}
    return EvaluationContext(cut, refs, osm, sem, otp, "v" * 64, "2008-06-03", "US", tuple(D_))


def router_art(feeds, window=("2007-06-01", "2011-06-01")):
    return {"artifact_id": "ROUTER:x", "request_slot": "ROUTER:region=R", "birth_cut_id": "CUT:b",
            "gtfs_logical_versions": {f: [f + "#L1", "h"] for f in feeds}, "canon_digest": "c" * 64,
            "graph_sha256": "g" * 64, "horizon_D": D, "service_window": list(window)}


def val_art():
    return {"artifact_class": "VAL_REPORT", "feed_id": "f", "request_slot": "VAL:feed=f", "birth_cut_id": "CUT:b",
            "report_digest": "r" * 64}


@pytest.mark.gate("S2-27")
def test_k0_val_and_router(system, spec):
    cs, blobs = system
    b = ctx(blobs, spec, {"f": zip_with()})
    c = cs.generate_val(val_art(), b, "K0")
    assert c.footprint["canonical_content_sha256"] == b.feeds["f"]["canonical_content_sha256"]
    assert c.footprint["date"] == "2008-06-03" and c.footprint["country"] == "US" and c.footprint["validator_sha256"]
    assert cs.evaluate(c, b).verdict == "VALID"
    assert cs.evaluate(c, replace(b, consumer_date="2008-06-04")).verdict == "INVALID"     # date is bound
    r = cs.generate_router(router_art(["f"]), b, "K0")
    assert set(r.footprint) >= {"osm_sha256", "semantic_config_digest", "otp_sha256", "feeds"}
    assert cs.evaluate(r, replace(b, osm_sha256="x" * 64)).verdict == "INVALID"
    repack = ctx(blobs, spec, {"f": build_zip(BASE, __import__("f1.workload_c.fixturegen.gtfs_gen",
                                                               fromlist=["ZipStyle"]).ZipStyle(crlf=True, bom=True))})
    assert cs.evaluate(r, repack).verdict == "VALID"                                         # canonical identity


@pytest.mark.gate("S2-28")
def test_k1_per_file_hashes(system, spec):
    cs, blobs = system
    b = ctx(blobs, spec, {"f": zip_with()})
    c = cs.generate_router(router_art(["f"]), b, "K1")
    files = c.footprint["feeds"]["f"]
    assert set(files) <= set(__import__("f1.workload_c.contracts.k2", fromlist=["x"]).ROUTING_FILES)
    assert "feed_info.txt" not in files and "stops.txt" in files
    info_change = ctx(blobs, spec, {"f": zip_with(edit=lambda n, d: d.replace("v1-A", "v9-A") if n == "feed_info.txt" else d)})
    assert cs.evaluate(c, info_change).verdict == "VALID"                     # not a routing file
    v = cs.generate_val(val_art(), b, "K1")
    assert "feed_info.txt" in v.footprint["files"]                            # validator reads every GTFS file
    assert cs.evaluate(v, info_change).verdict == "INVALID"
    name_change = ctx(blobs, spec, {"f": zip_with(edit=lambda n, d: d.replace("Stop s1", "Stop ONE") if n == "stops.txt" else d)})
    assert cs.evaluate(c, name_change).verdict == "INVALID"                   # K1 is file-granular (K2 is not)
    v2 = cs.generate_val(val_art(), b, "K2")
    assert v2.footprint["files"] == v.footprint["files"]                     # VAL K2 = K1


@pytest.mark.gate("S2-29")
@pytest.mark.gate("S2-33")
@pytest.mark.parametrize("label,edit,expect", [
    ("display stop_name", lambda n, d: d.replace("Stop s1", "Stop ONE") if n == "stops.txt" else d, "VALID"),
    ("display agency_name/url", lambda n, d: d.replace("Agency K", "Renamed").replace("a1.example", "zz.example")
     if n == "agency.txt" else d, "VALID"),
    ("future-only calendar_dates", lambda n, d: d if n != "__extra__" else
     {"calendar_dates.txt": "service_id,date,exception_type\nS1,20090105,2\n"}, "VALID"),
    ("feed_info only", lambda n, d: d.replace("v1-A", "v2-A") if n == "feed_info.txt" else d, "VALID"),
    ("active stop_time", lambda n, d: d.replace("06:00:00", "06:01:00") if n == "stop_times.txt" else d, "INVALID"),
    ("active calendar_dates removal", lambda n, d: d if n != "__extra__" else
     {"calendar_dates.txt": "service_id,date,exception_type\nS1,20080604,2\n"}, "INVALID"),
    ("stop coordinate", lambda n, d: d.replace("37.7700000", "37.7710000") if n == "stops.txt" else d, "INVALID"),
    ("agency timezone", lambda n, d: d.replace("America/Los_Angeles", "America/Denver") if n == "agency.txt" else d, "INVALID"),
    ("route_type", lambda n, d: d.replace(",1,3", ",1,2") if n == "routes.txt" else d, "INVALID"),
])
def test_k2_semantic_closure_classes(system, spec, label, edit, expect):
    cs, blobs = system
    b = ctx(blobs, spec, {"f": zip_with()})
    c = cs.generate_router(router_art(["f"]), b, "K2")
    assert cs.evaluate(c, ctx(blobs, spec, {"f": zip_with(edit=edit)}, cut="CUT:x")).verdict == expect, label


@pytest.mark.gate("S2-29")
def test_k2_window_rule_and_D_dependence(system, spec):
    cs, blobs = system
    b = ctx(blobs, spec, {"f": zip_with()})
    c = cs.generate_router(router_art(["f"], window=("2008-06-01", "2008-06-04")), b, "K2")
    assert cs.evaluate(c, b).verdict == "INVALID"                              # D ⊄ resolved imported window
    full = cs.generate_router(router_art(["f"]), b, "K2")
    sat_only = lambda n, d: d.replace("20080101,20081231", "20080101,20081231") if n == "calendar.txt" else d  # noqa: E731
    assert cs.evaluate(full, ctx(blobs, spec, {"f": zip_with(edit=sat_only)})).verdict == "VALID"
    p1 = k2_projection(zip_with(), ["2008-06-03"])
    p2 = k2_projection(zip_with(), ["2010-06-03"])                             # outside service: empty closure
    assert any(x.startswith("trip|") for x in p1) and not any(x.startswith("trip|") for x in p2)


@pytest.mark.gate("S2-33")
def test_k2_canon_alignment_full_frozen_suite():
    al = k2_canon_alignment()
    assert len(al) == 35 and all(r["sound"] for r in al) and all(r["agrees"] for r in al)


@pytest.mark.gate("S2-33")
def test_coverage_matrix_has_no_routing_unknown():
    import csv
    rows = list(csv.DictReader(open(ROOT / "frozen_specs/authoritative/09_ROUTING_FIELD_COVERAGE_FINAL.csv")))
    rows3 = list(csv.DictReader(open(ROOT / "frozen_specs/authoritative/03_STOP_STATION_ROUTING_FIELD_MATRIX.csv")))
    assert all(r["status"] in ("COVERED", "PROVEN IRRELEVANT") for r in rows)
    assert all("UNKNOWN" not in r["status"] for r in rows3)
    src = (ROOT / "src/f1/workload_c/contracts/k2.py").read_text()
    for field in ("block_id", "wheelchair_accessible", "bikes_allowed", "cars_allowed", "pickup_type", "drop_off_type",
                  "headway_secs", "exact_times", "agency_timezone", "route_type", "network_id", "wheelchair_boarding",
                  "parent_station", "stop_timezone", "level_index", "vehicle_type", "traversal_time", "stair_count",
                  "max_slope", "min_transfer_time"):
        assert field in src, field
    for display in ("stop_name", "route_long_name", "trip_headsign", "shape_id", "platform_code", "stop_code"):
        assert f'"{display}"' not in src, display


@pytest.mark.gate("S2-30")
def test_k3_reference_path_stub_and_ordinary_refusal(system, spec, tmp_path, cfg):
    cs, blobs = system
    b = ctx(blobs, spec, {"f": zip_with()})
    k3 = cs.generate_val(val_art(), b, "K3")
    assert cs.evaluate(k3, b).verdict == "ERROR"                               # not ordinary evaluation
    from f1.workload_c.campaign.s2 import make_producers
    from f1.workload_c.deps.pins import BinaryMode
    from f1.workload_c.producers.validator import ValidatorRequest
    _, _, vb, otp, val, canon = make_producers(BinaryMode.FIXTURE_STUB_BINARY, tmp_path / "w")
    zp = tmp_path / "f.zip"
    zp.write_bytes(zip_with())
    req = ValidatorRequest("VAL:feed=f", "R", "f", "f#L1", "c" * 64, str(zp), "2008-06-03", "US", "CUT:b", "FIXTURE")
    o = val.produce(req)
    art = {**o.val_report, "artifact_id": "VAL:a"}
    c = cs.generate_val(art, b, "K3")
    assert ReferencePath(validator=val).val_k3(c, req).verdict == "VALID"
    bad = cs.generate_val({**art, "report_digest": "0" * 64}, b, "K3")
    assert ReferencePath(validator=val).val_k3(bad, req).verdict == "INVALID"


@pytest.mark.gate("S2-30")
@pytest.mark.gate("S2-48")
def test_real_e2e_k3_reference_valid(real_e2e):
    assert real_e2e["binary_mode"] == "REAL_PINNED_BINARY" and real_e2e["k3"] == {"VAL": "VALID", "ROUTER": "VALID"}


@pytest.mark.gate("S2-31")
def test_contract_bytes_deterministic_across_processes(system, spec):
    cs, blobs = system
    b = ctx(blobs, spec, {"f": zip_with()})
    a1 = [cs.generate_router(router_art(["f"]), b, lv).digest for lv in ("K0", "K1", "K2", "K3")]
    a2 = [cs.generate_router(router_art(["f"]), b, lv).digest for lv in ("K0", "K1", "K2", "K3")]
    assert a1 == a2 and len(set(a1)) == 4
    c = cs.generate_router(router_art(["f"]), b, "K2")
    assert json.loads(c.canonical_bytes)["level"] == "K2" and c.metadata_size == len(c.canonical_bytes)
    code = f"""
import sys; sys.path.insert(0, {str(ROOT / 'src')!r})
from f1.workload_c.contracts.model import Contract
print(Contract.build('K2','ROUTER','a','s','c',{{'x':[1,2],'y':{{'b':1,'a':2}}}},'g','e').digest)"""
    outs = {subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, env={"PYTHONHASHSEED": s}).stdout
            for s in ("0", "1", "12345")}
    assert len(outs) == 1


@pytest.mark.gate("S2-32")
def test_contract_evaluation_fails_closed(system, spec, tmp_path):
    cs, blobs = system
    b = ctx(blobs, spec, {"f": zip_with()})
    c = cs.generate_router(router_art(["f"]), b, "K2")
    assert cs.evaluate(c, replace(b, feeds={})).verdict == "ERROR"                       # feed missing in cut
    tampered = dataclasses.replace(c, footprint={**c.footprint, "osm_sha256": "x"})
    assert cs.evaluate(tampered, b).verdict == "ERROR"                                   # bytes != body
    other_eval = Contract.build(c.level, c.artifact_class, c.artifact_id, c.request_slot, c.birth_cut_id, c.footprint,
                                c.generator_digest, "different-evaluator")
    assert cs.evaluate(other_eval, b).verdict == "ERROR"
    k1 = cs.generate_router(router_art(["f"]), b, "K1")
    missing_blob = replace(b, feeds={"f": {**b.feeds["f"], "raw_zip_sha256": "0" * 64}})
    assert cs.evaluate(k1, missing_blob).verdict == "ERROR"                              # unreadable reference data
    no_D = replace(b, horizon=())
    assert cs.evaluate(c, no_D).verdict in ("ERROR", "INVALID") and cs.evaluate(c, no_D).verdict != "VALID"


@pytest.mark.gate("S2-34")
def test_history_dag_partial_order(tmp_path):
    h = RealizedHistory(tmp_path / "h.jsonl")
    a1 = h.add(Event("LOGICAL_VERSION_AVAILABLE", "2025-01-01T00:00:00Z", "R", "a", {"index": 1}, ()))
    b1 = h.add(Event("LOGICAL_VERSION_AVAILABLE", "2025-01-01T00:00:00Z", "R", "b", {"index": 1}, ()))
    q = h.add(Event("PRODUCER_QUEUED", "2025-01-01T00:00:00Z", "R", "a", {"job": "v"}, (a1,)))
    s = h.add(Event("PRODUCER_STARTED", "2025-01-01T01:00:00Z", "R", "a", {"job": "v"}, (q,)))
    born = h.add(Event("ARTIFACT_BORN", "2025-01-01T02:00:00Z", "R", "a", {"job": "v"}, (s,)))
    assert h.happens_before(a1, born) and h.concurrent(a1, b1) and h.concurrent(b1, born)
    with pytest.raises(HistoryError):
        h.add(Event("ARTIFACT_BORN", "2025-01-02T00:00:00Z", "R", None, {}, ("f" * 64,)))     # unknown cause
    with pytest.raises(HistoryError):
        h.add(Event("LOGICAL_VERSION_AVAILABLE", "2025-01-02T00:00:00Z", "R", "a", {"index": 3}, (a1,)))
    with pytest.raises(HistoryError):
        h.add(Event("LOGICAL_VERSION_AVAILABLE", "2025-01-02T00:00:00Z", "R", "a", {"index": 2}, ()))  # chain broken
    with pytest.raises(HistoryError):
        h.add(Event("PRODUCER_COMPLETED", "2024-12-31T00:00:00Z", "R", "a", {}, (s,)))       # before its cause
    assert h.add(Event("ARTIFACT_BORN", "2025-01-01T02:00:00Z", "R", "a", {"job": "v"}, (s,))) == born  # idempotent
    assert RealizedHistory(tmp_path / "h.jsonl").order == h.order


def _hist():
    h = RealizedHistory()
    prev = {}
    for f, i, t in (("a", 1, "2025-01-01T00:00:00Z"), ("a", 2, "2025-01-05T00:00:00Z"), ("b", 1, "2025-01-02T00:00:00Z"),
                    ("a", 3, "2025-01-09T00:00:00Z"), ("b", 2, "2025-01-09T00:00:00Z")):
        prev[f] = h.add(Event("LOGICAL_VERSION_AVAILABLE", t, "R", f, {"index": i}, (prev[f],) if f in prev else ()))
    return h


@pytest.mark.gate("S2-35")
def test_cut_model():
    h = _hist()
    c = cut_at(h, "R", ["b", "a"], "2025-01-06T00:00:00Z")
    assert c.frontier == (("a", 2), ("b", 1)) and is_consistent(h, c, "2025-01-06T00:00:00Z")
    assert not is_consistent(h, Cut.of("R", {"a": 3, "b": 1}), "2025-01-06T00:00:00Z")
    assert c.cut_id == Cut.of("R", {"b": 1, "a": 2}).cut_id and c.serialize() == Cut.of("R", {"b": 1, "a": 2}).serialize()
    all_cuts = list(enumerate_cuts(h, "R", ["a", "b"], "2025-01-10T00:00:00Z"))
    assert len(all_cuts) == 3 * 2 and all(is_consistent(h, x, "2025-01-10T00:00:00Z") for x in all_cuts)
    assert len(list(enumerate_cuts(h, "R", ["a", "b"], "2025-01-10T00:00:00Z", max_back=1))) == 2 * 2
    assert len(list(enumerate_cuts(h, "R", ["a", "b"], "2025-01-10T00:00:00Z", include_empty=True))) == 4 * 3
    assert Cut.of("R", {"a": 1, "b": 1}).leq(c) and not c.leq(Cut.of("R", {"a": 1, "b": 2}))


def _add(cat, slot="VAL:feed=a", cut="CUT:1", **kw):
    base = dict(request_slot=slot, producer_type="gtfs-validator", artifact_class="VAL_REPORT", birth_cut_id=cut,
                birth_frontier=(("a", 1),), logical_inputs=[("a", "a#L1", "h")], contract_ids=["K0:x"], status="SUCCESS",
                provenance_digest="p", output_digests=[("report", "r")], cost={"wall_s": 1.0}, namespace="FIXTURE",
                binary_mode="FIXTURE_STUB_BINARY")
    base.update(kw)
    return cat.add(**base)


@pytest.mark.gate("S2-36")
def test_catalog_immutable_append_only(tmp_path):
    cat = ArtifactCatalog(tmp_path / "c.jsonl")
    e = _add(cat)
    with pytest.raises(dataclasses.FrozenInstanceError):
        e.status = "INFRA_ERROR"
    forged = dataclasses.replace(e, status="INFRA_ERROR")
    with pytest.raises(CatalogError):
        cat._insert(forged, persist=True)
    assert cat._insert(e, persist=True) is e                          # identical re-add is idempotent
    with pytest.raises(CatalogError):
        cat._insert(dataclasses.replace(e, artifact_id="other", instance=5), persist=True)
    again = ArtifactCatalog(tmp_path / "c.jsonl")
    assert again.get(e.artifact_id) == e and len(again) == 1
    assert not hasattr(cat, "find_by_content") and not hasattr(cat, "substitute")   # no free historical substitution


@pytest.mark.gate("S2-37")
def test_request_slot_vs_derivation_instance(tmp_path):
    slots = designated_slots("R:a+b", ["b", "a"])
    assert [s.slot_id for s in slots] == ["VAL:feed=a", "VAL:feed=b", "ROUTER:region=R:a+b"]
    cat = ArtifactCatalog()
    e1 = _add(cat, cut="CUT:1")
    e2 = _add(cat, cut="CUT:2", logical_inputs=[("a", "a#L2", "h2")])
    assert e1.request_slot == e2.request_slot and e1.artifact_id != e2.artifact_id and (e1.instance, e2.instance) == (1, 2)
    assert [x.artifact_id for x in cat.instances("VAL:feed=a")] == [e1.artifact_id, e2.artifact_id]
    assert cat.instances("VAL:feed=b") == []                           # instances never leak across slots
    assert RequestSlot("ROUTER", "R:a+b").slot_id == "ROUTER:region=R:a+b"


@pytest.mark.gate("S2-38")
def test_rederive_creates_new_instance_same_slot():
    cat = ArtifactCatalog()
    e1 = _add(cat, cut="CUT:1")
    kw = dict(producer_type="gtfs-validator", artifact_class="VAL_REPORT", birth_frontier=(("a", 3),),
              logical_inputs=[("a", "a#L3", "h3")], contract_ids=[], status="SUCCESS", provenance_digest="p3",
              output_digests=[("report", "r3")], cost={}, namespace="FIXTURE", binary_mode="FIXTURE_STUB_BINARY")
    r = cat.rederive("VAL:feed=a", "CUT:9", **kw)
    assert r.request_slot == e1.request_slot and r.instance == 2 and r.rederived_from == e1.artifact_id
    assert r.birth_cut_id == "CUT:9" and r.artifact_id != e1.artifact_id and cat.get(e1.artifact_id) == e1
    with pytest.raises(CatalogError):
        cat.rederive("VAL:feed=zzz", "CUT:9", **kw)


def rin(versions, tz="Europe/Paris", start="2025-03-27T00:00:00Z", end="2025-04-02T00:00:00Z", feeds=("a", "b")):
    return RegionScheduleInput("R", tz, feeds, tuple(VersionAvailability(f, i, f"{f}#L{i}", t) for f, i, t in versions),
                               start, end)


V = [("a", 1, "2025-03-27T10:00:00Z"), ("b", 1, "2025-03-27T10:00:00Z"), ("a", 2, "2025-03-28T23:00:00Z")]


@pytest.mark.gate("S2-39")
def test_validator_scheduler_fifo_one_worker(spec):
    r = simulate(spec, rin(V), FixtureDurationBackend(validator_s=3600))
    st = [(e["t"], e["feed_id"]) for e in r.events if e["kind"] == "PRODUCER_STARTED" and e["producer"] == "validator"]
    assert st == [("2025-03-27T10:00:00Z", "a"), ("2025-03-27T11:00:00Z", "b"), ("2025-03-28T23:00:00Z", "a")]
    born = [(e["t"], e["feed_id"]) for e in r.events if e["kind"] == "ARTIFACT_BORN" and e["producer"] == "validator"]
    assert born[1] == ("2025-03-27T12:00:00Z", "b")                    # exists at real completion (queued 1 h)


@pytest.mark.gate("S2-40")
def test_otp_scheduler_rules(spec):
    r = simulate(spec, rin(V, feeds=("a", "b")), FixtureDurationBackend(otp_s=26 * 3600))
    kinds = [(e["t"], e["kind"], e.get("reason")) for e in r.events if e["kind"] in ("OTP_TRIGGER", "OTP_TRIGGER_SKIPPED")]
    assert kinds[0] == ("2025-03-27T01:00:00Z", "OTP_TRIGGER_SKIPPED", "not every feed has a version")
    assert kinds[1] == ("2025-03-28T01:00:00Z", "OTP_TRIGGER", None)           # 02:00 CET = 01:00Z
    assert kinds[2] == ("2025-03-29T01:00:00Z", "OTP_TRIGGER_SKIPPED", "build running")
    starts = [e for e in r.events if e["kind"] == "PRODUCER_STARTED" and e["producer"] == "otp"]
    assert starts[0]["inputs"] == {"a": 1, "b": 1} and starts[1]["inputs"] == {"a": 2, "b": 1}
    r2 = simulate(spec, rin(V), FixtureDurationBackend(otp_s=600))
    skipped = [e for e in r2.events if e.get("reason") == "no newer inputs"]
    assert skipped                                                             # build only if newer inputs exist
    at_trigger = simulate(spec, rin([("a", 1, "2025-03-27T10:00:00Z"), ("b", 1, "2025-03-28T01:00:00Z")]),
                          FixtureDurationBackend())
    s = [e for e in at_trigger.events if e["kind"] == "PRODUCER_STARTED" and e["producer"] == "otp"]
    assert s[0]["t"] == "2025-03-28T01:00:00Z" and s[0]["inputs"] == {"a": 1, "b": 1}   # update exactly at trigger


@pytest.mark.gate("S2-40")
def test_otp_sch01_frozen_last_successful_build(spec):
    """SCH-01 frozen at PRE-S3: newer-than reference = last SUCCESSFUL build (cases A-E)."""
    from f1.workload_c.scheduler.workload_c import FROZEN_OTP_NEWER_THAN, scientific_policy
    assert FROZEN_OTP_NEWER_THAN == "last_successful_build" and scientific_policy("last_successful_build")
    with pytest.raises(SchedulerError):
        scientific_policy("last_completed_build")
    otp_starts = lambda r: [e for e in r.events if e["kind"] == "PRODUCER_STARTED" and e["producer"] == "otp"]  # noqa: E731
    # A: no prior successful build -> attempt at the first eligible trigger
    a = simulate(spec, rin(V[:2]), FixtureDurationBackend())
    assert otp_starts(a)[0]["t"] == "2025-03-28T01:00:00Z"
    # B: the attempt with (a1,b1) FAILED -> the next trigger retries the same inputs (default path)
    fail = FixtureDurationBackend(outcomes={"otp|a:1,b:1": "INFRA_ERROR"})
    b = simulate(spec, rin(V[:2]), fail)
    st = otp_starts(b)
    assert len(st) >= 2 and st[0]["inputs"] == st[1]["inputs"] == {"a": 1, "b": 1}
    assert not [e for e in b.events if e["kind"] == "ARTIFACT_BORN" and e["producer"] == "otp"]
    # C: last SUCCESSFUL build used exactly the current inputs -> no rebuild
    c = simulate(spec, rin(V[:2]), FixtureDurationBackend())
    assert len(otp_starts(c)) == 1 and any(e.get("reason") == "no newer inputs" for e in c.events)
    # C': a later failure of NEWER inputs does not trigger a rebuild of the already-successful older state
    c2 = simulate(spec, rin(V), FixtureDurationBackend(outcomes={"otp|a:2,b:1": "INFRA_ERROR"}))
    assert all(s["inputs"] != {"a": 1, "b": 1} for s in otp_starts(c2)[1:])
    # D: newer input than the last successful build -> build
    d = simulate(spec, rin(V), FixtureDurationBackend())
    assert [s["inputs"] for s in otp_starts(d)] == [{"a": 1, "b": 1}, {"a": 2, "b": 1}]
    # E: previous build still running at the trigger -> skipped
    e = simulate(spec, rin(V), FixtureDurationBackend(otp_s=26 * 3600))
    assert any(x["kind"] == "OTP_TRIGGER_SKIPPED" and x["reason"] == "build running" for x in e.events)
    # provenance-only alternative still behaves as recorded in Session 2 (never used by the scientific path)
    old = simulate(spec, rin(V[:2]), fail, otp_newer_than="last_completed_build")
    assert len(otp_starts(old)) == 1
    with pytest.raises(SchedulerError):
        simulate(spec, rin(V), fail, otp_newer_than="whatever")


@pytest.mark.gate("S2-41")
def test_consumer_ticks_and_visibility(spec):
    r = simulate(spec, rin(V), FixtureDurationBackend(otp_s=4 * 3600))      # OTP 01:00Z -> 05:00Z = 06:00 CET exactly
    ticks = [e for e in r.events if e["kind"] == "CONSUMER_TICK"]
    t28 = next(e for e in ticks if e["local_date"] == "2025-03-28")
    assert t28["t"] == "2025-03-28T05:00:00Z" and t28["visible_router"] == {"a": 1, "b": 1}  # completion == tick
    assert t28["cut"] == {"a": 1, "b": 1} and t28["visible_val"] == {"a": 1, "b": 1}


@pytest.mark.gate("S2-42")
def test_dst_rules():
    assert local_to_utc(__import__("datetime").date(2025, 3, 30), "02:00", "Europe/Paris") == \
        (__import__("datetime").datetime(2025, 3, 30, 1, 0, tzinfo=__import__("datetime").timezone.utc),
         "nonexistent->next-valid-minute")                                     # 02:00 -> 03:00 CEST
    u, rule = local_to_utc(__import__("datetime").date(2025, 10, 26), "02:00", "Europe/Paris")
    assert rule == "ambiguous->first" and u.isoformat() == "2025-10-26T00:00:00+00:00"   # first (CEST) occurrence
    u, rule = local_to_utc(__import__("datetime").date(2025, 3, 9), "02:30", "America/New_York")
    assert rule == "nonexistent->next-valid-minute" and u.isoformat() == "2025-03-09T07:00:00+00:00"
    u, rule = local_to_utc(__import__("datetime").date(2025, 11, 2), "01:30", "America/New_York")
    assert rule == "ambiguous->first" and u.isoformat() == "2025-11-02T05:30:00+00:00"
    u, rule = local_to_utc(__import__("datetime").date(2025, 6, 1), "06:00", "Australia/Sydney")
    assert rule == "ordinary" and u.isoformat() == "2025-05-31T20:00:00+00:00"


@pytest.mark.gate("S2-42")
def test_scheduler_across_dst_transitions(spec):
    r = simulate(spec, rin(V, start="2025-03-28T00:00:00Z", end="2025-04-01T00:00:00Z"), FixtureDurationBackend())
    trig = {e["local_date"]: (e["t"], e["dst_rule"]) for e in r.events if e["kind"] in ("OTP_TRIGGER", "OTP_TRIGGER_SKIPPED")}
    assert trig["2025-03-30"] == ("2025-03-30T01:00:00Z", "nonexistent->next-valid-minute")
    assert trig["2025-03-31"] == ("2025-03-31T00:00:00Z", "ordinary")               # 02:00 CEST
    ticks = {e["local_date"]: e["t"] for e in r.events if e["kind"] == "CONSUMER_TICK"}
    assert ticks["2025-03-29"] == "2025-03-29T05:00:00Z" and ticks["2025-03-30"] == "2025-03-30T04:00:00Z"
    fall = simulate(spec, rin(V, start="2025-10-25T00:00:00Z", end="2025-10-28T00:00:00Z"), FixtureDurationBackend())
    ft = {e["local_date"]: (e["t"], e["dst_rule"]) for e in fall.events if e["kind"] in ("OTP_TRIGGER", "OTP_TRIGGER_SKIPPED")}
    assert ft["2025-10-26"] == ("2025-10-26T00:00:00Z", "ambiguous->first")


@pytest.mark.gate("S2-43")
def test_overlapping_and_simultaneous_jobs(spec):
    simul = [("a", 1, "2025-03-27T10:00:00Z"), ("b", 1, "2025-03-27T10:00:00Z"), ("c", 1, "2025-03-27T10:00:00Z")]
    r = simulate(spec, rin(simul, feeds=("a", "b", "c")), FixtureDurationBackend(validator_s=1800))
    st = [(e["t"], e["feed_id"]) for e in r.events if e["kind"] == "PRODUCER_STARTED" and e["producer"] == "validator"]
    assert st == [("2025-03-27T10:00:00Z", "a"), ("2025-03-27T10:30:00Z", "b"), ("2025-03-27T11:00:00Z", "c")]
    running = 0
    peak = 0
    for e in r.events:
        if e.get("producer") == "validator" and e["kind"] == "PRODUCER_STARTED":
            running += 1
        if e.get("producer") == "validator" and e["kind"] == "PRODUCER_COMPLETED":
            running -= 1
        peak = max(peak, running)
    assert peak == 1                                                           # one validator worker per region
    long_otp = simulate(spec, rin(V), FixtureDurationBackend(otp_s=50 * 3600))
    otp_running = max_running = 0
    for e in long_otp.events:
        if e.get("producer") == "otp":
            otp_running += {"PRODUCER_STARTED": 1, "PRODUCER_COMPLETED": -1}.get(e["kind"], 0)
            max_running = max(max_running, otp_running)
    assert max_running == 1                                                    # 1 build per region


@pytest.mark.gate("S2-44")
def test_event_ledger_deterministic_and_order_independent(spec):
    ref = simulate(spec, rin(V), FixtureDurationBackend())
    for seed in range(10):
        vv = list(V)
        random.Random(seed).shuffle(vv)                                        # test-only input permutation
        assert simulate(spec, rin(vv), FixtureDurationBackend()).digest == ref.digest
    h1, h2 = RealizedHistory(), RealizedHistory()
    assert to_history(ref, h1) == to_history(simulate(spec, rin(V), FixtureDurationBackend()), h2)
    with pytest.raises(SchedulerError):
        simulate(spec, rin([("a", 2, "2025-03-27T10:00:00Z")], feeds=("a",)), FixtureDurationBackend())
    assert ref.backend_mode == "FIXTURE_DURATION_BACKEND"
    from f1.workload_c.scheduler.workload_c import RealMeasuredBackend
    real = simulate(spec, rin(V), RealMeasuredBackend(lambda kind, key: (600.0 if kind == "validator" else 5400.0, "SUCCESS")))
    assert real.backend_mode == "REAL_MEASURED_BACKEND" and \
        all(e["backend"] == "REAL_MEASURED_BACKEND" for e in real.events if e["kind"] == "PRODUCER_COMPLETED")
