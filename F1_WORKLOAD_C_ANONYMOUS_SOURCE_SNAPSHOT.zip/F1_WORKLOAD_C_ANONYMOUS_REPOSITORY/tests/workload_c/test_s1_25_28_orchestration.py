import json
import os
import subprocess
import sys

import pytest

from conftest import ROOT, make_orchestrator, read_jsonl
from f1.workload_c import FIXTURE_MARKER, REAL_MODE_REFUSAL
from f1.workload_c.campaign.orchestrator import FailureInjection, InjectedCrash, Orchestrator
from f1.workload_c.campaign.phases import PHASE_IDS
from f1.workload_c.errors import (CheckpointIntegrityError, FailureInjectionNotAllowed, IncompatibleResumeError,
                                  RealModeRefused)


def ledger(run_dir):
    return read_jsonl(run_dir / "ledger/run_state.jsonl")


def ran(run_dir):
    return {r["phase"] for r in ledger(run_dir) if r["to"] == "RUNNING"}


# ---------------------------------------------------------------------------------------------- S1-30
@pytest.mark.gate("S1-30")
def test_complete_phase00_to_18(full_run):
    res = full_run["result"]
    assert res.status == "COMPLETE" and set(res.states.values()) == {"COMPLETE"} and len(res.states) == 19
    d = full_run["dir"]
    v = json.loads((d / "phases/18_final_verdict/FINAL_VERDICT.json").read_text())
    assert v["marker"] == FIXTURE_MARKER and v["verdict"] == "FIXTURE_ORCHESTRATION_COMPLETE"
    assert v["scientific_results"] == "NONE" and len(v["phases_complete"]) == 19
    assert FIXTURE_MARKER in (d / "phases/17_result_package/README_RESULTS.md").read_text()
    seq = [r["phase"] for r in ledger(d) if r["to"] == "RUNNING"]
    assert seq == list(PHASE_IDS)                      # strict order, each exactly once
    cps = sorted(p.stem for p in (d / "checkpoints").glob("*.json") if p.name != "RUN_IDENTITY.json")
    assert cps == sorted(PHASE_IDS)
    pre = json.loads((d / "phases/00_bootstrap_preflight/preflight.json").read_text())
    assert pre["frozen_specs_verified"] >= 27 and pre["gpu_required"] is False


@pytest.mark.gate("S1-30")
def test_real_engines_used_for_phases_02_to_07(full_run):
    from f1.workload_c.campaign.phases import PHASES
    assert [p.phase_id for p in PHASES if p.engine == "REAL_S1"] == [
        "00_bootstrap_preflight", "02_mobility_snapshot", "03_logical_versions", "04_license_gate",
        "05_eligible_regions", "06_select_24", "07_split_8_16"]
    srv = full_run["wiring"]["services"]["server"]
    assert len(srv.calls) > 3000                       # the real client really talked to the mock API
    for ph in ("03_logical_versions", "06_select_24"):
        m = [r for r in ledger(full_run["dir"]) if r["phase"] == ph and r["to"] == "COMPLETE"][0]
        assert m["outputs"]


@pytest.mark.gate("S1-30")
def test_cli_fixture_mode_and_real_mode_refusal(tmp_path):
    env = {**os.environ, "PYTHONPATH": str(ROOT / "src"), "MOBILITY_DB_TOKEN": "must-never-be-read-in-s1-0000"}
    cp = subprocess.run([sys.executable, "-m", "f1.workload_c.campaign.cli", "run", "--real",
                         "--run-root", str(tmp_path)], env=env, capture_output=True, text=True)
    assert cp.returncode == 3 and REAL_MODE_REFUSAL in cp.stdout and not any(tmp_path.iterdir())
    cp2 = subprocess.run([sys.executable, "-m", "f1.workload_c.campaign.cli", "run", "--fixture-mode",
                          "--run-root", str(tmp_path), "--run-id", "cli", "--inject", "05=BLOCKED"],
                         env=env, capture_output=True, text=True)
    assert cp2.returncode == 2, cp2.stdout + cp2.stderr
    out = json.loads(cp2.stdout)
    assert out["status"] == "BLOCKED" and out["stopped_at"] == "05_eligible_regions"
    assert "must-never-be-read" not in "".join(p.read_text(errors="ignore") for p in tmp_path.rglob("*.json*"))


@pytest.mark.gate("S1-30")
def test_orchestrator_real_mode_refuses_before_any_io(cfg, tmp_path):
    from f1.workload_c.config.runtime import load_effective_config
    real = load_effective_config(ROOT / "configs/workload_c/real.yaml")

    class Tripwire:
        def request(self, *a, **k):
            raise AssertionError("network attempted")
    o = Orchestrator(real, tmp_path, "r", services={"transport": Tripwire()}, adapters={})
    with pytest.raises(RealModeRefused) as e:
        o.run()
    assert REAL_MODE_REFUSAL in str(e.value) and not (tmp_path / "VALIDATION").exists()
    with pytest.raises(FailureInjectionNotAllowed):
        Orchestrator(real, tmp_path, "r", injection=FailureInjection({"05_eligible_regions": "FAIL"}))
    from f1.workload_c.campaign.fixture import fixture_wiring
    with pytest.raises(RealModeRefused):
        fixture_wiring(real)


# ---------------------------------------------------------------------------------------------- S1-27 / S1-28
@pytest.mark.gate("S1-27")
@pytest.mark.parametrize("phase,action", [("06_select_24", "FAIL"), ("02_mobility_snapshot", "BLOCKED"),
                                          ("13_scientific_test_campaign", "FAIL")])
def test_hard_gate_stops_everything_after(cfg, tmp_path, phase, action):
    o, _ = make_orchestrator(cfg, tmp_path, run_id="hg", injection=FailureInjection({phase: action}))
    res = o.run()
    k = PHASE_IDS.index(phase)
    assert res.status == ("FAILED" if action == "FAIL" else "BLOCKED") and res.stopped_at == phase
    assert ran(res.run_dir) == set(PHASE_IDS[: k + 1])
    assert all(res.states[p] == "PENDING" for p in PHASE_IDS[k + 1:])
    for p in PHASE_IDS[k + 1:]:
        assert not (res.run_dir / "phases" / p).exists() and not (res.run_dir / "checkpoints" / f"{p}.json").exists()
    ev = read_jsonl(res.run_dir / "logs/events.jsonl")
    assert ev[-1]["event"] == "RUN_STOPPED_HARD_GATE"


@pytest.mark.gate("S1-27")
def test_adapter_level_block_and_population_shortfall_fail(cfg, tmp_path):
    # Session 2 replaced the Phase-01 mock adapter by the real L28 runner: the adapter-level BLOCK is now injected at
    # that component boundary (services["l28_runner"]), which must propagate as a hard-gate BLOCKED.
    from f1.workload_c.errors import PhaseBlocked

    def l28_blocked(out_dir):
        raise PhaseBlocked("injected component-level BLOCK (L28 runner)")
    o, w = make_orchestrator(cfg, tmp_path / "a", run_id="blk")
    w["services"]["l28_runner"] = l28_blocked
    r = o.run()
    assert r.status == "BLOCKED" and r.stopped_at == "01_l28_target_conformance"
    # population shortfall: drop most catalog records -> phase 06 B1 FAIL, no automatic target reduction
    o2, w = make_orchestrator(cfg, tmp_path / "b", run_id="short")
    srv = w["services"]["server"]
    srv.catalog = srv.catalog[:30]
    r2 = o2.run()
    assert r2.status == "FAILED" and r2.stopped_at == "06_select_24"
    assert "B1 FAIL — POPULATION TARGET UNSATISFIED" in r2.error["message"]
    assert ran(r2.run_dir) == set(PHASE_IDS[:7])


@pytest.mark.gate("S1-27")
def test_auth_failure_blocks_phase02(cfg, tmp_path):
    o, w = make_orchestrator(cfg, tmp_path, run_id="auth")
    w["services"]["server"].refresh_token = "a-different-token-value-zzzz"
    r = o.run()
    assert r.status == "BLOCKED" and r.stopped_at == "02_mobility_snapshot"
    assert "MOBILITY_AUTH_401" in r.error["message"]


@pytest.mark.gate("S1-28")
@pytest.mark.parametrize("action", ["FAIL", "BLOCKED"])
def test_injection_at_every_phase_with_resume_chain(cfg, tmp_path, action):
    """One run directory: inject at phase k, verify stop + ledger + checkpoints, then resume injecting at k+1.
    Covers all 19 phases and the resume-after-FAIL/BLOCKED path at every phase."""
    for k, ph in enumerate(PHASE_IDS):
        o, _ = make_orchestrator(cfg, tmp_path, run_id="chain", injection=FailureInjection({ph: action}))
        res = o.run()
        assert res.status == ("FAILED" if action == "FAIL" else "BLOCKED") and res.stopped_at == ph, (ph, res.error)
        assert all(res.states[p] == "COMPLETE" for p in PHASE_IDS[:k])
        assert res.states[ph] == ("FAILED" if action == "FAIL" else "BLOCKED")
        assert all(res.states[p] == "PENDING" for p in PHASE_IDS[k + 1:])
        assert ran(res.run_dir) == set(PHASE_IDS[: k + 1])
        cps = {p.stem for p in (res.run_dir / "checkpoints").glob("*.json")} - {"RUN_IDENTITY"}
        assert cps == set(PHASE_IDS[:k])
        L = ledger(res.run_dir)
        last = [r for r in L if r["phase"] == ph][-1]
        assert last["error"]["error_class"] == ("PHASE_FAILED" if action == "FAIL" else "PHASE_BLOCKED")
        # completed earlier phases ran exactly once across the whole chain (reused, never recomputed)
        for p in PHASE_IDS[:k]:
            assert sum(1 for r in L if r["phase"] == p and r["to"] == "COMPLETE") == 1
    o, _ = make_orchestrator(cfg, tmp_path, run_id="chain")
    final = o.run()
    assert final.status == "COMPLETE"
    L = ledger(final.run_dir)
    assert all(sum(1 for r in L if r["phase"] == p and r["to"] == "RUNNING") == 2 for p in PHASE_IDS)


@pytest.mark.gate("S1-28")
def test_failure_injection_refused_outside_fixture(cfg, tmp_path):
    import copy
    from f1.workload_c.config.runtime import load_effective_config
    rt = copy.deepcopy(cfg.runtime)
    rt["failure_injection_allowed"] = False
    c2 = load_effective_config(runtime_obj=rt)
    with pytest.raises(FailureInjectionNotAllowed):
        Orchestrator(c2, tmp_path, "x", injection=FailureInjection({"00_bootstrap_preflight": "FAIL"}))


# ---------------------------------------------------------------------------------------------- S1-25
@pytest.mark.gate("S1-25")
def test_crash_after_outputs_before_complete_then_resume(cfg, tmp_path, full_run):
    o, _ = make_orchestrator(cfg, tmp_path, run_id="crash",
                             injection=FailureInjection(crash_after_outputs="05_eligible_regions"))
    with pytest.raises(InjectedCrash):
        o.run()
    rd = tmp_path / "FIXTURE" / "crash"
    L = ledger(rd)
    assert L[-1]["phase"] == "05_eligible_regions" and L[-1]["to"] == "RUNNING"
    assert not (rd / "checkpoints/05_eligible_regions.json").exists()
    o2, w2 = make_orchestrator(cfg, tmp_path, run_id="crash")
    res = o2.run()
    assert res.status == "COMPLETE"
    L = ledger(rd)
    stale = [r for r in L if r["phase"] == "05_eligible_regions"]
    assert [r["to"] for r in stale] == ["RUNNING", "FAILED", "RUNNING", "COMPLETE"]
    assert stale[1]["error"]["error_class"] == "INTERRUPTED"
    for p in PHASE_IDS[:5]:
        assert [r["to"] for r in L if r["phase"] == p] == ["RUNNING", "COMPLETE"]   # reused, not rerun
    assert len(w2["services"]["server"].calls) == 0                                  # no re-fetch on resume
    for rel in ("05_eligible_regions/eligible_population.csv", "07_split_8_16/split_proof.csv"):
        assert (rd / "phases" / rel).read_bytes() == (full_run["dir"] / "phases" / rel).read_bytes()


@pytest.mark.gate("S1-25")
def test_process_death_via_cli_then_resume(tmp_path):
    env = {**os.environ, "PYTHONPATH": str(ROOT / "src")}
    base = [sys.executable, "-m", "f1.workload_c.campaign.cli", "run", "--fixture-mode", "--run-root", str(tmp_path),
            "--run-id", "die"]
    cp = subprocess.run(base + ["--crash-after", "03"], env=env, capture_output=True, text=True)
    assert cp.returncode == 137
    cp2 = subprocess.run(base, env=env, capture_output=True, text=True)
    assert cp2.returncode == 0, cp2.stdout + cp2.stderr
    L = ledger(tmp_path / "FIXTURE" / "die")
    assert [r["to"] for r in L if r["phase"] == "03_logical_versions"] == ["RUNNING", "FAILED", "RUNNING", "COMPLETE"]
    assert [r["to"] for r in L if r["phase"] == "02_mobility_snapshot"] == ["RUNNING", "COMPLETE"]


@pytest.mark.gate("S1-25")
def test_snapshot_interrupted_mid_phase_resumes_idempotently(cfg, tmp_path, full_run):
    o, _ = make_orchestrator(cfg, tmp_path, run_id="snap", wiring_kw={"crash_after_fetches": 700})
    r1 = o.run()
    assert r1.status == "FAILED" and r1.stopped_at == "02_mobility_snapshot"
    assert "SimulatedInterruption" in r1.error["error_class"]
    o2, w2 = make_orchestrator(cfg, tmp_path, run_id="snap")
    r2 = o2.run()
    assert r2.status == "COMPLETE"
    stats = json.loads((r2.run_dir / "phases/02_mobility_snapshot/client_stats.json").read_text())
    assert stats["cache_hits"] == 700 and stats["cache_misses"] == 3395 - 700
    a = json.loads((r2.run_dir / "phases/02_mobility_snapshot/mobility_snapshot.json").read_text())
    b = json.loads((full_run["dir"] / "phases/02_mobility_snapshot/mobility_snapshot.json").read_text())
    assert a["snapshot_content_sha256"] == b["snapshot_content_sha256"]


@pytest.mark.gate("S1-25")
def test_tampered_committed_output_refuses_resume(cfg, tmp_path):
    o, _ = make_orchestrator(cfg, tmp_path, run_id="tamper", injection=FailureInjection({"08_osm_pinning": "FAIL"}))
    assert o.run().stopped_at == "08_osm_pinning"
    f = tmp_path / "FIXTURE/tamper/phases/06_select_24/selected_24.csv"
    f.write_text(f.read_text().replace("R:", "R:X", 1))
    o2, _ = make_orchestrator(cfg, tmp_path, run_id="tamper")
    with pytest.raises(CheckpointIntegrityError):
        o2.run()


# ---------------------------------------------------------------------------------------------- S1-26
@pytest.mark.gate("S1-26")
def test_incompatible_resume_refused(cfg, tmp_path):
    import copy
    from f1.workload_c.config.runtime import load_effective_config
    o, _ = make_orchestrator(cfg, tmp_path, run_id="inc", injection=FailureInjection({"01_l28_target_conformance": "FAIL"}))
    assert o.run().status == "FAILED"
    o2, _ = make_orchestrator(cfg, tmp_path, run_id="inc", impl="wc-s1:" + "f" * 64)
    with pytest.raises(IncompatibleResumeError) as e:
        o2.run()
    assert "implementation_id" in str(e.value)
    rt = copy.deepcopy(cfg.runtime)
    rt["mobility"]["page_limit"] = 25                 # any config change (incl. frozen spec/seed) changes the digest
    c2 = load_effective_config(runtime_obj=rt)
    o3, _ = make_orchestrator(cfg, tmp_path, run_id="inc", cfg_override=c2)
    with pytest.raises(IncompatibleResumeError) as e3:
        o3.run()
    assert "config_digest" in str(e3.value)
    o4, _ = make_orchestrator(cfg, tmp_path, run_id="inc")
    assert o4.run().status == "COMPLETE"              # the original identity still resumes


@pytest.mark.gate("S1-26")
def test_changed_spec_or_seed_refused(cfg, tmp_path):
    import dataclasses
    from f1.workload_c.config.runtime import EffectiveConfig
    o, _ = make_orchestrator(cfg, tmp_path, run_id="seed", injection=FailureInjection({"07_split_8_16": "FAIL"}))
    assert o.run().stopped_at == "07_split_8_16"
    raw = json.loads(json.dumps(cfg.spec.raw))
    raw["seeds"]["domains"] = raw["seeds"]["domains"] + ["extra"]
    spec2 = dataclasses.replace(cfg.spec, raw=raw, digest="0" * 64)
    c2 = EffectiveConfig(spec=spec2, interp=cfg.interp, license_table=cfg.license_table, runtime=cfg.runtime,
                         digest=cfg.digest)                      # even with a forged equal config digest
    o2, _ = make_orchestrator(cfg, tmp_path, run_id="seed", cfg_override=c2)
    with pytest.raises(IncompatibleResumeError) as e:
        o2.run()
    assert "spec_digest" in str(e.value)


@pytest.mark.gate("S1-26")
def test_cli_resume_refusal_exit_code(tmp_path):
    env = {**os.environ, "PYTHONPATH": str(ROOT / "src")}
    base = [sys.executable, "-m", "f1.workload_c.campaign.cli", "run", "--fixture-mode", "--run-root", str(tmp_path),
            "--run-id", "cli-inc"]
    assert subprocess.run(base + ["--inject", "01=FAIL"], env=env, capture_output=True).returncode == 1
    idp = tmp_path / "FIXTURE/cli-inc/checkpoints/RUN_IDENTITY.json"
    d = json.loads(idp.read_text())
    d["identity"]["implementation_id"] = "wc-s1:" + "0" * 64
    idp.write_text(json.dumps(d))
    cp = subprocess.run(base, env=env, capture_output=True, text=True)
    assert cp.returncode == 4 and "INCOMPATIBLE_RESUME" in cp.stdout
