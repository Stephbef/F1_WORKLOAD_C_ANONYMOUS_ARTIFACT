"""Workload-C Session-1 test configuration. Run with --confcutdir=tests/workload_c so that the core suite's
conftest (numpy/pyarrow dependent) is not required. Gate markers: @pytest.mark.gate("S1-xx")."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from f1.workload_c.config.runtime import load_effective_config  # noqa: E402


def pytest_configure(config):
    config.addinivalue_line("markers", "gate(id): maps a test to a Session-1 acceptance gate")


@pytest.fixture(scope="session")
def cfg():
    return load_effective_config(ROOT / "configs" / "workload_c" / "fixture.yaml")


@pytest.fixture(scope="session")
def spec(cfg):
    return cfg.spec


@pytest.fixture(scope="session")
def population():
    from f1.workload_c.fixturegen.population import build_fixture_population
    return build_fixture_population()


def make_orchestrator(cfg, run_root, run_id="t-run", injection=None, impl=None, wiring_kw=None, cfg_override=None):
    from f1.workload_c.campaign.fixture import fixture_wiring
    from f1.workload_c.campaign.orchestrator import Orchestrator
    c = cfg_override or cfg
    w = fixture_wiring(c, **(wiring_kw or {}))
    o = Orchestrator(c, run_root, run_id, secrets=w["secrets"], services=w["services"], adapters=w["adapters"],
                     clock=w["clock"], injection=injection, implementation_id=impl)
    return o, w


@pytest.fixture(scope="session")
def full_run(cfg, tmp_path_factory):
    """One complete clean Phase00->18 fixture run shared by many tests."""
    root = tmp_path_factory.mktemp("full_run")
    o, w = make_orchestrator(cfg, root, run_id="wc-full")
    res = o.run()
    return {"result": res, "dir": res.run_dir, "wiring": w, "orch": o}


def read_csv(p):
    import csv
    with open(p, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def read_jsonl(p):
    return [json.loads(x) for x in Path(p).read_text(encoding="utf-8").splitlines() if x]


# ---- gate ledger collection -------------------------------------------------------------------------------
_GATE_RESULTS: list = []


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    gates = [m.args[0] for m in item.iter_markers("gate")]
    if not gates:
        return
    if rep.when == "call" or (rep.when == "setup" and rep.outcome != "passed"):
        status = "SKIPPED" if rep.skipped else ("PASSED" if rep.passed else "FAILED")
        _GATE_RESULTS.append({"nodeid": item.nodeid, "gates": gates, "status": status,
                              "duration_s": round(rep.duration, 3)})


def pytest_sessionfinish(session, exitstatus):
    out = os.environ.get("F1_WC_GATE_REPORT")
    if out:
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        Path(out).write_text(json.dumps({"exitstatus": int(exitstatus), "results": _GATE_RESULTS}, indent=1))


# ---- Session-2 shared fixtures ------------------------------------------------------------------------------
@pytest.fixture(scope="session")
def real_deps():
    from f1.workload_c.deps.pins import BinaryMode, resolve
    return resolve(BinaryMode.REAL_PINNED_BINARY)          # raises (fails the dependent gates) if pins do not verify


@pytest.fixture(scope="session")
def s2_work(tmp_path_factory):
    return tmp_path_factory.mktemp("s2work")


@pytest.fixture(scope="session")
def real_producers(real_deps, s2_work):
    from f1.workload_c.campaign.s2 import make_producers
    from f1.workload_c.deps.pins import BinaryMode
    return make_producers(BinaryMode.REAL_PINNED_BINARY, s2_work / "real")


@pytest.fixture(scope="session")
def real_base_build(real_producers, s2_work):
    """One real OTP 2.10.0 build of the frozen 'base' fixture + Canon_D through the Session-2 code path."""
    from f1.workload_c.conformance.harness import FixtureBuilder
    spec, deps, blobs, otp, val, canon = real_producers
    b = FixtureBuilder(otp, canon, s2_work / "builds")
    job = b.build("base", "base_normal")
    return {"builder": b, "job": job, "digest": b.canon_digest(job)}


@pytest.fixture(scope="session")
def real_e2e(real_deps, tmp_path_factory):
    from f1.workload_c.campaign.e2e import run_fixture_e2e
    out = tmp_path_factory.mktemp("e2e_real") / "run"
    return run_fixture_e2e(out, "real")["summary"] | {"_dir": str(out)}
