"""Session-2 gates S2-07..S2-16, S2-24..S2-26, S2-45, S2-46 (dependencies, producers, Canon, semantic config)."""
import io
import json
import os
import subprocess
import sys
import zipfile
from datetime import date
from pathlib import Path

import pytest

from conftest import ROOT
from f1.workload_c.deps.pins import (BinaryMode, DependencyMissing, DigestMismatch, load_manifest, resolve, verify_all)
from f1.workload_c.errors import WCError
from f1.workload_c.producers.failure import FailureClass, classify_process, has_artifact
from f1.workload_c.producers.semconfig import resolve_service_bounds, semantic_config_digest

FROZEN_OTP = "8acd28081f859cfbb4a18a7979789fc02d472f229ce656167f3da5971eea7990"
FROZEN_VAL = "19293ddd9b6f954f216d4f12054bd8a3232921751c4484339e339764a91000e2"
BASE_FROZEN_CANON = "37a5b102317d5d41389fee0f217266b5888c1d8e52eb847c30b5fd3fb610497c"
FIX = ROOT / "frozen_specs/authoritative/conformance/fixtures/oracle"


# ---------------------------------------------------------------------------------------------- S2-07 / S2-08
@pytest.mark.gate("S2-07")
def test_pin_schema_exact_and_frozen_digests():
    m = load_manifest()
    pins = {a["name"]: a for a in m["artifacts"]}
    assert pins["otp"]["sha256"] == FROZEN_OTP and pins["otp"]["version"] == "2.10.0"
    assert pins["gtfs-validator"]["sha256"] == FROZEN_VAL and pins["gtfs-validator"]["version"] == "8.0.1"
    tools = {t["name"]: t for t in m["tools"]}
    assert tools["jdk"]["version"] == "25.0.4.1" and tools["osmium-tool"]["version"] == "1.16.0"
    for st in verify_all():
        for k in ("name", "version", "source", "expected_sha256", "actual_sha256", "license", "provenance", "status"):
            assert k in st.to_dict()
    bad = json.loads(json.dumps(m))
    bad["artifacts"][0]["version"] = "latest"
    with pytest.raises(WCError):
        load_manifest_obj(bad)
    bad2 = json.loads(json.dumps(m))
    bad2["artifacts"][0]["sha256"] = "abc"
    with pytest.raises(WCError):
        load_manifest_obj(bad2)


def load_manifest_obj(obj, tmp=Path("/tmp/f1wc_pin_test.json")):
    tmp.write_text(json.dumps(obj))
    return load_manifest(tmp)


@pytest.mark.gate("S2-07")
def test_all_pins_verified_in_this_environment():
    st = {s.name: s for s in verify_all()}
    assert st["otp"].status == "VERIFIED" and st["otp"].actual_sha256 == FROZEN_OTP
    assert st["gtfs-validator"].status == "VERIFIED" and st["gtfs-validator"].actual_sha256 == FROZEN_VAL
    assert st["jdk"].status == "VERIFIED_BY_VERSION" and "25.0.4.1" in st["jdk"].detail
    assert st["osmium-tool"].status == "VERIFIED_BY_VERSION" and st["faketime"].status == "VERIFIED_BY_VERSION"


@pytest.mark.gate("S2-08")
def test_digest_mismatch_refused_no_fallback(tmp_path):
    (tmp_path / "otp-shaded-2.10.0.jar").write_bytes(b"not the pinned jar")
    with pytest.raises(DigestMismatch):
        resolve(BinaryMode.REAL_PINNED_BINARY, store=tmp_path)
    with pytest.raises(DependencyMissing):
        resolve(BinaryMode.REAL_PINNED_BINARY, store=tmp_path / "empty")
    stub = resolve(BinaryMode.FIXTURE_STUB_BINARY, store=tmp_path)
    assert stub.otp_jar is None and stub.validator_jar is None          # stub mode never hands out "real" paths


@pytest.mark.gate("S2-08")
def test_fetch_script_rejects_wrong_bytes(tmp_path):
    mirror, dest = tmp_path / "mirror", tmp_path / "dest"
    mirror.mkdir()
    (mirror / "otp-shaded-2.10.0.jar").write_bytes(b"tampered")
    (mirror / "gtfs-validator-8.0.1-cli.jar").write_bytes(b"tampered too")
    cp = subprocess.run(["bash", str(ROOT / "scripts/fetch_pinned_dependencies.sh")], capture_output=True, text=True,
                        env={**os.environ, "F1_WC_DEPS_DIR": str(dest), "F1_WC_DEPS_MIRROR": str(mirror)})
    assert cp.returncode == 1 and "DIGEST_MISMATCH" in cp.stderr
    assert not list(dest.glob("*.jar")) and not list(dest.glob(".tmp-*"))


# ---------------------------------------------------------------------------------------------- validator
def _vreq(zp, slot="VAL:feed=f1", date_="2008-06-03"):
    from f1.workload_c.producers.validator import ValidatorRequest
    return ValidatorRequest(slot, "R:f1", "f1", "f1#L00001", "c" * 64, str(zp), date_, "US", "CUT:x", "FIXTURE")


def _stub_val(tmp_path, cfg, behavior="ok", timeout_s=86400):
    from f1.workload_c.producers.validator import GtfsValidatorProducer
    from f1.workload_c.storage.blobstore import BlobStore
    from f1.workload_c.timeutil import FixedTickClock
    return GtfsValidatorProducer(cfg.spec, resolve(BinaryMode.FIXTURE_STUB_BINARY), BlobStore(tmp_path / "s"),
                                 tmp_path / "j", FixedTickClock(), timeout_s=timeout_s, stub_behavior=behavior)


@pytest.mark.gate("S2-09")
def test_validator_command_exact_frozen_flags(real_producers, tmp_path, cfg):
    spec, deps, blobs, otp, val, canon = real_producers
    argv = val.command(_vreq("/x/feed.zip"), "/job/out")
    assert argv[0].endswith("/java") and argv[1] == "-Xmx4g" and "-jar" in argv
    assert argv[argv.index("-jar") + 1].endswith("gtfs-validator-8.0.1-cli.jar")
    tail = argv[argv.index("-jar") + 2:]
    assert tail == ["-i", "/x/feed.zip", "-o", "/job/out", "-d", "2008-06-03", "-c", "US", "-svu", "-t", "1"]
    s = _stub_val(tmp_path, cfg)
    sargv = s.command(_vreq("/x/feed.zip"), "/job/out")
    assert sargv[1].endswith("stub_gtfs_validator.py") and "--stub-behavior" in sargv
    assert s.producer_name.startswith("FIXTURE-STUB")


@pytest.mark.gate("S2-10")
@pytest.mark.gate("S2-46")
def test_real_validator_provenance(real_producers):
    spec, deps, blobs, otp, val, canon = real_producers
    o = val.produce(_vreq(FIX / "base/feedA.gtfs.zip"))
    p = o.provenance
    for k in ("producer", "binary_mode", "binary_sha256", "runtime_identity", "config_digest", "input_digests",
              "resource_envelope", "started_utc", "ended_utc", "wall_s", "cpu_s", "host", "stdout_sha256",
              "stderr_sha256", "result_digest", "argv_digest", "failure_class"):
        assert k in p
    assert p["producer"] == "gtfs-validator 8.0.1" and p["binary_mode"] == "REAL_PINNED_BINARY"
    assert p["binary_sha256"] == FROZEN_VAL and "25.0.4.1" in p["runtime_identity"]["jdk"]
    assert p["extra"]["network_isolated"] is True and p["wall_s"] > 0
    r = o.val_report
    for k in ("birth_cut_id", "logical_version_id", "consumer_date", "validator_sha256", "country", "report_digest"):
        assert r[k]
    assert blobs.get(r["report_digest"]) and blobs.get(r["raw_report_sha256"])


@pytest.mark.gate("S2-11")
def test_real_validator_semantic_gate(real_producers, tmp_path):
    spec, deps, blobs, otp, val, canon = real_producers
    o = val.produce(_vreq(FIX / "base/feedA.gtfs.zip"))          # frozen fixture has invalid_row_length ERRORs
    assert o.failure_class == "SEMANTIC_FAIL" and o.val_gate["gate"] == "FAIL" and o.val_report["n_error_notices"] > 0
    from f1.workload_c.fixturegen.gtfs_gen import FeedContent, FStop, build_zip
    good = FeedContent("G", (("A1", "Agency G", "America/Los_Angeles"),),
                       (FStop("s1", 37.77, -122.42), FStop("s2", 37.78, -122.41), FStop("s3", 37.79, -122.40)),
                       service_start="20080101", service_end="20081231")
    zp = tmp_path / "good.zip"
    src = zipfile.ZipFile(io.BytesIO(build_zip(good)))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:          # the real validator rejects '.invalid' TLD URLs (invalid_url ERROR)
        for n in src.namelist():
            z.writestr(n, src.read(n).replace(b".example.invalid", b".example.org"))
    zp.write_bytes(buf.getvalue())
    g = val.produce(_vreq(zp, date_="2008-06-03"))
    assert g.failure_class == "SUCCESS" and g.val_gate["gate"] == "PASS"
    sev = {n["severity"] for n in json.loads(blobs.get(g.val_report["report_digest"]))["notices"]}
    assert "ERROR" not in sev and "WARNING" in sev                # WARNING-only feed passes the gate
    again = val.produce(_vreq(zp, date_="2008-06-03"))
    assert again.val_report["report_digest"] == g.val_report["report_digest"]   # semantic report is deterministic


@pytest.mark.gate("S2-11")
def test_stub_validator_semantics(tmp_path, cfg):
    from f1.workload_c.fixturegen.gtfs_gen import FeedContent, FStop, build_zip
    c = FeedContent("T", (("A", "A", "UTC"),), (FStop("s", 1, 1), FStop("t", 1.001, 1)))
    s = _stub_val(tmp_path, cfg)
    zp = tmp_path / "ok.zip"
    zp.write_bytes(build_zip(c))
    assert s.produce(_vreq(zp)).val_gate["gate"] == "PASS"
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z, zipfile.ZipFile(zp) as src:
        for n in src.namelist():
            if n != "stops.txt":
                z.writestr(n, src.read(n))
    zp2 = tmp_path / "missing.zip"
    zp2.write_bytes(buf.getvalue())
    o = s.produce(_vreq(zp2))
    assert o.failure_class == "SEMANTIC_FAIL" and o.val_gate["gate"] == "FAIL"


@pytest.mark.gate("S2-12")
@pytest.mark.gate("S2-45")
@pytest.mark.parametrize("behavior,timeout,expect", [("nonzero", 600, "INFRA_ERROR"), ("corrupt", 600, "INFRA_ERROR"),
                                                     ("timeout", 2, "TIMEOUT"), ("oom", 600, "RESOURCE_FAILURE")])
def test_validator_infra_classification(tmp_path, cfg, behavior, timeout, expect):
    from f1.workload_c.fixturegen.gtfs_gen import FeedContent, FStop, build_zip
    zp = tmp_path / "f.zip"
    zp.write_bytes(build_zip(FeedContent("T", (("A", "A", "UTC"),), (FStop("s", 1, 1),))))
    o = _stub_val(tmp_path, cfg, behavior, timeout).produce(_vreq(zp))
    assert o.failure_class == expect and o.val_report is None and o.val_gate is None     # never a semantic FAIL


@pytest.mark.gate("S2-12")
def test_malformed_input_is_invalid_input_without_invocation(tmp_path, cfg):
    zp = tmp_path / "bad.zip"
    zp.write_bytes(b"not a zip")
    o = _stub_val(tmp_path, cfg).produce(_vreq(zp))
    assert o.failure_class == "INVALID_INPUT" and o.provenance["extra"]["rc"] is None


@pytest.mark.gate("S2-12")
@pytest.mark.gate("S2-45")
def test_real_cgroup_memory_kill_is_resource_failure(tmp_path):
    """Real kernel enforcement (cgroup v1 memory limit) kills an over-allocating process -> RESOURCE_FAILURE."""
    from f1.workload_c.producers.process import base_env, run_process
    from f1.workload_c.resources.manager import ResourceManager, detect_capabilities, sandbox_envelope
    mgr = ResourceManager(detect_capabilities(probe_systemd=False))
    env = sandbox_envelope(memory="64M")
    with mgr.select().open(env, f"memkill{os.getpid()}") as sc:
        pr = run_process([sys.executable, "-c", "b = bytearray(512*1024*1024); print(len(b))"], tmp_path,
                         env=base_env(tmp_path), wrappers=[sc.wrapper], timeout_s=120)
    assert pr.failure_class == "RESOURCE_FAILURE" and pr.signal == 9


@pytest.mark.gate("S2-45")
def test_failure_class_table():
    assert classify_process(0, False, None, False) == FailureClass.SUCCESS
    assert classify_process(1, False, None, False) == FailureClass.INFRA_ERROR
    assert classify_process(None, True, 9, False) == FailureClass.TIMEOUT
    assert classify_process(None, False, 9, True) == FailureClass.RESOURCE_FAILURE
    assert has_artifact(FailureClass.SEMANTIC_FAIL) and not has_artifact(FailureClass.TIMEOUT)
    from f1.workload_c.producers.failure import EXCLUDED_FROM_PRIMARY, INFRASTRUCTURE
    assert FailureClass.TIMEOUT in EXCLUDED_FROM_PRIMARY and FailureClass.SEMANTIC_FAIL not in INFRASTRUCTURE
    from f1.workload_c.producers.process import OPERATIONAL_CAP_S
    assert OPERATIONAL_CAP_S == 24 * 3600


@pytest.mark.gate("S2-46")
def test_producer_env_never_carries_credentials(tmp_path):
    from f1.workload_c.producers.process import ProducerInvocationError, base_env
    e = base_env(tmp_path)
    assert set(e) == {"PATH", "LANG", "LC_ALL", "TZ", "HOME"} and e["TZ"] == "UTC"
    for bad in ({"MOBILITY_DB_TOKEN": "x"}, {"AWS_SECRET": "y"}, {"FOO": "z"}):
        with pytest.raises(ProducerInvocationError):
            base_env(tmp_path, bad)


# ---------------------------------------------------------------------------------------------- OTP
def _otp_req(tmp_path, build_date="2008-06-01", feeds=None, start=None, end=None):
    from f1.workload_c.producers.otp import OtpFeedInput, OtpRequest
    feeds = feeds or (OtpFeedInput("B", "B#L1", "b" * 64, str(FIX / "d6a/fb.zip")),
                      OtpFeedInput("A", "A#L1", "a" * 64, str(FIX / "d6a/fa.zip")))
    return OtpRequest("ROUTER:region=R:A+B", "R:A+B", tuple(feeds), str(FIX / "base/street.osm.pbf"),
                      "America/Los_Angeles", build_date, ("2008-06-03", "2008-06-04"), "CUT:y", "FIXTURE", start, end)


@pytest.mark.gate("S2-13")
def test_otp_command_and_build_config(cfg, tmp_path, real_producers):
    from f1.workload_c.producers.otp import build_config_for
    from f1.workload_c.resources.manager import otp_authoritative_envelope
    spec, deps, blobs, otp, val, canon = real_producers
    c, files = build_config_for(_otp_req(tmp_path))
    assert c["transitServiceStart"] == "2007-06-01" and c["transitServiceEnd"] == "2011-06-01"
    assert [f["feedId"] for f in c["transitFeeds"]] == ["A", "B"] and c["osm"] == [{"source": "street.osm.pbf"}]
    assert c["transitModelTimeZone"] == "America/Los_Angeles" and set(files) == {"feed00.gtfs.zip", "feed01.gtfs.zip",
                                                                                   "street.osm.pbf"}
    env = otp_authoritative_envelope(cfg.spec)
    assert list(env.jvm_flags) == ["-XX:ActiveProcessorCount=8", "-Xms24g", "-Xmx24g", "-XX:+UseG1GC",
                                   "-Duser.timezone=UTC"]
    assert env.memory_max_bytes == 32 * 1024 ** 3 and env.cpu_quota_us == 800000 and env.cpu_period_us == 100000
    old = otp.envelope
    otp.envelope = env
    try:
        cmds = otp.commands(tmp_path)
    finally:
        otp.envelope = old
    assert cmds[0][1:7] == list(env.jvm_flags) + [f"-Djava.io.tmpdir={tmp_path / 'tmp'}"]
    assert cmds[0][-2:] == ["--buildStreet", str(tmp_path / "graph")]
    assert cmds[1][-3:] == ["--loadStreet", "--save", str(tmp_path / "graph")]
    with pytest.raises(ValueError):
        otp_authoritative_envelope(cfg.spec, cpuset="0-3")          # no selective resizing


@pytest.mark.gate("S2-14")
def test_historical_service_bounds_resolution():
    assert resolve_service_bounds(date(2008, 6, 1)) == ("2007-06-01", "2011-06-01")
    assert resolve_service_bounds(date(2024, 2, 29)) == ("2023-02-28", "2027-02-28")
    assert resolve_service_bounds(date(2025, 4, 1), "-P2W", "P10D") == ("2025-03-18", "2025-04-11")
    assert resolve_service_bounds(date(2025, 4, 1), "2025-01-01", "2026-01-01") == ("2025-01-01", "2026-01-01")
    rel = {"transitServiceStart": "-P1Y", "transitServiceEnd": "P3Y", "transitModelTimeZone": "UTC",
           "transitFeeds": [], "osm": []}
    absolute = dict(rel, transitServiceStart="2007-06-01", transitServiceEnd="2011-06-01")
    assert semantic_config_digest(rel, date(2008, 6, 1)) == semantic_config_digest(absolute, date(2008, 6, 1))
    assert semantic_config_digest(rel, date(2008, 6, 1)) != semantic_config_digest(rel, date(2009, 6, 1))


@pytest.mark.gate("S2-15")
def test_config_generation_independent_of_wall_clock_and_env(tmp_path, monkeypatch):
    from f1.workload_c.producers.otp import build_config_for
    a = build_config_for(_otp_req(tmp_path))[0]
    monkeypatch.setenv("TZ", "Asia/Tokyo")
    import time
    time.tzset()
    b = build_config_for(_otp_req(tmp_path))[0]
    monkeypatch.delenv("TZ")
    time.tzset()
    assert a == b
    code = ("import sys,json; sys.path.insert(0, %r); from f1.workload_c.producers.otp import build_config_for, OtpRequest, "
            "OtpFeedInput; print(json.dumps(build_config_for(OtpRequest('s','r',(OtpFeedInput('A','A#L1','a'*64,'x'),),'o',"
            "'UTC','2008-06-01',('2008-06-03',),'c','FIXTURE'))[0], sort_keys=True))") % str(ROOT / "src")
    outs = {subprocess.run(["faketime", fake, sys.executable, "-c", code], capture_output=True, text=True).stdout
            for fake in ("2031-03-15 04:00:00", "1999-12-31 23:59:59")}
    assert len(outs) == 1 and "2007-06-01" in outs.pop()


@pytest.mark.gate("S2-15")
@pytest.mark.gate("S2-24")
def test_real_build_under_faketime_has_identical_canon(real_base_build):
    b = real_base_build["builder"]
    fake = b.build("base", "base_faketime", extra_wrappers=[["faketime", "2031-03-15 04:00:00"]])
    assert b.canon_digest(fake) == real_base_build["digest"] == BASE_FROZEN_CANON


@pytest.mark.gate("S2-16")
@pytest.mark.gate("S2-46")
def test_real_otp_router_artifact_provenance(real_producers, tmp_path):
    spec, deps, blobs, otp, val, canon = real_producers
    o = otp.produce(_otp_req(tmp_path))
    assert o.failure_class == "SUCCESS", o.provenance
    r = o.router
    for k in ("artifact_id", "birth_cut_id", "gtfs_logical_versions", "osm_sha256", "otp_sha256", "jdk",
              "semantic_config_digest", "horizon_D", "graph_sha256", "canon_digest", "producer_start", "producer_end",
              "status", "service_window"):
        assert r[k]
    assert r["otp_sha256"] == FROZEN_OTP and r["binary_mode"] == "REAL_PINNED_BINARY"
    assert r["service_window"] == ["2007-06-01", "2011-06-01"] and r["canon_schema"] == "F1-OTP-CANON-1.3"
    assert o.provenance["extra"]["network_isolated"] is True
    assert o.provenance["resource_envelope"]["authoritative"] is False      # sandbox envelope is labelled as such


@pytest.mark.gate("S2-16")
def test_otp_stub_infra_outcomes(cfg, tmp_path):
    from f1.workload_c.campaign.s2 import make_producers
    for beh, exp in (("nonzero", "INFRA_ERROR"), ("oom", "RESOURCE_FAILURE")):
        _, _, _, otp, _, _ = make_producers(BinaryMode.FIXTURE_STUB_BINARY, tmp_path / beh, stub_behavior=beh)
        o = otp.produce(_otp_req(tmp_path))
        assert o.failure_class == exp and o.router is None
    _, _, _, otp, _, _ = make_producers(BinaryMode.FIXTURE_STUB_BINARY, tmp_path / "ok")
    o = otp.produce(_otp_req(tmp_path))
    assert o.router["binary_mode"] == "FIXTURE_STUB_BINARY" and o.router["canon_schema"].endswith("FIXTURE-STUB")


# ---------------------------------------------------------------------------------------------- Canon
@pytest.mark.gate("S2-24")
def test_canon_frozen_source_bound_and_digest_matches_frozen_record(real_base_build, real_producers, tmp_path, cfg):
    assert real_base_build["digest"] == BASE_FROZEN_CANON
    spec, deps, blobs, otp, val, canon = real_producers
    assert canon.source_sha == cfg.spec["sources"]["CANON06"]["sha256"]
    import dataclasses
    from f1.workload_c.producers.canon import CanonError, CanonRunner
    raw = json.loads(json.dumps(cfg.spec.raw))
    raw["sources"]["CANON06"]["sha256"] = "0" * 64
    with pytest.raises(CanonError):
        CanonRunner(dataclasses.replace(cfg.spec, raw=raw), deps, tmp_path, None)
    job = real_base_build["job"]
    r1 = canon.run(job / "graph/graph.obj", ["2008-06-03"], "c" * 64, "o" * 64, FROZEN_OTP, "x", tmp_path / "c1")
    r2 = canon.run(job / "graph/graph.obj", ["2008-06-03"], "c" * 64, "o" * 64, FROZEN_OTP, "x", tmp_path / "c2")
    assert r1.status == "OK" and r1.digest == r2.digest and r1.digest.sha256 != BASE_FROZEN_CANON  # header-bound
    bad = canon.run(tmp_path / "missing.obj", ["2008-06-03"], "c", "o", FROZEN_OTP, "x", tmp_path / "c3")
    assert bad.status == "ERROR" and bad.digest is None


@pytest.mark.gate("S2-25")
def test_live_oracle_subset_through_integrated_path(real_base_build, tmp_path):
    from f1.workload_c.conformance.harness import oracle_suite
    rows = oracle_suite(real_base_build["builder"], tmp_path / "o.csv", only={"O5", "O13", "ORA2"})
    assert [r["result"] for r in rows] == ["PASS"] * 3 and all(r["matches_frozen_record"] == "True" for r in rows)


@pytest.mark.gate("S2-25")
def test_full_oracle_suite_evidence():
    """The full 35-comparison suite is executed by scripts/run_oracle_conformance.sh (real OTP builds, ~7 min) in the
    same test run (scripts/run_tests.sh runs it first); this gate verifies that evidence."""
    import csv
    p = Path(os.environ.get("F1_WC_CONFORMANCE_DIR", ROOT / "reports" / "conformance")) / "oracle_results.csv"
    rows = list(csv.DictReader(open(p)))
    assert len(rows) == 35 and all(r["result"] == "PASS" for r in rows)
    assert all(r["matches_frozen_record"] == "True" for r in rows)
    exp = list(csv.DictReader(open(ROOT / "frozen_specs/authoritative/conformance/expected/oracle_expected.csv")))
    assert [r["test"] for r in rows] == [r["test"] for r in exp]


@pytest.mark.gate("S2-26")
def test_semantic_config_frozen_c_suite_and_invariances(tmp_path):
    from f1.workload_c.conformance.harness import config_suite
    from f1.workload_c.producers.semconfig import UnclassifiedConfigKey
    rows = config_suite(tmp_path / "c.csv")
    assert len(rows) == 8 and all(r["result"] == "PASS" for r in rows)
    base = {"transitServiceStart": "2008-06-01", "transitServiceEnd": "2008-06-30", "transitModelTimeZone": "UTC",
            "transitFeeds": [{"type": "gtfs", "feedId": "A", "source": "/tmp/a/x.zip"},
                             {"type": "gtfs", "feedId": "B", "source": "b.zip"}], "osm": [{"source": "s.pbf"}]}
    d = date(2008, 6, 1)
    h = semantic_config_digest(base, d)
    moved = json.loads(json.dumps(base))
    moved["transitFeeds"][0]["source"] = "https://example.invalid/other/path.zip"
    moved["transitFeeds"].reverse()
    moved["cache"] = {"enabled": True}
    moved["buildReportDir"] = "/var/tmp/r"
    assert semantic_config_digest(moved, d) == h                       # locators, ordering, cache, report dir
    for key, val in (("transitModelTimeZone", "Europe/Paris"), ("maxTransferDuration", "PT1H"),
                     ("transitServiceEnd", "2008-07-30")):
        assert semantic_config_digest(dict(base, **{key: val}), d) != h
    with pytest.raises(UnclassifiedConfigKey):
        semantic_config_digest(dict(base, someNewKey=1), d)
