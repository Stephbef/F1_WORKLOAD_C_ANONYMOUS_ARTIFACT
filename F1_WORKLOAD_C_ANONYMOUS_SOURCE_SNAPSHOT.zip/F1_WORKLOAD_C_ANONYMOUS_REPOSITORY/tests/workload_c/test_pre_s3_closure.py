"""PRE-S3 scientific closure gates P3-01..P3-12 (decisions frozen before any study outcome)."""
import csv
import hashlib
import json
import re
import subprocess

import pytest

from conftest import ROOT
from f1.workload_c.config.runtime import load_interpretations, load_license_table
from f1.workload_c.errors import NamespaceViolation, SpecValidationError

PRE = ROOT / "docs" / "pre_s3"


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


@pytest.mark.gate("P3-01")
def test_input_identity_recorded():
    ident = json.loads((PRE / "PRE_S3_INPUT_IDENTITY.json").read_text())
    assert ident["input_zip_sha256"] == "f54171a60707cedc04df9de974f3be86f71dc22ecf72e55678efba005b511e8b"
    assert ident["s2_head"] == "f1e9368c4f802f478f7f41e8d730d039e6262abb" and ident["clone_matches_source_manifest"]
    if (ROOT / ".git").exists() and not (ROOT / "ANONYMIZED_REVIEW_ARTIFACT").exists():
        r = subprocess.run(["git", "merge-base", "--is-ancestor", ident["s2_head"], "HEAD"], cwd=ROOT)
        assert r.returncode == 0
        tree = subprocess.run(["git", "rev-parse", ident["s2_head"] + "^{tree}"], cwd=ROOT, capture_output=True, text=True)
        assert tree.stdout.strip() == ident["s2_tree"]


EXPECTED = {"in_force_instant_utc": "2025-04-01T00:00:00Z", "history_window_start_utc": "2025-04-01T00:00:00Z",
            "history_window_end_exclusive_utc": "2026-07-01T00:00:00Z", "history_gap_basis": "archive_observations",
            "history_requires_observation_at_or_before_start": True, "megabyte_bytes": 1000000,
            "earth_radius_m": 6371008.8, "distance_comparison": "inclusive",
            "stop_rows_used": "boarding_points_location_type_blank_or_0", "bbox_source": "latest_logical_version_stops",
            "agency_identity": "exact_agency_id", "merged_bundle_measure": "overlap_coefficient_drop_strictly_larger_agency_set",
            "merged_bundle_equal_cardinality": "keep_both", "dedup_survivor": "smallest_feed_id",
            "url_normalization": "lowercase_scheme_host_drop_default_port_drop_trailing_slash",
            "alias_key": "normalized_provider_and_feed_name", "source_locator_failure": "exclude_feed_archive_unretrievable",
            "feed_timezone_rule": "unique_agency_timezone_else_undefined", "otp_newer_than": "last_successful_build"}


@pytest.mark.gate("P3-02")
def test_register_frozen_and_consistent(tmp_path):
    reg = load_interpretations()
    assert reg.confirmed and reg.raw["frozen_before_outcomes"] is True
    for k, v in EXPECTED.items():
        assert reg.p[k] == v, k
    ids = [i["id"] for i in reg.raw["items"]]
    assert ids == [f"INT-{k:02d}" for k in range(1, 11)] + ["SCH-01"]
    assert all(i["status"] == "FROZEN_PRE_S3" and "alternatives" not in i for i in reg.raw["items"])
    raw = json.loads((ROOT / "configs/workload_c/spec_interpretations.json").read_text())
    for key, val in (("megabyte_bytes", 1048576), ("history_gap_basis", "logical_versions"),
                     ("otp_newer_than", "last_completed_build"), ("in_force_instant_utc", "2025-04-01T23:59:59Z")):
        bad = json.loads(json.dumps(raw))
        bad["parameters"][key] = val
        p = tmp_path / f"{key}.json"
        p.write_text(json.dumps(bad))
        with pytest.raises(SpecValidationError):
            load_interpretations(p)
    stale = json.loads(json.dumps(raw))
    stale["items"][0]["status"] = "UNRESOLVED_SCIENTIFIC_SPEC"
    (tmp_path / "s.json").write_text(json.dumps(stale))
    with pytest.raises(SpecValidationError):
        load_interpretations(tmp_path / "s.json")


@pytest.mark.gate("P3-03")
def test_licence_table_audited_and_frozen(cfg):
    from f1.workload_c.licensing.engine import LicenseEngine, LicenseEvidence
    t = load_license_table()
    assert t.raw["status"] == "PI_CONFIRMED" and "audit" in t.raw
    expected = {"cc0-1.0": "A", "pddl-1.0": "A", "cc-by-4.0": "A+C", "cc-by-3.0": "A+C", "cc-by-sa-4.0": "A+C",
                "odbl-1.0": "A+C", "ogl-uk-3.0": "A+C", "etalab-2.0": "A+C", "research-use-only": "B",
                "no-redistribution-research-permitted": "B+C", "cc-by-nd-4.0": "B+C", "login-only-terms": "E",
                "no-derivatives-no-research": "E", "proprietary-prohibits-research": "E"}
    eng = LicenseEngine(cfg.spec, t)
    got = {lid: eng.classify(LicenseEvidence("f", None, lid, "audit")).license_class for lid in t.raw["identifiers"]}
    assert got == expected
    for unknown in ("cc-by-nc-4.0", "gpl-3.0", "custom-terms", "mit"):
        d = eng.classify(LicenseEvidence("f", None, unknown, "audit"))
        assert d.classification == "UNCLEAR" and not d.eligible            # fail closed
    assert sha(ROOT / "configs/workload_c/license_identifier_table.json") == \
        json.loads((PRE / "PRE_S3_FROZEN_DIGESTS.json").read_text())["license_identifier_table_sha256"]


@pytest.mark.gate("P3-04")
def test_sch01_frozen_everywhere():
    import inspect
    from f1.workload_c.scheduler import workload_c as W
    assert load_interpretations().p["otp_newer_than"] == W.FROZEN_OTP_NEWER_THAN == "last_successful_build"
    assert inspect.signature(W.simulate).parameters["otp_newer_than"].default == "last_successful_build"
    assert "otp_newer_than" not in (ROOT / "src/f1/workload_c/campaign/e2e.py").read_text()   # e2e uses the default


def A(t):
    from f1.workload_c.ingestion.gtfs import ArchiveRecord
    return ArchiveRecord("FIXTURE", "f", t, {}, t, "", "r", "h", 1, {}, {})


@pytest.mark.gate("P3-05")
def test_int02_boundary_gaps(cfg):
    from f1.workload_c.regions.eligibility import history_check
    from f1.workload_c.timeutil import epoch, from_epoch
    start, end = epoch("2025-04-01T00:00:00Z"), epoch("2026-07-01T00:00:00Z")
    pts = [A("2025-04-01T00:00:00Z")]
    t = start
    while t + 30 * 86400 < end:
        t += 30 * 86400
        pts.append(A(from_epoch(t)))
    assert history_check(cfg, pts, [])[0]                                   # last -> end gap <= 30 d
    late = [A("2025-04-01T00:00:00Z"), A(from_epoch(start + 30 * 86400 + 1))]
    assert history_check(cfg, late, [])[1] == "HISTORY_GAP_EXCEEDED"       # start -> first boundary gap
    tail = [A(from_epoch(end - 30 * 86400 - 1 - k * 20 * 86400)) for k in range(25)] + [A("2025-03-30T00:00:00Z")]
    assert history_check(cfg, tail, [])[1] == "HISTORY_GAP_EXCEEDED"       # last -> end boundary gap
    assert history_check(cfg, [A("2025-04-01T00:00:01Z")], [])[1] == "HISTORY_INSUFFICIENT_START"


@pytest.mark.gate("P3-06")
def test_int06_equal_cardinality_keeps_both():
    from f1.workload_c.ingestion.gtfs import GtfsSummary, Stop
    from f1.workload_c.regions.dedup import deduplicate
    from f1.workload_c.regions.model import FeedFacts, FeedRecord

    def f(fid, ids):
        x = FeedFacts(fid, latest_canonical_sha256=fid)
        x.latest_summary = GtfsSummary([Stop("s", 0, 0)], ["UTC"] * len(ids), ["n"] * len(ids), agency_ids=ids)
        return x
    R = {k: FeedRecord(k, True, (), "active", 0, f"https://{k}", f"P{k}", f"N{k}", (), None, None) for k in ("a", "b")}
    d = deduplicate(R, {"a": f("a", ["X", "Y"]), "b": f("b", ["X", "Z"])}, ["a", "b"], 0.5)
    assert d["a"].kept and d["b"].kept


@pytest.mark.gate("P3-07")
def test_no_stale_unresolved_claims():
    current = [ROOT / "SCIENTIFIC_SPEC_BLOCKER.md", ROOT / "docs/INT01_INT10_RESOLUTION_AUDIT.md", ROOT / "docs/SCHEDULER.md",
               ROOT / "configs/workload_c/spec_interpretations.json", ROOT / "configs/workload_c/license_identifier_table.json"]
    current += sorted(PRE.glob("*.md")) + sorted(PRE.glob("*.txt"))
    for p in current:
        txt = p.read_text()
        assert "UNRESOLVED_SCIENTIFIC_SPEC" not in txt.replace("UNRESOLVED_SCIENTIFIC_SPEC statuses", ""), p
        assert '"status": "UNCONFIRMED"' not in txt, p
        assert not re.search(r"default\W+last_completed_build", txt), p
    src = "".join(p.read_text() for p in (ROOT / "src/f1/workload_c").rglob("*.py"))
    assert "UNRESOLVED, flagged" not in src


@pytest.mark.gate("P3-08")
def test_firewall_machine_checks():
    from f1.workload_c.security.firewall import (ChangeClass, ChangeRecord, FirewallViolation, Stage, check_change,
                                                 check_namespace_read)
    with pytest.raises(FirewallViolation):
        check_change(ChangeRecord(ChangeClass.R1, Stage.IMPLEMENTATION))
    with pytest.raises(FirewallViolation):
        check_change(ChangeRecord(ChangeClass.E1, Stage.VALIDATION_OPEN, issue_id="I1", failing_test="t",
                                  regression_test="r", motivated_by_comparative_result=True))
    with pytest.raises(FirewallViolation):
        check_change(ChangeRecord(ChangeClass.S1, Stage.POST_VALIDATION))
    with pytest.raises(FirewallViolation):
        check_change(ChangeRecord(ChangeClass.S1, Stage.CAMPAIGN, formal_amendment="A1"))
    with pytest.raises(FirewallViolation):
        check_change(ChangeRecord(ChangeClass.E1, Stage.VALIDATION_OPEN))            # no failing/regression test
    check_change(ChangeRecord(ChangeClass.E1, Stage.VALIDATION_OPEN, "I1", "t_fail", "t_reg"))
    check_change(ChangeRecord(ChangeClass.S1, Stage.IMPLEMENTATION))                 # before validation access only
    with pytest.raises(FirewallViolation):            # V1.1: amendment alone is insufficient (restart evidence required)
        check_change(ChangeRecord(ChangeClass.S1, Stage.POST_VALIDATION, formal_amendment="AMEND-1"))
    check_change(ChangeRecord(ChangeClass.S1, Stage.POST_VALIDATION, formal_amendment="AMEND-1",
                              restart_from_clean_freeze=True, restart_evidence_id="FREEZE-2"))
    check_namespace_read("FIXTURE", Stage.IMPLEMENTATION)
    for ns, st, kw in (("VALIDATION", Stage.IMPLEMENTATION, {}), ("VALIDATION", Stage.VALIDATION_OPEN, {}),
                       ("TEST", Stage.POST_VALIDATION, {"campaign_certificate_verified": True}),
                       ("TEST", Stage.CAMPAIGN, {}), ("PROD", Stage.CAMPAIGN, {})):
        with pytest.raises(NamespaceViolation):
            check_namespace_read(ns, st, **kw)
    check_namespace_read("VALIDATION", Stage.VALIDATION_OPEN, validation_gate_open=True)
    check_namespace_read("TEST", Stage.CAMPAIGN, campaign_certificate_verified=True)


@pytest.mark.gate("P3-09")
def test_s3_gate_ledger_frozen():
    rows = list(csv.DictReader(open(PRE / "14_SESSION3_ACCEPTANCE_GATES.csv")))
    assert [r["gate"] for r in rows] == [f"S3-{k:02d}" for k in range(1, 57)]
    assert all(r["requirement"] and r["evidence_type"] in ("test", "command", "ledger") for r in rows)
    assert all(r["status_now"] == "NOT_YET_IMPLEMENTED" for r in rows)
    md = (PRE / "15_SESSION3_ACCEPTANCE_GATES.md").read_text()
    assert all(f"| {r['gate']} |" in md for r in rows)
    prompt = (PRE / "17_S3_ULTIMATE_IMPLEMENTATION_PROMPT.txt").read_text()
    assert all(r["gate"] in prompt for r in rows)


@pytest.mark.gate("P3-10")
def test_session3_interfaces_v11_frozen_and_unimplemented():
    """V1.1: the frozen interface file is the joint-request version; all ten protocols present; nothing implemented."""
    import typing
    from f1.workload_c.interfaces import session3 as S
    dig = json.loads((PRE / "PRE_S3_FROZEN_DIGESTS.json").read_text())
    assert sha(ROOT / "src/f1/workload_c/interfaces/session3.py") == dig["session3_interfaces_sha256"]
    assert S.INTERFACE_VERSION == dig["session3_interface_version"] == "F1-WC-S3-INTERFACES-V1.2"
    assert set(S.SESSION3_INTERFACES) == {"WitnessSearch", "AdmissionEngine", "RepairEngine", "CostModel", "N1Baseline",
                                          "N5Baseline", "ReplayEngine", "MutationEngine", "StatisticsExporter",
                                          "FrozenAnalysis"}
    for name in S.SESSION3_INTERFACES:
        assert getattr(getattr(S, name), "_is_protocol", False), name
    assert "request_slots" in typing.get_type_hints(S.ConsumerRequest)                    # joint request
    assert typing.get_type_hints(S.JointWitness)["bindings"] == tuple[S.WitnessBinding, ...]
    assert "mode" in typing.get_type_hints(S.AdmissionDecision) and "repair" in typing.get_type_hints(S.AdmissionDecision)
    assert typing.get_type_hints(S.N5Baseline.decide)["view"] is S.RequestBinding
    assert typing.get_type_hints(S.N1Baseline.decide)["view"] is S.N1CurrentView
    assert "tick_utc" in typing.get_type_hints(S.CostModel.estimate_rederive)
    import pkgutil
    import f1.workload_c as wc
    marker = ROOT / "configs/workload_c/session_phase.json"
    phase = json.loads(marker.read_text())["phase"] if marker.exists() else "PRE_S3"
    if phase == "PRE_S3":
        mods = {m.name for m in pkgutil.walk_packages(wc.__path__, "f1.workload_c.")}
        impl = [m for m in mods if any(x in m for x in ("admission", "witness", "repair", "baselines", "replay",
                                                        "mutation", "analysis", "exporter"))]
        assert impl == []                                                    # Session-3 engines not implemented here
    else:                                                                    # Session 3+: engines conform to protocols
        assert phase == "S3"
        from f1.workload_c.engines import baselines_n, core, f1, mutation, replay, stats
        impls = {"WitnessSearch": f1.WitnessSearchImpl(), "AdmissionEngine": f1.AdmissionEngineImpl(),
                 "RepairEngine": f1.RepairEngineImpl(), "CostModel": core.CostModelImpl(),
                 "N5Baseline": baselines_n.N5BaselineImpl(), "N1Baseline": baselines_n.N1BaselineImpl(),
                 "ReplayEngine": replay.ReplayEngineImpl(frozenset()),
                 "MutationEngine": mutation.MutationEngineImpl(mutation.MutationSubjectStore({}, {})),
                 "StatisticsExporter": stats.StatisticsExporterImpl(), "FrozenAnalysis": stats.FrozenAnalysisImpl()}
        for name in S.SESSION3_INTERFACES:
            assert isinstance(impls[name], getattr(S, name)), name


@pytest.mark.gate("P3-11")
def test_no_study_data_or_results():
    hits = []
    for p in ROOT.rglob("*"):
        if ".git" in p.parts or ".deps" in p.parts or not p.is_file() or p.suffix not in (".csv", ".json", ".jsonl", ".md", ".txt"):
            continue
        t = p.read_text(errors="ignore")
        if re.search(r"HSR_(witness|repair)\s*[=:]\s*[0-9]", t) or re.search(r"Delta(E2E|Cost)_history\s*[=:]\s*-?[0-9]", t):
            hits.append(str(p))
    assert hits == []
    assert not list(ROOT.glob("**/TEST/**/*.json"))


@pytest.mark.gate("P3-12")
def test_frozen_digests_match(cfg):
    dig = json.loads((PRE / "PRE_S3_FROZEN_DIGESTS.json").read_text())
    assert sha(ROOT / "configs/workload_c/spec_interpretations.json") == dig["spec_interpretations_sha256"]
    assert sha(ROOT / "configs/workload_c/pinned_dependencies.json") == dig["pinned_dependencies_sha256"]
    assert sha(ROOT / "frozen_specs/FROZEN_SPECS_SHA256.txt") == dig["frozen_specs_manifest_sha256"]
    assert sha(PRE / "14_SESSION3_ACCEPTANCE_GATES.csv") == dig["s3_gates_csv_sha256"]
    assert cfg.spec.digest == dig["protocol_spec_digest"] and cfg.interp.digest == dig["interpretations_digest"]
    assert cfg.digest == dig["fixture_effective_config_digest"]
