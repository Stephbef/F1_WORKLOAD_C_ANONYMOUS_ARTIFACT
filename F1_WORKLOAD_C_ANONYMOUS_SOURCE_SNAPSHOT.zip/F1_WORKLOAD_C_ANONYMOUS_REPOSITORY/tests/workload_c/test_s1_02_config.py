import copy
import json

import pytest

from conftest import ROOT
from f1.workload_c.config.runtime import load_effective_config, validate_runtime, load_interpretations
from f1.workload_c.config.spec import load_protocol_spec, validate_protocol_spec
from f1.workload_c.errors import SpecValidationError

SPEC_PATH = ROOT / "frozen_specs/derived/workload_c_protocol_spec.json"


def raw():
    return json.loads(SPEC_PATH.read_text(encoding="utf-8"))


@pytest.mark.gate("S1-02")
def test_spec_loads_with_frozen_values(spec):
    assert spec["history"] == {"window_start": "2025-04-01", "window_end_inclusive": "2026-06-30", "max_gap_days": 30,
                               "source": "SPEC17 §3 feed eligibility"}
    assert spec["feed_eligibility"]["max_bbox_diagonal_km"] == 500
    assert spec["connectivity"]["min_stop_pairs"] == 3 and spec["connectivity"]["stop_pair_max_distance_m"] == 400
    assert spec["connectivity"]["hull_max_distance_m"] == 2000
    assert (spec["region"]["min_feeds"], spec["region"]["max_feeds"]) == (2, 8)
    assert spec["region"]["max_total_latest_zip_mb"] == 500
    assert spec["selection"]["count"] == 24 and spec["split"]["validation_count"] == 8
    assert spec["split"]["test_count"] == 16
    assert spec.master_hex == "0ccf15f46abd87cd62e2f17ed319cca0bf69f249a5f1a2135bbb448a1a9c9b4b"
    assert spec.integer_seed("region-selection") == 12315358096030423863
    assert spec.integer_seed("validation-test") == 16591930606484844613
    assert len(spec.gtfs_member_names) == 31


MUTATIONS = [
    ("unknown top key", lambda s: s.__setitem__("extra", 1)),
    ("missing section", lambda s: s.pop("region")),
    ("unknown section key", lambda s: s["history"].__setitem__("foo", 1)),
    ("missing section key", lambda s: s["history"].pop("max_gap_days")),
    ("wrong type", lambda s: s["history"].__setitem__("max_gap_days", "30")),
    ("bool as int", lambda s: s["region"].__setitem__("max_feeds", True)),
    ("gap changed vs spec17", lambda s: s["history"].__setitem__("max_gap_days", 31)),
    ("bbox changed", lambda s: s["feed_eligibility"].__setitem__("max_bbox_diagonal_km", 600)),
    ("pairs changed", lambda s: s["connectivity"].__setitem__("min_stop_pairs", 2)),
    ("count mismatch", lambda s: s["split"].__setitem__("validation_count", 9)),
    ("same domains", lambda s: s["split"].__setitem__("domain", "region-selection")),
    ("master mismatch", lambda s: s["seeds"].__setitem__("master_hex", "0" * 64)),
    ("extra normalisation", lambda s: s["logical_versions"].__setitem__("normalizations",
                                                                         ["strip_utf8_bom", "crlf_to_lf", "trim"])),
    ("gtfs list differs", lambda s: s["logical_versions"]["gtfs_member_names"].pop()),
    ("source hash", lambda s: s["sources"]["SPEC17"].__setitem__("sha256", "0" * 64)),
    ("source missing", lambda s: s["sources"].pop("TOOL_HASHRANK")),
    ("unclear eligible", lambda s: s["feed_eligibility"].__setitem__("eligible_license_classes", ["A", "B", "C", "D"])),
    ("schema", lambda s: s.__setitem__("schema", "X")),
]


@pytest.mark.gate("S1-02")
@pytest.mark.parametrize("name,mut", MUTATIONS, ids=[m[0] for m in MUTATIONS])
def test_malformed_spec_rejected(name, mut):
    s = raw()
    mut(s)
    with pytest.raises(SpecValidationError):
        validate_protocol_spec(s, ROOT / "frozen_specs")


@pytest.mark.gate("S1-02")
def test_spec_digest_stable_and_sensitive():
    a = load_protocol_spec()
    b = validate_protocol_spec(raw(), ROOT / "frozen_specs")
    assert a.digest == b.digest


@pytest.mark.gate("S1-02")
def test_runtime_validation_and_digest(cfg):
    import yaml
    base = yaml.safe_load((ROOT / "configs/workload_c/fixture.yaml").read_text())
    for bad in ({**base, "mode": "REAL"},                      # REAL with FIXTURE namespace + injection
                {**base, "namespace": "TEST"},                 # FIXTURE mode must be FIXTURE namespace
                {**base, "unknown": 1},
                {**base, "mobility": {**base["mobility"], "base_url": "http://x"}},
                {**base, "mobility": {**base["mobility"], "timeout_s": 0}},
                {**base, "mobility": {**base["mobility"], "retry": {**base["mobility"]["retry"], "max_attempts": 50}}}):
        with pytest.raises(SpecValidationError):
            validate_runtime(copy.deepcopy(bad))
    real = yaml.safe_load((ROOT / "configs/workload_c/real.yaml").read_text())
    validate_runtime(real)
    with pytest.raises(SpecValidationError):
        validate_runtime({**real, "failure_injection_allowed": True})
    changed = copy.deepcopy(base)
    changed["mobility"]["page_limit"] = 11
    c2 = load_effective_config(runtime_obj=changed)
    assert c2.digest != cfg.digest and c2.spec.digest == cfg.spec.digest
    assert load_effective_config(runtime_obj=copy.deepcopy(base)).digest == cfg.digest


@pytest.mark.gate("S1-02")
def test_interpretation_register_validated(tmp_path):
    good = json.loads((ROOT / "configs/workload_c/spec_interpretations.json").read_text())
    assert load_interpretations().raw["status"] == "PI_CONFIRMED"          # frozen at PRE-S3 (authorized decision)
    bad = copy.deepcopy(good)
    bad["parameters"]["history_gap_basis"] = "vibes"
    p = tmp_path / "i.json"
    p.write_text(json.dumps(bad))
    with pytest.raises(SpecValidationError):
        load_interpretations(p)


@pytest.mark.gate("S1-02")
def test_no_frozen_constants_scattered_in_engines():
    """Engines read thresholds from the spec: no frozen numeric literal / date string in their code (AST scan)."""
    import ast
    frozen_ints = {500, 400, 2000, 24, 16, 30}
    for rel in ("regions/eligibility.py", "regions/connectivity.py", "regions/construct.py", "regions/dedup.py",
                "selection/hashrank.py", "versioning/logical.py", "regions/spatial.py"):
        tree = ast.parse((ROOT / "src/f1/workload_c" / rel).read_text())
        docstrings = {id(n.body[0].value) for n in ast.walk(tree)
                      if isinstance(n, (ast.Module, ast.FunctionDef, ast.ClassDef)) and n.body
                      and isinstance(n.body[0], ast.Expr) and isinstance(n.body[0].value, ast.Constant)}
        for n in ast.walk(tree):
            if isinstance(n, ast.Constant) and id(n) not in docstrings:
                if isinstance(n.value, int) and not isinstance(n.value, bool):
                    assert n.value not in frozen_ints, (rel, n.value, n.lineno)
                if isinstance(n.value, str):
                    assert "2025-04-01" not in n.value and "2026-06-30" not in n.value, (rel, n.lineno)
