"""PRE-S3 V1.2 deterministic micro-freeze gates P3-21..P3-26 (conventions + reference vectors; no S3 algorithm)."""
import csv
import dataclasses
import hashlib
import json
from fractions import Fraction

import pytest
from reference_v12 import (bca_reference, bind_reference, est_reference, execute_reference, int_seed, sign_test_p,
                           wild_reference)

from conftest import ROOT
from f1.workload_c.history.realized import Cut
from f1.workload_c.interfaces import session3 as S

PRE = ROOT / "docs" / "pre_s3"
VEC = json.loads((PRE / "V1_2_REFERENCE_VECTORS.json").read_text())
FREEZE = (PRE / "V1_2_DETERMINISTIC_FREEZE.md").read_text()
REG = "R:A+B"
SLOTS = ("VAL:feed=A", "VAL:feed=B", "ROUTER:region=R:A+B")


def obs(rows):
    return tuple(S.ProducerRunObservation(r, c, t, w, w, o) for r, c, t, w, o in rows)


@pytest.mark.gate("P3-21")
def test_est_median_convention_vectors():
    exp = {"no_observations": 5400.0, "one": 5000.0, "odd": 5200.0, "even": 5100.0, "failed_excluded": 5150.0,
           "at_t_and_future_and_other_region_excluded": 400.0, "validator_prior": 600.0}
    for name, case in VEC["est"].items():
        prior = S.PriorCostView.before(REG, case["tick_utc"], obs(case["observations"]))
        got = est_reference(case["producer_class"], prior)
        assert got == case["expected"] == exp[name], name
        # F1 and N5 obtain bitwise-identical est(s,t): same shared view, same function, same float bits
        f1 = est_reference(case["producer_class"], S.PriorCostView.before(REG, case["tick_utc"], obs(case["observations"])))
        assert f1.hex() == got.hex()
    assert "(x[n/2−1] + x[n/2]) / 2.0" in FREEZE and "[5000, 5200] → 5100.0" in FREEZE
    for forbidden in ("upper/lower\nmedian", "weighted median"):
        assert forbidden.replace("\n", " ") in FREEZE.replace("\n", " ")


@pytest.mark.gate("P3-22")
def test_repair_execution_semantics():
    tv, post = {"A": 1, "B": 1}, {"A": 3}
    for name, case in VEC["repair_execution"].items():
        if name == "filtered_subset":
            st = execute_reference(SLOTS, set(case["failing"]), tv, {}, {}, post)
            assert [s["slot"] for s in st] == case["expected_order"] == ["VAL:feed=B", "ROUTER:region=R:A+B"]
            continue
        st = execute_reference(SLOTS, set(case["failing"]), tv, case["outcomes"],
                               {"VAL:feed=A": 600, "VAL:feed=B": 610, "ROUTER:region=R:A+B": 5400}, post)
        assert [{k: s[k] for k in ("slot", "outcome", "wall_s", "artifact")} for s in st] == case["expected_steps"], name
        for s in st:
            if s["outcome"] is not None:
                assert s["inputs"] == tv and "A" not in {k for k, v in s["inputs"].items() if v == 3}   # no post-t version
    v = VEC["repair_execution"]
    assert [s["outcome"] for s in v["valA_fail"]["expected_steps"]] == ["INFRA_ERROR", None, None]
    assert [s["outcome"] for s in v["valB_fail"]["expected_steps"]] == ["SUCCESS", "TIMEOUT", None]
    assert [s["outcome"] for s in v["router_fail"]["expected_steps"]] == ["SUCCESS", "SUCCESS", "RESOURCE_FAILURE"]
    assert v["valA_semantic_fail"]["expected_action"] == "REDERIVE" and v["valB_fail"]["charged_wall_s"] == 1210.0
    # structural enforcement through the frozen datatypes
    cut = Cut.of(REG, {"A": 2, "B": 1})
    from f1.workload_c.contracts.model import EvaluationContext
    req = S.ConsumerRequest(REG, SLOTS, "2025-06-03T13:00:00Z", cut,
                            EvaluationContext(cut.cut_id, {}, "o", "s", "p", "v", "2025-06-03", "US", ("2025-06-03",)))

    def plan(outcomes, order=SLOTS):
        steps = tuple(S.RederivationStep(s, cut.cut_id, "otp" if s.startswith("ROUTER") else "validator",
                                         {"VAL:feed=A": 600.0, "VAL:feed=B": 610.0}.get(s, 5400.0), o,
                                         "new" if o in ("SUCCESS", "SEMANTIC_FAIL") else None, None,
                                         None if o is None else 1.0) for s, o in zip(order, outcomes, strict=True))
        return S.RepairPlan(req.request_id, S.Mode.CURRENT, cut, tuple(order), steps, sum(x.estimate_s for x in steps), None, None)
    S.AdmissionDecision(req, "F1", "K2", S.Action.REDERIVE, S.Mode.CURRENT, (), repair=plan(["SUCCESS"] * 3))
    S.AdmissionDecision(req, "N5", "K2", S.Action.NO_ARTIFACT, None, (), repair=plan(["SUCCESS", "TIMEOUT", None]))
    for kw in (dict(action=S.Action.NO_ARTIFACT, mode=None, repair=plan(["INFRA_ERROR", "SUCCESS", None])),   # not fail-fast
               dict(action=S.Action.REDERIVE, mode=S.Mode.CURRENT, repair=plan(["SUCCESS", "TIMEOUT", None])),
               dict(action=S.Action.REDERIVE, mode=S.Mode.CURRENT,
                    repair=plan(["SUCCESS"] * 3, order=(SLOTS[1], SLOTS[0], SLOTS[2])))):                  # non-canonical
        with pytest.raises(S.InterfaceInvariantError):
            S.AdmissionDecision(req, "F1", "K2", current_evaluations=(), **kw)
    bad = plan(["INFRA_ERROR", None, None])
    unattempted_with_cost = dataclasses.replace(bad, steps=(bad.steps[0], dataclasses.replace(bad.steps[1], measured_wall_s=5.0),
                                                            bad.steps[2]))
    with pytest.raises(S.InterfaceInvariantError):
        S.AdmissionDecision(req, "F1", "K2", S.Action.NO_ARTIFACT, None, (), repair=unattempted_with_cost)
    for k in ("A serial, deterministic", "fail-fast", "t is the information boundary", "zero producer cost"):
        assert k.lower() in FREEZE.lower() or k.replace("fail-fast", "stop after the first") in FREEZE


@pytest.mark.gate("P3-23")
def test_request_parity_and_overlay_isolation():
    b = VEC["binding"]
    t = b["tick"]
    f1 = bind_reference(SLOTS[2], b["shared"], b["f1_overlay"], t)
    n5 = bind_reference(SLOTS[2], b["shared"], b["n5_overlay"], t)
    assert f1["id"] == b["expected_f1"] == "F1o" and n5["id"] == b["expected_n5"] == "N5o"     # legitimately differ
    for mutated in ([], [{"slot": SLOTS[2], "instance": 9, "born_utc": "2025-06-03T12:59:59Z", "id": "F1x"}],
                    b["f1_overlay"] * 3):
        assert bind_reference(SLOTS[2], b["shared"], b["n5_overlay"], t) == n5        # N5 invariant to F1 overlay
        assert mutated is not b["n5_overlay"]
    assert bind_reference(SLOTS[2], b["shared"], [], t)["id"] == "S1"                 # S2 born after t
    src = (ROOT / "src/f1/workload_c/interfaces/session3.py").read_text()
    assert "IDENTICAL object" not in src and "THAT METHOD'S own on-demand overlay" in src
    for doc in ("07_F1_N5_CAUSAL_PARITY_SPEC.md", "08_N5_HISTORY_NONINTERFERENCE_SPEC.md"):
        assert "identical object F1 starts from" not in (PRE / doc).read_text()
    assert "never F1's overlay" in (PRE / "08_N5_HISTORY_NONINTERFERENCE_SPEC.md").read_text()
    prompt = (PRE / "17_S3_ULTIMATE_IMPLEMENTATION_PROMPT.txt").read_text()
    assert "N5 can NEVER observe F1's overlay" in prompt
    # the ConsumerRequest is identical across methods: same request_id for the same (region, slots, tick, cut, D)
    from f1.workload_c.contracts.model import EvaluationContext
    cut = Cut.of(REG, {"A": 2, "B": 1})
    mk = lambda: S.ConsumerRequest(REG, SLOTS, t, cut, EvaluationContext(cut.cut_id, {}, "o", "s", "p", "v", "d", "US", ("d",)))  # noqa: E731
    assert mk().request_id == mk().request_id


@pytest.mark.gate("P3-24")
def test_n1_costs_and_preprocessing_frozen():
    rows = {r["gate"]: r["requirement"] for r in csv.DictReader(open(PRE / "14_SESSION3_ACCEPTANCE_GATES.csv"))}
    assert "N1" in rows["S3-19"] and "OWN measured native executions" in rows["S3-19"]
    assert "same producer cost observations" not in rows["S3-19"]
    assert "charged ONCE per region" in FREEZE and "not divided by" in FREEZE and "no double count" in FREEZE
    assert "never a hypothetical full-build cost" in FREEZE
    assert "S3-55" in rows


@pytest.mark.gate("P3-25")
def test_inference_determinism_vectors():
    inf = VEC["inference"]
    master = hashlib.sha256(b"F1-SIGMOD2027-WORKLOAD-C-PROTOCOL-V4-MASTER-SEED").hexdigest()
    assert inf["seeds"]["bootstrap"] == int_seed("bootstrap") == int.from_bytes(
        hashlib.sha256((master + "|bootstrap").encode()).digest()[:8], "big")
    vals = inf["region_values"]
    theta, ci, z0, a = bca_reference(vals)
    assert (theta, list(ci), z0, a) == (inf["bca"]["theta"], inf["bca"]["ci95"], inf["bca"]["z0"], inf["bca"]["a"])
    perm = dict(reversed(list(vals.items())))                                         # permutation invariance
    assert bca_reference(perm)[1] == ci and wild_reference(perm)[1] == tuple(inf["wild"]["ci95"])
    assert sign_test_p(inf["sign_test"]["diffs"], "greater") == Fraction(inf["sign_test"]["p"]) == Fraction(11, 32)
    assert sign_test_p([-1.0, -2.0, 0.0, 3.0], "less") == Fraction(inf["sign_test_less"]["p"]) == Fraction(1, 2)
    assert inf["B"] == 9999 and "Cluster/resampling unit = REGION" in FREEZE and "numpy\n2.4.4" in FREEZE
    import numpy
    pins = json.loads((ROOT / "configs/workload_c/pinned_dependencies.json").read_text())
    assert pins["python"]["packages"]["numpy"] == numpy.__version__ == "2.4.4"


@pytest.mark.gate("P3-26")
def test_v12_gates_prompt_interface_frozen():
    rows = list(csv.DictReader(open(PRE / "14_SESSION3_ACCEPTANCE_GATES.csv")))
    req = {r["gate"]: r["requirement"] for r in rows}
    assert [r["gate"] for r in rows] == [f"S3-{k:02d}" for k in range(1, 57)]
    assert "P3-01..P3-26" in req["S3-07"] and "P3-01..P3-20" in req["S3-07"]
    assert "V1.2" in req["S3-51"]
    prompt = (PRE / "17_S3_ULTIMATE_IMPLEMENTATION_PROMPT.txt").read_text()
    for needle in ("F1-WC-S3-INTERFACES-V1.2", "5100.0", "fail-fast", "N5 can NEVER observe F1's overlay",
                   "OWN measured --loadStreet + cache.enabled", "ONCE per region", "P3-01..P3-26", "cluster = REGION",
                   "Rademacher B = 9,999", "S3-01…S3-56", "Do not choose \"reasonable defaults\""):
        assert needle in prompt, needle
    dig = json.loads((PRE / "PRE_S3_FROZEN_DIGESTS.json").read_text())
    assert S.INTERFACE_VERSION == "F1-WC-S3-INTERFACES-V1.2" == dig["session3_interface_version"]
    sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()  # noqa: E731
    assert sha(ROOT / "src/f1/workload_c/interfaces/session3.py") == dig["session3_interfaces_sha256"]
    assert sha(PRE / "V1_2_REFERENCE_VECTORS.json") == dig["v12_reference_vectors_sha256"]
    assert sha(PRE / "17_S3_ULTIMATE_IMPLEMENTATION_PROMPT.txt") == dig["s3_prompt_sha256"]
    for root_copy in ("14_SESSION3_ACCEPTANCE_GATES.csv", "15_SESSION3_ACCEPTANCE_GATES.md",
                      "17_S3_ULTIMATE_IMPLEMENTATION_PROMPT.txt", "16_SESSION3_IMPLEMENTATION_ROADMAP.md"):
        assert (ROOT / root_copy).read_bytes() == (PRE / root_copy).read_bytes(), root_copy
