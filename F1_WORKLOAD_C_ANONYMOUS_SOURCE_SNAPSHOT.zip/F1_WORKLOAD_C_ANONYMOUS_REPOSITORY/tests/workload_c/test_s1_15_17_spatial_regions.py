import itertools

import pytest

from f1.workload_c.fixturegen.gtfs_gen import offset
from f1.workload_c.ingestion.gtfs import GtfsSummary, Stop
from f1.workload_c.regions.connectivity import evaluate_pair
from f1.workload_c.regions.construct import construct_regions, region_id, split_oversized
from f1.workload_c.regions.eligibility import decide_feed, history_check
from f1.workload_c.regions.model import Edge, FeedFacts, FeedRecord
from f1.workload_c.regions.spatial import (bbox_diagonal_m, convex_hull, haversine_m, hull_criterion, hull_relation,
                                           stop_pairs_within)
from f1.workload_c.ingestion.gtfs import ArchiveRecord

R = 6371008.8


@pytest.mark.gate("S1-15")
def test_haversine_reference_values():
    assert haversine_m(0, 0, 0, 1, R) == pytest.approx(111195.08, abs=0.01)
    assert haversine_m(51.5007, -0.1246, 40.6892, -74.0445, R) == pytest.approx(5574840, rel=1e-3)
    assert haversine_m(10, 10, 10, 10, R) == 0.0
    assert bbox_diagonal_m([Stop("a", 0, 0), Stop("b", 0, 1), Stop("c", 1, 0)], R) == pytest.approx(157249.6, rel=1e-5)


def grid(prefix, lat0, lon0, n, step):
    out = []
    for i in range(n):
        for j in range(n):
            la, lo = offset(lat0, lon0, i * step, j * step)
            out.append(Stop(f"{prefix}{i}_{j}", la, lo))
    return out


@pytest.mark.gate("S1-15")
def test_stop_pair_count_equals_brute_force_and_inclusive_threshold():
    a, b = grid("a", 45.0, 7.0, 7, 230.0), grid("b", 45.001, 7.0013, 7, 310.0)
    n, sample = stop_pairs_within(a, b, 400, R)
    brute = sum(1 for x in a for y in b if haversine_m(x.lat, x.lon, y.lat, y.lon, R) <= 400)
    assert n == brute and n > 10 and len(sample) == 10
    assert sample == sorted(sample, key=lambda s: (s["distance_m"], s["stop_a"], s["stop_b"]))
    d = haversine_m(a[0].lat, a[0].lon, b[0].lat, b[0].lon, R)
    assert stop_pairs_within([a[0]], [b[0]], d, R)[0] == 1          # exactly at threshold counts
    assert stop_pairs_within([a[0]], [b[0]], d - 1e-6, R)[0] == 0
    assert stop_pairs_within(list(reversed(a)), b, 400, R)[0] == n  # order independent


@pytest.mark.gate("S1-15")
def test_hull_relations():
    sq = convex_hull([(0, 0), (10, 0), (10, 10), (0, 10), (5, 5)])
    assert len(sq) == 4
    assert hull_relation(sq, convex_hull([(5, 5), (20, 5), (20, 20)])) == (True, 0.0)       # crossing
    assert hull_relation(sq, convex_hull([(2, 2), (3, 2), (2, 3)])) == (True, 0.0)          # containment
    inter, d = hull_relation(sq, convex_hull([(13, 0), (20, 0), (20, 10)]))
    assert not inter and d == pytest.approx(3.0)
    assert hull_relation([(0, 0)], [(3, 4)]) == (False, 5.0)                                 # degenerate points
    assert hull_relation(convex_hull([(0, 0), (10, 0)]), convex_hull([(5, -1), (5, 1)]))[0]  # segments cross
    near = [Stop("n", *offset(45, 7, 0, 0))]
    far = [Stop("f", *offset(45, 7, 1999.0, 0)), Stop("g", *offset(45, 7, 2500, 100))]
    ok, dist = hull_criterion(near, far, R)
    assert not ok and dist == pytest.approx(1999.0, abs=1.0)


def ff(fid, stops, tz="Europe/Paris"):
    f = FeedFacts(fid, in_force_lv=f"{fid}#L00001")
    f.in_force_summary = GtfsSummary(stops, [tz], [f"Ag {fid}"])
    return f


@pytest.mark.gate("S1-15")
def test_connectivity_edge_criteria(cfg):
    base = [Stop(f"x{k}", *offset(45, 7, k * 1000.0, 0)) for k in range(4)]
    near3 = [Stop(f"y{k}", *offset(45, 7, k * 1000.0, 30)) for k in range(3)]
    near2 = near3[:2]
    e, ev = evaluate_pair(cfg, ff("b", near3), ff("a", base))
    assert e == Edge("a", "b", 3) and ev["decision"] == "EDGE" and ev["feed_a"] == "a"
    e2, ev2 = evaluate_pair(cfg, ff("a", base), ff("b", near2))
    assert e2 is None and ev2["reasons"] == ["STOP_PAIRS_BELOW_THRESHOLD"]
    e3, ev3 = evaluate_pair(cfg, ff("a", base), ff("b", near3, "Europe/Berlin"))
    assert e3 is None and ev3["reasons"] == ["TIMEZONE_MISMATCH"]
    multi = ff("c", near3)
    multi.in_force_summary = GtfsSummary(near3, ["Europe/Paris", "Europe/Rome"], ["a", "b"])
    assert evaluate_pair(cfg, ff("a", base), multi)[1]["reasons"] == ["TIMEZONE_UNDEFINED"]
    far = [Stop("z", *offset(46, 7, 0, 0))]
    e4, ev4 = evaluate_pair(cfg, ff("a", base), ff("d", far))
    assert e4 is None and "pruned_lat_gap_m" in ev4 and set(ev4["reasons"]) == {"STOP_PAIRS_BELOW_THRESHOLD", "HULL_TOO_FAR"}


@pytest.mark.gate("S1-16")
def test_region_construction_bounds_and_ids(cfg):
    ids = ["f1", "f2", "f3", "f4", "f5", "lone"]
    edges = [Edge("f1", "f2", 5), Edge("f2", "f3", 4), Edge("f4", "f5", 9)]
    size = {i: 1000 for i in ids}
    tz = {i: "UTC" for i in ids}
    regs, log = construct_regions(cfg, ids, edges, size, tz, {i: "A" for i in ids})
    got = {r.region_id: (r.status, r.reason) for r in regs}
    assert got == {"R:f1+f2+f3": ("ELIGIBLE", "ELIGIBLE"), "R:f4+f5": ("ELIGIBLE", "ELIGIBLE"),
                   "R:lone": ("EXCLUDED", "REGION_SINGLETON_NO_EDGE")} and log == []
    big = {**size, "f4": 400_000_000, "f5": 100_000_001}
    regs2, _ = construct_regions(cfg, ids, edges, big, tz, {})
    assert {r.region_id: r.reason for r in regs2}["R:f4+f5"] == "REGION_ZIP_SIZE_EXCEEDED"
    big["f5"] = 100_000_000                                         # exactly 500 MB is allowed
    assert {r.region_id: r.reason for r in construct_regions(cfg, ids, edges, big, tz, {})[0]}["R:f4+f5"] == "ELIGIBLE"
    assert region_id(cfg.spec, ["b", "a", "a"]) == "R:a+b"
    with pytest.raises(ValueError):
        region_id(cfg.spec, ["a+b", "c"])


@pytest.mark.gate("S1-16")
def test_oversize_split_weakest_edge_and_tiebreak(cfg):
    a = [f"a{i}" for i in range(5)]
    b = [f"b{i}" for i in range(5)]
    E = [Edge(x, y, 4) for g in (a, b) for x, y in itertools.combinations(g, 2)] + [Edge("a0", "b0", 3)]
    parts, log = split_oversized(a + b, E, 8)
    assert parts == [a, b] and log[0]["removed_edge"] == ["a0", "b0"]
    # tie on pair count -> smallest (a, b) ids removed first
    chain = [f"c{i}" for i in range(9)]
    E2 = [Edge(chain[i], chain[i + 1], 3) for i in range(8)]
    parts2, log2 = split_oversized(chain, E2, 8)
    assert log2[0]["removed_edge"] == ["c0", "c1"] and parts2 == [["c0"], chain[1:]]
    regs, slog = construct_regions(cfg, chain, E2, {c: 1 for c in chain}, {c: "UTC" for c in chain}, {})
    assert {r.region_id: r.reason for r in regs} == {"R:c0": "SPLIT_PART_SINGLETON",
                                                       "R:" + "+".join(chain[1:]): "ELIGIBLE"}
    assert slog[0]["n_feeds"] == 9


@pytest.mark.gate("S1-16")
def test_construction_permutation_invariant(cfg):
    ids = [f"f{i}" for i in range(12)]
    E = [Edge(f"f{i}", f"f{i + 1}", 3 + (i % 3)) for i in range(11)]
    ref = construct_regions(cfg, ids, E, {i: 1 for i in ids}, {i: "UTC" for i in ids}, {})
    for k in range(5):
        ids2 = ids[k:] + ids[:k]
        E2 = list(reversed(E))
        got = construct_regions(cfg, ids2, E2, {i: 1 for i in ids}, {i: "UTC" for i in ids}, {})
        assert [r.to_row() for r in got[0]] == [r.to_row() for r in ref[0]] and got[1] == ref[1]


def A(t, status="OK", aid=None):
    return ArchiveRecord("FIXTURE", "f", aid or t, {}, t, "", "r", "h", 1, {}, {}, status)


@pytest.mark.gate("S1-17")
def test_history_rule_boundaries(cfg):
    from f1.workload_c.timeutil import epoch, from_epoch
    s0 = epoch("2025-04-01T00:00:00Z")
    series = [A("2025-03-31T00:00:00Z")] + [A(from_epoch(s0 + k * 30 * 86400)) for k in range(1, 16)]
    ok, reason, gap = history_check(cfg, series, [])
    assert ok and gap == pytest.approx(30.0)                          # gaps of exactly 30 days are allowed
    assert not history_check(cfg, series[:3] + series[4:], [])[0]     # removing one observation -> 60-day gap
    ok2, r2, _ = history_check(cfg, [A("2025-04-01T00:00:00Z"), A("2025-05-01T00:00:01Z")], [])
    assert not ok2 and r2 == "HISTORY_GAP_EXCEEDED"
    ok3, r3, _ = history_check(cfg, [A("2025-04-01T00:00:01Z")], [])
    assert r3 == "HISTORY_INSUFFICIENT_START"
    ok4, r4, _ = history_check(cfg, [A("2025-04-01T00:00:00Z")] + [A(f"2025-{m:02d}-01T00:00:00Z") for m in range(5, 13)]
                               + [A(f"2026-{m:02d}-01T00:00:00Z") for m in range(1, 6)], [])
    assert not ok4 and r4 == "HISTORY_GAP_EXCEEDED"                   # 2026-05-01 -> 2026-07-01 tail gap
    assert history_check(cfg, [A("2025-01-01T00:00:00Z", "SOURCE_LOCATOR_FAILURE")], [])[1] == "NO_HISTORY"


@pytest.mark.gate("S1-17")
def test_feed_decision_reasons(cfg):
    good = FeedRecord("f", True, (), "active", 0, "u", "p", "n", (), None, None)
    facts = FeedFacts("f", history_ok=True, n_archives_ok=5, bbox_diagonal_m=499_999.0)
    lic_ok = {"eligible": True, "classification": "PASS"}
    assert decide_feed(cfg, good, facts, lic_ok).eligible
    bad = FeedRecord("f", False, ("x",), "deprecated", 2, "u", "p", "n", (), None, None)
    f2 = FeedFacts("f", history_ok=False, history_reason="HISTORY_GAP_EXCEEDED", n_archives_ok=3, archive_failures=1,
                   bbox_diagonal_m=500_001.0, malformed_reason="MALFORMED_ARCHIVE")
    d = decide_feed(cfg, bad, f2, {"eligible": False, "classification": "UNCLEAR"})
    assert d.reasons == ["MALFORMED_METADATA", "STATUS_NOT_ACTIVE", "AUTHENTICATION_REQUIRED", "ARCHIVE_UNRETRIEVABLE",
                         "MALFORMED_GTFS", "HISTORY_GAP_EXCEEDED", "BBOX_DIAGONAL_EXCEEDED", "LICENSE_UNCLEAR"]
    assert decide_feed(cfg, good, facts, None).reasons == ["LICENSE_UNCLEAR"]
    assert decide_feed(cfg, good, facts, {"eligible": False, "classification": "INCOMPATIBLE"}).reasons == ["LICENSE_INCOMPATIBLE"]
    facts.bbox_diagonal_m = 500_000.0
    assert decide_feed(cfg, good, facts, lic_ok).eligible            # <= 500 km inclusive
