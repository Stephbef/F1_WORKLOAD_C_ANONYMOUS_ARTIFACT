"""Session-3 engine gates (frozen PRE-S3 V1.2 specs). FIXTURE / non-study data only."""
import ast
import dataclasses
import functools
import hashlib
import inspect
import json
import typing
from pathlib import Path

import pytest

from conftest import ROOT
from f1.workload_c.campaign import e2e_s3
from f1.workload_c.catalog.artifacts import ArtifactCatalog
from f1.workload_c.config.spec import load_protocol_spec
from f1.workload_c.contracts.generators import ContractSystem
from f1.workload_c.engines import baselines_n, core, f1, mutation, stats
from f1.workload_c.engines.core import (CostModelImpl, CutContextFactoryImpl, GammaAdmissibilityImpl,
                                        InProcessFixtureProducer, MethodCatalog, ProducerRederiver, RegionState,
                                        VersionInfo, execute_plan)
from f1.workload_c.history.realized import Cut
from f1.workload_c.interfaces import session3 as S
from f1.workload_c.storage.blobstore import BlobStore

PRE = ROOT / "docs" / "pre_s3"
VEC = json.loads((PRE / "V1_2_REFERENCE_VECTORS.json").read_text())


@functools.lru_cache(maxsize=None)
def trace(name: str, tag: str = "", outcomes: tuple = ()):
    import tempfile
    d = Path(tempfile.mkdtemp(prefix=f"s3-{name}-{tag}-"))
    return e2e_s3.run_trace(name, d / name, dict(outcomes) if outcomes else None)


def dec(t, method, level):
    return [r for r in t["records"] if r["method"] == method and r["level"] == level][0]


def region_with(versions_spec, tz="America/Los_Angeles", feeds=("A",)):
    """versions_spec: [(feed, index, zip_bytes, available_utc)]"""
    import tempfile
    blobs = BlobStore(Path(tempfile.mkdtemp(prefix="s3-reg-")))
    names = load_protocol_spec().gtfs_member_names
    from f1.workload_c.ingestion.gtfs import canonical_content_hash
    vs = {}
    for f, i, z, av in versions_spec:
        ref = blobs.put(z, "application/zip", provenance={"namespace": "FIXTURE", "fixture": f"{f}{i}"})
        vs[(f, i)] = VersionInfo(f, i, f"{f}#L{i}", canonical_content_hash(z, names), ref.sha256, av)
    return RegionState("R:x", tz, tuple(feeds), vs, "osm", "sem", "otp", "val", "US", blobs)


# ----------------------------------------------------------------------------------------------------- Γ
@pytest.mark.gate("S3-08")
def test_gamma_admissibility_and_sensitivities():
    full = e2e_s3._feed("A")
    short = e2e_s3._feed("A", service_end="20250612")
    reg = region_with([("A", 1, full, "2025-06-01T00:00:00Z"), ("A", 2, e2e_s3._feed("A", headway_min=20),
                                                                 "2025-06-02T00:00:00Z"),
                       ("A", 3, e2e_s3._feed("A", headway_min=25), "2025-06-03T00:00:00Z"),
                       ("A", 4, short, "2025-06-04T00:00:00Z"),
                       ("A", 5, e2e_s3._feed("A", headway_min=30), "2025-06-20T00:00:00Z")])     # after t
    t = "2025-06-10T13:00:00Z"
    g = GammaAdmissibilityImpl(reg)
    cands = [c.index("A") for c in g.candidates(t)]
    assert cands == [3, 2]              # cur = 4 (A5 not yet available), depth 2, A4 itself is current, A1 too deep
    ev = g.evidence(Cut.of("R:x", {"A": 4}), t)
    assert not ev.admissible and ev.per_feed[0][4] is False         # current A4 lacks service on D (ends 06-12)
    assert g.evidence(Cut.of("R:x", {"A": 1}), t).per_feed[0][3] is False         # depth 3 > 2
    assert not g.evidence(Cut.of("R:x", {"A": 5}), t).admissible                  # not available at t
    assert [c.index("A") for c in GammaAdmissibilityImpl(reg, depth=1).candidates(t)] == [3]
    assert [c.index("A") for c in GammaAdmissibilityImpl(reg, depth=4).candidates(t)] == [3, 2, 1]
    assert [c.index("A") for c in GammaAdmissibilityImpl(reg, horizon_days=3).candidates(t)] == [3, 2]
    assert GammaAdmissibilityImpl(reg, horizon_days=13).evidence(Cut.of("R:x", {"A": 3}), t).admissible


@pytest.mark.gate("S3-09")
def test_witness_search_deterministic_and_permutation_invariant():
    t1, t1b = trace("T1"), trace("T1", "again")
    for k in ("K0", "K1", "K2"):
        a, b = dec(t1, "F1", k), dec(t1b, "F1", k)
        assert a["witness_cut_id"] == b["witness_cut_id"] and a["contract_verdicts"] == b["contract_verdicts"]
    reg = t1["region"]
    perm = RegionState(reg.region_id, reg.tz, tuple(reversed(reg.feeds)), dict(reversed(list(reg.versions.items()))),
                       reg.osm_sha256, reg.semantic_config_digest, reg.otp_sha256, reg.validator_sha256, reg.country,
                       reg.blobs)
    t = e2e_s3.TICK
    assert [c.cut_id for c in GammaAdmissibilityImpl(perm).candidates(t)] == \
        [c.cut_id for c in GammaAdmissibilityImpl(reg).candidates(t)]


@pytest.mark.gate("S3-10")
def test_no_future_cut_or_future_artifact_in_witness():
    t1 = trace("T1")
    w = dec(t1, "F1", "K2")
    reg = t1["region"]
    ws = Cut.of(reg.region_id, {"A": 1, "B": 1})
    assert w["witness_cut_id"] == ws.cut_id
    assert all(reg.versions[(f, i)].available_utc <= e2e_s3.TICK for f, i in ws.frontier)
    with pytest.raises(S.InterfaceInvariantError):
        S.TemporalEvidence(e2e_s3.TICK, "2025-06-10T13:00:01Z", ())
    with pytest.raises(S.InterfaceInvariantError):
        S.TemporalEvidence(e2e_s3.TICK, "2025-06-10T00:00:00Z", (("A", 9, "2025-06-11T00:00:00Z"),))
    camp = t1["campaign"]
    mc = MethodCatalog(camp.shared, camp.shared_born, ArtifactCatalog(None), {}, {})
    for slot in camp.shared.slots():
        got = mc.bind(slot, e2e_s3.TICK)
        assert got is None or got[1] <= e2e_s3.TICK
    late = mc.bind("VAL:feed=A", "2025-06-10T12:59:59Z")
    assert late is not None and late[0].birth_frontier == (("A", 1),)      # VAL(A1) completes at 14:00Z (after t)
    with pytest.raises(core.EngineError):
        f1._check_realized(None, Cut.of(reg.region_id, {"A": 3, "B": 1}), e2e_s3.TICK, GammaAdmissibilityImpl(reg))


@pytest.mark.gate("S3-11")
def test_fixed_r_enforced():
    t1 = trace("T1")
    rec = dec(t1, "F1", "K2")
    assert [s for s, _ in rec["bound_artifacts"]] == list(rec["request_slots"])
    assert "catalog" not in inspect.signature(f1.WitnessSearchImpl.search).parameters
    camp = t1["campaign"]
    binding = core.bind_request(S.ConsumerRequest(camp.r.region_id, tuple(rec["request_slots"]), e2e_s3.TICK,
                                                  camp.r.current_cut(e2e_s3.TICK),
                                                  CutContextFactoryImpl(camp.r).context_for(
                                                      camp.r.current_cut(e2e_s3.TICK), e2e_s3.TICK)),
                                MethodCatalog(camp.shared, camp.shared_born, ArtifactCatalog(None), {},
                                              dict(camp.contracts)), tuple((s, 1.0) for s in rec["request_slots"]))
    b0, b1 = binding.bindings[0], binding.bindings[1]
    with pytest.raises(S.InterfaceInvariantError):
        S.RequestBinding(binding.request, ((b0[0], b1[1]),) + binding.bindings[1:], binding.contracts, binding.estimates)
    with pytest.raises(core.EngineError):                      # rederive outside the designated slot space
        ProducerRederiver(camp.r, MethodCatalog(camp.shared, {}, ArtifactCatalog(None)), None).rederive(
            "OTHER:slot", camp.r.current_cut(e2e_s3.TICK), e2e_s3.TICK, 1.0)


@pytest.mark.gate("S3-12")
def test_joint_witness_provenance_complete():
    t1 = trace("T1")
    camp = t1["campaign"]
    d = [x for x in camp._arms if x.method == "F1" and x.level == "K2"][0].decisions[0]
    w = d.witness
    assert w is not None and tuple(b.slot_id for b in w.bindings) == d.request.request_slots
    for b in w.bindings:
        assert b.evaluations and all(e.cut_id == w.witness_cut.cut_id and e.verdict == "VALID" for e in b.evaluations)
        assert b.artifact.catalog_entry_digest and b.artifact.birth_cut_id and b.artifact.provenance_digest
        assert b.temporal.artifact_born_utc <= b.temporal.tick_utc and b.temporal.witness_versions_available_utc
    assert w.gamma.admissible and w.gamma.horizon


@pytest.mark.gate("S3-13")
def test_k3_never_an_admission_contract():
    t1 = trace("T1")
    camp = t1["campaign"]
    k3 = [c for cs in camp.contracts.values() for c in cs if c.level == "K3"][0]
    ev = core.TimedEvaluator(camp.cs)
    r = ev.evaluate(k3, CutContextFactoryImpl(camp.r).context_for(camp.r.current_cut(e2e_s3.TICK), e2e_s3.TICK))
    assert r.verdict == "ERROR"
    with pytest.raises(core.EngineError):
        f1.WitnessSearchImpl().search(None, "K3", None, None, None, None)
    with pytest.raises(core.EngineError):
        core.level_contracts(S.RequestBinding.__new__(S.RequestBinding), "a", "K3")


@pytest.mark.gate("S3-14")
def test_admission_decision_order():
    exp = {"T1": ("REUSE", "HISTORICAL"), "T2": ("REDERIVE", "HISTORICAL"), "T4": ("REDERIVE", "CURRENT")}
    for t, (a, m) in exp.items():
        for k in ("K0", "K1", "K2"):
            r = dec(trace(t), "F1", k)
            assert (r["action"], r["mode"]) == (a, m), (t, k)
    t3 = trace("T3")
    assert (dec(t3, "F1", "K2")["action"], dec(t3, "F1", "K2")["mode"]) == ("REUSE", "CURRENT")
    fail = trace("T4", "fail", (("ROUTER:region=R:T4", "INFRA_ERROR"),))
    r = dec(fail, "F1", "K2")
    assert r["action"] == "NO_ARTIFACT" and r["mode"] is None and r["rederivations"][0]["outcome"] == "INFRA_ERROR"


class _G:
    def __init__(self, cuts, region):
        import types
        vs = {(f, i): types.SimpleNamespace(available_utc="2025-06-01T00:00:00Z") for c in cuts for f, i in c.frontier}
        self.cuts, self.r = cuts, types.SimpleNamespace(versions=vs)

    def candidates(self, t):
        return list(self.cuts)

    def evidence(self, cut, t):
        return S.GammaEvidence(t, ("d",), tuple((f, i, i, True, True) for f, i in cut.frontier), True)


class _Ctx:
    def context_for(self, cut, t):
        from f1.workload_c.contracts.model import EvaluationContext
        return EvaluationContext(cut.cut_id, {}, horizon=("d",))


class _Ev:
    def __init__(self, valid):          # valid: set of (artifact_id, cut_id)
        self.valid = valid

    def evaluate(self, c, ctx):
        from f1.workload_c.contracts.model import EvaluationResult
        return EvaluationResult(c.contract_id, ctx.cut_id, "VALID" if (c.artifact_id, ctx.cut_id) in self.valid else
                                "INVALID", "fake", "e")


def _fake_binding(est):
    from f1.workload_c.contracts.model import Contract
    reg = "R:x"
    cur = Cut.of(reg, {"A": 2, "B": 1})
    from f1.workload_c.contracts.model import EvaluationContext
    req = S.ConsumerRequest(reg, S.canonical_request_slots(reg, ["A", "B"]), "2025-06-10T13:00:00Z", cur,
                            EvaluationContext(cur.cut_id, {}, horizon=("d",)))
    bs, cs = [], []
    for s in req.request_slots:
        aid = "a:" + s
        b = S.BoundArtifact(s, aid, "X", "p", "CUT:b", (), (), (f"K2:{aid}",), "SUCCESS", "2025-06-10T00:00:00Z", "e",
                            "p", (), "FIXTURE", "FIXTURE_STUB_BINARY")
        bs.append((s, b))
        cs.append((aid, (Contract.build("K2", "X", aid, s, "CUT:b", {}, "g", "e"),)))
    return S.RequestBinding(req, tuple(bs), tuple(cs), tuple((s, est[s]) for s in req.request_slots)), cur


def _fake_history():
    """Realized history for the fake region: A#1, A#2, B#1 available before the tick (F1 requires it, S3.1)."""
    from f1.workload_c.history.realized import Event, RealizedHistory
    h = RealizedHistory(None)
    a1 = h.add(Event("LOGICAL_VERSION_AVAILABLE", "2025-06-01T00:00:00Z", "R:x", "A", {"index": 1}, ()))
    h.add(Event("LOGICAL_VERSION_AVAILABLE", "2025-06-01T00:00:00Z", "R:x", "A", {"index": 2}, (a1,)))
    h.add(Event("LOGICAL_VERSION_AVAILABLE", "2025-06-01T00:00:00Z", "R:x", "B", {"index": 1}, ()))
    return h


@pytest.mark.gate("S3-15")
def test_repair_deterministic_and_tie_goes_to_current(tmp_path):
    est = {"VAL:feed=A": 600.0, "VAL:feed=B": 600.0, "ROUTER:region=R:x": 5400.0}
    binding, cur = _fake_binding(est)
    hist = _fake_history()
    h = Cut.of("R:x", {"A": 1, "B": 1})
    # current fails VAL B only (600); historical fails VAL A only (600) -> tie -> CURRENT
    valid = {("a:VAL:feed=A", cur.cut_id), ("a:ROUTER:region=R:x", cur.cut_id), ("a:VAL:feed=B", h.cut_id),
             ("a:ROUTER:region=R:x", h.cut_id)}
    p = f1.RepairEngineImpl().plan(binding, "K2", hist, _Ctx(), _G([h], None), _Ev(valid))
    assert p.mode == S.Mode.CURRENT and p.failing_slots == ("VAL:feed=B",) and p.opt_current == p.opt_hist == 600.0
    # historical strictly cheaper -> HISTORICAL; repeated planning identical
    valid2 = {("a:VAL:feed=A", cur.cut_id), ("a:VAL:feed=B", cur.cut_id), ("a:VAL:feed=B", h.cut_id),
              ("a:ROUTER:region=R:x", h.cut_id)}
    p2 = f1.RepairEngineImpl().plan(binding, "K2", hist, _Ctx(), _G([h], None), _Ev(valid2))
    p3 = f1.RepairEngineImpl().plan(binding, "K2", hist, _Ctx(), _G([h], None), _Ev(valid2))
    assert p2 == p3 and p2.mode == S.Mode.HISTORICAL and p2.opt_current == 5400.0 and p2.opt_hist == 600.0
    t2 = trace("T2")
    assert dec(t2, "F1", "K2")["opt_hist"] == 600.0 and dec(t2, "F1", "K2")["opt_current"] == 5400.0


@pytest.mark.gate("S3-16")
def test_rederive_new_instance_same_slot_no_future():
    t2 = trace("T2")
    arm = [a for a in t2["campaign"]._arms if a.method == "F1" and a.level == "K2"][0]
    inst = arm.mc.overlay.instances("VAL:feed=A")
    assert len(inst) == 1 and inst[0].request_slot == "VAL:feed=A" and inst[0].birth_frontier == (("A", 1),)
    born = arm.mc.overlay_born[inst[0].artifact_id]
    assert born == "2025-06-10T13:10:00Z"                       # t + executed serial duration (600 s)
    reg = t2["region"]
    red = ProducerRederiver(reg, MethodCatalog(ArtifactCatalog(None), {}, ArtifactCatalog(None)),
                            InProcessFixtureProducer(reg, t2["campaign"].cs, CutContextFactoryImpl(reg)))
    st = red.rederive("VAL:feed=A", Cut.of(reg.region_id, {"A": 2, "B": 1}), "2025-06-10T09:00:00Z", 600.0)
    assert st.outcome == core.INFEASIBLE and st.new_artifact_id is None and st.measured_wall_s is None


@pytest.mark.gate("S3-17")
def test_a_b_a_distinct_realized_states():
    a, b = e2e_s3._feed("A"), e2e_s3._feed("A", headway_min=20)
    reg = region_with([("A", 1, a, "2025-06-01T00:00:00Z"), ("A", 2, b, "2025-06-03T00:00:00Z"),
                       ("A", 3, a, "2025-06-05T00:00:00Z")])
    from f1.workload_c.engines.runner import root_change_units
    assert root_change_units(reg, "2025-05-01T00:00:00Z") == {("A", 2), ("A", 3)}      # A→B and B→A
    assert root_change_units(reg, "2025-06-02T00:00:00Z") == {("A", 2), ("A", 3)}      # A1 = baseline state
    assert root_change_units(reg, "2025-06-04T00:00:00Z") == {("A", 3)}
    t = "2025-06-10T13:00:00Z"
    cands = GammaAdmissibilityImpl(reg).candidates(t)
    assert [c.index("A") for c in cands] == [2, 1] and len({c.cut_id for c in cands}) == 2
    cs = ContractSystem(reg.blobs, load_protocol_spec().gtfs_member_names)
    ctxf = CutContextFactoryImpl(reg)
    p = InProcessFixtureProducer(reg, cs, ctxf).produce("VAL:feed=A", Cut.of(reg.region_id, {"A": 1}), t)
    k0 = [c for c in p.contracts if c.level == "K0"][0]
    assert cs.evaluate(k0, ctxf.context_for(Cut.of(reg.region_id, {"A": 3}), t)).verdict == "VALID"   # recurrence
    assert cs.evaluate(k0, ctxf.context_for(Cut.of(reg.region_id, {"A": 2}), t)).verdict == "INVALID"


# ----------------------------------------------------------------------------------------------------- costs
@pytest.mark.gate("S3-18")
@pytest.mark.gate("S3-52")
def test_cost_model_median_vectors_and_determinism():
    cm = CostModelImpl()
    for name, case in VEC["est"].items():
        obs = tuple(S.ProducerRunObservation(r, c, t, w, w, o) for r, c, t, w, o in case["observations"])
        p = S.PriorCostView.before("R:A+B", case["tick_utc"], obs)
        slot = "ROUTER:region=R:A+B" if case["producer_class"] == "otp" else "VAL:feed=A"
        got = cm.estimate_rederive(slot, case["producer_class"], case["tick_utc"], p)
        assert got == case["expected"], name
        assert cm.estimate_rederive(slot, case["producer_class"], case["tick_utc"], p).hex() == got.hex()
    with pytest.raises(core.EngineError):
        cm.estimate_rederive("VAL:feed=A", "otp", "2025-06-03T13:00:00Z",
                             S.PriorCostView.before("R:A+B", "2025-06-03T13:00:00Z", ()))


@pytest.mark.gate("S3-19")
def test_cost_symmetry_and_measurement_parity():
    for t in ("T1", "T2", "T3", "T4"):
        recs = trace(t)["records"]
        ests = {(r["method"], r["level"]): r["estimates"] for r in recs}
        assert len({json.dumps(v) for v in ests.values()}) == 1                    # identical est(s,t) for all arms
        for r in recs:
            a_items = [i for i in r["costs"]["items"] if i["category"] == "A_PRODUCER" and i["component"] != "n1_preprocessing"]
            mine = [s for s in r["rederivations"] if s["outcome"] is not None]
            assert len(a_items) == len(mine)                                          # charged exactly own executions
    n1 = dec(trace("T2"), "N1", "K0")
    router = [i for i in n1["costs"]["items"] if i["component"] == "producer:otp-native"][0]
    assert router["wall_s"] == 1800.0 != dict(n1["estimates"])["ROUTER:region=R:T2"]       # own native observation


@pytest.mark.gate("S3-20")
def test_control_plane_costs_charged_to_incurring_method():
    """Complete B category: evaluate, admission, catalog_lookup (every method, same methodology), witness_search
    (F1 when current fails; includes Γ construction), repair_solver (F1 repair; includes Γ construction),
    journal_fsync (online overlay catalog insertion when a re-derivation succeeded)."""
    for t in ("T1", "T2"):
        for r in trace(t)["records"]:
            comps = [i["component"] for i in r["costs"]["items"] if i["category"] == "B_CONTROL_PLANE"]
            assert {"evaluate", "admission", "catalog_lookup"} <= set(comps), (t, r["method"])
            assert comps.count("catalog_lookup") == 1 and comps.count("admission") == 1
            if r["method"] == "F1":
                assert "witness_search" in comps
                assert ("repair_solver" in comps) == (r["action"] != "REUSE")
            else:
                assert "witness_search" not in comps and "repair_solver" not in comps
            # journal_fsync = online overlay CATALOG insertion by a successful re-derivation; the N1 native router
            # build persists native OTP state (part of its measured native producer cost), not a catalog entry
            made = any(s["new_artifact_id"] and not s["new_artifact_id"].startswith("N1:") for s in r["rederivations"])
            assert ("journal_fsync" in comps) == made, (t, r["method"], r["level"])
            assert all(i["wall_s"] >= 0 for i in r["costs"]["items"])


@pytest.mark.gate("S3-21")
def test_failed_attempts_accounted():
    fail = trace("T2", "fail", (("ROUTER:region=R:T2", "RESOURCE_FAILURE"),))
    r = dec(fail, "N5", "K2")
    assert r["action"] == "NO_ARTIFACT" and r["failures"] == [["ROUTER:region=R:T2", "RESOURCE_FAILURE"]]
    a = [i for i in r["costs"]["items"] if i["category"] == "A_PRODUCER"]
    assert a and a[0]["producer_outcome"] == "RESOURCE_FAILURE" and a[0]["wall_s"] == 5400.0


@pytest.mark.gate("S3-22")
def test_offline_cost_excluded():
    rec = S.CostRecord((S.CostItem(S.CostCategory.A_PRODUCER, "p", 2.0, 2.0),
                        S.CostItem(S.CostCategory.C_OFFLINE, "replay", 99.0, 99.0)))
    assert CostModelImpl().online_cost(rec) == 2.0
    for r in trace("T1")["records"]:
        assert all(i["category"] != "C_OFFLINE" for i in r["costs"]["items"])          # replay/stat never online


# ----------------------------------------------------------------------------------------------------- N5
def _imports(mod) -> set:
    tree = ast.parse(Path(mod.__file__).read_text())
    out = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.ImportFrom):
            out.add((n.module or "") + ":" + ",".join(a.name for a in n.names))
        elif isinstance(n, ast.Import):
            out |= {a.name for a in n.names}
    return out


class Sentinel:
    def __getattr__(self, name):
        raise AssertionError(f"N5 touched a forbidden object ({name})")


@pytest.mark.gate("S3-23")
def test_n5_history_noninterference():
    imps = " ".join(_imports(baselines_n))
    for forbidden in ("history.realized", "ArtifactCatalog", "enumerate_cuts", ".f1", "Witness"):
        assert forbidden not in imps, forbidden
    t2 = trace("T2")
    camp = t2["campaign"]
    req = dec(t2, "N5", "K2")
    arm = [a for a in camp._arms if a.method == "N5" and a.level == "K2"][0]
    # fresh replay of N5 with sentinels attached wherever history/catalog/witness could be reached
    view = core.bind_request(arm.decisions[0].request, MethodCatalog(camp.shared, camp.shared_born, ArtifactCatalog(None),
                                                                    {}, dict(camp.contracts)), arm.decisions[0].request and
                             tuple(tuple(x) for x in req["estimates"]))
    seen = []

    class SpyEval:
        history = catalog = witness_index = Sentinel()

        def evaluate(self, c):
            r = core.CurrentCutEvaluatorImpl(core.TimedEvaluator(camp.cs), view.request.context).evaluate(c)
            seen.append(r.cut_id)
            return r

    class SpyRed:
        history = catalog = Sentinel()

        def rederive(self, slot_id, estimate_s):
            return S.RederivationStep(slot_id, view.request.current_cut.cut_id, core.producer_class_of(slot_id),
                                      estimate_s, "SUCCESS", "x", "p", 1.0)
    d = baselines_n.N5BaselineImpl().decide(view, "K2", SpyEval(), SpyRed())
    assert seen and set(seen) == {view.request.current_cut.cut_id}           # only current-cut evaluations
    assert d.mode != S.Mode.HISTORICAL and d.witness is None


@pytest.mark.gate("S3-24")
def test_n5_current_cut_parity_with_f1():
    for t in ("T1", "T2", "T3", "T4"):
        for k in ("K0", "K1", "K2"):
            a, b = dec(trace(t), "F1", k), dec(trace(t), "N5", k)
            cur = trace(t)["records"][0]["current_cut_id"]
            fa = [v for v in a["contract_verdicts"] if v[2] == cur]
            fb = [v for v in b["contract_verdicts"] if v[2] == cur]
            assert fa == fb, (t, k)                         # identical contracts, evaluator and verdicts at c_cur


@pytest.mark.gate("S3-25")
@pytest.mark.gate("S3-54")
def test_n5_receives_no_f1_outputs_and_binding_vector():
    b = VEC["binding"]

    def cat(rows):
        c, born = ArtifactCatalog(None), {}
        for r in rows:
            e = c.add(request_slot=r["slot"], producer_type="otp", artifact_class="ROUTER", birth_cut_id="CUT:" + r["id"],
                      birth_frontier=(), logical_inputs=[], contract_ids=[], status="SUCCESS", provenance_digest=r["id"],
                      output_digests=[("id", r["id"])], cost={}, namespace="FIXTURE", binary_mode="FIXTURE_STUB_BINARY")
            born[e.artifact_id] = r["born_utc"]
            r["_aid"] = e.artifact_id
        return c, born
    sh, shb = cat([dict(x) for x in b["shared"]])
    f1o, f1b = cat([dict(x) for x in b["f1_overlay"]])
    n5o, n5b = cat([dict(x) for x in b["n5_overlay"]])
    ids = {v: k for k, v in {**{x: y for x, y in []}}.items()}
    _ = ids
    m_f1, m_n5 = MethodCatalog(sh, shb, f1o, f1b), MethodCatalog(sh, shb, n5o, n5b)
    slot = "ROUTER:region=R:A+B"
    got_f1, got_n5 = m_f1.bind(slot, b["tick"]), m_n5.bind(slot, b["tick"])
    assert got_f1[0].provenance_digest == b["expected_f1"] and got_n5[0].provenance_digest == b["expected_n5"]
    f1o.add(request_slot=slot, producer_type="otp", artifact_class="ROUTER", birth_cut_id="CUT:X", birth_frontier=(),
            logical_inputs=[], contract_ids=[], status="SUCCESS", provenance_digest="F1x", output_digests=[("id", "x")],
            cost={}, namespace="FIXTURE", binary_mode="FIXTURE_STUB_BINARY")
    assert m_n5.bind(slot, b["tick"]) == got_n5                       # N5 invariant to any F1 overlay change
    assert {f.name for f in dataclasses.fields(S.RequestBinding)} == {"request", "bindings", "contracts", "estimates"}
    exp = stats.StatisticsExporterImpl()
    t1 = trace("T1")
    n5_arm = [a for a in t1["campaign"]._arms if a.method == "N5"][0]
    with pytest.raises(core.EngineError):                             # N5 cannot be registered with a non-CurrentCutView
        exp.register("N5", "K2", S.N1CurrentView.__new__(S.N1CurrentView))
    assert n5_arm.mc.overlay is not [a for a in t1["campaign"]._arms if a.method == "F1"][0].mc.overlay


# ----------------------------------------------------------------------------------------------------- N1
@pytest.mark.gate("S3-26")
@pytest.mark.gate("S3-27")
@pytest.mark.gate("S3-28")
@pytest.mark.gate("S3-29")
@pytest.mark.gate("S3-55")
def test_n1_real_native_build_amended_evidence(real_producers, tmp_path):
    spec, deps, blobs, otp, val, canon = real_producers
    oracle = ROOT / "frozen_specs/authoritative/conformance/fixtures/oracle"
    b = baselines_n.RealNativeOtpBuilder(otp, tmp_path / "n1", "envelope")
    b.inputs["R:fx"] = {"osm": str(oracle / "base/street.osm.pbf"), "tz": "America/Los_Angeles",
                        "build_date": "2008-06-02", "feeds": {("A", "A#1"): str(oracle / "base/feedA.gtfs.zip"),
                                                              ("A", "A#2"): str(oracle / "o5/feedA.gtfs.zip")}}
    st = b.initial_state("R:fx")
    pp = b.preprocessing["R:fx"]
    assert pp["charged_once"] and pp["binary_mode"] == "REAL_PINNED_BINARY" and pp["wall_s"] > 0
    from f1.workload_c.contracts.model import EvaluationContext
    walls = []
    for idx, lv in ((1, "A#1"), (2, "A#2")):
        cut = Cut.of("R:fx", {"A": idx})
        req = S.ConsumerRequest("R:fx", S.canonical_request_slots("R:fx", ["A"]), "2008-06-03T13:00:00Z", cut,
                                EvaluationContext(cut.cut_id, {}, horizon=("2008-06-03",)))
        v = S.N1CurrentView(req, (("VAL:feed=A", None),), (), (("A", lv, "h"),), st,
                            (("VAL:feed=A", 600.0), ("ROUTER:region=R:fx", 5400.0)))
        step, st, ev = b.build(v)
        e = b.last_evidence
        assert step.outcome == "SUCCESS" and step.measured_wall_s == e["wall_s"]          # N1's own measured cost
        assert e["street_graph_loaded"] and e["frozen_config_identical"] and e["cache_tasks"] == ["ELEVATION",
                                                                                                  "VISIBILITY"]
        assert e["cache_status"] == baselines_n.CACHE_NO_TASK
        assert not any(v["applicable"] for v in e["cache_task_applicability"].values())
        assert e["otp_jar_sha256"].startswith("8acd2808")
        walls.append(step.measured_wall_s)
    # identical envelope: same java/JVM flags/wrappers as F1 router production
    job = tmp_path / "probe"
    job.mkdir()
    f1_prefix = otp.commands(job)[0][:otp.commands(job)[0].index("-jar") + 2]
    assert [str(otp.deps.java)] + otp.jvm_flags(job) + ["-jar", str(otp.deps.otp_jar)] == f1_prefix
    # no historical mechanism in N1 (signature + invariant)
    hints = typing.get_type_hints(S.N1Baseline.decide)
    assert "history" not in hints
    with pytest.raises(baselines_n.N1BlockedError):                          # an applicable task without activity
        cfg_dir = tmp_path / "dem"
        cfg_dir.mkdir()
        (cfg_dir / "x.tif").write_bytes(b"x")
        appl = baselines_n.applicable_cache_tasks(("ELEVATION", "VISIBILITY"), {}, cfg_dir, "Skipping visibility graph construction")
        if any(v["applicable"] for v in appl.values()):
            raise baselines_n.N1BlockedError("applicable task without cache activity")
    unknown = baselines_n.applicable_cache_tasks(("NEWTASK",), {}, tmp_path, "")
    assert unknown["NEWTASK"]["applicable"] is True                          # never assumed inapplicable


@pytest.mark.gate("S3-55")
def test_n1_preprocessing_charged_once_per_region():
    t2 = trace("T2")
    n1 = [r for r in t2["records"] if r["method"] == "N1"]
    pre = [i for r in n1 for i in r["costs"]["items"] if i["component"] == "n1_preprocessing"]
    assert len(pre) == 1 and pre[0]["wall_s"] == 3600.0


@pytest.mark.gate("S3-26")
def test_n1_fixture_builder_blocked_without_cache_evidence(tmp_path):
    b = baselines_n.FixtureNativeOtpBuilder(tmp_path, evidence_cache=False)
    st = b.initial_state("R:x", "env")
    from f1.workload_c.contracts.model import EvaluationContext
    cut = Cut.of("R:x", {"A": 1})
    req = S.ConsumerRequest("R:x", S.canonical_request_slots("R:x", ["A"]), "2025-06-10T13:00:00Z", cut,
                            EvaluationContext(cut.cut_id, {}, horizon=("d",)))
    with pytest.raises(baselines_n.N1BlockedError):
        b.build(S.N1CurrentView(req, (("VAL:feed=A", None),), (), (("A", "A#1", "h"),), st,
                                (("VAL:feed=A", 600.0), ("ROUTER:region=R:x", 5400.0))))


# ----------------------------------------------------------------------------------------------------- traces
@pytest.mark.gate("S3-47")
def test_identifiability_traces_t1_t4():
    t1, t2, t3, t4 = (trace(t) for t in ("T1", "T2", "T3", "T4"))
    for k in ("K0", "K1", "K2"):
        assert dec(t1, "F1", k)["action"] == "REUSE" and dec(t1, "F1", k)["rederivations"] == []
        assert [s["slot_id"] for s in dec(t1, "N5", k)["rederivations"]] == ["VAL:feed=A", "ROUTER:region=R:T1"]
        assert dec(t2, "F1", k)["opt_hist"] < dec(t2, "F1", k)["opt_current"]
        assert dec(t4, "F1", k)["mode"] == "CURRENT" and dec(t4, "F1", k)["opt_hist"] is None
    assert dec(t3, "F1", "K2")["action"] == "REUSE" and dec(t3, "N5", "K2")["action"] == "REUSE"
    assert dec(t3, "F1", "K0")["mode"] == "HISTORICAL"
    for t in (t1, t2, t3, t4):
        assert all(r["run"]["namespace"] == "FIXTURE" for r in t["records"])


# ----------------------------------------------------------------------------------------------------- vectors
@pytest.mark.gate("S3-53")
def test_repair_execution_vectors():
    reg = trace("T2")["region"]
    slots = ("VAL:feed=A", "VAL:feed=B", "ROUTER:region=R:T2")
    for name, case in VEC["repair_execution"].items():
        if name == "filtered_subset":
            continue
        outs = {s.replace("R:A+B", "R:T2"): o for s, o in case["outcomes"].items()}
        cut = Cut.of(reg.region_id, {"A": 1, "B": 1})
        mc = MethodCatalog(ArtifactCatalog(None), {}, ArtifactCatalog(None))
        cs = ContractSystem(reg.blobs, load_protocol_spec().gtfs_member_names)
        prod = InProcessFixtureProducer(reg, cs, CutContextFactoryImpl(reg),
                                        durations={"validator": 600.0, "otp": 5400.0}, outcomes=outs)
        prod.durations_by_slot = {"VAL:feed=A": 600.0, "VAL:feed=B": 610.0}
        orig = prod.produce

        def produce(slot, c, t, _o=orig, _p=prod):
            p = _o(slot, c, t)
            if slot in _p.durations_by_slot:
                p.wall_s = p.cpu_s = _p.durations_by_slot[slot]
            return p
        prod.produce = produce
        red = ProducerRederiver(reg, mc, prod)
        est = {"VAL:feed=A": 600.0, "VAL:feed=B": 610.0, "ROUTER:region=R:T2": 5400.0}
        plan = S.RepairPlan("r", S.Mode.CURRENT, cut, slots, tuple(S.RederivationStep(s, cut.cut_id,
                                                                                       core.producer_class_of(s), est[s])
                                                                    for s in slots), sum(est.values()), None, None)
        done = execute_plan(plan, lambda st, _r=red, _c=cut: _r.rederive(st.slot_id, _c, "2025-06-10T13:00:00Z",
                                                                          st.estimate_s))
        got = [{"slot": s.slot_id.replace("R:T2", "R:A+B"), "outcome": s.outcome,
                "wall_s": float(s.measured_wall_s or 0.0), "artifact": s.new_artifact_id is not None} for s in done.steps]
        assert got == case["expected_steps"], name
        assert [c[0] for c in prod.calls] == [s["slot"].replace("R:A+B", "R:T2") for s in case["expected_steps"]
                                              if s["outcome"] is not None]
        assert all(c[1] in (Cut.of(reg.region_id, {"A": 1}).cut_id, Cut.of(reg.region_id, {"B": 1}).cut_id, cut.cut_id)
                   for c in prod.calls)                                    # exact target cut, never a post-t version
    order = [s for s in slots if s in {"ROUTER:region=R:T2", "VAL:feed=B"}]
    assert order == ["VAL:feed=B", "ROUTER:region=R:T2"]


@pytest.mark.gate("S3-56")
def test_inference_vectors():
    inf = VEC["inference"]
    assert stats.int_seed("bootstrap") == inf["seeds"]["bootstrap"]
    assert stats.int_seed("wild-bootstrap") == inf["seeds"]["wild-bootstrap"]
    t, ci, z0, a = stats.bca(inf["region_values"])
    assert [t, list(ci), z0, a] == [inf["bca"]["theta"], inf["bca"]["ci95"], inf["bca"]["z0"], inf["bca"]["a"]]
    assert list(stats.wild(inf["region_values"])[1]) == inf["wild"]["ci95"]
    assert str(stats.sign_test_p(inf["sign_test"]["diffs"], "greater")) == inf["sign_test"]["p"]
    assert str(stats.sign_test_p(inf["sign_test_less"]["diffs"], "less")) == inf["sign_test_less"]["p"]
    import numpy
    assert numpy.__version__ == "2.4.4" and stats.B == 9999


@pytest.mark.gate("S3-51")
def test_interface_file_unchanged():
    dig = json.loads((PRE / "PRE_S3_FROZEN_DIGESTS.json").read_text())
    p = ROOT / "src/f1/workload_c/interfaces/session3.py"
    assert hashlib.sha256(p.read_bytes()).hexdigest() == dig["session3_interfaces_sha256"]
    assert S.INTERFACE_VERSION == "F1-WC-S3-INTERFACES-V1.2"


# ----------------------------------------------------------------------------------------------------- mutations
@pytest.mark.gate("S3-32")
def test_mutation_sample_ranked_deterministic():
    st = mutation.oracle_router_subjects()
    eng = mutation.MutationEngineImpl(st)
    ids = tuple(sorted(st.cls))
    p1, p2 = eng.plan(S.MutationPopulation("ROUTER", ids)), eng.plan(S.MutationPopulation("ROUTER", ids))
    assert p1 == p2 and len(p1.selected) == 2                                   # ceil(0.05 * 35)
    sp = load_protocol_spec()
    ranked = sorted(ids, key=lambda i: hashlib.sha256(sp.seed_bytes("mutation") + b"\x00" + i.encode()).digest())
    assert list(p1.selected) == ranked[:2]
    with pytest.raises(mutation.InvalidMutation):
        eng.plan(S.MutationPopulation("ROUTER", tuple(reversed(ids))))
    with pytest.raises(mutation.InvalidMutation):
        eng.plan(S.MutationPopulation("ROUTER", ids, seed_domain="bootstrap"))


@pytest.mark.gate("S3-33")
def test_mutation_families_exact_and_invalid_fail_closed():
    fam = set(mutation.FAMILIES)
    for f in ("stop_times", "frequencies", "calendar_dates", "transfers", "block_id", "coordinates", "pathways",
              "wheelchair", "route_type", "timezones", "namespace", "horizon", "shapes", "validator_date",
              "validator_file", "M-FUTURE-1", "M-FUTURE-2", "M-CT", "M-STOP-ACTIVE", "M-STOP-INACTIVE",
              "M-AGENCY-FUTURE", "M-AGENCY-ACTIVE"):
        assert f in fam
    assert {f for f in fam if f.startswith("M-FREQ")} == {"M-FREQ-IN", "M-FREQ-OUT"}
    eng = mutation.MutationEngineImpl(mutation.oracle_router_subjects())
    assert eng.apply("ORACLE:O14", "nonsense").status == "INVALID_MUTATION"
    assert eng.apply("ORACLE:O14", "validator_date").status == "INVALID_MUTATION"
    assert eng.apply("UNKNOWN", "stop_times").status == "INVALID_MUTATION"
    assert eng.apply("ORACLE:O14", "M-STOP-INACTIVE").status == "INVALID_MUTATION"
    v = mutation.MutationEngineImpl(mutation.MutationSubjectStore({"V": "VAL_REPORT"}, {"V": mutation.ValSubject(
        b"", "2025-01-01", [(b"", "2025-01-02", None, "date")])}))
    assert v.apply("V", "validator_date").status == "INVALID_MUTATION"        # no reference verdict -> fail closed
    assert v.apply("V", "validator_file").status == "INVALID_MUTATION"        # date-only comparison never used


@pytest.mark.gate("S3-34")
def test_mutation_detection_semantics_on_frozen_oracle():
    eng = mutation.MutationEngineImpl(mutation.oracle_router_subjects())
    ids = sorted(eng.store.cls)
    detected = {f: {a.split(":")[1] for a in ids if eng.apply(a, f).detected_missing_dependence}
                for f in ("stop_times", "transfers", "coordinates", "frequencies", "calendar_dates", "wheelchair")}
    assert "O5" in detected["stop_times"] and {"O8", "O17"} <= detected["transfers"]
    assert "O9" in detected["coordinates"] and detected["frequencies"] and "O7" in detected["calendar_dates"]
    for f in mutation.INPUT_FAMILIES:                      # without a Canon_D reference: fail closed, never assumed
        r = eng.apply("ORACLE:O14", f)
        assert r.status == "INVALID_MUTATION" and r.canon_changed is None, f
