import hashlib
import json
import multiprocessing as mp
import os
import subprocess
import sys

import pytest

from conftest import ROOT
from f1.workload_c.errors import (BlobCorruptionError, BlobMissingError, HashMismatchError, ImmutableOverwriteError,
                                  NamespaceViolation, StorageError)
from f1.workload_c.storage.blobstore import BlobStore, ManifestStore, SnapshotStore


@pytest.mark.gate("S1-03")
def test_first_and_duplicate_insert(tmp_path):
    bs = BlobStore(tmp_path)
    r1 = bs.put(b"hello", "text/plain", provenance={"src": "a"})
    assert r1.sha256 == hashlib.sha256(b"hello").hexdigest() and r1.size == 5 and r1.media_type == "text/plain"
    p = bs.path_of(r1.sha256)
    ino, mtime = p.stat().st_ino, p.stat().st_mtime_ns
    r2 = bs.put(b"hello", "application/other", provenance={"src": "b"})
    assert r2 == r1                                   # first-insert metadata is immutable
    assert p.stat().st_ino == ino and p.stat().st_mtime_ns == mtime   # never rewritten
    assert {x["src"] for x in bs.provenance(r1.sha256)} == {"a", "b"}
    assert oct(p.stat().st_mode & 0o777) == "0o444"
    assert bs.get(r1.sha256) == b"hello"
    assert list(bs.iter_keys()) == [r1.sha256]


@pytest.mark.gate("S1-03")
def test_restart_persistence_and_manifests(tmp_path):
    bs = BlobStore(tmp_path)
    h = bs.put(b"x" * 1000).sha256
    ms = ManifestStore(bs)
    m = ms.put({"schema": "s", "kind": "k", "namespace": "FIXTURE", "v": 1})
    bs2 = BlobStore(tmp_path)  # "process restart"
    assert bs2.get(h) == b"x" * 1000 and bs2.verify_all() == []
    assert ManifestStore(bs2).get(m.sha256, expect_namespace="FIXTURE")["v"] == 1
    with pytest.raises(NamespaceViolation):
        ManifestStore(bs2).get(m.sha256, expect_namespace="TEST")
    with pytest.raises(StorageError):
        ms.put({"schema": "s", "kind": "k"})
    with pytest.raises(NamespaceViolation):
        ms.put({"schema": "s", "kind": "k", "namespace": "PROD"})


@pytest.mark.gate("S1-03")
def test_snapshot_commit_idempotent_and_immutable(tmp_path):
    bs = BlobStore(tmp_path)
    ss = SnapshotStore(bs, ManifestStore(bs))
    a, b = bs.put(b"a").sha256, bs.put(b"b").sha256
    s1 = ss.commit("snap", {"x": a, "y": b}, "FIXTURE")
    assert ss.commit("snap", {"y": b, "x": a}, "FIXTURE") == s1     # order-independent, idempotent
    with pytest.raises(ImmutableOverwriteError):
        ss.commit("snap", {"x": b}, "FIXTURE")
    assert ss.load("snap")["entries"] == {"x": a, "y": b}
    with pytest.raises(BlobMissingError):
        ss.commit("other", {"x": "0" * 64}, "FIXTURE")


def _worker(args):
    root, i = args
    bs = BlobStore(root)
    out = []
    for k in range(40):
        out.append(bs.put(f"blob-{k % 10}".encode(), provenance={"w": i, "k": k}).sha256)
    return out


@pytest.mark.gate("S1-03")
def test_concurrent_multiprocess_inserts(tmp_path):
    with mp.get_context("fork").Pool(4) as pool:
        res = pool.map(_worker, [(str(tmp_path), i) for i in range(4)])
    assert all(r == res[0] for r in res)
    bs = BlobStore(tmp_path)
    assert len(list(bs.iter_keys())) == 10 and bs.verify_all() == []
    assert not list((tmp_path / "tmp").iterdir())


@pytest.mark.gate("S1-04")
def test_hash_mismatch_on_expected(tmp_path):
    bs = BlobStore(tmp_path)
    with pytest.raises(HashMismatchError):
        bs.put(b"data", expected_sha256="0" * 64)
    assert list(bs.iter_keys()) == []


@pytest.mark.gate("S1-04")
def test_corruption_detected_on_read_verify_and_reput(tmp_path):
    bs = BlobStore(tmp_path)
    h = bs.put(b"original content").sha256
    p = bs.path_of(h)
    os.chmod(p, 0o644)
    p.write_bytes(b"original contenT")
    with pytest.raises(BlobCorruptionError):
        bs.get(h)
    assert bs.verify_all() == [h]
    with pytest.raises(BlobCorruptionError):
        bs.put(b"original content")            # never silently "repairs" or overwrites
    p.write_bytes(b"orig")                     # truncation
    with pytest.raises(BlobCorruptionError):
        bs.get(h)


@pytest.mark.gate("S1-04")
def test_interrupted_write_in_process(tmp_path, monkeypatch):
    bs = BlobStore(tmp_path)
    real_link = os.link

    def boom(*a, **k):
        raise KeyboardInterrupt("simulated interruption between fsync and link")
    monkeypatch.setattr(os, "link", boom)
    with pytest.raises(KeyboardInterrupt):
        bs.put(b"payload")
    monkeypatch.setattr(os, "link", real_link)
    h = hashlib.sha256(b"payload").hexdigest()
    assert not bs.has(h)                       # no partial final object
    assert bs.put(b"payload").sha256 == h and bs.get(h) == b"payload"


@pytest.mark.gate("S1-04")
def test_interrupted_write_process_death(tmp_path):
    code = f"""
import os, sys
sys.path.insert(0, {str(ROOT / 'src')!r})
from f1.workload_c.storage.blobstore import BlobStore
bs = BlobStore({str(tmp_path)!r})
os.link = lambda *a, **k: os._exit(137)   # die after the temp file is fsynced, before the immutable link
bs.put(b"x" * 100000)
"""
    cp = subprocess.run([sys.executable, "-c", code])
    assert cp.returncode == 137
    leftovers = list((tmp_path / "tmp").glob(".tmp-*"))
    assert len(leftovers) == 1                 # only a temp file remains
    bs = BlobStore(tmp_path)
    h = hashlib.sha256(b"x" * 100000).hexdigest()
    assert not bs.has(h)
    assert bs.recover() == 1 and not list((tmp_path / "tmp").glob(".tmp-*"))
    assert bs.put(b"x" * 100000).sha256 == h and bs.verify_all() == []


@pytest.mark.gate("S1-04")
def test_provenance_record_corruption_detected(tmp_path):
    bs = BlobStore(tmp_path)
    h = bs.put(b"z", provenance={"a": 1}).sha256
    pf = next((tmp_path / "provenance").rglob("*.json"))
    os.chmod(pf, 0o644)
    pf.write_text(json.dumps({"blob": h, "provenance": {"a": 2}}))
    with pytest.raises(BlobCorruptionError):
        bs.provenance(h)
