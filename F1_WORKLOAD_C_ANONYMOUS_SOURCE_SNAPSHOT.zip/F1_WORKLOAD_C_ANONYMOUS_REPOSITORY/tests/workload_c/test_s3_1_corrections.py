"""Session 3.1 corrective gates S3-57..S3-66 and adversarial regression cases A–H (FIXTURE / frozen oracle only)."""
import copy
import dataclasses
import hashlib
import json
import shutil
from pathlib import Path

import pytest

from conftest import ROOT
from f1.workload_c.campaign import e2e_s3
from f1.workload_c.config.spec import load_protocol_spec
from f1.workload_c.engines import core, mutation, stats
from f1.workload_c.engines.core import EngineError
from f1.workload_c.engines.replay import ReplayEngineImpl
from test_s3_engines import trace

ORACLE = ROOT / "frozen_specs/authoritative/conformance/fixtures/oracle"
A = stats.FrozenAnalysisImpl()


def R(region, method, level, action, mode, units, rid, opt_c=None, opt_h=None, cost=1.0, cpu=None, reason=None,
      pre=None, pre_id=None):
    items = [{"category": "A_PRODUCER", "component": "producer:otp", "wall_s": cost,
              "cpu_s": cost if cpu is None else cpu, "slot_id": None, "producer_outcome": "SUCCESS"}]
    if pre is not None:
        items.append({"category": "A_PRODUCER", "component": "n1_preprocessing", "wall_s": pre, "cpu_s": pre,
                      "slot_id": pre_id or f"PREPROC:{region}", "producer_outcome": None})
    return {"run": {"namespace": "FIXTURE"}, "region_id": region, "request_id": rid, "method": method, "level": level,
            "action": action, "mode": mode, "root_changes": [list(u) for u in units], "opt_current": opt_c,
            "opt_hist": opt_h, "excluded": reason is not None, "exclusion_reason": reason, "costs": {"items": items}}


# ------------------------------------------------------------------------------------- CASE A / S3-57
@pytest.mark.gate("S3-57")
def test_case_a_paired_cap_excludes_all_primary_metrics():
    u = [("a", 2)]
    base = [R("R1", "F1", "K0", "REUSE", "HISTORICAL", u, "q1"),
            R("R1", "N5", "K0", "REDERIVE", "CURRENT", u, "q1", reason="OPERATIONAL_CAP")]
    pr = A.per_region(base)
    assert pr["R1"]["HSR_witness(K0)"] is None and pr["R1"]["units_witness_den(K0)"] == 0       # no contribution
    rev = [R("R1", "F1", "K0", "REDERIVE", "CURRENT", u, "q1", 5400.0, 600.0, reason="OPERATIONAL_CAP"),
           R("R1", "N5", "K0", "REUSE", "CURRENT", u, "q1")]
    p2 = A.per_region(rev)
    assert p2["R1"]["HSR_repair(K0)"] is None and p2["R1"]["DeltaCost_history(K0)"] == 0.0
    n1 = [R("R1", "F1", "K2", "REUSE", "HISTORICAL", u, "q1", cost=10.0),
          R("R1", "N5", "K2", "REDERIVE", "CURRENT", u, "q1", cost=50.0),
          R("R1", "N1", "K0", "REDERIVE", "CURRENT", u, "q1", cost=20.0, reason="OPERATIONAL_CAP", pre=7.0),
          R("R1", "F1", "K2", "REUSE", "CURRENT", u, "q2", cost=1.0),
          R("R1", "N5", "K2", "REUSE", "CURRENT", u, "q2", cost=1.0),
          R("R1", "N1", "K0", "REUSE", "CURRENT", u, "q2", cost=1.0)]
    p3 = A.per_region(n1)
    assert p3["R1"]["n_pairs_F1_N5(K2)"] == 1 and p3["R1"]["DeltaE2E_history(K2)"] == 0.0      # q1 excluded for ALL
    assert p3["R1"]["HSR_witness(K2)"] is None                                                 # F1 q1 excluded via N1 cap
    assert p3["R1"]["Cost_N1"] == 1.0 + 7.0                                                    # CASE C as well


# ------------------------------------------------------------------------------------- CASE B / S3-58
@pytest.mark.gate("S3-58")
def test_case_b_undefined_contrast_vs_defined_zero():
    recs = [R("R0", "F1", "K2", "REUSE", "CURRENT", [], "x", reason="OPERATIONAL_CAP"),
            R("R0", "N5", "K2", "REUSE", "CURRENT", [], "x"), R("R0", "N1", "K0", "REUSE", "CURRENT", [], "x", pre=0.0)]
    for i, reg in enumerate(("R1", "R2", "R3")):
        recs += [R(reg, "F1", "K2", "REUSE", "CURRENT", [], f"y{i}", cost=5.0),
                 R(reg, "N5", "K2", "REUSE", "CURRENT", [], f"y{i}", cost=5.0 if reg != "R3" else 8.0),
                 R(reg, "N1", "K0", "REUSE", "CURRENT", [], f"y{i}", cost=5.0, pre=0.0)]
    pr = A.per_region(recs)
    assert pr["R0"]["DeltaE2E_history(K2)"] is None and pr["R0"]["Native_contrast(K2)"] is None       # undefined
    assert pr["R1"]["DeltaE2E_history(K2)"] == 0.0 and pr["R1"]["Native_contrast(K2)"] == 0.0         # defined zero
    rep = {h.name: h for h in A.run(recs, "FIXTURE").hypotheses}
    assert rep["H_hist(K2)"].n_regions == 3 and rep["H_native(K2)"].n_regions == 3                    # R0 excluded
    assert rep["H_hist(K2)"].sign_test_p == 0.5                                                       # zeros dropped after
    assert pr["R0"]["DeltaE2E_history(K2)"] != pr["R1"]["DeltaE2E_history(K2)"]                      # never collapse


# ------------------------------------------------------------------------------------- CASE C / S3-59
@pytest.mark.gate("S3-59")
def test_case_c_n1_preprocessing_regional_once():
    recs = [R("R1", "F1", "K2", "REUSE", "CURRENT", [], "t1", cost=3.0),
            R("R1", "N5", "K2", "REUSE", "CURRENT", [], "t1", cost=3.0),
            R("R1", "N1", "K0", "REUSE", "CURRENT", [], "t1", cost=3.0, pre=3600.0, reason="OPERATIONAL_CAP"),
            R("R1", "F1", "K2", "REUSE", "CURRENT", [], "t2", cost=2.0),
            R("R1", "N5", "K2", "REUSE", "CURRENT", [], "t2", cost=2.0),
            R("R1", "N1", "K0", "REUSE", "CURRENT", [], "t2", cost=2.0)]
    pr = A.per_region(recs)
    assert pr["R1"]["Cost_N1"] == 2.0 + 3600.0 and pr["R1"]["N1_preprocessing"] == 3600.0       # charged once
    dup = recs + [R("R1", "N1", "K0", "REUSE", "CURRENT", [], "t3", cost=1.0, pre=3600.0)]       # same identity
    assert A.per_region(dup)["R1"]["N1_preprocessing"] == 3600.0                                  # de-duplicated
    bad = recs + [R("R1", "N1", "K0", "REUSE", "CURRENT", [], "t3", cost=1.0, pre=3600.0, pre_id="PREPROC:other")]
    with pytest.raises(EngineError):
        A.per_region(bad)
    missing = [r for r in recs if r["method"] != "N1"] + [R("R1", "N1", "K0", "REUSE", "CURRENT", [], "t2", cost=2.0)]
    with pytest.raises(EngineError):
        A.per_region(missing)                                                     # no silent zero
    t2 = trace("T2")
    pre = [i for r in t2["records"] for i in r["costs"]["items"] if i["component"] == "n1_preprocessing"]
    assert len(pre) == 1 and pre[0]["slot_id"].startswith("PREPROC:")


# ------------------------------------------------------------------------------------- S3-60 timers
@pytest.mark.gate("S3-60")
def test_catalog_lookup_journal_and_non_overlapping_timers():
    for r in trace("T2")["records"]:
        comps = [i["component"] for i in r["costs"]["items"] if i["category"] == "B_CONTROL_PLANE"]
        assert comps.count("catalog_lookup") == 1
    clock = {"t": 0.0}

    def tick():
        clock["t"] += 1.0
        return clock["t"]
    core.set_clock(tick)
    try:
        class Ev:
            wall_s = 0.0
        ev = Ev()
        tm = core.ControlTimer(ev)          # t = 1
        start = clock["t"]
        ev.wall_s = 0.5                     # half a second of evaluation inside the first interval
        tm.mark("admission")                # closes [1, 2]: 1.0 - 0.5 evaluate
        tm.mark("witness_search")           # closes [3, 4]
        tm.skip()                           # producer interval excluded
        tm.mark("repair_solver")
        end = clock["t"]
    finally:
        import time
        core.set_clock(time.perf_counter)
    total = sum(i.wall_s for i in tm.items)
    assert total <= end - start
    assert [i.component for i in tm.items] == ["evaluate", "admission", "witness_search", "repair_solver"]
    assert tm.items[0].wall_s == 0.5 and tm.items[1].wall_s == 0.5


# ------------------------------------------------------------------------------------- CASE H / S3-61
@pytest.mark.gate("S3-61")
def test_case_h_cpu_survives_to_export_and_replay(tmp_path):
    reg = trace("T2")["region"]
    from f1.workload_c.contracts.generators import ContractSystem

    class CpuProducer(core.InProcessFixtureProducer):
        def produce(self, slot_id, cut, tick_utc):
            p = super().produce(slot_id, cut, tick_utc)
            p.wall_s, p.cpu_s = 10.0, 3.0
            return p
    orig = e2e_s3.InProcessFixtureProducer
    e2e_s3.InProcessFixtureProducer = CpuProducer
    try:
        t = e2e_s3.run_trace("T2", tmp_path / "T2")
    finally:
        e2e_s3.InProcessFixtureProducer = orig
    r = [x for x in t["records"] if x["method"] == "N5" and x["level"] == "K2"][0]
    a = [i for i in r["costs"]["items"] if i["component"].startswith("producer:")]
    assert a and all(i["wall_s"] == 10.0 and i["cpu_s"] == 3.0 for i in a)
    raw = stats.RawExportLog.verify(Path(dict(t["ledger"].paths)["raw_export.jsonl"]))
    prod = [i for x in raw for i in x["costs"]["items"] if i["component"] in ("producer:otp", "producer:validator")]
    assert prod and all(i["wall_s"] == 10.0 and i["cpu_s"] == 3.0 for i in prod)
    rep = ReplayEngineImpl(load_protocol_spec().gtfs_member_names).replay(t["ledger"], ())
    assert all(i.status == "REPRODUCED" for i in rep.items)
    assert ContractSystem and reg


# ------------------------------------------------------------------------------------- CASE D/E / S3-62
@pytest.fixture(scope="module")
def canon_ref(real_producers, tmp_path_factory):
    spec, deps, blobs, otp, val, canon = real_producers
    return mutation.CanonReference(otp, str(ORACLE / "L0/street.osm.pbf"), "America/Los_Angeles", "2008-06-02",
                                   tmp_path_factory.mktemp("canonref"))


@pytest.mark.gate("S3-62")
def test_case_d_canon_reference_eq_despite_content_change(canon_ref):
    from f1.workload_c.ingestion.gtfs import canonical_content_hash
    from f1.workload_c.contracts.alignment import HORIZON
    a = (ORACLE / "L0/feedA.gtfs.zip").read_bytes()
    b = (ORACLE / "O14/feedA.gtfs.zip").read_bytes()
    names = load_protocol_spec().gtfs_member_names
    assert canonical_content_hash(a, names) != canonical_content_hash(b, names)        # content changed
    assert canon_ref.verdict({"A": a}, {"A": b}, list(HORIZON)) == "EQ"                 # Canon_D unchanged
    st = mutation.MutationSubjectStore({"X": "ROUTER"}, {"X": mutation.RouterSubject(
        {"A": a}, list(HORIZON), [({"A": b}, list(HORIZON), canon_ref.verdict({"A": a}, {"A": b}, list(HORIZON)), "L0->O14")])})
    r = mutation.MutationEngineImpl(st).apply("X", "calendar_dates")
    assert r.status == "APPLIED" and r.canon_changed is False and r.detected_missing_dependence is False


@pytest.mark.gate("S3-62")
def test_case_e_input_mutations_measured_and_bad_operator_exposed(canon_ref, monkeypatch):
    from f1.workload_c.contracts.alignment import HORIZON
    st = mutation.MutationSubjectStore({"X": "ROUTER"}, {"X": mutation.RouterSubject(
        {"A": (ORACLE / "base/feedA.gtfs.zip").read_bytes()}, list(HORIZON), [])})
    eng = mutation.MutationEngineImpl(st, canon_reference=canon_ref)
    for fam in ("M-FUTURE-1", "M-FUTURE-2", "M-STOP-ACTIVE"):
        r = eng.apply("X", fam)
        assert r.status == "APPLIED"
        exp = mutation.INPUT_FAMILIES[fam][0]
        assert r.canon_changed == exp, fam                          # MEASURED Canon_D agrees with the expectation
        assert r.contract_admits == (not exp), fam                   # unmutated K2 holds iff Canon unchanged
    assert all(x["match"] for x in eng.expectation_report)
    real = mutation.apply_input_mutation
    monkeypatch.setattr(mutation, "apply_input_mutation",
                        lambda z, D, f: z if f == "M-FUTURE-2" else real(z, D, f))       # defective operator
    eng2 = mutation.MutationEngineImpl(st, canon_reference=canon_ref)
    r = eng2.apply("X", "M-FUTURE-2")
    assert r.canon_changed is False                                  # measurement, NOT the expectation
    assert eng2.expectation_report[-1]["match"] is False and eng2.expectation_report[-1]["expected_canon_change"] is True


# ------------------------------------------------------------------------------------- S3-63
@pytest.mark.gate("S3-63")
def test_validator_date_and_file_subjects_distinct(real_producers, tmp_path):
    spec, deps, blobs, otp, val, canon = real_producers
    vref = mutation.ValidatorReference(val, tmp_path / "vref")
    z = (ORACLE / "base/feedA.gtfs.zip").read_bytes()
    zf = mutation.replace_member(z, "agency.txt", lambda b: b.replace(b"http://", b"not-a-url://")
                                 .replace(b"https://", b"not-a-url://"))
    zs = mutation.replace_member(z, "stops.txt", lambda b: b.replace(b"stop_lat", b"stop_lat", 1) + b"")
    assert zf != z
    d0, d1 = "2008-06-03", "2009-07-01"
    date_ref = vref.verdict(z, d0, z, d1)
    file_ref = vref.verdict(z, d0, zf, d0)
    assert date_ref == "NE" and file_ref == "NE"
    subj = mutation.ValSubject(z, d0, [(z, d1, date_ref, "date"), (zf, d0, file_ref, "file:agency.txt")])
    eng = mutation.MutationEngineImpl(mutation.MutationSubjectStore({"V": "VAL_REPORT"}, {"V": subj}))
    assert eng.apply("V", "validator_date").detected_missing_dependence is True      # positive (date)
    assert eng.apply("V", "validator_file").detected_missing_dependence is True      # positive (file)
    only_date = mutation.ValSubject(z, d0, [(z, d1, date_ref, "date")])
    eng2 = mutation.MutationEngineImpl(mutation.MutationSubjectStore({"V": "VAL_REPORT"}, {"V": only_date}))
    assert eng2.apply("V", "validator_file").status == "INVALID_MUTATION"            # date-only never reused for file
    other = mutation.replace_member(z, "stops.txt", lambda b: b.replace(b",", b", ", 1))
    neg_ref = vref.verdict(z, d0, other, d0)
    neg = mutation.ValSubject(z, d0, [(other, d0, neg_ref, "file:agency.txt")])      # agency omitted, stops differ
    eng3 = mutation.MutationEngineImpl(mutation.MutationSubjectStore({"V": "VAL_REPORT"}, {"V": neg}))
    r = eng3.apply("V", "validator_file")
    assert r.detected_missing_dependence is False                                    # negative (file)
    same_date = mutation.ValSubject(z, d0, [(z, d0, vref.verdict(z, d0, z, d0), "date")])
    eng4 = mutation.MutationEngineImpl(mutation.MutationSubjectStore({"V": "VAL_REPORT"}, {"V": same_date}))
    assert eng4.apply("V", "validator_date").detected_missing_dependence is False    # negative (date: EQ reference)
    assert zs


# ------------------------------------------------------------------------------------- S3-64
@pytest.mark.gate("S3-64")
def test_realized_history_populated_sealed_and_used():
    t1 = trace("T1")
    camp, led = t1["campaign"], t1["ledger"]
    hp = Path(dict(led.paths)["history.jsonl"])
    assert hp.exists() and led.history_journal_sha256 == hashlib.sha256(hp.read_bytes()).hexdigest()
    assert led.history_journal_sha256 != hashlib.sha256(Path(dict(led.paths)["schedule.json"]).read_bytes()).hexdigest()
    kinds = {e.kind for e in camp.history.events.values()}
    assert {"LOGICAL_VERSION_AVAILABLE", "ARTIFACT_BORN", "PRODUCER_COMPLETED", "CONSUMER_TICK"} <= kinds
    from f1.workload_c.engines.f1 import _check_realized
    from f1.workload_c.history.realized import Cut, RealizedHistory
    g = camp.gamma
    _check_realized(camp.history, Cut.of(camp.r.region_id, {"A": 1, "B": 1}), e2e_s3.TICK, g)
    with pytest.raises(EngineError):
        _check_realized(RealizedHistory(None), Cut.of(camp.r.region_id, {"A": 1, "B": 1}), e2e_s3.TICK, g)  # synthetic
    with pytest.raises(EngineError):
        _check_realized(None, Cut.of(camp.r.region_id, {"A": 1, "B": 1}), e2e_s3.TICK, g)
    with pytest.raises(EngineError):
        _check_realized(camp.history, Cut.of(camp.r.region_id, {"A": 2, "B": 1}), "2025-06-10T09:00:00Z", g)  # future


# ------------------------------------------------------------------------------------- CASE F/G / S3-65
@pytest.mark.gate("S3-65")
def test_case_f_g_semantic_digests_and_source_events(tmp_path):
    t1 = trace("T1")
    led = t1["ledger"]
    eng = ReplayEngineImpl(load_protocol_spec().gtfs_member_names)
    rep = eng.replay(led, ())
    hist_ids = {json.loads(ln)["kind"] and __import__("f1.workload_c.history.realized", fromlist=["Event"]).Event(
        **{k: (tuple(v) if k == "preds" else v) for k, v in json.loads(ln).items()
           if k in ("kind", "at_utc", "region_id", "feed_id", "payload", "preds")}).event_id
        for ln in Path(dict(led.paths)["history.jsonl"]).read_text().splitlines()}
    for it in rep.items:                                                          # CASE G
        assert it.source_event_ids and set(it.source_event_ids) <= hist_ids
    fields = ["history_journal_sha256", "contracts_sha256", "raw_export_sha256", "cost_ledger_sha256"]
    for f in fields:                                                              # CASE F
        bad = dataclasses.replace(led, **{f: "0" * 64})
        with pytest.raises(EngineError):
            eng.replay(bad, ())
    for k in range(len(led.catalog_journal_sha256s)):
        cats = list(led.catalog_journal_sha256s)
        cats[k] = (cats[k][0], "0" * 64)
        with pytest.raises(EngineError):
            eng.replay(dataclasses.replace(led, catalog_journal_sha256s=tuple(cats)), ())
    assert copy and shutil


# ------------------------------------------------------------------------------------- S3-66
@pytest.mark.gate("S3-66")
def test_deltacost_per_unit_mean_and_exact_binomial():
    u1, u2 = ("a", 2), ("b", 2)
    recs = [R("R1", "F1", "K0", "REDERIVE", "CURRENT", [u1], "1", 5400.0, 600.0),
            R("R1", "F1", "K0", "REDERIVE", "CURRENT", [u1, u2], "2", 5400.0, 1400.0),
            R("R2", "F1", "K0", "REUSE", "CURRENT", [u1], "3")]
    pr = A.per_region(recs)
    assert pr["R1"]["DeltaCost_history(K0)"] == 4800.0 + 4000.0
    assert pr["R1"]["DeltaCost_history_per_unit_mean(K0)"] == ((4800.0 + 4000.0) + 4000.0) / 2
    assert pr["R2"]["DeltaCost_history_per_unit_mean(K0)"] is None                    # zero denominator -> None
    d1, d2 = A.descriptive(recs), A.descriptive(list(reversed(recs)))
    assert d1 == d2
    rp = d1["prevalence"]["repair(K0)"]
    assert rp["regions_contributing"] == 1 and rp["regions_with_event"] == 1
    lo, hi = rp["exact_binomial_ci95"]
    assert abs(lo - 0.025) < 1e-9 and hi == 1.0                                      # Clopper–Pearson k=n=1
    assert stats._clopper_pearson(0, 0) is None
    lo, hi = stats._clopper_pearson(3, 10)
    assert abs(lo - 0.0667395) < 1e-6 and abs(hi - 0.6524529) < 1e-6
    rep = A.run(recs, "FIXTURE")
    assert [h.name for h in rep.hypotheses] == list(stats.HYPOTHESES)                  # still exactly four
