"""S1 correction gate (Session 2): INT-06 agency_id identity and INT-04 boarding-point connectivity regressions."""
import pytest

from f1.workload_c.fixturegen.gtfs_gen import offset
from f1.workload_c.ingestion.gtfs import GtfsSummary, Stop, summarize
from f1.workload_c.regions.connectivity import evaluate_pair
from f1.workload_c.regions.dedup import deduplicate
from f1.workload_c.regions.model import FeedFacts, FeedRecord


pytestmark = pytest.mark.gate("S2-02")

def rec(fid):
    return FeedRecord(fid, True, (), "active", 0, f"https://{fid}.example", f"P {fid}", f"N {fid}", (), None, None)


def facts(fid, h, ids, names):
    f = FeedFacts(fid, latest_canonical_sha256=h)
    f.latest_summary = GtfsSummary([Stop("s", 0, 0)], ["UTC"] * len(ids), list(names), agency_ids=list(ids))
    return f


@pytest.mark.gate("S1-14")
@pytest.mark.gate("S2-05")
def test_same_display_name_distinct_agency_ids_is_not_a_bundle():
    R = {"a": rec("a"), "b": rec("b")}
    F = {"a": facts("a", "h1", ["X1", "X2"], ["City Transit", "Metro"]),
         "b": facts("b", "h2", ["Y1"], ["City Transit"])}
    d = deduplicate(R, F, list(R), 0.5)
    assert d["a"].kept and d["b"].kept


@pytest.mark.gate("S1-14")
@pytest.mark.gate("S2-05")
def test_identical_agency_ids_trigger_bundle_regardless_of_names():
    R = {"a": rec("a"), "b": rec("b")}
    F = {"a": facts("a", "h1", ["X1", "X2"], ["Alpha", "Beta"]),
         "b": facts("b", "h2", ["X1"], ["Completely Different Name"])}
    d = deduplicate(R, F, list(R), 0.5)
    assert d["a"].reason == "DEDUP_MERGED_BUNDLE" and d["a"].collapsed_into == "b" and d["b"].kept


@pytest.mark.gate("S1-14")
@pytest.mark.gate("S2-05")
def test_blank_agency_ids_and_case_are_exact():
    R = {"a": rec("a"), "b": rec("b"), "c": rec("c")}
    F = {"a": facts("a", "h1", ["", ""], ["A", "B"]),          # no agency_id -> no identity -> never a bundle
         "b": facts("b", "h2", [""], ["A"]),
         "c": facts("c", "h3", ["x1"], ["Q"])}
    d = deduplicate(R, F, list(R), 0.5)
    assert all(v.kept for v in d.values())
    F2 = {"a": facts("a", "h1", ["AG1", "AG2"], ["n", "m"]), "b": facts("b", "h2", ["ag1"], ["n"]),
          "c": facts("c", "h3", ["zz"], ["q"])}
    assert deduplicate(R, F2, list(R), 0.5)["a"].kept         # 'AG1' != 'ag1': exact string identity


@pytest.mark.gate("S1-14")
@pytest.mark.gate("S2-05")
def test_summary_reads_agency_ids():
    import io
    import zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("agency.txt", "agency_id,agency_name,agency_url,agency_timezone\nA1,Same,u,UTC\nA2,Same,u,UTC\n")
        z.writestr("stops.txt", "stop_id,stop_name,stop_lat,stop_lon\ns,S,1,1\n")
    s = summarize(buf.getvalue())
    assert s.agency_ids == ["A1", "A2"] and s.agency_names == ["Same", "Same"]


def ff(fid, stops, tz="Europe/Paris"):
    f = FeedFacts(fid, in_force_lv=f"{fid}#L00001")
    f.in_force_summary = GtfsSummary(stops, [tz], [f"Ag {fid}"])
    return f


def line(prefix, dy, n, lt=""):
    return [Stop(f"{prefix}{k}", *offset(45, 7, k * 1000.0, dy), lt) for k in range(n)]


@pytest.mark.gate("S1-15")
@pytest.mark.gate("S2-06")
@pytest.mark.parametrize("lt", ["1", "2", "3", "4"])
def test_non_boarding_entities_do_not_inflate_stop_pairs(cfg, lt):
    """Feed b has 2 real platforms near feed a plus 3 co-located entities of location_type lt: still < 3 pairs."""
    a = line("a", 0, 5)
    b = line("p", 30, 2) + [Stop(f"e{k}", *offset(45, 7, 2000.0 + k * 1000.0, 30), lt) for k in range(3)]
    e, ev = evaluate_pair(cfg, ff("a", a), ff("b", b))
    assert e is None and ev["stop_pairs"] == 2 and "STOP_PAIRS_BELOW_THRESHOLD" in ev["reasons"]
    b_ok = line("p", 30, 2) + [Stop("p2", *offset(45, 7, 2000.0, 30), "0")]
    e2, ev2 = evaluate_pair(cfg, ff("a", a), ff("b", b_ok))
    assert e2 is not None and e2.stop_pairs == 3          # explicit location_type 0 counts like blank


@pytest.mark.gate("S1-15")
@pytest.mark.gate("S2-06")
def test_feed_with_only_stations_has_no_boarding_points(cfg):
    a = line("a", 0, 5)
    st = line("s", 30, 5, "1")
    e, ev = evaluate_pair(cfg, ff("a", a), ff("b", st))
    assert e is None and ev["reasons"] == ["NO_BOARDING_POINTS"]


@pytest.mark.gate("S1-15")
@pytest.mark.gate("S2-06")
def test_summary_records_location_type():
    import io
    import zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("agency.txt", "agency_id,agency_name,agency_url,agency_timezone\nA,A,u,UTC\n")
        z.writestr("stops.txt", "stop_id,stop_name,stop_lat,stop_lon,location_type,parent_station\n"
                                "st,Station,1,1,1,\np1,Plat,1,1,0,st\np2,Plat2,1,1,,st\nen,Entr,1,1,2,st\n")
    s = summarize(buf.getvalue())
    assert sorted(x.stop_id for x in s.boarding_stops) == ["p1", "p2"] and len(s.stops) == 4
