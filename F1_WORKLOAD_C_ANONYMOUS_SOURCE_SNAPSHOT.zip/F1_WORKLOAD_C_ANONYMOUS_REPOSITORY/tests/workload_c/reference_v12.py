"""PRE-S3 V1.2 SPECIFICATION ORACLES (test-only). These are executable restatements of the frozen conventions in
docs/pre_s3/V1_2_DETERMINISTIC_FREEZE.md; they are NOT the Session-3 implementations. Session 3 must reproduce the
reference vectors docs/pre_s3/V1_2_REFERENCE_VECTORS.json exactly (gates S3-52..S3-56)."""
from __future__ import annotations

import hashlib
import math
from fractions import Fraction
from statistics import NormalDist

PRIORS = {"validator": 600.0, "otp": 5400.0}


# ---------------------------------------------------------------------------------------------- est(s, t)
def est_reference(producer_class: str, prior) -> float:
    """Ordinary arithmetic median of SUCCESS wall seconds in a PriorCostView; prior constant when empty."""
    xs = sorted(o.wall_s for o in prior.observations if o.producer_class == producer_class and o.outcome == "SUCCESS")
    n = len(xs)
    if n == 0:
        return PRIORS[producer_class]
    if n % 2 == 1:
        return float(xs[n // 2])
    return (xs[n // 2 - 1] + xs[n // 2]) / 2.0


# ---------------------------------------------------------------------------------------------- binding rule
def bind_reference(slot_id: str, shared: list[dict], own_overlay: list[dict], tick_utc: str) -> dict | None:
    """Latest instance of the slot with born_utc <= t from shared + the method's OWN overlay.
    Tie on born_utc: overlay instance preferred over shared; then higher instance number."""
    cands = [(i["born_utc"], 0, i["instance"], i) for i in shared if i["slot"] == slot_id and i["born_utc"] <= tick_utc]
    cands += [(i["born_utc"], 1, i["instance"], i) for i in own_overlay if i["slot"] == slot_id and i["born_utc"] <= tick_utc]
    return max(cands, key=lambda c: c[:3])[3] if cands else None


# ---------------------------------------------------------------------------------------------- repair execution
ARTIFACT = ("SUCCESS", "SEMANTIC_FAIL")


def execute_reference(request_slots: tuple[str, ...], failing: set[str], target_versions: dict, producer_outcomes: dict,
                      durations: dict, available_after_t: dict) -> list[dict]:
    """Serial, canonical-order, fail-fast execution. Every step uses exactly the target cut's versions (decided at t);
    versions that became available after t are never observed. Unattempted steps: outcome None, cost 0."""
    steps, stopped = [], False
    for slot in [s for s in request_slots if s in failing]:
        if stopped:
            steps.append({"slot": slot, "outcome": None, "wall_s": 0.0, "inputs": None, "artifact": False})
            continue
        oc = producer_outcomes.get(slot, "SUCCESS")
        steps.append({"slot": slot, "outcome": oc, "wall_s": float(durations.get(slot, 0.0)),
                      "inputs": dict(sorted(target_versions.items())), "artifact": oc in ARTIFACT,
                      "ignored_post_t_versions": dict(sorted(available_after_t.items()))})
        if oc not in ARTIFACT:
            stopped = True
    return steps


# ---------------------------------------------------------------------------------------------- inference
def int_seed(domain: str) -> int:
    master = hashlib.sha256(b"F1-SIGMOD2027-WORKLOAD-C-PROTOCOL-V4-MASTER-SEED").hexdigest()
    return int.from_bytes(hashlib.sha256((master + "|" + domain).encode()).digest()[:8], "big")


def sign_test_p(diffs: list[float], direction: str) -> Fraction:
    """Exact one-sided sign test over regions; zeros dropped; direction 'greater' (H: effect > 0) or 'less'."""
    nz = [d for d in diffs if d != 0]
    n = len(nz)
    if n == 0:
        return Fraction(1)
    k = sum(1 for d in nz if (d > 0 if direction == "greater" else d < 0))
    return Fraction(sum(math.comb(n, j) for j in range(k, n + 1)), 2 ** n)


def bca_reference(region_values: dict, B: int = 9999, domain: str = "bootstrap", level: float = 0.95):
    """BCa for the mean of region-level values; regions sorted by id; numpy Generator(PCG64(int_seed)) with
    rng.integers(0, n, size=(B, n)); z0 from (#< + 0.5 #==)/B clamped to [1/(2B), 1-1/(2B)]; acceleration by
    leave-one-region-out jackknife (a = 0 when degenerate); endpoints = order statistics ceil(alpha*B) (1-based)."""
    import numpy as np
    ids = sorted(region_values)
    x = np.array([float(region_values[i]) for i in ids])
    n = len(x)
    theta = float(x.mean())
    rng = np.random.Generator(np.random.PCG64(int_seed(domain)))
    idx = rng.integers(0, n, size=(B, n))
    boots = np.sort(x[idx].mean(axis=1))
    p0 = (np.sum(boots < theta) + 0.5 * np.sum(boots == theta)) / B
    p0 = min(max(p0, 1 / (2 * B)), 1 - 1 / (2 * B))
    nd = NormalDist()
    z0 = nd.inv_cdf(p0)
    jack = np.array([np.delete(x, i).mean() for i in range(n)])
    d = jack.mean() - jack
    den = 6.0 * float(np.sum(d ** 2)) ** 1.5
    a = float(np.sum(d ** 3)) / den if den > 0 else 0.0
    out = []
    for q in ((1 - level) / 2, 1 - (1 - level) / 2):
        z = nd.inv_cdf(q)
        alpha = nd.cdf(z0 + (z0 + z) / (1 - a * (z0 + z)))
        k = min(max(math.ceil(alpha * B), 1), B)
        out.append(float(boots[k - 1]))
    return theta, tuple(out), z0, a


def wild_reference(region_values: dict, B: int = 9999, domain: str = "wild-bootstrap", level: float = 0.95):
    """Wild-cluster (region) bootstrap of the mean: replicate_b = mean + mean_i(w_bi (x_i - mean)), w = 2*U{0,1}-1 from
    numpy Generator(PCG64(int_seed)) rng.integers(0, 2, size=(B, n)); percentile interval by order statistics."""
    import numpy as np
    ids = sorted(region_values)
    x = np.array([float(region_values[i]) for i in ids])
    m = float(x.mean())
    rng = np.random.Generator(np.random.PCG64(int_seed(domain)))
    w = rng.integers(0, 2, size=(B, len(x))) * 2 - 1
    reps = np.sort(m + (w * (x - m)).mean(axis=1))
    lo = reps[min(max(math.ceil((1 - level) / 2 * B), 1), B) - 1]
    hi = reps[min(max(math.ceil((1 - (1 - level) / 2) * B), 1), B) - 1]
    return m, (float(lo), float(hi))
