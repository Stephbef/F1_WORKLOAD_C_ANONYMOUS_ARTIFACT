import csv
import importlib.util
import zipfile
from dataclasses import replace

import pytest

from conftest import ROOT
from f1.workload_c.errors import GtfsFormatError
from f1.workload_c.fixturegen.gtfs_gen import FeedContent, FStop, ZipStyle, build_zip
from f1.workload_c.ingestion.gtfs import ArchiveRecord, canonical_content_hash, summarize
from f1.workload_c.versioning.logical import build_logical_versions, ledger_digest, version_in_force

TOOL = ROOT / "frozen_specs/authoritative/tools/logical_versions.py"
_spec = importlib.util.spec_from_file_location("frozen_lv", TOOL)
frozen = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(frozen)

C = FeedContent("T", (("A1", "Agency T", "Europe/Paris"),),
                (FStop("s1", 48.85, 2.35), FStop("s2", 48.86, 2.36), FStop("s3", 48.87, 2.37)))
STYLES = [ZipStyle(), ZipStyle(date_time=(2026, 5, 4, 3, 2, 0)), ZipStyle(compression=zipfile.ZIP_STORED),
          ZipStyle(order_rotation=3), ZipStyle(crlf=True), ZipStyle(bom=True), ZipStyle(folder="gtfs/"),
          ZipStyle(extra_member=True), ZipStyle((2030, 1, 1, 0, 0, 0), zipfile.ZIP_STORED, 5, True, True, "x/", True)]


@pytest.fixture(scope="module")
def names(spec):
    return spec.gtfs_member_names


@pytest.mark.gate("S1-09")
@pytest.mark.parametrize("style", STYLES)
def test_packaging_variants_equal(style, names, tmp_path):
    a, b = build_zip(C), build_zip(C, style)
    if style != ZipStyle():
        assert a != b                             # different raw bytes
    assert canonical_content_hash(a, names) == canonical_content_hash(b, names)
    p = tmp_path / "b.zip"
    p.write_bytes(b)
    assert frozen.canonical_hash(str(p)) == canonical_content_hash(b, names)


@pytest.mark.gate("S1-09")
@pytest.mark.parametrize("change", [dict(headway_min=10), dict(weekday_pattern="1111110"),
                                    dict(calendar_dates=(("S1", "20270105", 2),)), dict(feed_info_version="v2"),
                                    dict(stops=C.stops[:2])])
def test_meaningful_difference_unequal(change, names):
    assert canonical_content_hash(build_zip(C), names) != canonical_content_hash(build_zip(replace(C, **change)), names)


@pytest.mark.gate("S1-09")
def test_member_rules_exact(names, tmp_path):
    import io
    def mk(members):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            for n, b in members:
                z.writestr(n, b)
        return buf.getvalue()
    base = mk([("stops.txt", b"a\nb\n")])
    assert canonical_content_hash(mk([("STOPS.TXT", b"a\nb\n")]), names) == canonical_content_hash(base, names)
    assert canonical_content_hash(mk([("stops.txt", b"a\nb\n"), ("notes.txt", b"z")]), names) == \
        canonical_content_hash(base, names)
    # no extra normalisation: trailing whitespace and lone CR are significant
    assert canonical_content_hash(mk([("stops.txt", b"a \nb\n")]), names) != canonical_content_hash(base, names)
    assert canonical_content_hash(mk([("stops.txt", b"a\rb\r")]), names) != canonical_content_hash(base, names)
    for m in ([("stops.txt", b"a\nb\n"), ("dir/stops.txt", b"q")], [("Agency.txt", b"\xef\xbb\xbfx\r\n")]):
        z = mk(m)
        p = tmp_path / "m.zip"
        p.write_bytes(z)
        assert frozen.canonical_hash(str(p)) == canonical_content_hash(z, names)
    with pytest.raises(GtfsFormatError):
        canonical_content_hash(b"not a zip", names)


@pytest.mark.gate("S1-09")
def test_summary_parsing(spec):
    s = summarize(build_zip(C, ZipStyle(bom=True, crlf=True)))
    assert [x.stop_id for x in s.stops] == ["s1", "s2", "s3"] and s.timezone == "Europe/Paris"
    with pytest.raises(GtfsFormatError):
        summarize(build_zip(replace(C, malformed="no_stops")))
    import io
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:      # duplicated basename: the shallowest member is read (deterministic)
        src = zipfile.ZipFile(io.BytesIO(build_zip(C)))
        for n in src.namelist():
            z.writestr(n, src.read(n))
        z.writestr("old/stops.txt", "stop_id,stop_name,stop_lat,stop_lon\nzz,Z,1,1\n")
    assert [x.stop_id for x in summarize(buf.getvalue()).stops] == ["s1", "s2", "s3"]
    with pytest.raises(GtfsFormatError):
        summarize(build_zip(replace(C, malformed="bad_coords")))


def arch(fid, aid, t, h, status="OK"):
    return ArchiveRecord("FIXTURE", fid, aid, {}, t, "2026-10-08T00:00:00Z", "r" + aid, h, 10, {}, {}, status)


@pytest.mark.gate("S1-10")
def test_A_A_collapse():
    v = build_logical_versions([arch("f", "a1", "2025-01-01T00:00:00Z", "A"), arch("f", "a2", "2025-02-01T00:00:00Z", "A")])
    assert len(v) == 1 and v[0].archive_ids == ("a1", "a2") and v[0].first_observed_utc == "2025-01-01T00:00:00Z"
    assert v[0].logical_version_id == "f#L00001"


@pytest.mark.gate("S1-11")
def test_A_B_two_versions():
    v = build_logical_versions([arch("f", "a2", "2025-02-01T00:00:00Z", "B"), arch("f", "a1", "2025-01-01T00:00:00Z", "A")])
    assert [x.canonical_content_sha256 for x in v] == ["A", "B"] and [x.index for x in v] == [1, 2]
    assert version_in_force(v, "2025-01-15T00:00:00Z").canonical_content_sha256 == "A"
    assert version_in_force(v, "2025-02-01T00:00:00Z").canonical_content_sha256 == "B"
    assert version_in_force(v, "2024-12-31T00:00:00Z") is None


@pytest.mark.gate("S1-12")
def test_A_B_A_recurrence_three_events():
    recs = [arch("f", f"a{i}", f"2025-0{i + 1}-01T00:00:00Z", h) for i, h in enumerate("AABBA")]
    v = build_logical_versions(recs)
    assert [x.canonical_content_sha256 for x in v] == ["A", "B", "A"]
    assert [x.archive_ids for x in v] == [("a0", "a1"), ("a2", "a3"), ("a4",)]
    assert v[2].first_observed_utc == "2025-05-01T00:00:00Z"


@pytest.mark.gate("S1-12")
def test_failed_archives_skipped_and_idempotent_permutation():
    recs = [arch("f", "a1", "2025-01-01T00:00:00Z", "A"), arch("f", "a2", "2025-02-01T00:00:00Z", "", "SOURCE_LOCATOR_FAILURE"),
            arch("f", "a3", "2025-03-01T00:00:00Z", "A"), arch("g", "b1", "2025-01-01T00:00:00Z", "X")]
    v1 = build_logical_versions(recs)
    assert [x.logical_version_id for x in v1] == ["f#L00001", "g#L00001"]
    assert ledger_digest(build_logical_versions(list(reversed(recs)))) == ledger_digest(v1)
    assert ledger_digest(build_logical_versions(recs)) == ledger_digest(v1)
    with pytest.raises(ValueError):
        build_logical_versions(recs + [arch("f", "a1", "2025-04-01T00:00:00Z", "B")])


@pytest.mark.gate("S1-12")
def test_engine_equals_frozen_tool_on_real_zips(names, tmp_path):
    seq = [(C, ZipStyle()), (C, ZipStyle(crlf=True)), (replace(C, headway_min=10), ZipStyle()), (C, ZipStyle(bom=True))]
    rows, recs = [], []
    for i, (c, st) in enumerate(seq):
        b = build_zip(c, st)
        p = tmp_path / f"{i}.zip"
        p.write_bytes(b)
        t = f"2025-0{i + 1}-01T00:00:00Z"
        rows.append({"feed_id": "f", "archive_id": f"a{i}", "archive_observed_utc": t, "zip_path": str(p)})
        recs.append(arch("f", f"a{i}", t, canonical_content_hash(b, names)))
    ours = [{"feed_id": v.feed_id, "logical_version_id": v.logical_version_id,
             "canonical_content_sha256": v.canonical_content_sha256, "first_observed_utc": v.first_observed_utc,
             "archive_ids": list(v.archive_ids)} for v in build_logical_versions(recs)]
    assert ours == frozen.build(rows) and len(ours) == 3     # A, A(repacked CRLF), B, A(BOM) -> 3


@pytest.mark.gate("S1-12")
def test_fixture_run_logical_ledger_matches_frozen_tool(full_run):
    rows = list(csv.DictReader(open(full_run["dir"] / "phases/03_logical_versions/logical_versions.csv")))
    assert len(rows) > 150
    assert any(r["archive_ids"].count(";") > 5 for r in rows)          # collapsed repacks (A,A,...)
    by_feed = {}
    for r in rows:
        by_feed.setdefault(r["feed_id"], []).append(r["canonical_content_sha256"])
    assert any(len(v) == 3 and v[0] == v[2] != v[1] for v in by_feed.values())   # A,B,A in the fixture
