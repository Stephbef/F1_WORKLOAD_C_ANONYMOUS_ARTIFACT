import csv
import hashlib
import json
import random
import subprocess
import sys

import pytest

from conftest import ROOT, make_orchestrator, read_csv
from f1.workload_c.errors import PopulationShortfall
from f1.workload_c.selection.hashrank import rank, select_and_split, selection_proof_rows, split_proof_rows

TOOL = ROOT / "frozen_specs/authoritative/tools/select_regions_hashrank.py"
EXPECTED = json.loads((ROOT / "fixtures/expected/fixture_population_expected.json").read_text())


def frozen_tool(ids, tmp_path):
    inp, out = tmp_path / "in.csv", tmp_path / "out.csv"
    with open(inp, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["region_id"])
        w.writerows([[i] for i in ids])
    cp = subprocess.run([sys.executable, str(TOOL), str(inp), str(out)], capture_output=True, text=True)
    return cp, (list(csv.DictReader(open(out))) if out.exists() else [])


SYNTH = [f"R:mdb-{i}+mdb-{i + 1}" for i in range(2000, 2100, 2)]


@pytest.mark.gate("S1-18")
def test_rank_definition_bytes(spec):
    master = hashlib.sha256(b"F1-SIGMOD2027-WORKLOAD-C-PROTOCOL-V4-MASTER-SEED").hexdigest()
    sb = hashlib.sha256((master + "|region-selection").encode()).digest()
    rid = "R:mdb-1+mdb-2"
    assert rank(spec, "region-selection", rid) == hashlib.sha256(sb + b"\x00" + rid.encode()).digest()


@pytest.mark.gate("S1-18")
def test_first_24_equals_frozen_tool(spec, tmp_path):
    res = select_and_split(spec, SYNTH)
    cp, rows = frozen_tool(SYNTH, tmp_path)
    assert cp.returncode == 0
    assert sorted(r["region_id"] for r in rows) == sorted(res.selected)
    assert [r["region_id"] for r in rows] == list(res.split_order)
    assert [r["selection_rank_hex"] for r in rows] == [rank(spec, "region-selection", r).hex() for r in res.split_order]
    ranks = [rank(spec, "region-selection", r) for r in res.selection_order]
    assert ranks == sorted(ranks) and list(res.selected) == list(res.selection_order[:24])
    proof = selection_proof_rows(spec, res)
    assert len(proof) == len(SYNTH) and sum(p["selected"] == "1" for p in proof) == 24


@pytest.mark.gate("S1-18")
def test_shortfall_fails_never_reduces(spec, tmp_path):
    with pytest.raises(PopulationShortfall) as e:
        select_and_split(spec, SYNTH[:23])
    assert "B1 FAIL — POPULATION TARGET UNSATISFIED" in str(e.value)
    cp, _ = frozen_tool(SYNTH[:23], tmp_path)
    assert cp.returncode != 0 and "B1 FAIL" in cp.stderr
    assert len(select_and_split(spec, SYNTH[:24]).selected) == 24


@pytest.mark.gate("S1-19")
def test_split_8_16_independent_domain(spec, tmp_path):
    res = select_and_split(spec, SYNTH)
    assert len(res.validation) == 8 and len(res.test) == 16 and not set(res.validation) & set(res.test)
    assert set(res.validation) | set(res.test) == set(res.selected)
    sr = [rank(spec, "validation-test", r) for r in res.split_order]
    assert sr == sorted(sr)
    assert list(res.split_order) != list(res.selected)       # independent ordering from the selection domain
    _, rows = frozen_tool(SYNTH, tmp_path)
    assert [r["region_id"] for r in rows if r["split"] == "validation"] == list(res.validation)
    assert [r["region_id"] for r in rows if r["split"] == "test"] == list(res.test)
    assert [r["split"] for r in split_proof_rows(spec, res)] == ["VALIDATION"] * 8 + ["TEST"] * 16


@pytest.mark.gate("S1-20")
def test_selection_input_permutation_invariance(spec):
    ref = select_and_split(spec, SYNTH)
    for seed in range(25):                       # test-only shuffles of the INPUT order (never used by the engine)
        ids = list(SYNTH) + list(SYNTH[:5])      # also duplicates
        random.Random(seed).shuffle(ids)
        assert select_and_split(spec, ids) == ref


@pytest.mark.gate("S1-18")
def test_fixture_selection_matches_frozen_expectation(full_run):
    d = full_run["dir"] / "phases"
    assert [r["region_id"] for r in read_csv(d / "06_select_24/selected_24.csv")] == EXPECTED["selected_24_in_rank_order"]
    proof = read_csv(d / "06_select_24/selection_proof.csv")
    assert len(proof) == EXPECTED["n_eligible_regions"] == 33     # every eligible region with its digest
    assert all(len(p["selection_rank_hex"]) == 64 for p in proof)


@pytest.mark.gate("S1-19")
def test_fixture_split_matches_frozen_expectation(full_run):
    d = full_run["dir"] / "phases/07_split_8_16"
    assert [r["region_id"] for r in read_csv(d / "validation_8.csv")] == EXPECTED["validation_8"]
    assert [r["region_id"] for r in read_csv(d / "test_16.csv")] == EXPECTED["test_16"]
    assert len(read_csv(d / "split_proof.csv")) == 24


@pytest.mark.gate("S1-20")
def test_full_pipeline_invariant_to_catalog_and_dataset_order(cfg, tmp_path, full_run):
    """Re-run phases 00-07 with the mock catalog and every dataset list reversed: identical outputs."""
    from f1.workload_c.campaign.orchestrator import FailureInjection
    o, w = make_orchestrator(cfg, tmp_path, run_id="perm", injection=FailureInjection({"08_osm_pinning": "FAIL"}))
    srv = w["services"]["server"]
    srv.catalog.reverse()
    for k in srv.datasets:
        srv.datasets[k].reverse()
    res = o.run()
    assert res.status == "FAILED" and res.stopped_at == "08_osm_pinning"
    for rel in ("05_eligible_regions/eligible_population.csv", "05_eligible_regions/excluded_population.csv",
                "05_eligible_regions/region_connectivity_evidence.jsonl", "03_logical_versions/logical_versions.csv",
                "06_select_24/selection_proof.csv", "07_split_8_16/split_proof.csv", "04_license_gate/license_ledger.csv"):
        assert (res.run_dir / "phases" / rel).read_bytes() == (full_run["dir"] / "phases" / rel).read_bytes(), rel
