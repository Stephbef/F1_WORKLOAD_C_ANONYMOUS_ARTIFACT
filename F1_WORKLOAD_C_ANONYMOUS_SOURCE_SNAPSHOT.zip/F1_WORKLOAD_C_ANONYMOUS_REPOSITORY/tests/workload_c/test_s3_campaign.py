"""Session-3 integration gates: input/baseline, replay, export, analysis, firewall, orchestrator, negative battery."""
import csv
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from conftest import ROOT, read_jsonl
from f1.workload_c.engines import stats
from f1.workload_c.engines.replay import ReplayEngineImpl, logical_view
from f1.workload_c.errors import NamespaceViolation
from f1.workload_c.interfaces import session3 as S
from test_s3_engines import trace

PRE = ROOT / "docs" / "pre_s3"
REPORTS = Path(os.environ.get("F1_WC_REPORT_DIR", ROOT / "reports"))
DIG = json.loads((PRE / "PRE_S3_FROZEN_DIGESTS.json").read_text())


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


@pytest.mark.gate("S3-01")
def test_input_integrity_recorded():
    ev = json.loads((ROOT / "docs/s3/S3_INPUT_EVIDENCE.json").read_text())
    assert ev["input_zip_sha256"] == "fe0dd2b24343bd077791c33b8b0213f10b8997d80fe46ccc6f0b1090eb47a801"
    assert ev["sha256sums_verified"] == 561 and ev["source_manifest_verified"] == 529 and ev["clone_matches_source_manifest"]
    assert ev["source_identity_head"] == ev["bundle_clone_head"] == "07148f2e60465ec620b4fba544aa74a9f9002315"
    if (ROOT / ".git").exists() and not (ROOT / "ANONYMIZED_REVIEW_ARTIFACT").exists():
        assert subprocess.run(["git", "merge-base", "--is-ancestor", ev["source_identity_head"], "HEAD"], cwd=ROOT).returncode == 0
    base = json.loads((ROOT / "docs/s3/S3_CLEAN_BASELINE.json").read_text())
    assert base["head"] == ev["source_identity_head"] and base["clean_tree"] and base["run_tests_rc"] == 0
    assert base["s1"] == "30/30" and base["s2"] == "50/50" and base["p3"] == "26/26"


@pytest.mark.gate("S3-02")
def test_register_unchanged():
    assert sha(ROOT / "configs/workload_c/spec_interpretations.json") == DIG["spec_interpretations_sha256"]
    assert json.loads((ROOT / "configs/workload_c/spec_interpretations.json").read_text())["status"] == "PI_CONFIRMED"


@pytest.mark.gate("S3-03")
def test_licence_table_unchanged():
    assert sha(ROOT / "configs/workload_c/license_identifier_table.json") == DIG["license_identifier_table_sha256"]


@pytest.mark.gate("S3-04")
def test_sch01_on_every_scientific_path():
    from f1.workload_c.scheduler.workload_c import FROZEN_OTP_NEWER_THAN
    assert FROZEN_OTP_NEWER_THAN == "last_successful_build"
    for p in (ROOT / "src/f1/workload_c/engines").glob("*.py"):
        assert "otp_newer_than" not in p.read_text(), p
    for p in ("campaign/s3_phases.py", "campaign/e2e_s3.py"):
        t = (ROOT / "src/f1/workload_c" / p).read_text()
        assert "simulate(" in t and "otp_newer_than" not in t


def _ledger(path: Path, n: int):
    rows = list(csv.DictReader(open(path)))
    assert len(rows) == n and all(r["status"] == "PASS" for r in rows)
    assert all(int(r["tests_skipped"]) == 0 for r in rows)


@pytest.mark.gate("S3-05")
def test_s1_rerun():
    _ledger(REPORTS / "s1" / "S1_GATE_LEDGER.csv", 30)


@pytest.mark.gate("S3-06")
def test_s2_rerun():
    _ledger(REPORTS / "S2_GATE_LEDGER.csv", 50)


@pytest.mark.gate("S3-07")
def test_p3_rerun():
    _ledger(REPORTS / "P3_GATE_LEDGER.csv", 26)


# ------------------------------------------------------------------------------------------------- replay
@pytest.mark.gate("S3-30")
def test_replay_reproduces_every_decision():
    from f1.workload_c.config.spec import load_protocol_spec
    eng = ReplayEngineImpl(load_protocol_spec().gtfs_member_names)
    for t in ("T1", "T2", "T3", "T4"):
        rep = eng.replay(trace(t)["ledger"], ())
        assert len(rep.items) == 7 and all(i.status == "REPRODUCED" for i in rep.items), t
        assert eng.replay(trace(t)["ledger"], ()) == rep                        # deterministic


@pytest.mark.gate("S3-31")
def test_replay_no_future_no_mutation(tmp_path):
    from f1.workload_c.config.spec import load_protocol_spec
    t2 = trace("T2")
    led = t2["ledger"]
    before = {k: sha(Path(v)) for k, v in led.paths if not k.startswith("sha256:")}
    ReplayEngineImpl(load_protocol_spec().gtfs_member_names).replay(led, ())
    assert {k: sha(Path(v)) for k, v in led.paths if not k.startswith("sha256:")} == before     # never mutated
    # tampering with a sealed input is refused
    d = tmp_path / "copy"
    shutil.copytree(Path(dict(led.paths)["region.json"]).parent, d)
    paths = tuple((k, (str(d / Path(v).name) if not k.startswith("sha256:") else v)) for k, v in led.paths)
    tampered = S.SealedLedger(led.history_journal_sha256, led.catalog_journal_sha256s, led.contracts_sha256,
                              led.raw_export_sha256, led.cost_ledger_sha256, paths)
    with (d / "cost_ledger.jsonl").open("a") as fh:
        fh.write(json.dumps({"region_id": "R:T2", "producer_class": "otp", "completed_utc": "2030-01-01T00:00:00Z",
                             "wall_s": 1.0, "cpu_s": 1.0, "outcome": "SUCCESS", "source": "SHARED_SCHEDULED"}) + "\n")
    from f1.workload_c.engines.core import EngineError
    with pytest.raises(EngineError):
        ReplayEngineImpl(load_protocol_spec().gtfs_member_names).replay(tampered, ())
    # a FUTURE cost observation cannot change est(s,t): PriorCostView only sees runs completed strictly before t
    runs = tuple(t2["campaign"].shared_runs)
    fut = runs + (S.ProducerRunObservation("R:T2", "otp", "2030-01-01T00:00:00Z", 1.0, 1.0, "SUCCESS"),)
    assert S.PriorCostView.before("R:T2", "2025-06-10T13:00:00Z", fut) == S.PriorCostView.before("R:T2", "2025-06-10T13:00:00Z", runs)


# ------------------------------------------------------------------------------------------------- export
FIELDS = {"run", "region_id", "request_id", "request_slots", "root_changes", "tick_utc", "tick_local", "method", "level",
          "current_cut_id", "current_frontier", "gamma_size", "action", "mode", "witness_cut_id", "bound_artifacts",
          "contract_verdicts", "rederivations", "costs", "estimates", "opt_current", "opt_hist", "failures",
          "scheduler_state_digest", "provenance_digests", "excluded", "exclusion_reason"}


@pytest.mark.gate("S3-35")
def test_raw_export_complete():
    for r in trace("T2")["records"]:
        assert FIELDS <= set(r) and r["run"]["namespace"] == "FIXTURE"
        assert any(p.startswith("binding:") for p in r["provenance_digests"])


@pytest.mark.gate("S3-36")
def test_raw_export_append_only_and_binding_provenance(tmp_path):
    t1 = trace("T1")
    path = Path(dict(t1["ledger"].paths)["raw_export.jsonl"])
    recs = stats.RawExportLog.verify(path)
    assert len(recs) == 7
    bad = tmp_path / "raw.jsonl"
    lines = path.read_text().splitlines()
    bad.write_text("\n".join([lines[1], lines[0]] + lines[2:]) + "\n")            # reorder → chain broken
    from f1.workload_c.engines.core import EngineError
    with pytest.raises(EngineError):
        stats.RawExportLog.verify(bad)
    exp = stats.StatisticsExporterImpl()
    camp = t1["campaign"]
    arm = [a for a in camp._arms if a.method == "F1" and a.level == "K2"][0]
    d = arm.decisions[0]
    from f1.workload_c.engines.core import MethodCatalog, bind_request
    from f1.workload_c.catalog.artifacts import ArtifactCatalog
    b = bind_request(d.request, MethodCatalog(camp.shared, camp.shared_born, ArtifactCatalog(None), {}, dict(camp.contracts)),
                     tuple(tuple(x) for x in [r for r in t1["records"] if r["method"] == "F1"][0]["estimates"]))
    dg = exp.register("F1", "K2", b)
    with pytest.raises(EngineError):
        exp.register("F1", "K2", b)                                               # one registration per request
    rec = exp.export(d, S.RunIdentityRecord("x", "FIXTURE", "i", "c"), (), "d", None, "s")
    assert ("binding:" + dg) in rec.provenance_digests
    orig = [r for r in t1["records"] if r["method"] == "F1" and r["level"] == "K2"][0]
    assert [p for p in orig["provenance_digests"] if p.startswith("binding:")] == ["binding:" + dg]
    with pytest.raises(EngineError):
        exp.export(d, S.RunIdentityRecord("x", "FIXTURE", "i", "c"), (), "d", None, "s")      # consumed once


@pytest.mark.gate("S3-37")
def test_aggregates_from_raw_export_only():
    recs_mem = [r for t in ("T1", "T2", "T3", "T4") for r in trace(t)["records"]]
    recs_file = [r for t in ("T1", "T2", "T3", "T4")
                 for r in stats.RawExportLog.verify(Path(dict(trace(t)["ledger"].paths)["raw_export.jsonl"]))]
    a = stats.FrozenAnalysisImpl().run(recs_mem, "FIXTURE")
    b = stats.FrozenAnalysisImpl().run(recs_file, "FIXTURE")
    assert a == b


def rec(region, method, level, action, mode, units, opt_c=None, opt_h=None, cost=0.0, excluded=False, reason=None,
        rid="q", pre=None):  # noqa: PLR0913
    items = [{"category": "A_PRODUCER", "component": "producer:otp", "wall_s": cost, "cpu_s": cost, "slot_id": None}]
    if pre is not None:
        items.append({"category": "A_PRODUCER", "component": "n1_preprocessing", "wall_s": pre, "cpu_s": pre,
                      "slot_id": f"PREPROC:{region}"})
    return {"run": {"namespace": "FIXTURE"}, "region_id": region, "request_id": rid, "method": method, "level": level,
            "action": action, "mode": mode, "root_changes": [list(u) for u in units], "opt_current": opt_c,
            "opt_hist": opt_h, "excluded": excluded, "exclusion_reason": reason, "costs": {"items": items}}


@pytest.mark.gate("S3-38")
def test_frozen_analysis_rules():
    A = stats.FrozenAnalysisImpl()
    recs = [rec("R1", "F1", "K0", "REUSE", "HISTORICAL", [("a", 2)], rid="1"),
            rec("R1", "F1", "K0", "REDERIVE", "CURRENT", [("b", 2)], 5400.0, 600.0, rid="2"),
            rec("R1", "F1", "K0", "REUSE", "CURRENT", [("c", 2)], rid="3"),
            rec("R2", "F1", "K0", "REUSE", "CURRENT", [("a", 2)], rid="4"),                   # zero denominator
            rec("R3", "F1", "K0", "REDERIVE", "CURRENT", [("a", 2)], 600.0, None, rid="5"),
            rec("R3", "F1", "K0", "REUSE", "CURRENT", [("a", 2)], excluded=True, reason="EVALUATION_ERROR", rid="6")]
    pr = A.per_region(recs)
    assert pr["R1"]["HSR_witness(K0)"] == 0.5 and pr["R1"]["HSR_repair(K0)"] == 1.0
    assert pr["R2"]["HSR_witness(K0)"] is None and pr["R2"]["units_witness_den(K0)"] == 0
    assert pr["R3"]["HSR_witness(K0)"] == 0.0 and pr["R3"]["HSR_repair(K0)"] == 0.0
    assert pr["R1"]["DeltaCost_history(K0)"] == 4800.0
    # operational-cap paired exclusion for cost contrasts
    cost = [rec("R1", "F1", "K2", "REUSE", "CURRENT", [], cost=10.0, rid="x"),
            rec("R1", "N5", "K2", "REDERIVE", "CURRENT", [], cost=50.0, rid="x"),
            rec("R1", "F1", "K2", "REUSE", "CURRENT", [], cost=10.0, rid="y"),
            rec("R1", "N5", "K2", "NO_ARTIFACT", None, [], cost=999.0, excluded=True, reason="OPERATIONAL_CAP", rid="y")]
    assert A.per_region(cost)["R1"]["DeltaE2E_history(K2)"] == 40.0
    # S3.1: the paired cap applies to HSR as well (F1 record at a capped request makes no contribution)
    capped = [rec("R9", "F1", "K0", "REUSE", "HISTORICAL", [("a", 2)], rid="c"),
              rec("R9", "N5", "K0", "REDERIVE", "CURRENT", [("a", 2)], reason="OPERATIONAL_CAP", excluded=True, rid="c")]
    assert A.per_region(capped)["R9"]["HSR_witness(K0)"] is None
    # contributing regions = statistic DEFINED (zeros count), evaluated before zeros are dropped
    zeros = []
    for i, reg in enumerate(("Ra", "Rb", "Rc")):
        zeros += [rec(reg, "F1", "K2", "REUSE", "CURRENT", [], cost=5.0, rid=f"z{i}"),
                  rec(reg, "N5", "K2", "REUSE", "CURRENT", [], cost=5.0 if i else 9.0, rid=f"z{i}"),
                  rec(reg, "N1", "K0", "REUSE", "CURRENT", [], cost=5.0, rid=f"z{i}", pre=0.0)]
    rep = A.run(zeros, "FIXTURE")
    h = {x.name: x for x in rep.hypotheses}["H_hist(K2)"]
    assert h.n_regions == 3 and h.sign_test_p == 0.5                         # 3 contribute; 2 zeros dropped by sign test
    two = [r for r in zeros if r["region_id"] != "Rc"]
    assert {x.name: x for x in A.run(two, "FIXTURE").hypotheses}["H_hist(K2)"].verdict == "INCONCLUSIVE"


@pytest.mark.gate("S3-39")
@pytest.mark.gate("S3-40")
def test_analysis_deterministic_and_holm_family():
    recs = [r for t in ("T1", "T2", "T3", "T4") for r in trace(t)["records"]]
    a, b = stats.FrozenAnalysisImpl().run(recs, "FIXTURE"), stats.FrozenAnalysisImpl().run(list(reversed(recs)), "FIXTURE")
    assert a.hypotheses == b.hypotheses and a.per_region == b.per_region
    assert stats.FrozenAnalysisImpl().descriptive(recs) == stats.FrozenAnalysisImpl().descriptive(list(reversed(recs)))
    assert [h.name for h in a.hypotheses] == ["H_witness(K0)", "H_repair(K0)", "H_hist(K2)", "H_native(K2)"]
    adj = stats.holm({"a": 0.01, "b": 0.04, "c": 0.03, "d": 0.5})
    assert adj == {"a": 0.04, "c": 0.09, "b": 0.09, "d": 0.5}


@pytest.mark.gate("S3-41")
def test_namespace_firewall():
    from f1.workload_c.security.firewall import Stage, check_namespace_read
    with pytest.raises(NamespaceViolation):
        check_namespace_read("TEST", Stage.IMPLEMENTATION)
    with pytest.raises(NamespaceViolation):
        check_namespace_read("VALIDATION", Stage.IMPLEMENTATION)
    check_namespace_read("FIXTURE", Stage.IMPLEMENTATION)
    recs = trace("T1")["records"]
    with pytest.raises(NamespaceViolation):
        stats.FrozenAnalysisImpl().run(recs, "TEST")
    mixed = recs + [{**recs[0], "run": {**recs[0]["run"], "namespace": "VALIDATION"}}]
    with pytest.raises(NamespaceViolation):
        stats.FrozenAnalysisImpl().run(mixed, "FIXTURE")


@pytest.mark.gate("S3-42")
def test_change_class_firewall():
    from f1.workload_c.security.firewall import ChangeClass as C, ChangeRecord as R, FirewallViolation, Stage, check_change
    for r in (R(C.R1, Stage.IMPLEMENTATION), R(C.S1, Stage.POST_VALIDATION, formal_amendment="A"),
              R(C.S1, Stage.CAMPAIGN, formal_amendment="A", restart_from_clean_freeze=True, restart_evidence_id="F"),
              R(C.E2, Stage.IMPLEMENTATION, issue_id="I")):
        with pytest.raises(FirewallViolation):
            check_change(r)
    recs = json.loads((ROOT / "docs/s3/CHANGE_RECORDS.json").read_text())["records"]
    s31 = ROOT / "docs/s3_1/CHANGE_RECORDS_S3_1.json"
    if s31.exists():
        recs += json.loads(s31.read_text())["records"]
    for r in recs:
        check_change(R(C(r["change_class"]), Stage(r["stage"]), r.get("issue_id"), r.get("failing_test"),
                       r.get("regression_test"), r.get("formal_amendment"), r.get("restart_from_clean_freeze", False),
                       r.get("restart_evidence_id"), r.get("semantic_preservation_evidence")))


# ------------------------------------------------------------------------------------------------- orchestrator
@pytest.mark.gate("S3-43")
@pytest.mark.gate("S3-46")
def test_orchestrator_real_s3_engines_fixture(full_run):
    from f1.workload_c.campaign.phases import PHASES
    assert full_run["result"].status == "COMPLETE"
    eng = {p.phase_id: p.engine for p in PHASES}
    for p in ("11_validation", "13_scientific_test_campaign", "14_result_reconciliation", "15_raw_result_seal",
              "16_frozen_statistics"):
        assert eng[p] == "REAL_S3"
    d = full_run["dir"] / "phases"
    test_raw = read_jsonl(d / "13_scientific_test_campaign/test_raw.jsonl")
    val_raw = read_jsonl(d / "11_validation/validation_raw.jsonl")
    assert test_raw and val_raw
    for r in test_raw + val_raw:                                              # serialized namespace is FIXTURE
        assert r["namespace"] == "FIXTURE" and r["record"]["run"]["namespace"] == "FIXTURE" and r["marker"]
    rc = json.loads((d / "14_result_reconciliation/reconciliation.json").read_text())
    assert rc["replayed"] == len(test_raw) and rc["mismatches"] == []
    st = json.loads((d / "16_frozen_statistics/statistics_report.json").read_text())
    assert st["namespace"] == "FIXTURE" and st["scientific_results"].startswith("NONE") and st["marker"]
    assert [h["name"] for h in st["hypotheses"]] == ["H_witness(K0)", "H_repair(K0)", "H_hist(K2)", "H_native(K2)"]
    mp = json.loads((d / "13_scientific_test_campaign/mutation_plan.json").read_text())
    assert mp["marker"] and set(mp["plans"]) <= {"ROUTER", "VAL_REPORT"}
    fv = json.loads((full_run["dir"] / "phases/18_final_verdict/FINAL_VERDICT.json").read_text())
    assert fv["scientific_results"] == "NONE" and fv["namespace"] == "FIXTURE"


@pytest.mark.gate("S3-44")
def test_no_secret_emitted(full_run):
    from f1.workload_c.security.secrets import scan_paths
    from f1.workload_c.campaign.fixture import FIXTURE_CANARY
    roots = [full_run["dir"]] + [Path(dict(trace(t)["ledger"].paths)["region.json"]).parent for t in ("T1", "T2")]
    assert scan_paths(roots, [FIXTURE_CANARY]) == []


@pytest.mark.gate("S3-45")
def test_no_live_campaign(tmp_path):
    env = {**os.environ, "PYTHONPATH": str(ROOT / "src")}
    cp = subprocess.run([sys.executable, "-m", "f1.workload_c.campaign.cli", "run", "--real", "--run-root", str(tmp_path)],
                        env=env, capture_output=True, text=True)
    assert cp.returncode == 3 and json.loads(cp.stdout)["reason"] == "REAL_MODE_NOT_YET_IMPLEMENTATION_COMPLETE"
    for p in list((ROOT / "src/f1/workload_c/engines").glob("*.py")) + [ROOT / "src/f1/workload_c/campaign/s3_phases.py"]:
        t = p.read_text()
        assert "mobilitydatabase" not in t and "urllib" not in t and "requests" not in t.split("import")[0:1][0]


# ------------------------------------------------------------------------------------------------- negatives
@pytest.mark.gate("S3-48")
def test_mandatory_negative_battery():
    """Index of the mandatory negative tests (each implemented and asserted in its own gate test)."""
    import test_s3_engines as E
    must = {"sentinel history/catalog/witness index (N5)": E.test_n5_history_noninterference,
            "historical catalog entries cannot reach N5": E.test_n5_receives_no_f1_outputs_and_binding_vector,
            "N1 receives no F1 history or catalog": E.test_n1_real_native_build_amended_evidence,
            "cross-slot substitution rejected": E.test_fixed_r_enforced,
            "future-cut witness / artifact born after tick rejected": E.test_no_future_cut_or_future_artifact_in_witness,
            "per-slot mixture of witness cuts rejected": None,
            "K3 as admission contract rejected": E.test_k3_never_an_admission_contract,
            "corrupted provenance fails closed": test_replay_no_future_no_mutation,
            "future cost observations cannot change est": test_replay_no_future_no_mutation,
            "TEST-namespace access during development fails": test_namespace_firewall,
            "identical deterministic input twice": E.test_witness_search_deterministic_and_permutation_invariant,
            "R1 / S1-without-restart rejected": test_change_class_firewall,
            "N1 without evidenced cache activity BLOCKED": E.test_n1_fixture_builder_blocked_without_cache_evidence}
    import test_s3_1_corrections as C
    must.update({"CASE A paired cap / HSR": C.test_case_a_paired_cap_excludes_all_primary_metrics,
                 "CASE B undefined vs zero": C.test_case_b_undefined_contrast_vs_defined_zero,
                 "CASE C N1 preprocessing": C.test_case_c_n1_preprocessing_regional_once,
                 "CASE D Canon reference EQ": C.test_case_d_canon_reference_eq_despite_content_change,
                 "CASE E bad mutation operator exposed": C.test_case_e_input_mutations_measured_and_bad_operator_exposed,
                 "CASE F/G replay digests + source events": C.test_case_f_g_semantic_digests_and_source_events,
                 "CASE H CPU": C.test_case_h_cpu_survives_to_export_and_replay})
    assert all(callable(f) for k, f in must.items() if f is not None)
    # per-slot mixture of witness cuts (asserted here directly)
    t1 = trace("T1")
    w = [a for a in t1["campaign"]._arms if a.method == "F1" and a.level == "K2"][0].decisions[0].witness
    from f1.workload_c.history.realized import Cut
    other = Cut.of(w.witness_cut.region_id, {"A": 2, "B": 1})
    from f1.workload_c.contracts.model import EvaluationResult
    import dataclasses
    mixed = (w.bindings[0], dataclasses.replace(w.bindings[1], evaluations=tuple(
        EvaluationResult(e.contract_id, other.cut_id, "VALID", "x", e.evaluator_digest) for e in w.bindings[1].evaluations)),
        ) + w.bindings[2:]
    with pytest.raises(S.InterfaceInvariantError):
        dataclasses.replace(w, bindings=mixed)
    # frozen config modified after seal → refusal (Session-1 seal machinery, re-asserted)
    from f1.workload_c.campaign.seal import FreezeSeal
    seal = FreezeSeal().seal("x", "FIXTURE", {"a": "0" * 64})
    with pytest.raises(Exception):  # noqa: B017 - any refusal type of the Session-1 seal machinery is acceptable
        FreezeSeal().verify(seal, {"a": "1" * 64})
    assert logical_view  # imported for replay comparison


@pytest.mark.gate("S3-49")
def test_static_analysis_clean():
    for argv in ([sys.executable, "-m", "ruff", "check", "src/f1/workload_c", "tests/workload_c", "-q"],
                 [sys.executable, "-m", "mypy", "src/f1/workload_c"]):
        cp = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True)
        assert cp.returncode == 0, cp.stdout[-2000:]
    sc = shutil.which("shellcheck")
    assert sc is not None
    scripts = [str(p) for p in (ROOT / "scripts").glob("*.sh") if p.name.startswith(("run_", "verify_", "fetch_"))]
    cp = subprocess.run([sc] + scripts, cwd=ROOT, capture_output=True, text=True)
    assert cp.returncode == 0, cp.stdout[-2000:]
