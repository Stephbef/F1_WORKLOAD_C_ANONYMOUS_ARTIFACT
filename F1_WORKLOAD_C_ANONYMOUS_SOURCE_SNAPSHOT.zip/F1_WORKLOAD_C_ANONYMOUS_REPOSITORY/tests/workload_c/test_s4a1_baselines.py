"""Session 4A.1 gates S4A1-01..S4A1-25 (AMENDMENT-S4A-BASELINES-01). FIXTURE / synthetic data only."""
import ast
import dataclasses
import functools
import hashlib
import json
import subprocess
import tempfile
import typing
from pathlib import Path

import pytest

from conftest import ROOT
from f1.workload_c.catalog.artifacts import ArtifactCatalog, ArtifactEntry
from f1.workload_c.contracts.model import Contract, EvaluationContext, EvaluationResult
from f1.workload_c.engines import baselines_s4 as B
from f1.workload_c.history.realized import Cut, RealizedHistory
from f1.workload_c.interfaces import session3 as S

DOCS = ROOT / "docs" / "s4a1"
AMEND = (DOCS / "AMENDMENT_S4A_BASELINES_01.md").read_text()
T = "2025-06-12T13:00:00Z"


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


@functools.lru_cache(maxsize=None)
def fixture_run(tag: str = "", outcomes: tuple = ()):
    from f1.workload_c.campaign.e2e_s4a1 import TICKS, build
    camp, run = build(Path(tempfile.mkdtemp(prefix=f"s4a1-{tag}-")), dict(outcomes) if outcomes else None)
    arms = run.run([("N0", None), ("N2", None), ("N3", None), ("N4", 24), ("N4", 168), ("N6", None)], TICKS)
    return camp, arms


def acts(arm):
    ab = {"REUSE": "u", "REDERIVE": "d", "NO_ARTIFACT": "x"}
    return ["".join(ab[s.action] for s in d.slots) for d in arm.decisions]


# ----------------------------------------------------------------------------------------- synthetic views
REG = "R:x"


def req(a=2, b=1, t=T):
    cut = Cut.of(REG, {"A": a, "B": b})
    return S.ConsumerRequest(REG, S.canonical_request_slots(REG, ["A", "B"]), t, cut,
                             EvaluationContext(cut.cut_id, {}, consumer_date=t[:10], horizon=(t[:10],)))


def own(slot, aid, born="2025-06-12T01:00:00Z", pin=None, key=None, iv=None, k0=None):
    """Method-specific projection: pass only the field the method uses (k0 for N2/N6-router, pin+iv for N3, key N6)."""
    c = (Contract.build("K0", "X", aid, slot, "CUT:b", {"ok": k0}, "g", "e"),) if k0 is not None else ()
    if pin is not None and iv is None:
        iv = ("2025-06-01T00:00:00Z", None)
    return B.OwnArtifact(slot, aid, born, c, pin, iv, key)


class Ev:
    def evaluate(self, c):
        return EvaluationResult(c.contract_id, "CUT:cur", "VALID" if json.loads(c.canonical_bytes)["footprint"]["ok"]
                                else "INVALID", "fake", "e")


class Prod:
    def __init__(self, fail=()):
        self.calls, self.fail = [], set(fail)

    def _step(self, kind, slot, est):
        self.calls.append((kind, slot))
        ok = slot not in self.fail
        return S.RederivationStep(slot, "CUT:cur", B.producer_class_of(slot), est, "SUCCESS" if ok else "INFRA_ERROR",
                                  f"new:{slot}" if ok else None, "p", 10.0)

    def validator(self, slot, est):
        return self._step("validator", slot, est)

    def router_full_cold(self, slot, est):
        return self._step("full_cold", slot, est)

    def router_n1_native(self, slot, est):
        return self._step("n1_native", slot, est)

    def cpu_of(self, st):
        return 3.0


def view(method, bound, r=None, tau=None, pins=None, keys=None, cache=()):
    r = r or req()
    vs = tuple(B.VersionEvent(f, i, f"ev:{f}{i}", f"h{f}{i}", "2025-06-01T00:00:00Z", None) for f, i in r.current_cut.frontier)
    pins = (pins or {s: ("p",) for s in r.request_slots}) if method == "N3" else {}
    if method == "N6":
        keys = keys or {s: ("k",) for s in r.request_slots if s.startswith("VAL:")}
        hits = tuple((s, tuple(a for k, a in cache if k == keys[s])) for s in keys)       # exact-key index lookup
        bound = {s: b for s, b in bound.items() if not s.startswith("VAL:")}
    else:
        keys, hits = {}, ()
    return B.BaselineView(method, r, tuple((s, bound.get(s)) for s in r.request_slots), vs, tuple(pins.items()),
                          tuple(keys.items()), hits, tuple((s, 1.0) for s in r.request_slots), tau)


SL = S.canonical_request_slots(REG, ["A", "B"])


# ------------------------------------------------------------------------------------------- identity & docs
@pytest.mark.gate("S4A1-01")
def test_input_s31_identity():
    ev = json.loads((DOCS / "S4A1_INPUT_IDENTITY.json").read_text())
    assert ev["s31_head"] == "d09da21c98cdae0d983dbe9c268f0fd29f630d4d" and ev["s31_zip_sha256"].startswith("dc57bbf1")
    assert ev["s31_sha256sums_verified"] == 641 and ev["s31_source_manifest_verified"] == 561
    if (ROOT / ".git").exists() and not (ROOT / "ANONYMIZED_REVIEW_ARTIFACT").exists():
        assert subprocess.run(["git", "merge-base", "--is-ancestor", ev["s31_head"], "HEAD"], cwd=ROOT).returncode == 0


@pytest.mark.gate("S4A1-02")
def test_blocked_report_identity():
    ev = json.loads((DOCS / "S4A1_INPUT_IDENTITY.json").read_text())
    assert ev["blocked_report_sha256"] == "9b61721368fa9566d669bcf6f9c41c5160d1122a90d7d1b0af6d2914a1cb1877"
    assert ev["blocked_report_contents_verified"] is True


@pytest.mark.gate("S4A1-03")
@pytest.mark.gate("S4A1-09")
@pytest.mark.gate("S4A1-22")
def test_amendment_and_n4_rule_committed_before_any_output():
    meta = json.loads((DOCS / "AMENDMENT_COMMIT.json").read_text())
    for f, dg in meta["sha256"].items():
        assert sha(ROOT / f) == dg, f                                  # unchanged since the amendment commit
    assert meta["validation_outputs_at_commit"] == 0 and meta["n4_outputs_at_commit"] == 0
    assert "created before any VALIDATION execution" in AMEND and "no N4 TTL outcome has ever been produced" in AMEND
    if (ROOT / ".git").exists() and not (ROOT / "ANONYMIZED_REVIEW_ARTIFACT").exists():
        r = subprocess.run(["git", "merge-base", "--is-ancestor", meta["commit"], "HEAD"], cwd=ROOT)
        assert r.returncode == 0
        files = subprocess.run(["git", "show", "--name-only", "--format=", meta["commit"]], cwd=ROOT,
                               capture_output=True, text=True).stdout.split()
        assert all(f.startswith("docs/s4a1/") for f in files)               # amendment commit contains no code/output
    assert not list((ROOT).glob("**/validation_outputs/**/*")) and not list(ROOT.glob("**/N4_VALIDATION_SELECTION*"))


@pytest.mark.gate("S4A1-04")
def test_router_conflict_resolution():
    for needle in ("N0 is the explicit exception", "N2, N3, N4, N6: every ROUTER re-derivation uses the N1 native",
                   "F1 and N5 remain EXACTLY as frozen in S3.1", "NOT applied retroactively to F1/N5"):
        assert needle in AMEND
    p = Prod()
    B.S4Baseline().decide(view("N0", {}), Ev(), p)
    assert ("full_cold", SL[2]) in p.calls
    for m in ("N2", "N3", "N6"):
        p = Prod()
        B.S4Baseline().decide(view(m, {}), Ev(), p)
        assert ("n1_native", SL[2]) in p.calls and ("full_cold", SL[2]) not in p.calls, m
    p = Prod()
    B.S4Baseline().decide(view("N4", {}, tau=24), Ev(), p)
    assert ("n1_native", SL[2]) in p.calls
    src = (ROOT / "src/f1/workload_c/engines/f1.py").read_text() + (ROOT / "src/f1/workload_c/engines/baselines_n.py").read_text()
    assert "baselines_s4" not in src                                           # F1/N5/N1 untouched by S4 baselines


# ------------------------------------------------------------------------------------------- N0
@pytest.mark.gate("S4A1-05")
@pytest.mark.gate("S4A1-12")
def test_n0_full_rebuild():
    with pytest.raises(B.EngineError):
        view("N0", {SL[0]: own(SL[0], "a")})                                  # N0 can never be given an artifact
    p = Prod(fail={SL[1]})
    d = B.S4Baseline().decide(view("N0", {}), Ev(), p)
    assert [c[0] for c in p.calls] == ["validator", "validator", "full_cold"]  # every slot, every request
    assert d.joint_action == "NO_ARTIFACT" and d.slots[1].action == "NO_ARTIFACT" and d.slots[2].action == "REDERIVE"
    assert len([i for i in d.costs.items if i.category == S.CostCategory.A_PRODUCER]) == 3      # failed work charged
    camp, arms = fixture_run()
    assert all(a == "ddd" for a in acts(arms[("N0", None)]))


# ------------------------------------------------------------------------------------------- N2
@pytest.mark.gate("S4A1-06")
@pytest.mark.gate("S4A1-13")
def test_n2_current_k0_selective():
    bound = {SL[0]: own(SL[0], "a", k0=True), SL[1]: own(SL[1], "b", k0=False), SL[2]: own(SL[2], "r", k0=True)}
    with pytest.raises(B.EngineError):
        view("N2", {SL[0]: own(SL[0], "a", pin=("p",))})                     # foreign (N3) metadata refused
    p = Prod()
    d = B.S4Baseline().decide(view("N2", bound), Ev(), p)
    assert [s.action for s in d.slots] == ["REUSE", "REDERIVE", "REUSE"] and p.calls == [("validator", SL[1])]
    p = Prod(fail={SL[1]})
    d = B.S4Baseline().decide(view("N2", bound), Ev(), p)
    assert d.slots[1].action == "NO_ARTIFACT" and d.joint_action == "NO_ARTIFACT"          # no stale fallback
    assert "K0 rerun" in (DOCS / "BASELINE_SEMANTICS_FINAL.md").read_text()


# ------------------------------------------------------------------------------------------- N3
@pytest.mark.gate("S4A1-07")
@pytest.mark.gate("S4A1-14")
@pytest.mark.gate("S4A1-17")
@pytest.mark.gate("S4A1-32")
def test_n3_pins_intervals_and_aba():
    pin_cur = ("VAL", "A", "ev:A3", "hA1", "2025-06-12", "US", "v")
    pin_old = ("VAL", "A", "ev:A1", "hA1", "2025-06-12", "US", "v")      # same CONTENT hash, different EVENT (A1 vs A3)
    pins = {s: ("p",) for s in SL}
    pins[SL[0]] = pin_cur
    old = own(SL[0], "a1", pin=pin_old, iv=("2025-06-01T00:00:00Z", "2025-06-05T00:00:00Z"))
    p = Prod()
    d = B.S4Baseline().decide(view("N3", {SL[0]: old}, pins=pins), Ev(), p)
    assert d.slots[0].action == "REDERIVE"                                     # A1 artifact NOT resurrected at A3
    ok = own(SL[0], "a3", pin=pin_cur, iv=("2025-06-12T00:00:00Z", None))
    d = B.S4Baseline().decide(view("N3", {SL[0]: ok}, pins=pins), Ev(), Prod())
    assert d.slots[0].action == "REUSE"
    edge = own(SL[0], "a3", pin=pin_cur, iv=("2025-06-01T00:00:00Z", T))       # half-open: t == upper end excluded
    assert B.S4Baseline().decide(view("N3", {SL[0]: edge}, pins=pins), Ev(), Prod()).slots[0].action == "REDERIVE"
    start = own(SL[0], "a3", pin=pin_cur, iv=(T, None))                         # t == lower end included
    assert B.S4Baseline().decide(view("N3", {SL[0]: start}, pins=pins), Ev(), Prod()).slots[0].action == "REUSE"
    later = own(SL[0], "a3", pin=pin_cur, born="2025-06-12T13:00:01Z", iv=("2025-06-01T00:00:00Z", None))
    assert B.S4Baseline().decide(view("N3", {SL[0]: later}, pins=pins), Ev(), Prod()).slots[0].action == "REDERIVE"
    d = B.S4Baseline().decide(view("N3", {SL[0]: ok}, pins=pins), Ev(), Prod())
    assert [i.component for i in d.costs.items if i.category == S.CostCategory.B_CONTROL_PLANE][:1] == ["n3_pin_index_lookup"]
    _aba_fixture_assertions()


def _aba_fixture_assertions():
    """A1 -> A2 -> A3 with canonical(A3) == canonical(A1): inspect the EXACT pins of every N3 reuse."""
    camp, arms = fixture_run()
    run_lv = {(f, idx): eid for f, chain in camp.history.versions.items() for idx, _at, eid in chain}
    assert camp.r.versions[("A", 3)].canonical_content_sha256 == camp.r.versions[("A", 1)].canonical_content_sha256
    arm = arms[("N3", None)]
    a3_decisions = [d for d in arm.decisions if d.request.current_cut.index("A") == 3]
    assert a3_decisions, "fixture must contain requests at A3"
    checked = 0
    for d in a3_decisions:
        for sd in d.slots:
            if sd.slot_id not in ("VAL:feed=A", "ROUTER:region=R:S4") or sd.action != "REUSE":
                continue
            pin, _iv = arm.n3_index[sd.artifact_id]
            events = [pin[2]] if pin[0] == "VAL" else [e for f, e, _h in pin[2] if f == "A"]
            assert events == [run_lv[("A", 3)]], (sd, pin)                   # produced under the A3 EVENT itself
            assert run_lv[("A", 1)] not in events
            checked += 1
    a1 = run_lv[("A", 1)]
    a1_artifacts = [aid for aid, (pin, _iv) in arm.n3_index.items() if pin and (
        (pin[0] == "VAL" and pin[2] == a1) or (pin[0] == "ROUTER" and any(e == a1 for _f, e, _h in pin[2])))]
    reused = {sd.artifact_id for d in a3_decisions for sd in d.slots if sd.action == "REUSE"}
    assert a1_artifacts and not (set(a1_artifacts) & reused)                 # A1-pinned artifacts never resurrected
    return checked


# ------------------------------------------------------------------------------------------- N4
@pytest.mark.gate("S4A1-08")
@pytest.mark.gate("S4A1-15")
@pytest.mark.gate("S4A1-18")
def test_n4_ttl_semantics_and_boundary():
    with pytest.raises(B.EngineError):
        view("N4", {}, tau=336)
    with pytest.raises(B.EngineError):
        view("N2", {}, tau=24)
    born_eq = "2025-06-11T13:00:00Z"                                           # age == 24 h exactly
    stale = own(SL[0], "old", born=born_eq)                                     # TTL view carries no contracts at all
    with pytest.raises(B.EngineError):
        view("N4", {SL[0]: own(SL[0], "x", k0=False)}, tau=24)                 # N4 never receives K0 metadata
    p = Prod()
    d = B.S4Baseline().decide(view("N4", {SL[0]: stale}, tau=24), Ev(), p)
    assert d.slots[0].action == "REDERIVE"                                      # age == τ expires
    young = own(SL[0], "y", born="2025-06-11T13:00:01Z")                        # age < τ (inputs may have changed)
    d = B.S4Baseline().decide(view("N4", {SL[0]: young}, tau=24), Ev(), Prod())
    assert d.slots[0].action == "REUSE" and d.reuse_events[0][1] == "y"        # input change does not invalidate
    p = Prod(fail={SL[0]})
    d = B.S4Baseline().decide(view("N4", {SL[0]: stale}, tau=24), Ev(), p)
    assert d.slots[0].action == "NO_ARTIFACT" and d.slots[0].artifact_id is None   # no fallback to expired artifact
    assert d.reuse_events == () or all(e[1] != "old" for e in d.reuse_events)
    camp, arms = fixture_run()
    assert all(a == "uuu" for a in acts(arms[("N4", 168)]))                     # long τ keeps reusing (possibly stale)


# ------------------------------------------------------------------------------------------- N6
@pytest.mark.gate("S4A1-10")
@pytest.mark.gate("S4A1-16")
@pytest.mark.gate("S4A1-19")
def test_n6_dataset_cache():
    key_a = ("A", "ev:A2", "hA2", "US", "v")
    keys = {SL[0]: key_a, SL[1]: ("B", "ev:B1", "hB1", "US", "v")}
    cached = own(SL[0], "va", born="2025-06-01T01:00:00Z", key=key_a, k0=False)    # other consumer date → K0 invalid
    p = Prod()
    d = B.S4Baseline().decide(view("N6", {SL[2]: own(SL[2], "r", k0=True)}, keys=keys, cache=[(key_a, cached)]), Ev(), p)
    assert d.slots[0].action == "REUSE" and d.slots[0].artifact_id == "va"     # HIT across dates (date not in key)
    assert d.slots[1].action == "REDERIVE" and d.slots[2].action == "REUSE"     # MISS on B; ROUTER per N2 (K0 valid)
    new_event = {SL[0]: ("A", "ev:A3", "hA2", "US", "v"), SL[1]: keys[SL[1]]}
    d = B.S4Baseline().decide(view("N6", {}, keys=new_event, cache=[(key_a, cached)]), Ev(), Prod())
    assert d.slots[0].action == "REDERIVE"                                      # new logical-version EVENT → MISS
    d = B.S4Baseline().decide(view("N6", {SL[2]: own(SL[2], "r", k0=False)}, keys=keys), Ev(), p := Prod())
    assert ("n1_native", SL[2]) in p.calls                                     # ROUTER re-derivation N1-native
    assert "consumer date is DELIBERATELY absent" in AMEND
    camp, arms = fixture_run("inf", (("VAL:feed=B", "INFRA_ERROR"),))
    n6 = arms[("N6", None)]
    assert not any(e.request_slot == "VAL:feed=B" for e in n6.mc.overlay.instances("VAL:feed=B"))   # infra not cached
    camp, arms = fixture_run()
    seq = acts(arms[("N6", None)])
    assert seq[1][1] == "u"                                                     # day 2: B hit despite the new date


# ------------------------------------------------------------------------------------------- matrix / leakage
@pytest.mark.gate("S4A1-11")
def test_capability_matrix_complete():
    t = (DOCS / "BASELINE_CAPABILITY_MATRIX.md").read_text()
    for m in ("F1", "N0", "N1", "N2", "N3", "N4", "N5", "N6"):
        assert f"| {m} |" in t, m
    for col in ("current-cut", "RealizedHistory", "historical artifact enumeration", "own persistent", "own cache",
                "shared scheduled", "overlay", "Γ", "K evaluator", "producer", "K3 during decision", "K3 offline",
                "future information", "router rebuild", "VAL policy"):
        assert col in t, col


def reach(tp, seen=None):
    seen = set() if seen is None else seen
    for a in typing.get_args(tp) or ():
        reach(a, seen)
    if dataclasses.is_dataclass(tp) and tp not in seen:
        seen.add(tp)
        for h in typing.get_type_hints(tp).values():
            reach(h, seen)
    elif isinstance(tp, type):
        seen.add(tp)
    return seen


@pytest.mark.gate("S4A1-20")
def test_no_baseline_history_leakage():
    forbidden = {RealizedHistory, ArtifactCatalog, ArtifactEntry, S.JointWitness, S.WitnessBinding}
    assert not (reach(B.BaselineView) & forbidden)
    hints = typing.get_type_hints(B.S4Baseline.decide)
    assert set(hints) == {"view", "evaluator", "producers", "return"}
    tree = ast.parse((ROOT / "src/f1/workload_c/engines/baselines_s4.py").read_text())
    dec = [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef) and n.name == "S4Baseline"][0]
    names = {n.id for n in ast.walk(dec) if isinstance(n, ast.Name)} | {n.attr for n in ast.walk(dec) if isinstance(n, ast.Attribute)}
    for bad in ("history", "gamma", "candidates", "witness", "catalog", "overlay", "shared", "k3", "reference"):
        assert bad not in {x.lower() for x in names}, bad
    imps = " ".join(ast.unparse(n) for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom)))
    assert ".f1 " not in imps + " " and "witness" not in imps.lower()
    camp, arms = fixture_run()
    for (_m, _t), arm in arms.items():
        for d in arm.decisions:
            for s in d.slots:                                                    # no artifact from the future
                if s.action == "REUSE":
                    assert any(e[1] == s.artifact_id and e[2] <= d.request.tick_utc for e in d.reuse_events)


@pytest.mark.gate("S4A1-21")
def test_n4_selection_oracle():
    def outs(rows):
        return {t: B.TauOutcome(t, u, c) for t, u, c in rows}
    a = outs([(1, 0, 100.0), (6, 0, 80.0), (24, 1, 20.0), (72, 2, 10.0), (168, 4, 5.0)])
    assert B.select_tau(a) == 6
    b = outs([(1, 0, 80.0), (6, 0, 80.0), (24, 3, 1.0), (72, 3, 1.0), (168, 3, 1.0)])
    assert B.select_tau(b) == 1
    c = outs([(1, 5, 50.0), (6, 2, 70.0), (24, 2, 60.0), (72, 2, 60.0), (168, 9, 1.0)])
    assert B.select_tau(c) == 24
    with pytest.raises(B.SelectionBlocked):
        B.select_tau({**a, 24: B.TauOutcome(24, 1, 20.0, unclassifiable=1)})
    with pytest.raises(B.SelectionBlocked):
        B.select_tau({k: v for k, v in a.items() if k != 168})
    fields = {f.name for f in dataclasses.fields(B.TauOutcome)}
    assert not any("f1" in f.lower() or "gap" in f.lower() for f in fields)
    assert list(typing.get_type_hints(B.select_tau)) == ["outcomes", "return"]
    d = B.BaselineDecision("N4", 24, req(), tuple(B.SlotDecision(s, "REUSE", f"x{i}", None, "age") for i, s in enumerate(SL)),
                           "REUSE", S.CostRecord((S.CostItem(S.CostCategory.B_CONTROL_PLANE, "admission", 2.0, 2.0),)),
                           tuple((s, f"x{i}", "2025-06-12T01:00:00Z") for i, s in enumerate(SL)))
    assert B.classify_n4_reuses([d], lambda dd, s, a: a != "x1") == (1, 0)
    assert B.classify_n4_reuses([d], lambda dd, s, a: None if a == "x2" else True) == (0, 1)
    assert B.n4_cost([d]) == 2.0


@pytest.mark.gate("S4A1-23")
def test_no_test_outcome_accessed():
    for p in ROOT.rglob("*"):
        if ".git" in p.parts or not p.is_file():
            continue
        assert not ("TEST" in p.parts and p.suffix in (".jsonl", ".json") and "outputs" in str(p)), p
    marker = json.loads((ROOT / "configs/workload_c/session_phase.json").read_text())
    assert marker["phase"] in ("S3", "S4A1")


@pytest.mark.gate("S4A1-25")
def test_semantic_freeze_record():
    """The CURRENT amended freeze (S4A.1.1) matches every frozen file; the superseded S4A.1 freeze is preserved and
    its amendment documents are unchanged (historical evidence)."""
    fz = json.loads((DOCS / "S4A1_1_SEMANTIC_FREEZE.json").read_text())
    for rel, dg in fz["files"].items():
        assert sha(ROOT / rel) == dg, rel
    assert fz["validation_outputs"] == 0 and fz["test_outputs"] == 0
    assert fz["amendments"] == ["AMENDMENT-S4A-BASELINES-01", "AMENDMENT-S4A-BASELINES-01A"]
    old = json.loads((DOCS / "S4A1_SEMANTIC_FREEZE.json").read_text())
    for rel in ("docs/s4a1/AMENDMENT_S4A_BASELINES_01.md", "docs/s4a1/N4_SELECTION_RULE_FINAL.md"):
        assert sha(ROOT / rel) == old["files"][rel]
    assert fz["supersedes"] == "docs/s4a1/S4A1_SEMANTIC_FREEZE.json"


@pytest.mark.gate("S4A1-24")
def test_complete_regression_ledgers():
    import csv
    import os
    rep = Path(os.environ.get("F1_WC_REPORT_DIR", ROOT / "reports"))

    def ok(p, n, pending=()):
        rows = list(csv.DictReader(open(p)))
        assert len(rows) == n
        for r in rows:
            assert r["status"] == "PASS" or (r["gate"] in pending and r["status"] in ("PENDING", "NOT_EXECUTED")), r
    ok(rep / "s1" / "S1_GATE_LEDGER.csv", 30)
    ok(rep / "S2_GATE_LEDGER.csv", 50)
    ok(rep / "P3_GATE_LEDGER.csv", 26)
    ok(rep / "S3_GATE_LEDGER.csv", 66, pending=("S3-50",))
    conf = json.loads((rep / "conformance" / "conformance_summary.json").read_text())
    assert conf["oracle"]["pass"] == 35 and conf["determinism"]["pass"] == 11 and conf["config"]["pass"] == 8


# ============================================================================== S4A.1.1 corrective gates
@pytest.mark.gate("S4A1-26")
@pytest.mark.gate("S4A1-27")
def test_n3_val_pin_uses_validator_context_date_across_midnight(tmp_path):
    from f1.workload_c.campaign.e2e_s4a1 import build
    from f1.workload_c.engines.core import InProcessFixtureProducer, MethodCatalog, ProducerRederiver, local_date
    camp, run = build(tmp_path / "fx")
    mc = MethodCatalog(ArtifactCatalog(None), {}, ArtifactCatalog(None))
    red = ProducerRederiver(camp.r, mc, InProcessFixtureProducer(camp.r, camp.cs, camp.contexts))
    t = "2025-06-11T06:59:00Z"                                   # 2025-06-10 23:59 America/Los_Angeles
    st = red.rederive("VAL:feed=A", camp.r.current_cut(t), t, 600.0)
    born = mc.overlay_born[st.new_artifact_id]
    assert born == "2025-06-11T07:09:00Z" and local_date(born, camp.r.tz).isoformat() == "2025-06-11"   # 00:09 next day
    k0 = tuple(c for c in mc.contracts[st.new_artifact_id] if c.level == "K0")
    pin = B.n3_pin_from_contract("VAL:feed=A", k0, run.lv_event, mc.overlay.get(st.new_artifact_id).birth_frontier,
                                 camp.r.region_id)
    fp_date = json.loads(k0[0].canonical_bytes)["footprint"]["date"]
    assert pin[4] == fp_date == "2025-06-10"                     # validator context date, not ARTIFACT_BORN's date
    with pytest.raises(B.N3PinError):                            # no trustworthy provenance -> fail closed
        B.n3_pin_from_contract("VAL:feed=A", (), run.lv_event, (("A", 1),), camp.r.region_id)
    src = (ROOT / "src/f1/workload_c/engines/baselines_s4.py").read_text()
    assert "local_date(born" not in src and "local_date(entry" not in src


@pytest.mark.gate("S4A1-28")
def test_n3_control_plane_intervals_disjoint():
    from f1.workload_c.engines import core
    clock = {"t": 0.0}

    def tick():
        clock["t"] += 1.0
        return clock["t"]
    core.set_clock(tick)
    try:
        pins = {s: ("p",) for s in SL}
        bound = {s: own(s, f"a{i}", pin=("p",)) for i, s in enumerate(SL)}
        start = core.now_wall()
        d = B.S4Baseline().decide(view("N3", bound, pins=pins), Ev(), Prod())
        end = core.now_wall()
    finally:
        import time
        core.set_clock(time.perf_counter)
    b = [i for i in d.costs.items if i.category == S.CostCategory.B_CONTROL_PLANE]
    assert [i.component for i in b] == ["n3_pin_index_lookup", "admission"]       # each interval charged once
    assert sum(i.wall_s for i in b) <= end - start                                  # no overlapping interval
    assert not any(i.component == "n3_pin_index" for i in d.costs.items)            # S4A.1 double item removed


@pytest.mark.gate("S4A1-29")
def test_n3_index_update_and_lookup_without_double_counting():
    camp, arms = fixture_run()
    arm = arms[("N3", None)]
    comps = [[i.component for i in d.costs.items if i.category == S.CostCategory.B_CONTROL_PLANE] for d in arm.decisions]
    assert all("n3_pin_index_lookup" in c and "n3_pin_index_update" in c for c in comps)
    for d in arm.decisions:                                    # lookup inside decide is its own interval (not admission)
        assert sum(1 for i in d.costs.items if i.component == "admission") == 1
    from f1.workload_c.campaign.e2e_s4a1 import TICKS, build
    camp2, run2 = build(Path(tempfile.mkdtemp(prefix="s4a1-29-")))
    res = run2.run([("N3", None)], TICKS)
    assert run2.calls["n3_pin"] == len(res[("N3", None)].n3_index)               # each pin created exactly once


@pytest.mark.gate("S4A1-30")
def test_view_construction_charges_only_used_metadata():
    from f1.workload_c.campaign.e2e_s4a1 import TICKS, build
    expect = {"N2": {"n3_pin": 0, "n6_key": 0}, "N4": {"n3_pin": 0, "n6_key": 0, "k0": 0},
              "N0": {"n3_pin": 0, "n6_key": 0, "k0": 0}, "N3": {"n6_key": 0, "k0": 0}, "N6": {"n3_pin": 0}}
    for m, exp in expect.items():
        camp, run = build(Path(tempfile.mkdtemp(prefix=f"s4a1-30-{m}-")))
        res = run.run([(m, 24 if m == "N4" else None)], TICKS)
        for k, v in exp.items():
            assert run.calls[k] == v, (m, k)
        foreign = {"N2": ("n3_", "n6_"), "N4": ("n3_", "n6_"), "N0": ("n3_", "n6_"), "N3": ("n6_",), "N6": ("n3_",)}[m]
        for d in res[(m, 24 if m == "N4" else None)].decisions:
            assert not any(i.component.startswith(foreign) for i in d.costs.items), m


@pytest.mark.gate("S4A1-31")
def test_n6_exact_key_restricted_and_invariant(tmp_path):
    key_a = ("A", "ev:A2", "hA2", "US", "v")
    other = own(SL[0], "zz", born="2025-06-01T01:00:00Z", key=("A", "ev:A9", "h", "US", "v"))
    with pytest.raises(B.EngineError):                         # a non-matching candidate can never enter the view
        B.BaselineView("N6", req(), tuple((s, None) for s in SL), view("N6", {}).current_versions, (),
                       ((SL[0], key_a), (SL[1], ("B",))), ((SL[0], (other,)),), tuple((s, 1.0) for s in SL))
    from f1.workload_c.campaign.e2e_s4a1 import TICKS, build
    camp, run = build(tmp_path / "a")
    base = run.run([("N6", None)], TICKS)[("N6", None)]
    camp2, run2 = build(tmp_path / "b")
    for k in range(5):                                          # unrelated historical VAL artifacts (non-matching keys)
        e = camp2.shared.add(request_slot="VAL:feed=A", producer_type="gtfs-validator", artifact_class="VAL_REPORT",
                             birth_cut_id=f"CUT:junk{k}", birth_frontier=(("A", 2),), logical_inputs=[("A", "A#X", "x")],
                             contract_ids=[], status="SUCCESS", provenance_digest=f"junk{k}", output_digests=[("r", f"{k}")],
                             cost={}, namespace="FIXTURE", binary_mode="FIXTURE_STUB_BINARY")
        camp2.shared_born[e.artifact_id] = "2025-06-09T00:00:00Z"
    orig = run2.n6_key
    run2.n6_key = lambda slot, entry: ("JUNK", entry.artifact_id) if entry.provenance_digest.startswith("junk") else orig(slot, entry)
    alt = run2.run([("N6", None)], TICKS)[("N6", None)]
    assert acts(base) == acts(alt)
    assert not any(sd.artifact_id and sd.action == "REUSE" and "junk" in str(alt.mc.shared.get(sd.artifact_id).provenance_digest)
                   for d in alt.decisions for sd in d.slots if sd.artifact_id in {e.artifact_id for e in
                                                                                 alt.mc.shared.instances(sd.slot_id)})
    assert any(k[0] == "JUNK" for k in alt.n6_index)                                    # indexed, never a candidate


@pytest.mark.gate("S4A1-33")
def test_pi_confirmations_frozen():
    pc = (ROOT / "docs/s4a1/PI_CONFIRMATIONS_FINAL.md").read_text()
    for n in ("2.1", "2.2", "2.3"):
        assert f"§{n}" in pc
    assert "CONFIRMED" in pc and "awaiting" not in pc.lower()
    a = (ROOT / "docs/s4a1/AMENDMENT_S4A_BASELINES_01A.md").read_text()
    for need in ("before VALIDATION", "before real population retrieval", "before any N4 TTL outcome", "before TEST",
                 "independent code audit"):
        assert need in a, need
    v = (ROOT / "00_S4A1_1_EXECUTIVE_VERDICT.md").read_text()
    assert "awaiting" not in v.lower() and "need PI confirmation" not in v
    assert "or True" not in (ROOT / "tests/workload_c/test_s4a1_baselines.py").read_text().replace('"or True"', "")
