"""Session-2 gates S2-17..S2-23 (resource manager, enforcement, in-scope proof, L28)."""
import json
import os
import stat
import sys
from pathlib import Path

import pytest

from f1.workload_c.l28.runner import HostFacts, run_l28
from f1.workload_c.resources.manager import (CgroupV1Backend, CgroupV2Backend, Capabilities,  # noqa: I001
                                             ResourceEnforcementUnavailable, ResourceManager, SystemdRunBackend,
                                             detect_capabilities, otp_authoritative_envelope, sandbox_envelope)
from f1.workload_c.resources.proof import prove_in_scope

JAVA = "/usr/lib/jvm/java-25-openjdk-amd64/bin/java"


def fake_v2(root: Path, n_cpus=8):
    root.mkdir(parents=True, exist_ok=True)
    (root / "cgroup.controllers").write_text("cpuset cpu io memory pids\n")
    (root / "cpuset.mems.effective").write_text("0\n")
    return root


def fake_v1(root: Path):
    for c in ("cpu", "memory", "cpuset"):
        (root / c).mkdir(parents=True, exist_ok=True)
    (root / "cpuset" / "cpuset.mems").write_text("0\n")
    return root


@pytest.mark.gate("S2-17")
def test_capability_detection_layouts(tmp_path):
    v2 = detect_capabilities(fake_v2(tmp_path / "v2"), probe_systemd=False, fs_type="cgroup2fs")
    assert v2.v2_writable and not any(v2.v1_writable.values())
    v1 = detect_capabilities(fake_v1(tmp_path / "v1"), probe_systemd=False, fs_type="tmpfs")
    assert not v1.v2_writable and all(v1.v1_writable.values())
    none = detect_capabilities(tmp_path / "nothing", probe_systemd=False, fs_type="unknown")
    assert not none.v2_writable and not any(none.v1_writable.values())
    host = detect_capabilities()                                   # the real host of this session
    assert host.cgroup_fs and isinstance(host.systemd_run, bool)
    assert ResourceManager(v2).select().name == "cgroup-v2" and ResourceManager(v1).select().name == "cgroup-v1"


@pytest.mark.gate("S2-18")
def test_cgroup_v2_backend_writes_and_attaches(tmp_path):
    root = fake_v2(tmp_path / "cg")
    env = otp_authoritative_envelope(__import__("f1.workload_c.config.spec", fromlist=["x"]).load_protocol_spec())
    with CgroupV2Backend(root).open(env, "t1") as sc:
        d = Path(sc.paths["cgroup"])
        assert d.name.startswith("f1wc_t1_")
        assert (d / "cpu.max").read_text() == "800000 100000"
        assert (d / "memory.max").read_text() == str(32 * 1024 ** 3)
        assert (d / "cpuset.cpus").read_text() == "0-7" and (d / "cpuset.mems").read_text() == "0"
        import subprocess
        cp = subprocess.run(sc.wrapper + [sys.executable, "-c", "import os; print(os.getpid())"], capture_output=True,
                            text=True)
        assert cp.returncode == 0 and (d / "cgroup.procs").read_text().strip() == cp.stdout.strip()
        for f in d.iterdir():
            f.unlink()
    assert not d.exists()                                          # teardown removed the scope


@pytest.mark.gate("S2-18")
@pytest.mark.gate("S2-22")
def test_cgroup_v2_proof_reads_limits_from_process_cgroup(tmp_path, monkeypatch):
    """Simulated v2 host: fake /proc and cgroup roots; the proof must read the files of the cgroup listed in
    /proc/self/cgroup (not the intended command line)."""
    cg = fake_v2(tmp_path / "cg")
    d = cg / "f1wc_job"
    d.mkdir()
    (d / "cpu.max").write_text("50000 100000")
    (d / "memory.max").write_text(str(1024 ** 3))
    (d / "cpuset.cpus.effective").write_text("0")
    proc = tmp_path / "proc" / "self"
    proc.mkdir(parents=True)
    (proc / "status").write_text("Name:\tx\nCpus_allowed_list:\t0\n")
    (proc / "cgroup").write_text("0::/f1wc_job\n")
    monkeypatch.setenv("F1_WC_PROC_ROOT", str(tmp_path / "proc"))
    monkeypatch.setenv("F1_WC_CGROUP_ROOT", str(cg))
    from f1.workload_c.resources.proof import collect
    env = sandbox_envelope(memory="1G")
    r = collect(env.to_dict(), JAVA)
    assert r["cgroup_mode"] == "cgroup-v2" and r["cpu.max"] == "50000 100000" and r["resource_envelope_verified"]
    (d / "memory.max").write_text("max")
    assert not collect(env.to_dict(), JAVA)["memory_max_ok"]


@pytest.mark.gate("S2-19")
@pytest.mark.gate("S2-22")
def test_real_cgroup_v1_scope_and_in_scope_proof(tmp_path):
    caps = detect_capabilities(probe_systemd=False)
    assert all(caps.v1_writable.values()), "this host exposes writable cgroup v1 controllers"
    mgr = ResourceManager(caps)
    assert mgr.select().name == "cgroup-v1"
    env = sandbox_envelope(cpus=1, cpuset="0", memory="1G", heap="256m")
    r = prove_in_scope(mgr, env, job=f"t{os.getpid()}", java=JAVA, workdir=tmp_path)
    assert r["backend"] == "cgroup-v1" and r["cgroup_mode"] == "cgroup-v1"
    assert r["cpu.max"] == "50000 100000" and r["memory.max"] == str(1024 ** 3) and r["Cpus_allowed_list"] == "0"
    assert r["jvm_final_flags"] == {"ActiveProcessorCount": "1", "InitialHeapSize": str(256 * 1024 ** 2),
                                    "MaxHeapSize": str(256 * 1024 ** 2), "UseG1GC": "true"}
    assert r["resource_envelope_verified"] is True and r["envelope_authoritative"] is False
    assert (tmp_path / "TARGET_RESOURCE_RUNTIME_PROOF.json").exists()
    assert any("memory:/f1wc_" in ln for ln in r["proc_self_cgroup"])
    wrong = sandbox_envelope(cpus=1, cpuset="0", memory="1G", heap="256m")
    import dataclasses
    expect_more = dataclasses.replace(wrong, memory_max_bytes=2 * 1024 ** 3)
    # open with 1G but expect 2G: proof must disagree because it reads the APPLIED value
    with CgroupV1Backend("/sys/fs/cgroup").open(wrong, f"m{os.getpid()}") as sc:
        import subprocess
        envp = tmp_path / "e2.json"
        envp.write_text(json.dumps(expect_more.to_dict()))
        out = tmp_path / "p2.json"
        subprocess.run(sc.wrapper + [sys.executable, str(Path(__import__("f1.workload_c.resources.proof",
                                                                         fromlist=["x"]).__file__)), str(out), str(envp), ""],
                       check=True)
    assert json.loads(out.read_text())["memory_max_ok"] is False


@pytest.mark.gate("S2-19")
def test_cgroup_v1_backend_file_layout(tmp_path):
    root = fake_v1(tmp_path / "cg")
    env = sandbox_envelope(cpus=1, cpuset="0", memory="512M")
    with CgroupV1Backend(root).open(env, "x") as sc:
        cpu, mem, cs = (Path(sc.paths[c]) for c in ("cpu", "memory", "cpuset"))
        assert (cpu / "cpu.cfs_period_us").read_text() == "100000" and (cpu / "cpu.cfs_quota_us").read_text() == "50000"
        assert (mem / "memory.limit_in_bytes").read_text() == str(512 * 1024 ** 2)
        assert (cs / "cpuset.cpus").read_text() == "0" and (cs / "cpuset.mems").read_text() == "0" and "--v1" in sc.wrapper


@pytest.mark.gate("S2-20")
def test_systemd_capability_handling(tmp_path, monkeypatch):
    real = detect_capabilities()
    assert real.systemd_run is False                               # no systemd PID 1 in this session: not selected
    bindir = tmp_path / "bin"
    bindir.mkdir()
    fake = bindir / "systemd-run"
    fake.write_text("#!/bin/sh\nexit 0\n")
    fake.chmod(fake.stat().st_mode | stat.S_IEXEC)
    monkeypatch.setenv("PATH", f"{bindir}:{os.environ['PATH']}")
    c = detect_capabilities(tmp_path / "none", fs_type="unknown")
    assert c.systemd_run and set(c.systemd_properties) == {"MemoryMax", "CPUQuota", "AllowedCPUs"}
    assert ResourceManager(c).select().name == "systemd-run"
    fake.write_text("#!/bin/sh\ncase \"$*\" in *AllowedCPUs*) exit 1;; esac\nexit 0\n")
    c2 = detect_capabilities(tmp_path / "none", fs_type="unknown")
    assert not c2.systemd_run and "AllowedCPUs" not in c2.systemd_properties      # partial support is not enough
    env = otp_authoritative_envelope(__import__("f1.workload_c.config.spec", fromlist=["x"]).load_protocol_spec())
    w = SystemdRunBackend().open(env, "j").wrapper
    assert w[:3] == ["systemd-run", "--scope", "--quiet"] and "CPUQuota=800%" in w and "AllowedCPUs=0-7" in w
    assert f"MemoryMax={32 * 1024 ** 3}" in w


@pytest.mark.gate("S2-21")
def test_taskset_only_rejected(tmp_path):
    c = Capabilities(str(tmp_path), "unknown", False, {"cpu": False, "memory": False, "cpuset": False}, False, [], True)
    with pytest.raises(ResourceEnforcementUnavailable) as e:
        ResourceManager(c).select()
    assert "taskset" in str(e.value)
    assert ResourceManager(c, allow_noop=True).select().name == "noop-fixture"
    env = otp_authoritative_envelope(__import__("f1.workload_c.config.spec", fromlist=["x"]).load_protocol_spec())
    big = HostFacts(64, 384, "Intel(R) Xeon(R) Silver 4314 CPU @ 2.40GHz", True)
    r = run_l28(ResourceManager(c), env, tmp_path / "o", None, lambda e, w: [], host=big)
    assert r.overall == "BLOCKED" and "taskset" in r.reason


@pytest.mark.gate("S2-22")
def test_noop_backend_never_verifies(tmp_path):
    c = Capabilities(str(tmp_path), "unknown", False, {"cpu": False, "memory": False, "cpuset": False}, False, [], True)
    r = prove_in_scope(ResourceManager(c, allow_noop=True), sandbox_envelope(), "noop", java=JAVA, workdir=tmp_path)
    assert r["backend"] == "noop-fixture" and r["resource_envelope_verified"] is False


def _sim_host(tmp_path, monkeypatch):
    """Simulated target-sized host: fake cgroup-v2 root + fake /proc reporting the authoritative envelope."""
    cg = fake_v2(tmp_path / "cg")
    proc = tmp_path / "proc" / "self"
    proc.mkdir(parents=True)
    (proc / "status").write_text("Cpus_allowed_list:\t0-7\n")
    (proc / "cgroup").write_text("0::/f1wc_l28proof\n")
    monkeypatch.setenv("F1_WC_PROC_ROOT", str(tmp_path / "proc"))
    monkeypatch.setenv("F1_WC_CGROUP_ROOT", str(cg))
    caps = detect_capabilities(cg, probe_systemd=False, fs_type="cgroup2fs")
    return ResourceManager(caps), cg


@pytest.mark.gate("S2-23")
def test_l28_orchestration_paths(tmp_path, monkeypatch):
    from f1.workload_c.config.spec import load_protocol_spec
    env = otp_authoritative_envelope(load_protocol_spec())
    small = run_l28(ResourceManager(detect_capabilities(probe_systemd=False)), env, tmp_path / "real", JAVA,
                    lambda e, w: [])
    assert small.overall == "BLOCKED" and small.physical_l28 == "NOT_EXECUTED_ON_TARGET"   # this session's host
    mgr, cg = _sim_host(tmp_path, monkeypatch)
    big = HostFacts(64, 384, "Intel(R) Xeon(R) Silver 4314 CPU @ 2.40GHz", True)
    calls = []

    def suite_pass(e, wrapper):
        calls.append(wrapper)
        return [{"test": t, "result": "PASS"} for t in ("D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10", "DF")]

    import f1.workload_c.resources.proof as P
    real_prove = P.prove_in_scope

    def prove_sim(manager, envelope, job, java=None, workdir=None):
        d = cg / "f1wc_l28proof"
        d.mkdir(exist_ok=True)
        (d / "cpu.max").write_text("800000 100000")
        (d / "memory.max").write_text(str(32 * 1024 ** 3))
        (d / "cpuset.cpus.effective").write_text("0-7")
        r = P.collect(envelope.to_dict(), None)
        r["jvm_ok"] = True                                   # JVM 24 GiB heap cannot be committed in this sandbox
        r["resource_envelope_verified"] = r["cpu_quota_ok"] and r["memory_max_ok"] and r["cpuset_ok"]
        r["backend"] = manager.select().name
        return r
    import f1.workload_c.l28.runner as RN
    monkeypatch.setattr(RN, "prove_in_scope", prove_sim)
    r = run_l28(mgr, env, tmp_path / "sim", None, suite_pass, host=big)
    assert r.overall == "PASS" and r.physical_l28 == "NOT_EXECUTED_ON_TARGET" and calls and calls[0][:2][1].endswith("attach.py")
    monkeypatch.setenv("F1_WC_TARGET_ATTESTATION", "1")
    r2 = run_l28(mgr, env, tmp_path / "sim2", None, suite_pass, host=big)
    assert r2.physical_l28 == "EXECUTED_ON_TARGET"           # attestation logic only (simulated host)
    monkeypatch.delenv("F1_WC_TARGET_ATTESTATION")
    rf = run_l28(mgr, env, tmp_path / "sim3", None, lambda e, w: suite_pass(e, w)[:-1] + [{"test": "DF", "result": "FAIL"}],
                 host=big)
    rb = run_l28(mgr, env, tmp_path / "sim4", None, lambda e, w: suite_pass(e, w)[:-1] + [{"test": "DF", "result": "BLOCKED"}],
                 host=big)
    assert rf.overall == "FAIL" and rb.overall == "BLOCKED"
    sb = run_l28(mgr, sandbox_envelope(), tmp_path / "sb", None, suite_pass, host=big)
    assert sb.overall != "PASS"                                   # a sandbox envelope can never yield L28 PASS
    _ = real_prove
    assert json.loads((tmp_path / "sim" / "target_result.json").read_text())["overall"] == "PASS"


@pytest.mark.gate("S2-23")
def test_l28_sandbox_rehearsal_evidence():
    """scripts/run_l28_fixture.sh runs the authoritative attempt + a sandbox rehearsal (real cgroup v1 scope, real
    OTP determinism suite D1–D10+DF) in the same test run; verify that evidence."""
    p = Path(os.environ.get("F1_WC_L28_DIR", Path(__file__).resolve().parents[2] / "reports" / "l28")) / "L28_SUMMARY.json"
    s = json.loads(p.read_text())
    assert s["authoritative"]["overall"] == "BLOCKED" and s["authoritative"]["physical_l28"] == "NOT_EXECUTED_ON_TARGET"
    sb = s["sandbox_rehearsal"]
    assert sb["proof"]["resource_envelope_verified"] is True and sb["proof"]["backend"] == "cgroup-v1"
    assert set(sb["tests"]) == {"D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10", "DF"}
    assert all(v == "PASS" for v in sb["tests"].values()) and sb["overall"] == "FAIL"   # non-authoritative envelope
    assert sb["physical_l28"] == "NOT_EXECUTED_ON_TARGET"
