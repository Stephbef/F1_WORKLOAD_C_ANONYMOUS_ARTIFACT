import itertools

import pytest

from f1.workload_c.ingestion.gtfs import GtfsSummary, Stop
from f1.workload_c.licensing.engine import LicenseClassification, LicenseEngine, LicenseEvidence
from f1.workload_c.regions.dedup import deduplicate, normalize_url
from f1.workload_c.regions.model import FeedFacts, FeedRecord


@pytest.fixture(scope="module")
def eng(cfg):
    return LicenseEngine(cfg.spec, cfg.license_table)


def ev(url=None, lid=None):
    return LicenseEvidence("mdb-1", url, lid, "test")


CASES = [
    (ev("https://creativecommons.org/publicdomain/zero/1.0/"), "PASS", "A", False, "LICENSE_REDISTRIBUTION_PERMITTED"),
    (ev("http://www.creativecommons.org/licenses/by/4.0/legalcode"), "PASS", "A+C", True, "LICENSE_REDISTRIBUTION_PERMITTED"),
    (ev(None, "research-use-only"), "RESTRICTED_BUT_USABLE", "B", False, "LICENSE_RESEARCH_ONLY"),
    (ev("https://creativecommons.org/licenses/by-nd/4.0/deed.en"), "RESTRICTED_BUT_USABLE", "B+C", True, "LICENSE_RESEARCH_ONLY"),
    (ev(None, None), "UNCLEAR", "D", False, "NO_LICENSE_EVIDENCE"),
    (ev("https://example.invalid/terms"), "UNCLEAR", "D", False, "UNKNOWN_LICENSE_URL"),
    (ev(None, "some-new-licence"), "UNCLEAR", "D", False, "UNKNOWN_LICENSE_IDENTIFIER"),
    (ev("https://creativecommons.org/publicdomain/zero/1.0/", "login-only-terms"), "UNCLEAR", "D", False,
     "CONFLICTING_LICENSE_EVIDENCE"),
    (ev(None, "LOGIN-ONLY-TERMS"), "INCOMPATIBLE", "E", False, "LICENSE_INCOMPATIBLE"),
    (ev(None, "proprietary-prohibits-research"), "INCOMPATIBLE", "E", False, "LICENSE_INCOMPATIBLE"),
]


@pytest.mark.gate("S1-13")
@pytest.mark.parametrize("e,cls,letters,attr,reason", CASES)
def test_license_classes(eng, e, cls, letters, attr, reason):
    d = eng.classify(e)
    assert (d.classification, d.license_class, d.attribution_required, d.reason_code) == (cls, letters, attr, reason)
    assert d.eligible == (cls in ("PASS", "RESTRICTED_BUT_USABLE"))
    assert d.evidence["source"] == "test" and d.provenance["table_digest"]
    assert d.redistribution_constraints and d.processing_constraints


@pytest.mark.gate("S1-13")
def test_all_four_classes_reachable_and_unclear_never_pass(eng, cfg):
    seen = {eng.classify(c[0]).classification for c in CASES}
    assert seen == {x.value for x in LicenseClassification}
    for lid in cfg.license_table.raw["identifiers"]:
        d = eng.classify(ev(None, lid))
        assert d.classification != "UNCLEAR"
    for junk in ("", "   ", "cc-by", "https://", "mailto:x"):
        d = eng.classify(ev(junk or None, None))
        assert d.classification == "UNCLEAR" and not d.eligible


@pytest.mark.gate("S1-13")
def test_fixture_license_ledger(full_run):
    from conftest import read_csv
    rows = read_csv(full_run["dir"] / "phases/04_license_gate/license_ledger.csv")
    classes = {r["classification"] for r in rows}
    assert classes == {"PASS", "RESTRICTED_BUT_USABLE", "UNCLEAR", "INCOMPATIBLE"}


def rec(fid, url=None, provider=None, name=None, redirects=()):
    return FeedRecord(fid, True, (), "active", 0, url, provider, name, tuple(redirects), None, None)


def facts(fid, h, agency_ids, names=None):
    f = FeedFacts(fid, latest_canonical_sha256=h)
    f.latest_summary = GtfsSummary([Stop("s", 0, 0)], ["UTC"] * len(agency_ids),
                                   list(names) if names is not None else [f"name-{a}" for a in agency_ids],
                                   agency_ids=list(agency_ids))
    return f


def world():
    R = {"m1": rec("m1", "https://a.example/x.zip", "P1", "N1"),
         "m2": rec("m2", "HTTPS://A.Example:443/x.zip/", "P2", "N2"),       # identical URL -> m1
         "m3": rec("m3", "https://b.example/y.zip", "P3", "N3"),
         "m4": rec("m4", "https://c.example/z.zip", "P4", "N4"),            # identical content to m3
         "m5": rec("m5", "https://d.example", " p1 ", "n1"),                # alias of m1
         "m6": rec("m6", "https://e.example", "P6", "N6", redirects=("m3",)),
         "m7": rec("m7", "https://f.example", "Bundle", "All"),            # bundle over m8 + m9
         "m8": rec("m8", "https://g.example", "P8", "N8"),
         "m9": rec("m9", "https://h.example", "P9", "N9"),
         "m10": rec("m10", "https://i.example", "P10", "N10")}
    F = {"m1": facts("m1", "h1", ["Ag1"]), "m2": facts("m2", "h2", ["Ag2"]), "m3": facts("m3", "h3", ["Ag3"]),
         "m4": facts("m4", "h3", ["Ag4"]), "m5": facts("m5", "h5", ["Ag5"]), "m6": facts("m6", "h6", ["Ag6"]),
         "m7": facts("m7", "h7", ["Ag8", "Ag9"]), "m8": facts("m8", "h8", ["Ag8"]), "m9": facts("m9", "h9", ["Ag9"]),
         "m10": facts("m10", "h10", ["Ag10", "Ag11"])}
    return R, F


@pytest.mark.gate("S1-14")
def test_dedup_rules_reason_codes():
    R, F = world()
    d = deduplicate(R, F, list(R), 0.5)
    got = {k: (v.reason, v.collapsed_into) for k, v in d.items()}
    assert got == {"m1": ("KEPT", None), "m2": ("DEDUP_IDENTICAL_URL", "m1"), "m3": ("KEPT", None),
                   "m4": ("DEDUP_IDENTICAL_CONTENT", "m3"), "m5": ("DEDUP_ALIAS", "m1"), "m6": ("DEDUP_REDIRECT", "m3"),
                   "m7": ("DEDUP_MERGED_BUNDLE", "m8"), "m8": ("KEPT", None), "m9": ("KEPT", None),
                   "m10": ("KEPT", None)}


@pytest.mark.gate("S1-14")
def test_dedup_input_order_independent():
    R, F = world()
    ref = {k: v for k, v in deduplicate(R, F, list(R), 0.5).items()}
    for perm in itertools.islice(itertools.permutations(list(R)), 0, 2000, 97):
        R2 = {k: R[k] for k in perm}
        assert deduplicate(R2, F, list(perm), 0.5) == ref


@pytest.mark.gate("S1-14")
def test_bundle_threshold_boundaries_and_transitivity():
    R = {f"m{i}": rec(f"m{i}", f"https://x{i}.example") for i in range(1, 5)}
    F = {"m1": facts("m1", "a", ["A", "B", "C", "D"]), "m2": facts("m2", "b", ["A", "X"]),     # 1/2 = 0.5 -> drop m1
         "m3": facts("m3", "c", ["Q", "R"]), "m4": facts("m4", "d", ["Q", "S"])}               # equal sizes -> keep
    d = deduplicate(R, F, list(R), 0.5)
    assert d["m1"].reason == "DEDUP_MERGED_BUNDLE" and d["m3"].kept and d["m4"].kept
    F["m2"] = facts("m2", "b", ["A", "X", "Y"])                                                 # 1/3 < 0.5
    assert deduplicate(R, F, list(R), 0.5)["m1"].kept
    R2 = {"a": rec("a", "https://u1"), "b": rec("b", "https://u2"), "c": rec("c", "https://u2")}
    F2 = {"a": facts("a", "H", ["1"]), "b": facts("b", "H2", ["2"]), "c": facts("c", "H", ["3"])}
    d2 = deduplicate(R2, F2, list(R2), 0.5)     # c == b by URL; b survives url rule, then a == b? no: a == c by hash
    assert d2["c"].reason == "DEDUP_IDENTICAL_URL" and d2["a"].kept and d2["b"].kept
    assert normalize_url("http://H:80/a/") == "http://h/a" and normalize_url("https://h:8443/a?q=1") == "https://h:8443/a?q=1"


@pytest.mark.gate("S1-14")
def test_fixture_dedup_controlled_cases(full_run):
    from conftest import read_jsonl
    d = {r["feed_id"]: r for r in read_jsonl(full_run["dir"] / "phases/05_eligible_regions/dedup_decisions.jsonl")}
    reasons = {r["reason"] for r in d.values()}
    assert {"DEDUP_IDENTICAL_CONTENT", "DEDUP_IDENTICAL_URL", "DEDUP_ALIAS", "DEDUP_REDIRECT",
            "DEDUP_MERGED_BUNDLE", "KEPT"} == reasons
