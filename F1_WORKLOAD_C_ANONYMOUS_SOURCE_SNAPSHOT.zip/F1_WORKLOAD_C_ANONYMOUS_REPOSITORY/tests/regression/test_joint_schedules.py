"""J1–J4 (T-A, T-B): identifiability of the primary asynchronous joint phenomenon. Deterministic and synthetic."""
import json

import pytest
import yaml

from conftest import DAY, ROOT, in_set, make_artifact, put_json
from f1.admission.engine import AdmissionEngine
from f1.common.util import parse_iso
from f1.contracts.lang import Evaluator
from f1.core.gamma import Gamma
from f1.core.history import History, Version
from f1.statistics.metrics import joint_metrics
from f1.workloads.base import ClusterSpec

T0 = parse_iso("2025-01-01")


def workload(cas, tmp_path, sync: bool, grace):
    from f1.workloads.real import WorkloadA
    w = yaml.safe_load((ROOT / "configs" / "workload_a.yaml").read_text())["workload_a"]
    w["window"] = {"birth_start": "2025-01-01", "birth_end": "2025-01-03", "horizon_end": "2025-02-01"}
    w["schedules"]["vuln_on_lock_change"] = sync
    w["secondary_policy_grace"] = {"p_grace_days": grace}
    wl = WorkloadA({"workload_a": w}, cas, tmp_path)
    wl._repo["r"] = {"tags": [], "revs": []}
    return wl


def history(cas):
    return History([Version("S", "s0", T0 - DAY, put_json(cas, "s0")), Version("S", "s1", T0 + DAY + 10 * 3600, put_json(cas, "s1")),
                    Version("V", "v0", T0 - DAY, put_json(cas, "v0")), Version("P", "p0", 0, put_json(cas, "p0")),
                    Version("L", "l0", 0, put_json(cas, "l0"))])


def artifacts(wl, h, lic_tolerant=False):
    arts = []
    for i, (t, pid) in enumerate(wl.births(ClusterSpec("r", "test"), h)):
        cut = h.latest_cut(t)
        typ = "vuln_gate" if pid == "cargo-audit" else "lic_gate"
        s_now = cut["S"]
        region = in_set("S", ["s0", "s1"]) if (lic_tolerant and typ == "lic_gate") else in_set("S", [s_now])
        a = make_artifact(f"{typ}{i}", h, cut, ["S"], {"K2": region}, atype=typ)
        a.birth_time = t
        arts.append(a)
    return arts


def primary(wl, h, arts):
    """Primary events of the dashboard tick 2025-01-02 12:00 (lockfile changed at 10:00 the same day)."""
    t = T0 + DAY + 12 * 3600
    return [e for e in wl.consumer_events(ClusterSpec("r", "test"), h, arts)
            if e.scenario == "primary_async_joint" and abs(e.t - t) < 1]


def joint_outcome(h, loader, arts, ev):
    by = {a.artifact_id: a for a in arts}
    R = [by[i] for i in ev.artifact_ids]
    g = Gamma.from_json(ev.gamma)
    eng = AdmissionEngine(h, Evaluator(loader))
    cands = list(h.enumerate_cuts(g.allowed(h)))
    unary = [any(eng.kappa_eff(a, "K2", c)[0] for c in cands) for a in R]
    admitted = eng.admit(R, "K2", g, ev.event_id, ev.t)["admitted"]
    return unary, admitted, R


def test_J1_synchronised_schedule_has_no_stale_S_divergence(cas, loader, tmp_path):
    wl, h = workload(cas, tmp_path, sync=True, grace=[14]), history(cas)
    arts = artifacts(wl, h)
    for ev in primary(wl, h, arts):
        unary, admitted, R = joint_outcome(h, loader, arts, ev)
        assert {a.birth_cut["S"] for a in R} == {"s1"}       # both producers re-ran on the lockfile change
        assert all(unary) and admitted                       # common witness: no M4


def test_J2_natural_asynchronous_schedule_produces_M4(cas, loader, tmp_path):
    wl, h = workload(cas, tmp_path, sync=False, grace=[14]), history(cas)
    births = wl.births(ClusterSpec("r", "test"), h)
    assert ("cargo-audit" in {p for _, p in births}) and not any(p == "cargo-audit" and abs(t - (T0 + DAY + 10 * 3600 + 1)) < 2 for t, p in births)
    arts = artifacts(wl, h)
    m4 = 0
    for ev in primary(wl, h, arts):
        unary, admitted, R = joint_outcome(h, loader, arts, ev)
        assert {a.birth_cut["S"] for a in R} == {"s0", "s1"}  # vulnerability artifact @S_i, license artifact @S_i+1
        if ev.gamma["rules"]["S"]["last_k"] >= 2:
            assert all(unary) and not admitted                # each individually acceptable, no common witness
            m4 += 1
        else:
            assert not all(unary)                             # Gamma excludes S_i: a unary failure, not M4
    assert m4 == 6                                            # k in {3,5} x V windows {0,1,7}
    rows = [{"event_id": f"e{i}", "cluster": "r", "scenario": "primary_async_joint", "cell": "c", "oracle_unary": [True, True],
             "oracle_W_nonempty": False, **{f"{k}_unary": [True, True] for k in ("K0", "K1", "K2", "K3")},
             **{f"{k}_admitted": False for k in ("K0", "K1", "K2", "K3")}} for i in range(m4)]
    assert joint_metrics(rows, B=20, seed=1)["primary_async_joint/ALL"]["anomaly_count"] == 6


def test_J3_overlapping_contracts_admit_jointly(cas, loader, tmp_path):
    wl, h = workload(cas, tmp_path, sync=False, grace=[14]), history(cas)
    arts = artifacts(wl, h, lic_tolerant=True)
    for ev in primary(wl, h, arts):
        unary, admitted, R = joint_outcome(h, loader, arts, ev)
        if ev.gamma["rules"]["S"]["last_k"] >= 2:
            assert all(unary) and admitted                    # common witness at S_i


def test_J4_primary_M4_is_independent_of_policy_grace(cas, loader, tmp_path):
    out = []
    for grace in ([14], []):
        wl, h = workload(cas, tmp_path, sync=False, grace=grace), history(cas)
        arts = artifacts(wl, h)
        out.append(sorted((ev.event_id, joint_outcome(h, loader, arts, ev)[1]) for ev in primary(wl, h, arts)))
    assert out[0] == out[1]
