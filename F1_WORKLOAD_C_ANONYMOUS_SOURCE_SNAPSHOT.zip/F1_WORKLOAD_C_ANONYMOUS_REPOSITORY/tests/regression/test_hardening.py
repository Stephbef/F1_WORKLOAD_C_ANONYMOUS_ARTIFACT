"""Hardening regressions R-A ... R-I and oracle-leakage tests."""
import ast
import copy
import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

from conftest import ROOT, DAY, put_json
from f1.catalog.artifact import Artifact
from f1.core.history import History, Version
from f1.statistics.disagreements import CLASSES, binom_upper, classify, summarize_soundness, unary_disagreements
from f1.statistics.gates import evaluate, g5
from f1.statistics.metrics import incremental_vs_k0, repair_metrics

sys.path.insert(0, str(ROOT / "tests" / "integration"))
from helpers import make_config, run_f1  # noqa: E402

GATES = yaml.safe_load((ROOT / "configs" / "decision_gates.yaml").read_text())


# ---------------------------------------------------------------- R-A primary joint without policy grace
def _wa(cas, tmp_path, grace):
    from f1.workloads.real import WorkloadA
    cfg = {"workload_a": yaml.safe_load((ROOT / "configs" / "workload_a.yaml").read_text())["workload_a"]}
    cfg["workload_a"]["window"] = {"birth_start": "2025-01-01", "birth_end": "2025-01-10", "horizon_end": "2025-02-01"}
    cfg["workload_a"]["secondary_policy_grace"] = {"p_grace_days": grace}
    wl = WorkloadA(cfg, cas, tmp_path)
    wl._repo["r"] = {"tags": [], "revs": []}
    from f1.common.util import parse_iso
    t0 = parse_iso("2025-01-01")
    h = History([Version("S", "s0", t0 - DAY, put_json(cas, "s0")), Version("S", "s1", t0 + 3 * DAY, put_json(cas, "s1")),
                 Version("V", "v0", t0 - DAY, put_json(cas, "v0")), Version("P", "p0", 0, put_json(cas, "p0")),
                 Version("P", "p1", t0 + 4 * DAY, put_json(cas, "p1")), Version("L", "l", 0, put_json(cas, "l"))])

    def art(aid, typ, t):
        return Artifact(aid, "A", "r", "test", "x", typ, t, {}, {}, [], {}, "v", "x", 1.0, {}, {})
    arts = [art("v1", "vuln_gate", t0), art("l1", "lic_gate", t0)]
    from f1.workloads.base import ClusterSpec
    return wl.consumer_events(ClusterSpec("r", "test"), h, arts)


def test_RA_primary_joint_scenario_does_not_use_policy_grace(cas, tmp_path):
    with_grace = _wa(cas, tmp_path, [14])
    without = _wa(cas, tmp_path, [])
    prim = [e for e in with_grace if e.scenario == "primary_async_joint"]
    assert prim and all(e.gamma["rules"]["P"] == {"latest": True} for e in prim)
    assert all("window_s" not in e.gamma["rules"]["P"] for e in prim)
    # the primary population is identical whether or not the secondary grace analysis is configured
    key = lambda es: sorted((e.event_id, json.dumps(e.gamma, sort_keys=True)) for e in es if e.scenario == "primary_async_joint")
    assert key(with_grace) == key(without)
    assert any(e.scenario == "secondary_policy_grace" for e in with_grace)
    assert not any(e.scenario == "secondary_policy_grace" for e in without)


def test_RA_gate_G5_reads_only_the_primary_scenario():
    ci = {"lo": 0.1, "hi": 0.3}
    def grp(anom):
        base = {"n_events": 10, "anomaly_count": anom, "clusters_with_oracle_joint_failure": 5 if anom else 0, "clusters_total": 5,
                "M4_oracle": {"macro": 0.2 if anom else 0.0, "ci": ci if anom else {"lo": 0.0, "hi": 0.0}}}
        base.update({k: {"naive_composition_error": {"macro": 0.0}} for k in CLASSES})
        return base
    w = {"joint": {"secondary_policy_grace/ALL": grp(7), "primary_async_joint/ALL": grp(0)}}
    assert g5(w, GATES, GATES["gates"]["G5"])["outcome"] == "FAIL"
    w = {"joint": {"secondary_policy_grace/ALL": grp(0), "primary_async_joint/ALL": grp(7)}}
    assert g5(w, GATES, GATES["gates"]["G5"])["outcome"] == "PASS"


# ---------------------------------------------------------------- R-B / R-C incremental benefit over K0
def _row(aid, cl, use, k0, k1, cost=10.0, e0=0.1, e1=0.3, c0=0.12, c1=0.35):
    r = {"artifact_id": aid, "cluster": cl, "use": use, "cost_s": cost}
    for c, v, e, ch in (("K0", k0, e0, c0), ("K1", k1, e1, c1), ("K2", k1, e1, c1), ("K3", k1, e1, c1)):
        r[f"{c}_eff"], r[f"{c}_eval_s"], r[f"{c}_check_s"] = v, e, ch
    return r


def test_RB_K1_identical_to_K0_yields_no_incremental_gain():
    rows = [_row("a", "c1", True, False, False), _row("a", "c1", True, True, True), _row("b", "c2", False, False, False),
            _row("b", "c2", True, True, True)]
    inc = incremental_vs_k0(rows, "K1", B=50, seed=1)
    assert inc["delta_recall"]["mean"] == 0.0 and inc["totals"]["recovered_pairs"] == 0
    assert inc["totals"]["additional_avoided_s"] == 0.0
    assert inc["totals"]["delta_nb_total_s"] <= 0.0 and inc["delta_nb_per_pair_s"]["mean"] <= 0.0


def test_RC_K1_recovers_oracle_valid_cases_and_dNB_is_exact():
    rows = [_row("a", "c1", True, False, True, cost=10.0),    # recovered: credited 10
            _row("a", "c1", True, True, True, cost=10.0),     # K0 already accepts: NOT credited
            _row("b", "c2", False, False, True, cost=10.0),   # K1 unsafe: not credited, counted as incremental unsafe
            _row("b", "c2", True, False, False, cost=10.0)]   # neither accepts
    inc = incremental_vs_k0(rows, "K1", B=50, seed=1)
    t = inc["totals"]
    assert t["recovered_pairs"] == 1 and t["additional_avoided_s"] == 10.0 and t["incremental_unsafe_pairs"] == 1
    d_eval, d_adm = 4 * (0.3 - 0.1), 4 * ((0.35 - 0.3) - (0.12 - 0.1))
    assert abs(t["incremental_contract_s"] - d_eval) < 1e-12 and abs(t["incremental_admission_s"] - d_adm) < 1e-12
    assert abs(t["delta_nb_total_s"] - (10.0 - d_eval - d_adm)) < 1e-12
    # dRecall per artifact over usable pairs: a: 1.0-0.5 ; b: 0.0-0.0 -> mean 0.25
    assert abs(inc["delta_recall"]["mean"] - 0.25) < 1e-12


# ---------------------------------------------------------------- R-D raw M5 > 0 but M5_net < 0
def test_RD_overhead_turns_positive_raw_savings_negative():
    rows = [{"event_id": "e", "cluster": "c", "scenario": "primary_async_joint", "cell": "x", "cls": "K2",
             "opt_cost": 0.10, "recompute_all": 0.30, "current_cut_cost": 0.20, "feasible": True,
             "contract_eval_s": 0.05, "admission_excl_s": 0.03, "solver_excl_s": 0.04, "solver_s": 0.06}]
    r = repair_metrics(rows, B=20, seed=1)["primary_async_joint/x/K2"]
    assert r["M5_savings_vs_current_cut"]["macro"] > 0          # raw savings 0.10 / 0.20
    assert r["M5_net_vs_current_cut"]["mean"] < 0               # (0.20 - 0.10 - 0.12) / 0.20
    assert abs(r["M5_net_vs_current_cut"]["mean"] - (0.20 - 0.10 - 0.12) / 0.20) < 1e-12
    assert r["events_raw_positive_net_negative"]["vs_current_cut"] == 1
    assert r["M5_net_vs_recompute_all"]["mean"] > 0             # (0.30-0.10-0.12)/0.30: reported, not hidden


# ---------------------------------------------------------------- R-E deterministic gates
def test_RE_decision_gates_are_deterministic(full_engineering_run):
    run = full_engineering_run
    m = json.loads((run / "statistics" / "metrics.json").read_text())
    a = evaluate(m, m["soundness"], {"synthetic": True}, {}, GATES)
    b = evaluate(copy.deepcopy(m), copy.deepcopy(m["soundness"]), {"synthetic": True}, {}, copy.deepcopy(GATES))
    assert json.dumps(a, sort_keys=True) == json.dumps(b, sort_keys=True)
    g = json.loads((run / "statistics" / "DECISION_GATES.json").read_text())
    assert set(g["by_workload"]["synthetic"]) == {"G1", "G2", "G3", "G4", "G5", "G6"}
    assert (run / "DECISION_GATES.md").read_text().startswith("# DECISION GATES")
    assert "ENGINEERING ONLY" in (run / "DECISION_GATES.md").read_text()


# ---------------------------------------------------------------- R-F gates hash frozen; tampering refused
def test_RF_freeze_manifest_contains_gates_hash_and_tampering_is_refused(tmp_path):
    cdir = tmp_path / "configs"
    shutil.copytree(ROOT / "configs", cdir)
    cfg = make_config(tmp_path)
    c = yaml.safe_load(cfg.read_text())
    c["paths"]["configs"] = str(cdir)
    cfg.write_text(yaml.safe_dump(c))
    run_f1("freeze", "--config", str(cfg))
    fm = json.loads((tmp_path / "FREEZE_MANIFEST.json").read_text())
    from f1.common.util import sha256_file
    assert fm["decision_gates_sha256"] == sha256_file(cdir / "decision_gates.yaml")
    assert fm["sha256"]["config:decision_gates.yaml"] == fm["decision_gates_sha256"]
    assert fm["code_sha256"] and (tmp_path / "FREEZE_MANIFEST.md").exists()
    (cdir / "decision_gates.yaml").write_text((cdir / "decision_gates.yaml").read_text() + "\n# edited after freeze\n")
    p = run_f1("full", "--config", str(cfg), check=False)
    assert p.returncode != 0 and "decision gates changed" in (p.stdout + p.stderr)


# ---------------------------------------------------------------- R-G U1–U4 classification + serialisation
def test_RG_disagreement_classification_and_serialisation(cas, tmp_path):
    assert classify("K1", None, True, False)[0] == "U4"
    assert classify("K1", True, False, True)[0] == "U3"
    assert classify("K0", True, False, False)[0] == "U3"
    assert classify("K3", True, False, False)[0] == "U1"
    assert classify("K2", True, False, False)[0] == "U1"
    assert classify("K2", False, False, False)[0] == "U2"
    assert classify("K1", None, False, False)[0] == "UNDETERMINED"
    h = History([Version("X", "x0", 0, put_json(cas, 1)), Version("X", "x1", 1, put_json(cas, 2))])
    a = Artifact("r", "test", "c", "test", "p", "t", 0.0, {"X": "x0"}, {}, ["X"], {"X": h.content({"X": "x0"}, "X")}, "LOW", "v", 1.0,
                 {"K3": {"x": 1}}, {"hidden_reads": []})
    pairs = {"p1": {"artifact_id": "r", "cut": {"X": "x1"}, "t": 1.0, "age_s": 1.0}}
    adm = {"p1": {"K0_eff": False, "K1_eff": True, "K2_eff": True, "K3_eff": False}}
    orc = {"p1": {"use": False, "oracle_value": "HIGH", "oracle_nondeterministic": False, "birth_nondeterministic": False}}
    rows = unary_disagreements(pairs, adm, orc, {"r": a}, lambda art, cut: {i: h.content(cut, i) for i in art.read_set})
    assert {r["cls"]: r["label"] for r in rows} == {"K1": "U2", "K2": "U2"}
    assert rows[0]["changed_items"] == ["X"]
    p = tmp_path / "d.jsonl"
    p.write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in rows))
    back = [json.loads(l) for l in p.read_text().splitlines()]
    assert back == json.loads(json.dumps(rows))
    s = summarize_soundness([{"wl": "test", "artifact_type": "t", "K0_eff": True, "K1_eff": True, "K2_eff": True, "K3_eff": True}] * 100,
                            [], 0.05)
    assert s["test/t/K1"]["U2"] == 0 and abs(s["test/t/K1"]["u2_upper_bound"] - (1 - 0.05 ** (1 / 100))) < 1e-6
    assert "not a proof" in s["test/t/K1"]["statement"]
    assert abs(binom_upper(0, 300) - (1 - 0.05 ** (1 / 300))) < 1e-6


# ---------------------------------------------------------------- R-H / leakage
ADMISSION_SIDE = ["admission", "repair", "core", "catalog", "contracts"]


def test_RH_static_admission_side_never_imports_oracle_or_producer_execution():
    src = ROOT / "src" / "f1"
    bad = []
    for pkg in ADMISSION_SIDE:
        for f in (src / pkg).rglob("*.py"):
            tree = ast.parse(f.read_text())
            for node in ast.walk(tree):
                names = []
                if isinstance(node, ast.Import):
                    names = [a.name for a in node.names]
                elif isinstance(node, ast.ImportFrom):
                    names = [("." * node.level) + (node.module or "")]
                for n in names:
                    if "oracle" in n or "producers" in n or "stages_eval" in n or "hermetic" in n:
                        bad.append(f"{f.relative_to(src)}: {n}")
    assert not bad, bad


def test_RH_admission_role_cannot_execute_producers(cas, tmp_path):
    code = f"""
import sys, json; sys.path.insert(0, {str(ROOT / 'src')!r})
from f1.common.firewall import install_role_guard, FirewallViolation
from f1.common.util import CAS
from f1.core.history import History, Version
from f1.producers.synthetic import SyntheticProducer
from pathlib import Path
cas = CAS({str(tmp_path / 'cas')!r})
h = History([Version('X','x',0,cas.put(b'[1.0]')), Version('P','p',0,cas.put(json.dumps({{'version':'v','limit':2}}).encode()))])
install_role_guard('admission', {str(tmp_path / 'oracle')!r})
try:
    SyntheticProducer().execute({{'X':'x','P':'p'}}, h, cas, Path({str(tmp_path)!r}))
    print('EXECUTED'); sys.exit(1)
except FirewallViolation:
    print('BLOCKED')
"""
    p = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
    assert p.returncode == 0 and "BLOCKED" in p.stdout, p.stdout + p.stderr


def test_RH_oracle_store_absent_before_seal(tmp_path):
    cfg = make_config(tmp_path)
    env = dict(os.environ, F1_TEST_STOP_AFTER="admission", PYTHONPATH=str(ROOT / "src"))
    p = subprocess.run([sys.executable, "-m", "f1", "full", "--config", str(cfg)], capture_output=True, text=True, env=env)
    assert p.returncode == 4, p.stdout + p.stderr
    run = tmp_path / "out" / "smoke-synthetic"
    assert (run / "raw" / "unary_admission.jsonl").exists()
    assert not (run / "oracle").exists() and not (run / "SEAL.json").exists()


# ---------------------------------------------------------------- R-I resume preserves the phase boundary
def test_RI_resume_after_oracle_crash_preserves_seal_and_separation(tmp_path):
    cfg = make_config(tmp_path)
    env = dict(os.environ, F1_TEST_ABORT_AFTER_JOBS="oracle:20", PYTHONPATH=str(ROOT / "src"))
    p = subprocess.run([sys.executable, "-m", "f1", "full", "--config", str(cfg)], capture_output=True, text=True, env=env)
    assert p.returncode != 0 and "simulated crash in oracle" in (p.stdout + p.stderr)
    run = tmp_path / "out" / "smoke-synthetic"
    seal1 = (run / "SEAL.json").read_text()
    done_before = len((run / "oracle" / "oracle_runs.jsonl").read_text().splitlines())
    assert done_before >= 20
    # tampering with sealed admission data between crash and resume must be refused
    f = run / "raw" / "repair.jsonl"
    os.chmod(f, 0o644)
    orig = f.read_bytes()
    f.write_bytes(orig + b"\n")
    p = run_f1("full", "--config", str(cfg), check=False)
    assert p.returncode != 0 and "modified after seal" in (p.stdout + p.stderr)
    f.write_bytes(orig)
    p = run_f1("full", "--config", str(cfg))
    assert "[admission] already complete" in p.stdout and "[births] already complete" in p.stdout
    assert f"{done_before} already done" in p.stdout                     # completed oracle jobs reused
    assert (run / "SEAL.json").read_text() == seal1                      # seal untouched by the resume
    assert (run / "RUN_COMPLETE.json").exists()


@pytest.fixture(scope="module")
def full_engineering_run(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("hard")
    cfg = make_config(tmp)
    run_f1("full", "--config", str(cfg))
    return tmp / "out" / "smoke-synthetic"
