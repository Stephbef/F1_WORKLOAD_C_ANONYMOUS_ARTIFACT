"""CE-A (pinning over-invalidates), CE-B (TTL falsely admits), CE-C (unary checks pass, no joint witness).
Uses the real producer execution path (hermetic subprocess) as the oracle."""
import json

import pytest

from conftest import DAY
from f1.admission.engine import AdmissionEngine
from f1.catalog.artifact import Artifact
from f1.contracts.features_generic import k0_expr
from f1.contracts.lang import Contract, Evaluator
from f1.core.gamma import Gamma
from f1.core.history import History, Version
from f1.producers.synthetic import SyntheticProducer

H = 3600.0


def setup_ce(cas, tmp_path):
    put = lambda v: cas.put(json.dumps(v, sort_keys=True).encode())
    pol = put({"version": "v1", "limit": 10.0})
    vs = [Version("X", "v0", 0, put([8.2, 9.1])), Version("X", "v1", 1 * H, put([8.7, 9.6])),
          Version("X", "v2", 2 * H, put([8.2, 11.3])), Version("P", "p1", 0, pol)]
    return History(vs)


def birth(cas, loader, h, cut, tmp_path, aid="r"):
    p = SyntheticProducer()
    res, out = p.execute(cut, h, cas, tmp_path / "sb")
    assert res.status == "ok", res.stderr_tail
    exprs = p.contracts("tier", cut, h, loader, out)
    refs = p.birth_refs(cut, h)
    cs = {"K0": Contract.build(aid, "K0", k0_expr(refs)).to_json()}
    cs.update({k: Contract.build(aid, k, e).to_json() for k, e in exprs.items()})
    t = max(h.version(i, cut[i]).ts for i in cut)
    return Artifact(aid, "test", "c", "test", p.producer_id, "tier", t, cut, {}, sorted(p.read_items), refs, out, "x", res.cpu_s, cs, {}), p


def oracle_use(p, cas, h, cut, art, tmp_path):
    res, out = p.execute(cut, h, cas, tmp_path / "osb")
    return p.equivalent("tier", p.project(out, "tier"), art.value)


def test_ce_a_pinning_overinvalidates(cas, loader, tmp_path):
    h = setup_ce(cas, tmp_path)
    r, p = birth(cas, loader, h, {"X": "v0", "P": "p1"}, tmp_path)
    eng = AdmissionEngine(h, Evaluator(loader))
    c1 = {"X": "v1", "P": "p1"}
    assert eng.kappa_raw(r, "K0", c1)[0] is False          # content pinning rejects
    assert oracle_use(p, cas, h, c1, r, tmp_path) is True   # yet the artifact is still usable
    assert eng.kappa_eff(r, "K2", c1)[0] is True            # tolerant region contract admits


def test_ce_b_ttl_falsely_admits(cas, loader, tmp_path):
    h = setup_ce(cas, tmp_path)
    r, p = birth(cas, loader, h, {"X": "v0", "P": "p1"}, tmp_path)
    eng = AdmissionEngine(h, Evaluator(loader))
    c2 = {"X": "v2", "P": "p1"}
    age = h.version("X", "v2").ts - r.birth_time
    assert age <= 24 * H                                    # TTL(24h) would admit
    assert oracle_use(p, cas, h, c2, r, tmp_path) is False  # but the artifact is no longer usable
    for cls in ("K0", "K1", "K2", "K3"):
        assert eng.kappa_eff(r, cls, c2)[0] is False        # every contract class rejects


def test_ce_c_unary_pass_no_joint_witness(cas, loader, tmp_path):
    put = lambda v: cas.put(json.dumps(v, sort_keys=True).encode())
    vs = [Version("X", "x0", 0, put([5.0])), Version("P", "w1", 0, put({"version": "v1", "limit": 10.0})),
          Version("P", "w2", 1 * H, put({"version": "v2", "limit": 10.0}))]
    h = History(vs)
    r1, p = birth(cas, loader, h, {"X": "x0", "P": "w1"}, tmp_path, "r1")
    r2, _ = birth(cas, loader, h, {"X": "x0", "P": "w2"}, tmp_path, "r2")
    eng = AdmissionEngine(h, Evaluator(loader))
    g = Gamma("g", 2 * H, {"X": {"latest": True}, "P": {"window_s": 2 * H}})
    cands = list(h.enumerate_cuts(g.allowed(h)))
    assert len(cands) == 2
    for cls in ("K0", "K2", "K3"):
        assert any(eng.kappa_eff(r1, cls, c)[0] for c in cands)  # r1 admissible somewhere in Gamma
        assert any(eng.kappa_eff(r2, cls, c)[0] for c in cands)  # r2 admissible somewhere in Gamma
        assert eng.admit([r1, r2], cls, g, "e", 2 * H)["admitted"] is False
    # ground truth agrees: no single cut where both historical outputs are what the producer would emit
    assert not any(oracle_use(p, cas, h, c, r1, tmp_path) and oracle_use(p, cas, h, c, r2, tmp_path) for c in cands)
