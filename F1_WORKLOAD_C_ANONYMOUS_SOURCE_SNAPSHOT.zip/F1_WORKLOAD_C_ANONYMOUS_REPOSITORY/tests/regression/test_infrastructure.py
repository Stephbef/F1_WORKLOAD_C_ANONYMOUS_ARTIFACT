"""T-D ledger, T-E scheduler, T-F telemetry, T-G repair fast path (R1–R4), T-H fair accounting, T-I parse cache."""
import json
import math
import os
import random
import subprocess
import sys
import time
from pathlib import Path

import pytest

from conftest import ROOT, in_set, make_artifact, put_json, random_history
from f1.admission.engine import AdmissionEngine, effective_contracts
from f1.common.loader import Loader
from f1.contracts.lang import Contract, Evaluator
from f1.core.gamma import Gamma
from f1.repair.solvers import opt_bnb, opt_bruteforce
from f1.runner.context import ResourceBudget, class_limits
from f1.statistics.metrics import repair_metrics

sys.path.insert(0, str(ROOT / "tests" / "integration"))
sys.path.insert(0, str(ROOT / "tests" / "property"))
from helpers import make_config, run_f1  # noqa: E402

SERVER = {"cpu_budget_cores": 60, "ram_budget_gb": 290, "io_budget_mb_s": 1200, "max_workers": 48,
          "classes": {"LIGHT_CPU": {"cpu": 1.0, "ram_gb": 0.6, "io_mb_s": 15}, "MEDIUM_CPU": {"cpu": 1.0, "ram_gb": 8.0, "io_mb_s": 40},
                      "HEAVY_CPU_RAM_IO": {"cpu": 4.0, "ram_gb": 14.0, "io_mb_s": 200}}}


@pytest.fixture(scope="module")
def run(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("infra")
    cfg = make_config(tmp)
    run_f1("full", "--config", str(cfg))
    return tmp, cfg, tmp / "out" / "smoke-synthetic"


# ---------------------------------------------------------------- T-D canonical ledger
def test_TD_ledger_reconciles_exactly(run):
    _, _, rd = run
    L = json.loads((rd / "statistics" / "LEDGER.json").read_text())
    assert L["assertions_passed"]
    o, a = L["oracle"], L["admission"]
    assert o["runs_total"] == o["runs_rep0"] + o["runs_replica"] + o["runs_sample"] == sum(o["runs_by_workload"].values())
    assert o["requested_instances"] == o["unique_inputs"] + o["dedup_hits"]
    assert a["solver_invocations"] + a["fast_path_events"] == a["repair_rows"] == L["populations"]["joint_events"] * 4
    assert L["births"]["requested"] == L["births"]["unique_inputs"] + L["births"]["deduplicated"]


def test_TD_ledger_detects_mismatch(run, tmp_path):
    import shutil
    from f1.common.util import F1Error
    from f1.statistics.ledger import build
    _, _, rd = run
    cp = tmp_path / "copy"
    shutil.copytree(rd, cp)
    f = cp / "oracle" / "oracle_runs.jsonl"
    os.chmod(f, 0o644)
    lines = f.read_text().splitlines()
    f.write_text("\n".join(lines[:-1]) + "\n")                # drop one oracle record: an off-by-one must be fatal
    with pytest.raises(F1Error):
        build(cp, ["synthetic"])


# ---------------------------------------------------------------- T-E resource scheduler
def test_TE_class_limits_formula():
    lim = class_limits(SERVER)
    assert lim == {"LIGHT_CPU": min(60, 483, 80, 48), "MEDIUM_CPU": min(60, 36, 30, 48), "HEAVY_CPU_RAM_IO": min(15, 20, 6, 48)}


def test_TE_budget_never_exceeded_under_random_dispatch():
    b = ResourceBudget(SERVER)
    rng = random.Random(3)
    running = []
    for _ in range(5000):
        if running and rng.random() < 0.45:
            b.release(running.pop(rng.randrange(len(running))))
        else:
            cls = rng.choice(list(SERVER["classes"]))
            if b.fits(cls):
                b.acquire(cls)
                running.append(cls)
        assert b.used["cpu"] <= 60 + 1e-9 and b.used["ram"] <= 290 + 1e-9 and b.used["io"] <= 1200 + 1e-9
        assert all(b.running[c] <= b.limits[c] for c in b.running)


def test_TE_ram_estimate_adapts_upward_only():
    b = ResourceBudget(SERVER)
    b.acquire("HEAVY_CPU_RAM_IO")
    b.release("HEAVY_CPU_RAM_IO", measured_rss_kb=int(20 * 2**20))  # 20 GB measured
    assert b.prof["HEAVY_CPU_RAM_IO"]["ram_gb"] == 24.0 and b.limits["HEAVY_CPU_RAM_IO"] == min(15, 12, 6, 48)
    b.acquire("HEAVY_CPU_RAM_IO")
    b.release("HEAVY_CPU_RAM_IO", measured_rss_kb=int(1 * 2**20))
    assert b.prof["HEAVY_CPU_RAM_IO"]["ram_gb"] == 24.0


# ---------------------------------------------------------------- T-F telemetry
def test_TF_telemetry_start_sample_flush_stop(tmp_path):
    from f1.telemetry.sampler import finalize
    (tmp_path / "telemetry_stage").write_text("births")
    p = subprocess.Popen([sys.executable, "-m", "f1.telemetry.sampler", "--run-dir", str(tmp_path), "--root-pid", str(os.getpid()),
                          "--interval", "0.3", "--size-every", "2"], env=dict(os.environ, PYTHONPATH=str(ROOT / "src")))
    time.sleep(2.0)
    p.terminate()
    p.wait(timeout=10)
    lines = (tmp_path / "raw" / "server_telemetry.jsonl").read_text().splitlines()
    assert len(lines) >= 3
    r = json.loads(lines[-1])
    for k in ("cpu_total_pct", "cpu_per_core_pct", "load", "used_gb", "available_gb", "exp_rss_gb", "disk_read_mb_s", "stage"):
        assert k in r
    assert r["stage"] == "births"
    s = finalize(tmp_path)
    assert s["samples"] == len(lines) and "births" in s["by_stage"]
    assert (tmp_path / "raw" / "server_telemetry.parquet").exists() and (tmp_path / "statistics" / "server_resource_summary.csv").exists()


def test_TF_pipeline_writes_telemetry(run):
    _, _, rd = run
    s = json.loads((rd / "statistics" / "server_resource_summary.json").read_text())
    assert s["samples"] >= 1 and (rd / "raw" / "server_telemetry.parquet").exists()


# ---------------------------------------------------------------- T-G repair fast path (R1–R4)
@pytest.mark.parametrize("seed", range(40))
def test_TG_R1_R3_fast_path_equivalent_to_solver(cas, loader, seed):
    from test_properties import random_instance
    h, g, arts = random_instance(cas, seed)
    eng = AdmissionEngine(h, Evaluator(loader))
    allowed = g.allowed(h)
    costs = [a.cost_s for a in arts]
    fps = [sorted(set().union(*[set(c.footprint) for c in effective_contracts(a, "K2")[0]])) for a in arts]
    sat = lambda i, cut: eng.kappa_eff(arts[i], "K2", cut)[0]
    rec = eng.admit(arts, "K2", g, "e", g.t)
    full = opt_bnb(h, allowed, costs, sat, fps)
    if rec["admitted"]:                                  # R1: fast path (Q = empty, cost 0) == full solver semantics
        assert full["opt_cost"] == 0 and all(sat(i, rec["witness"]) for i in range(len(arts)))
    else:                                                # R3: no witness -> the solver is needed and finds cost > 0
        assert full["opt_cost"] > 0


def test_TG_R2_R4_pipeline_solver_counts_and_resume(run):
    tmp, cfg, rd = run
    rows = [json.loads(l) for l in (rd / "raw" / "repair.jsonl").read_text().splitlines()]
    joint = {json.loads(l)["event_id"]: json.loads(l) for l in (rd / "raw" / "joint_admission.jsonl").read_text().splitlines()}
    for r in rows:
        admitted = joint[r["event_id"]][f"{r['cls']}_admitted"]
        assert r["solver_invoked"] is (not admitted)    # R2/R3
        if admitted:
            assert r["opt_cost"] == 0 and r["opt_Q"] == [] and r["solver_excl_s"] == 0.0
    before = (rd / "raw" / "repair.jsonl").read_bytes()
    run_f1("full", "--config", str(cfg))                 # R4: resume keeps fast-path results byte-identical
    assert (rd / "raw" / "repair.jsonl").read_bytes() == before


# ---------------------------------------------------------------- T-H fair accounting
def test_TH_shared_cost_cancels_symmetrically():
    base = {"cluster": "c", "scenario": "primary_async_joint", "cell": "x", "cls": "K2", "feasible": True, "recompute_all": 1.0}
    rows = [dict(base, event_id="a", opt_cost=0.2, current_cut_cost=0.5, shared_decision_s=0.30, f1_specific_s=0.05,
                 contract_eval_s=0.32, admission_excl_s=0.02, solver_excl_s=0.01),
            dict(base, event_id="b", opt_cost=0.2, current_cut_cost=0.5, shared_decision_s=0.0, f1_specific_s=0.05,
                 contract_eval_s=0.02, admission_excl_s=0.02, solver_excl_s=0.01)]
    r = repair_metrics(rows, B=20, seed=1)["primary_async_joint/x/K2"]
    assert abs(r["M5_net_fair_vs_current_cut"]["mean"] - (0.5 - 0.2 - 0.05) / 0.5) < 1e-12   # shared cost does not matter
    e = r["end_to_end_total_s"]
    assert abs(e["f1"] - (0.30 + 0.05 + 0.2 + 0.0 + 0.05 + 0.2)) < 1e-12
    assert abs(e["current_cut"] - (0.30 + 0.5 + 0.0 + 0.5)) < 1e-12
    assert abs(r["incremental_f1_minus_current_cut_s"] - (e["f1"] - e["current_cut"])) < 1e-12
    assert r["M5_net_vs_current_cut"]["mean"] < r["M5_net_fair_vs_current_cut"]["mean"]       # asymmetric view still reported


# ---------------------------------------------------------------- T-I immutable parse cache
def test_TI_cached_equals_uncached_on_random_contracts(cas):
    from test_properties import random_instance
    for seed in range(30):
        h, g, arts = random_instance(cas, seed)
        cached = AdmissionEngine(h, Evaluator(Loader(cas)))
        for cut in h.enumerate_cuts(g.allowed(h)):
            for a in arts:
                for cls in ("K0", "K2"):
                    unc = AdmissionEngine(h, Evaluator(Loader(cas, enabled=False))).kappa_eff(a, cls, cut)[0]
                    assert cached.kappa_eff(a, cls, cut)[0] == unc


def test_TI_cached_equals_uncached_on_rustsec_snapshot(tmp_path):
    from semver_cases import CASES, build
    from f1.common.util import CAS
    from f1.contracts.lang import FEATURES, ItemView
    db, lock = build(tmp_path, [c for c in CASES if c[0] not in ("ca-wild", "ca-overlap")])
    cas = CAS(tmp_path / "cas")
    files = {str(p.relative_to(db)): p.read_bytes() for p in db.rglob("*.md")}
    vref, sref = cas.put_tree(files), cas.put(lock.read_bytes())
    pk = FEATURES["lock_packages"](ItemView("S", sref, Loader(cas)))
    warm = Loader(cas)
    for _ in range(3):
        a = FEATURES["affecting_triples"](ItemView("V", vref, warm), packages=pk)
        b = FEATURES["affecting_triples"](ItemView("V", vref, Loader(cas, enabled=False)), packages=pk)
        assert a == b
    assert warm.stats["by_kind"]["rustsec-db"]["hits"] >= 2 and warm.stats["by_kind"]["rustsec-db"]["misses"] == 1


def test_TE_worker_thread_pools_are_bounded():
    import pyarrow as pa
    from f1.producers.dq import DQProducer, set_threads
    set_threads(1)
    assert pa.cpu_count() == 1
    p = DQProducer([], uses_ref=False, policy_id="t", resource_class="HEAVY_CPU_RAM_IO", threads=4)
    set_threads(p.threads)
    assert pa.cpu_count() == 4
    set_threads(1)
