import json
import math
import os
import random
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import f1.contracts.features_generic  # noqa: E402,F401
import f1.producers.dq  # noqa: E402,F401
import f1.producers.license_spdx  # noqa: E402,F401
import f1.producers.rustsec  # noqa: E402,F401
import f1.producers.synthetic  # noqa: E402,F401
from f1.catalog.artifact import Artifact  # noqa: E402
from f1.common.loader import Loader  # noqa: E402
from f1.common.util import CAS  # noqa: E402
from f1.contracts.features_generic import k0_expr  # noqa: E402
from f1.contracts.lang import Contract, feature  # noqa: E402
from f1.core.history import History, Version  # noqa: E402

DAY = 86400.0


@feature("test_value")
def _test_value(view):
    """Test-only feature: the JSON value stored in the item."""
    return json.loads(view.loader.text(view.content_ref))


@pytest.fixture
def cas(tmp_path):
    return CAS(tmp_path / "cas")


@pytest.fixture
def loader(cas):
    return Loader(cas)


def put_json(cas, v):
    return cas.put(json.dumps(v, sort_keys=True).encode())


def make_artifact(aid, h, birth_cut, read_set, contracts: dict, cost=1.0, value="v", atype="t", split="test", cluster="c0"):
    refs = {i: h.content(birth_cut, i) for i in read_set}
    cs = {"K0": Contract.build(aid, "K0", k0_expr(refs)).to_json()}
    for cls, expr in contracts.items():
        cs[cls] = Contract.build(aid, cls, expr).to_json()
    return Artifact(artifact_id=aid, workload="test", cluster=cluster, split=split, producer_id="p", artifact_type=atype,
                    birth_time=max(h.version(i, birth_cut[i]).ts for i in birth_cut), birth_cut=birth_cut,
                    birth_revs={i: birth_cut[i] for i in read_set}, read_set=sorted(read_set), birth_refs=refs,
                    value=value, value_ref="x", cost_s=cost, contracts=cs, run={"production_key": aid, "version": "t"})


def in_set(item, values):
    """kappa: value of item in a given set (expressed as or of equalities -> K2-style region)."""
    f = {"op": "feat", "item": item, "f": "test_value"}
    return {"op": "or", "args": [{"op": "eq", "a": f, "b": {"op": "const", "v": v}} for v in values]}


def random_history(cas, rng, n_items=3, max_versions=4, edge_p=0.3):
    items = [f"I{k}" for k in range(n_items)]
    vs, t = [], 0.0
    events = []
    for it in items:
        for j in range(rng.randint(1, max_versions)):
            t += rng.uniform(1, 10)
            events.append((it, f"{it}v{j}", t))
    vs = [Version(it, vid, ts, put_json(cas, f"{vid}")) for it, vid, ts in events]
    edges = []
    for a in vs:
        for b in vs:
            if a.item != b.item and a.ts < b.ts and rng.random() < edge_p / max(1, len(vs)) * 3:
                edges.append(((a.item, a.vid), (b.item, b.vid)))
    return History(vs, edges), items
