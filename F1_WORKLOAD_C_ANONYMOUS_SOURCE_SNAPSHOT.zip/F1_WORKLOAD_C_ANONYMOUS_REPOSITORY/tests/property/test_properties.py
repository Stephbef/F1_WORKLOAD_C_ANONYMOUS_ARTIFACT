"""Seeded randomized property tests (no external property-testing dependency)."""
import itertools
import math
import random

import pytest

from conftest import in_set, make_artifact, random_history
from f1.admission.engine import AdmissionEngine, effective_contracts, replay_journal
from f1.contracts.lang import Evaluator
from f1.core.gamma import Gamma
from f1.repair.solvers import ilp_available, opt_bnb, opt_bruteforce, opt_ilp

SEEDS = list(range(60))


def random_instance(cas, seed):
    rng = random.Random(seed)
    h, items = random_history(cas, rng, n_items=rng.randint(2, 4), max_versions=4)
    tmax = max(v.ts for vs in h.items.values() for v in vs)
    rules = {}
    for it in items:
        r = rng.choice(["any", "last_k", "window"])
        rules[it] = {"any": True} if r == "any" else ({"last_k": rng.randint(1, 3)} if r == "last_k" else {"window_s": rng.uniform(0, tmax)})
    g = Gamma("g", tmax + 1, rules)
    arts = []
    for k in range(rng.randint(1, 4)):
        birth = h.latest_cut(rng.uniform(0, tmax + 1))
        if birth is None or not h.is_consistent(birth):
            birth = h.latest_cut(tmax + 1)
        fp = rng.sample(items, rng.randint(1, len(items)))
        # region contract: the birth version's value plus random extra versions (always accepts birth cut)
        terms = []
        for it in fp:
            vals = {f"{birth[it]}"} | {f"{v.vid}" for v in h.items[it] if rng.random() < 0.4}
            terms.append(in_set(it, sorted(vals)))
        expr = terms[0] if len(terms) == 1 else {"op": "and", "args": terms}
        cost = rng.choice([1.0, 2.0, 5.0, math.inf]) if rng.random() < 0.15 else float(rng.randint(1, 9))
        arts.append(make_artifact(f"r{k}", h, birth, fp, {"K2": expr}, cost=cost))
    return h, g, arts


@pytest.mark.parametrize("seed", SEEDS)
def test_witness_soundness_and_birth_acceptance(cas, loader, tmp_path, seed):
    h, g, arts = random_instance(cas, seed)
    ev = Evaluator(loader)
    eng = AdmissionEngine(h, ev, journal_path=tmp_path / "j.jsonl")
    for a in arts:
        for cls in ("K0", "K2"):
            assert eng.kappa_eff(a, cls, a.birth_cut)[0], "contract must accept its birth cut"
    for cls in ("K0", "K2"):
        rec = eng.admit(arts, cls, g, event_id=f"e{seed}{cls}", t=g.t)
        if rec["admitted"]:
            w = rec["witness"]
            assert h.is_consistent(w) and g.contains(h, w)
            assert all(eng.kappa_eff(a, cls, w)[0] for a in arts)
        else:
            assert not any(all(eng.kappa_eff(a, cls, c)[0] for a in arts) for c in h.enumerate_cuts(g.allowed(h)))
    assert replay_journal(tmp_path / "j.jsonl", h, {a.artifact_id: a for a in arts}, ev)["records"] == 2


@pytest.mark.parametrize("seed", SEEDS)
def test_exact_solvers_agree_and_repair_is_admissible(cas, loader, seed):
    h, g, arts = random_instance(cas, seed)
    ev = Evaluator(loader)
    eng = AdmissionEngine(h, ev)
    allowed = g.allowed(h)
    costs = [a.cost_s for a in arts]
    fps = [sorted(set().union(*[set(c.footprint) for c in effective_contracts(a, "K2")[0]])) for a in arts]
    sat = lambda i, cut: eng.kappa_eff(arts[i], "K2", cut)[0]
    bf = opt_bruteforce(h, allowed, costs, sat)
    bb = opt_bnb(h, allowed, costs, sat, fps)
    assert bf["opt_cost"] == bb["opt_cost"]
    if ilp_available() and len(list(h.enumerate_cuts(allowed))) <= 64:
        il = opt_ilp(h, allowed, costs, sat, fps)
        assert (math.isinf(il["opt_cost"]) and math.isinf(bf["opt_cost"])) or abs(il["opt_cost"] - bf["opt_cost"]) < 1e-6
    if bb["feasible"]:
        cut = bb["opt_cut"]
        assert h.is_consistent(cut) and g.contains(h, cut)
        assert sum(costs[i] for i in bb["Q"]) == bb["opt_cost"]
        # after re-deriving Q at cut, the new artifacts' K0 accepts cut -> the repaired set admits cut
        repaired = [make_artifact(f"n{i}", h, cut, arts[i].read_set, {}, cost=costs[i]) if i in bb["Q"] else arts[i]
                    for i in range(len(arts))]
        assert all(eng.kappa_eff(a, "K2", cut)[0] for a in repaired)


@pytest.mark.parametrize("seed", SEEDS[:30])
def test_enumeration_complete_and_consistent(cas, seed):
    h, g, _ = random_instance(cas, seed)
    allowed = g.allowed(h)
    items = h.item_names()
    got = {tuple(c[i] for i in items) for c in h.enumerate_cuts(allowed)}
    want = {combo for combo in itertools.product(*[allowed[i] for i in items]) if h.is_consistent(dict(zip(items, combo)))}
    assert got == want


@pytest.mark.parametrize("seed", range(1000, 1240))
def test_solver_crosscheck_extended(cas, loader, seed):
    """Extended reference cross-check (240 further random instances): optimal cost, cut validity, repair validity."""
    h, g, arts = random_instance(cas, seed)
    eng = AdmissionEngine(h, Evaluator(loader))
    allowed = g.allowed(h)
    costs = [a.cost_s for a in arts]
    fps = [sorted(set().union(*[set(c.footprint) for c in effective_contracts(a, "K2")[0]])) for a in arts]
    sat = lambda i, cut: eng.kappa_eff(arts[i], "K2", cut)[0]
    bf, bb = opt_bruteforce(h, allowed, costs, sat), opt_bnb(h, allowed, costs, sat, fps)
    assert bf["opt_cost"] == bb["opt_cost"]
    if bb["feasible"]:
        assert h.is_consistent(bb["opt_cut"]) and g.contains(h, bb["opt_cut"])
        assert set(bb["Q"]) == {i for i in range(len(arts)) if not sat(i, bb["opt_cut"])}
    if ilp_available() and len(list(h.enumerate_cuts(allowed))) <= 64:
        il = opt_ilp(h, allowed, costs, sat, fps)
        assert (math.isinf(il["opt_cost"]) and math.isinf(bf["opt_cost"])) or abs(il["opt_cost"] - bf["opt_cost"]) < 1e-6
