# Publishing the anonymous repository

Create an empty **private** repository under an account/organization appropriate for anonymous review, then from this directory run:

```bash
git remote add origin <PRIVATE_REPOSITORY_GIT_URL>
git push -u origin main
```

Do not add names, institutional affiliations, personal email addresses, ORCID identifiers, personal profile links, or campaign credentials while anonymous review is active.

If an anonymous-review mirror service is used, configure it from the private source repository and share only the mirror URL in the submission.
