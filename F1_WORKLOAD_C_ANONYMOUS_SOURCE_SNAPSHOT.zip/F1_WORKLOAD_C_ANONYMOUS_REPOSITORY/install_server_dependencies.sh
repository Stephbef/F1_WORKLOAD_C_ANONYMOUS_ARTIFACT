#!/usr/bin/env bash
# Installs ONLY the exact frozen dependencies; detects first, verifies after; never upgrades unrelated packages.
# Root is needed only for system packages (osmium-tool 1.16.0, faketime 0.9.10) and for the cold-state cache drop.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"
PY="${PYTHON:-python3}"
need_root=()
echo "== detection"
"$PY" -c 'import sys; v=sys.version_info; sys.exit(0 if (v.major, v.minor) == (3, 12) else 1)' && echo "python 3.12: OK" || echo "python 3.12: MISSING (install from the OS vendor; not done automatically)"
for spec in "numpy==2.4.4" "PyYAML==6.0.3"; do
  mod="${spec%%==*}"; ver="${spec##*==}"; imp="$mod"; [ "$mod" = "PyYAML" ] && imp=yaml
  got="$("$PY" -c "import $imp; print($imp.__version__)" 2>/dev/null || true)"
  if [ "$got" = "$ver" ]; then echo "$spec: OK"; else
    echo "$spec: installing exact pin (user site)"; "$PY" -m pip install --user --no-deps "$spec"
    got="$("$PY" -c "import $imp; print($imp.__version__)")"; [ "$got" = "$ver" ] || { echo "FAILED: $spec"; exit 1; }
  fi
done
if command -v java >/dev/null && java -version 2>&1 | grep -q '"25.0.4.1'; then echo "OpenJDK 25.0.4.1: OK"; else
  echo "OpenJDK 25.0.4.1: MISSING — install the exact Temurin/OpenJDK 25.0.4.1 build (scripts/fetch_pinned_dependencies.sh verifies)"; fi
if command -v osmium >/dev/null && osmium --version 2>/dev/null | head -1 | grep -q "1.16.0"; then echo "osmium-tool 1.16.0: OK"; else
  need_root+=("osmium-tool 1.16.0"); fi
if command -v faketime >/dev/null; then echo "faketime: OK"; else need_root+=("faketime 0.9.10"); fi
echo "== pinned producer jars (exact SHA-256)"
bash scripts/fetch_pinned_dependencies.sh
bash scripts/verify_pinned_dependencies.sh
if [ "${#need_root[@]}" -gt 0 ]; then
  echo "== requires root / package manager (exact versions only; this script does not run them):"
  for p in "${need_root[@]}"; do echo "   - $p"; done
  if [ -f /etc/redhat-release ]; then echo "   RHEL/CentOS-compatible: install the exact versions from EPEL or vendor RPMs; do not 'dnf upgrade'."
  elif [ -f /etc/debian_version ]; then echo "   Debian/Ubuntu: apt-get install osmium-tool=1.16.0-1build1 faketime (exact versions)"
  else echo "   unsupported distribution — install exact versions manually"; exit 3; fi
  exit 4
fi
echo "ALL FROZEN DEPENDENCIES PRESENT"
